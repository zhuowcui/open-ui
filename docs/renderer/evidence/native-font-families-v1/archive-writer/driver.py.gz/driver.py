import gzip,hashlib,json
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui')
BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b')
DEST=ROOT/'docs/renderer/evidence/native-font-families-v1'
INDEX=ROOT/'docs/renderer/generated/native-font-families-v1.json'
load=lambda p:json.loads(Path(p).read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
proofs={name:load('/tmp/'+path) for name,path in [('chromium','openui-native-general-font-chromium-audit-v3831.json'),('baseline','openui-native-general-font-baseline-audit-v3834.json'),('candidate','openui-native-general-font-candidate-audit-v3837.json')]}
for key,name in [('chromium','openui-native-general-font-chromium-reaped-v3832.json'),('baseline','openui-native-general-font-baseline-reaped-v3835.json'),('candidate','openui-native-general-font-candidate-reaped-v3838.json')]:
 proof=load('/tmp/'+name);assert proof['all_local_commands_terminal'] and proof['owners_absent']
 assert proof['source']==proofs[key]['source']
assert all(p['complete'] and p['owner_absent'] for p in proofs.values())
assert proofs['chromium']['source']['clean'] and all(c['alias_pixels_equal'] and c['alias_bounds_equal'] and c['different_face_changes_pixels'] for c in proofs['chromium']['cases'])
assert proofs['baseline']['totals']==dict(images=15,exact_images=0,bounds=210,exact_bounds=165)
assert proofs['candidate']['totals']==dict(images=15,exact_images=0,bounds=210,exact_bounds=180)
assert proofs['candidate']['baseline_comparison']['worsened_images']==15 and proofs['candidate']['baseline_comparison']['bounds_exact_gains']==15 and proofs['candidate']['baseline_comparison']['bounds_exact_losses']==0
restore=load('/tmp/openui-native-general-font-restored-v3840.json');assert restore['runtime_restored_to_head'] and restore['candidate_rejected'] and not restore['candidate_applied']
for row in restore['files']:assert sha((ROOT/row['path']).read_bytes())==row['restored_sha256']
assert not DEST.exists() and not INDEX.exists();DEST.mkdir(parents=True)
members=[];excluded=[]
def add(data,name):
 p=DEST/name;compressed=not name.endswith('.png')
 if compressed:p=p.with_name(p.name+'.gz')
 p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists()
 stored=gzip.compress(data,mtime=0) if compressed else data;p.write_bytes(stored)
 assert p.read_bytes()==stored and (gzip.decompress(stored) if compressed else stored)==data
 members.append(dict(path=str(p.relative_to(ROOT)),compression='gzip' if compressed else 'none',bytes=len(stored),sha256=sha(stored),raw_bytes=len(data),raw_sha256=sha(data)))
for key,folder in [('chromium','native-general-font-chromium-v3824'),('baseline','native-general-font-baseline-v3833'),('candidate','native-general-font-candidate-v3836')]:
 parent=BASE/folder
 assert sha((parent/'receipt.json').read_bytes())==proofs[key]['receipt_sha256']
 for p in sorted(parent.rglob('*')):
  if not p.is_file():continue
  if p.name=='native_font_family_probe':
   excluded.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p.read_bytes()),reason='owned executable; exact fresh compiler provenance and hash archived'));continue
  add(p.read_bytes(),key+'/'+str(p.relative_to(parent)))
for key,folder in [('baseline','native-general-font-baseline-source-v3835'),('candidate','native-general-font-candidate-source-v3838')]:
 parent=BASE/folder
 for p in sorted(parent.rglob('*')):
  if p.is_file():add(p.read_bytes(),'measured-source/'+key+'/'+str(p.relative_to(parent)))
for name in ['openui-native-general-font-chromium-v3824.py','openui-native-general-font-chromium-audit-v3831.py','openui-native-general-font-chromium-audit-v3831.json','openui-native-general-font-chromium-reaping-v3832.py','openui-native-general-font-chromium-reaped-v3832.json','openui-native-general-font-baseline-v3833.py','openui-native-general-font-baseline-audit-v3834.py','openui-native-general-font-baseline-audit-v3834.json','openui-native-general-font-baseline-reaping-v3835.py','openui-native-general-font-baseline-reaped-v3835.json','openui-native-general-font-applied-v3836.json','openui-native-general-font-candidate-v3836.py','openui-native-general-font-candidate-audit-v3837.py','openui-native-general-font-candidate-audit-v3837.json','openui-native-general-font-candidate-reaping-v3838.py','openui-native-general-font-candidate-reaped-v3838.json','openui-native-general-font-restored-v3840.json','openui_parallel_source_identity_v3060.py']:
 add((Path('/tmp')/name).read_bytes(),'probes-and-proofs/'+name)
for name in ['native-probe-draft.json','oracle-plan.json']:
 add((BASE/'native-general-font-draft-v3822'/name).read_bytes(),'inputs/'+name)
for name in ['draft.json','candidate.patch']:
 add((BASE/'native-general-font-draft-v3823'/name).read_bytes(),'inputs/shared-candidate/'+name)
add(Path(__file__).read_bytes(),'archive-writer/driver.py')
result=dict(schema_version=1,status='native-font-api-baseline-fails-shared-candidate-rejected',diagnostic_only=True,chromium=proofs['chromium'],baseline=proofs['baseline'],candidate=proofs['candidate'],runtime_restore=restore,public_native_rust_consumer='bindings/rust/openui/examples/native_font_family_probe.rs',native_callback_count=2,process_repeats=True,unchanged_frame_repeats=True,weak_teardown=True,all_local_commands_terminal=True,all_members_hash_verified=True,pixel_target='pinned Chromium',pixel_tolerance=0,javascript_executed_by_openui=False,scripts_run_only_in_separate_chromium_reference_process=True,historical_openui_archive_is_a_pixel_target=False,full_renderer_contract_qualified=False,all_native_apis_qualified=False,release_qualified=False,pending=['same-byte font aliases must preserve pixels','shared intrinsic text width and fallback line metrics','remove named-family raster selection using resolved font data','replace existing size/phase/hinting exceptions with shared behavior','new clean full matrices and every remaining native API','physical lab and release qualification'],archive=dict(files=len(members),bytes=sum(m['bytes'] for m in members),members=members,excluded=excluded))
INDEX.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(index=str(INDEX),files=len(members),bytes=result['archive']['bytes'],candidate_rejected=True)),flush=True)
