import fcntl,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui')
OUT=Path('/mnt/d/openui-v02-qualification-d174ea0b/native-general-font-candidate-v3836')
AUDIT=Path('/tmp/openui-native-general-font-candidate-audit-v3837.json')
DEST=Path('/tmp/openui-native-general-font-candidate-reaped-v3838.json')
load=lambda p:json.loads(Path(p).read_bytes())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
r=load(OUT/'receipt.json');a=load(AUDIT)
assert r['all_commands_terminal'] and a['complete'] and a['owner_absent']
assert r['observed_exit_code']==a['actual_owner_exit_code']==int(sys.argv[1]) and int(sys.argv[2])==0
assert sha(OUT/'receipt.json')==a['receipt_sha256']
sys.path.insert(0,'/tmp')
from openui_parallel_source_identity_v3060 import identity
assert identity(ROOT)==r['source']==a['source']
assert subprocess.run(['ps','-p',str(r['owner_pid'])],capture_output=True).returncode==1
for name in ['cargo','rustc','rustfmt','pixel_compare']:
 assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
assert not DEST.exists()
p=dict(schema_version=1,source=r['source'],all_local_commands_terminal=True,owners_absent=True,actual_owner_exit_code=int(sys.argv[1]),actual_audit_exit_code=0,actual_sessions=[dict(session=int(sys.argv[4]),actual_exit_code=int(sys.argv[1]),reaped=True),dict(session=int(sys.argv[3]),actual_exit_code=0,reaped=True)],receipt_sha256=sha(OUT/'receipt.json'),audit_sha256=sha(AUDIT),totals=a['totals'],guard_results=a['guard_results'],baseline_comparison=a['baseline_comparison'],diagnostic_only=True,baseline_before_generic_fixes=False,retired_for_reexecution_after_source_or_target_mutation=True,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,javascript_executed_by_openui=False)
DEST.write_text(json.dumps(p,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(proof=str(DEST),actual_owner_exit_code=p['actual_owner_exit_code'],totals=p['totals'])),flush=True)
