import fcntl,hashlib,json,os,re,shutil,signal,subprocess,sys,time
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui')
BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b')
OUT=BASE/'native-general-font-candidate-v3836'
REF=BASE/'native-general-font-chromium-v3824'
TARGET=Path('/mnt/e/openui-v02-cargo-c73754e2/target')
sys.path[:0]=[str(ROOT),'/tmp']
from openui_parallel_source_identity_v3060 import identity
from tools.qualification.residuals import analyze_image_difference
load=lambda p:json.loads(Path(p).read_bytes())
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(2**20),b''):h.update(b)
 return h.hexdigest()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','rustfmt','pixel_compare']:
 assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
source=identity(ROOT);assert source['commit']==sys.argv[1] and not source['clean']
refproof=load('/tmp/openui-native-general-font-chromium-reaped-v3832.json')
assert refproof['all_local_commands_terminal'] and refproof['owners_absent']
reference=load(REF/'receipt.json');assert sha(REF/'receipt.json')==refproof['receipt_sha256']
baseline_reaped=load('/tmp/openui-native-general-font-baseline-reaped-v3835.json');assert baseline_reaped['all_local_commands_terminal'] and baseline_reaped['owners_absent']
assert reference['all_commands_terminal'] and reference['observed_exit_code']==0
for row in load(BASE/'native-general-font-draft-v3823/draft.json')['files']:
 assert sha(ROOT/row['path'])==row['after_sha256'],row['path']
assert not OUT.exists();OUT.mkdir()
env=dict(os.environ,CARGO_TARGET_DIR=str(TARGET),CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='4',RUST_MIN_STACK='4194304',PYTHONDONTWRITEBYTECODE='1',TMPDIR='/dev/shm')
env.pop('LD_PRELOAD',None);env.pop('LD_LIBRARY_PATH',None)
cargo=['cargo','--config',str(ROOT/'bindings/rust/.cargo/config.chromium.toml')]
r=dict(schema_version=1,diagnostic_only=True,baseline_before_generic_fixes=False,source=source,owner_pid=os.getpid(),driver_sha256=sha(__file__),reference_receipt_sha256=sha(REF/'receipt.json'),reference_reaping_sha256=sha('/tmp/openui-native-general-font-chromium-reaped-v3832.json'),steps=[],cases=[],local_artifacts=[],all_commands_terminal=False,pixel_target='pinned Chromium',pixel_tolerance=0,javascript_executed_by_openui=False,historical_openui_archive_is_a_pixel_target=False,full_renderer_contract_qualified=False,all_native_apis_qualified=False,release_qualified=False)
def save():
 p=OUT/'receipt.tmp';p.write_text(json.dumps(r,sort_keys=True,indent=2)+'\n');os.replace(p,OUT/'receipt.json')
def run(name,command,cwd=ROOT,timeout=None):
 assert identity(ROOT)==source
 print('Starting '+name,flush=True);log=OUT/(name+'.log');child=None;start=time.monotonic()
 try:
  with log.open('xb') as f:
   child=subprocess.Popen(command,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
   r['current_process']=dict(name=name,pid=child.pid);save()
   while child.poll() is None:
    for path,limit in [(ROOT,128*2**20),(OUT,10*2**30),(TARGET,10*2**30),(Path('/dev/shm'),256*2**20)]:
     assert shutil.disk_usage(path).free>=limit,'disk guard '+str(path)
    if timeout and time.monotonic()-start>timeout:raise TimeoutError(name)
    time.sleep(1)
   code=child.wait()
 finally:
  if child is not None and child.poll() is None:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=20)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
  r.pop('current_process',None)
  r['steps'].append(dict(name=name,command=command,pid=None if child is None else child.pid,actual_exit_code=None if child is None else child.returncode,log_sha256=sha(log)));save()
 assert identity(ROOT)==source
 print(json.dumps(dict(stage=name,actual_exit_code=code)),flush=True)
 return code,log
save();code=1
try:
 status,log=run('metadata',cargo+['metadata','--locked','--offline','--format-version','1'],ROOT/'bindings/rust');assert status==0
 packages={p['id'] for p in load(log)['packages'] if Path(p['manifest_path']).resolve().is_relative_to(ROOT)}
 status,_=run('clean-local-packages',cargo+['clean','--locked',*[a for p in sorted(packages) for a in ['-p',p]]],ROOT/'bindings/rust');assert status==0
 status,log=run('native-build',cargo+['build','--locked','--offline','-p','openui','--example','native_font_family_probe','--message-format=json-render-diagnostics'],ROOT/'bindings/rust');assert status==0
 for line in log.read_text().splitlines():
  try:row=json.loads(line)
  except json.JSONDecodeError:continue
  if row.get('reason')=='compiler-artifact' and row['package_id'] in packages:
   assert not row['fresh']
   assert Path(row['manifest_path']).resolve().is_relative_to(ROOT) and Path(row['target']['src_path']).resolve().is_relative_to(ROOT)
   row['sha256']={p:sha(p) for p in row['filenames']};r['local_artifacts'].append(row)
 assert any(a['target']['name']=='native_font_family_probe' for a in r['local_artifacts'])
 binary=OUT/'native_font_family_probe';shutil.copy2(TARGET/'debug/examples/native_font_family_probe',binary);r['native_binary_sha256']=sha(binary);save()
 for i,ref in enumerate(reference['cases']):
  p=ref['profile'];row=dict(profile=p,runs=[],stages={})
  for repeat in [1,2]:
   directory=OUT/f'profile-{i}'/f'native-{repeat}'
   status,_=run(f'profile-{i}-native-{repeat}',[str(binary),str(directory),str(p['width']),str(p['height']),str(p['scale']),str(ROOT/'bindings/rust/openui-text/fonts')],timeout=120);assert status==0
   row['runs'].append(dict(directory=str(directory),files={p.name:sha(p) for p in sorted(directory.iterdir())}))
   lifecycle=load(directory/'lifecycle.json');assert lifecycle['callbacks']==2 and lifecycle['weak_teardown_passed'] and not lifecycle['javascript_executed_by_openui']
  assert row['runs'][0]['files']==row['runs'][1]['files']
  for stage in ['before','alias','after']:
   native=OUT/f'profile-{i}/native-1/{stage}.png';png=REF/f'profile-{i}/chromium-1-{stage}-capture-1.png'
   assert sha(png)==ref['png_sha256'][stage]
   bounds=load(OUT/f'profile-{i}/native-1/{stage}.json');assert len(bounds)==14
   row['stages'][stage]=dict(native_png_sha256=sha(native),chromium_png_sha256=sha(png),native_bounds=bounds,chromium_bounds=ref['geometry'][stage],exact_bounds=sum(a==b for a,b in zip(bounds,ref['geometry'][stage])),bounds_count=14,analysis=analyze_image_difference(png,native))
  row['native_alias_pixels_equal']=row['runs'][0]['files']['before.png']==row['runs'][0]['files']['alias.png']
  row['native_alias_bounds_equal']=load(OUT/f'profile-{i}/native-1/before.json')==load(OUT/f'profile-{i}/native-1/alias.json')
  r['cases'].append(row);save()
  print(json.dumps(dict(profile=p,exact_bounds={k:v['exact_bounds'] for k,v in row['stages'].items()},different_pixels={k:v['analysis']['mismatched_pixels'] for k,v in row['stages'].items()},native_alias_pixels_equal=row['native_alias_pixels_equal'])),flush=True)
 r['totals']=dict(images=15,exact_images=sum(s['analysis']['mismatched_pixels']==0 for c in r['cases'] for s in c['stages'].values()),bounds=210,exact_bounds=sum(s['exact_bounds'] for c in r['cases'] for s in c['stages'].values()))
 guards_code,guards_log=run('text-layout-paint-guards',cargo+['test','--locked','--offline','-p','openui-layout','-p','openui-text','-p','openui-paint','--lib'],ROOT/'bindings/rust')
 summaries=re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored;',guards_log.read_text())
 r['guard_results']=dict(actual_exit_code=guards_code,passed=sum(int(x[0]) for x in summaries),failed=sum(int(x[1]) for x in summaries),ignored=sum(int(x[2]) for x in summaries))
 code=int(r['totals']['exact_images']!=15 or r['totals']['exact_bounds']!=210 or guards_code!=0)
except BaseException as e:
 r['failure']=repr(e);raise
finally:
 r['source_after']=identity(ROOT);r['source_unchanged']=r['source_after']==source;r['all_commands_terminal']=True;r['observed_exit_code']=code;save()
print(json.dumps(dict(complete=True,actual_exit_code=code,totals=r.get('totals'),source_unchanged=r['source_unchanged'])),flush=True)
raise SystemExit(code)
