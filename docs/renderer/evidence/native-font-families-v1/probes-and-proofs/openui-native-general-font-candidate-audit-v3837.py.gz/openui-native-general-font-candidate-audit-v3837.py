import fcntl,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui')
BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b')
OUT=BASE/'native-general-font-candidate-v3836'
REF=BASE/'native-general-font-chromium-v3824'
DEST=Path('/tmp/openui-native-general-font-candidate-audit-v3837.json')
sys.path[:0]=[str(ROOT),'/tmp']
from openui_parallel_source_identity_v3060 import identity
from tools.qualification.residuals import analyze_image_difference
load=lambda p:json.loads(Path(p).read_bytes())
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(2**20),b''):h.update(b)
 return h.hexdigest()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
r=load(OUT/'receipt.json');reference=load(REF/'receipt.json')
assert r['all_commands_terminal'] and r['source_unchanged'] and r['observed_exit_code']==int(sys.argv[1])
assert 'failure' not in r and identity(ROOT)==r['source']==r['source_after']
assert not r['baseline_before_generic_fixes'] and r['diagnostic_only'] and not r['source']['clean']
assert subprocess.run(['ps','-p',str(r['owner_pid'])],capture_output=True).returncode==1
for name in ['cargo','rustc','rustfmt','pixel_compare']:
 assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
assert sha('/tmp/openui-native-general-font-candidate-v3836.py')==r['driver_sha256']
assert sha(REF/'receipt.json')==r['reference_receipt_sha256']
assert sha('/tmp/openui-native-general-font-chromium-reaped-v3832.json')==r['reference_reaping_sha256']
for step in r['steps']:
 assert step['actual_exit_code']==0 or step['name']=='text-layout-paint-guards'
 assert sha(OUT/(step['name']+'.log'))==step['log_sha256']
 assert subprocess.run(['ps','-p',str(step['pid'])],capture_output=True).returncode==1
compiled={}
for row in r['local_artifacts']:
 assert row['reason']=='compiler-artifact' and not row['fresh']
 assert Path(row['manifest_path']).resolve().is_relative_to(ROOT) and Path(row['target']['src_path']).resolve().is_relative_to(ROOT)
 for path,digest in row['sha256'].items():
  assert sha(path)==digest;compiled[path]=digest
assert any(row['target']['name']=='native_font_family_probe' for row in r['local_artifacts'])
assert sha(OUT/'native_font_family_probe')==r['native_binary_sha256']
assert len(r['cases'])==5
images=bounds=exact_images=exact_bounds=0
for i,case in enumerate(r['cases']):
 assert case['profile']==reference['cases'][i]['profile']
 assert case['runs'][0]['files']==case['runs'][1]['files']
 for run in case['runs']:
  directory=Path(run['directory'])
  assert {p.name:sha(p) for p in directory.iterdir()}==run['files']
  lifecycle=load(directory/'lifecycle.json');assert lifecycle['callbacks']==2 and lifecycle['weak_teardown_passed'] and not lifecycle['javascript_executed_by_openui']
 for stage,row in case['stages'].items():
  native=OUT/f'profile-{i}/native-1/{stage}.png';png=REF/f'profile-{i}/chromium-1-{stage}-capture-1.png'
  assert sha(native)==row['native_png_sha256'] and sha(png)==row['chromium_png_sha256']==reference['cases'][i]['png_sha256'][stage]
  assert load(OUT/f'profile-{i}/native-1/{stage}.json')==row['native_bounds']
  assert reference['cases'][i]['geometry'][stage]==row['chromium_bounds']
  assert row['analysis']==analyze_image_difference(png,native)
  assert row['bounds_count']==14 and row['exact_bounds']==sum(a==b for a,b in zip(row['native_bounds'],row['chromium_bounds']))
  images+=1;bounds+=14;exact_images+=row['analysis']['mismatched_pixels']==0;exact_bounds+=row['exact_bounds']
assert r['totals']==dict(images=images,exact_images=exact_images,bounds=bounds,exact_bounds=exact_bounds)
assert images==15 and bounds==210
assert r['observed_exit_code']==int(exact_images!=15 or exact_bounds!=210 or r['guard_results']['actual_exit_code']!=0)
baseline=load(BASE/'native-general-font-baseline-v3833/receipt.json')
assert baseline['all_commands_terminal'] and baseline['source_unchanged']
proof=load('/tmp/openui-native-general-font-baseline-reaped-v3835.json')
assert proof['all_local_commands_terminal'] and proof['owners_absent']
assert sha(BASE/'native-general-font-baseline-v3833/receipt.json')==proof['receipt_sha256']
gains=losses=worse_images=0
for prior,now in zip(baseline['cases'],r['cases']):
 assert prior['profile']==now['profile']
 for stage in prior['stages']:
  old=prior['stages'][stage];new=now['stages'][stage]
  assert old['chromium_png_sha256']==new['chromium_png_sha256'] and old['chromium_bounds']==new['chromium_bounds']
  for before,after,expected in zip(old['native_bounds'],new['native_bounds'],new['chromium_bounds']):
   gains+=before!=expected and after==expected
   losses+=before==expected and after!=expected
  worse_images+=new['analysis']['mismatched_pixels']>old['analysis']['mismatched_pixels']
comparison=dict(bounds_exact_gains=gains,bounds_exact_losses=losses,worsened_images=worse_images,baseline_receipt_sha256=sha(BASE/'native-general-font-baseline-v3833/receipt.json'),chromium_references_unchanged=True)
assert not DEST.exists()
p=dict(schema_version=1,complete=True,actual_owner_exit_code=r['observed_exit_code'],owner_absent=True,source=r['source'],receipt_sha256=sha(OUT/'receipt.json'),driver_sha256=r['driver_sha256'],audit_driver_sha256=sha(__file__),fresh_local_compiler_records=len(r['local_artifacts']),compiled_paths_verified=len(compiled),native_binary_sha256=r['native_binary_sha256'],process_repeats=True,unchanged_frames=True,rust_callback_count=2,weak_teardown=True,totals=r['totals'],guard_results=r['guard_results'],baseline_comparison=comparison,diagnostic_only=True,baseline_before_generic_fixes=False,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,javascript_executed_by_openui=False,retired_for_reexecution_after_source_or_target_mutation=True)
DEST.write_text(json.dumps(p,sort_keys=True,indent=2)+'\n');print(json.dumps(p),flush=True)
