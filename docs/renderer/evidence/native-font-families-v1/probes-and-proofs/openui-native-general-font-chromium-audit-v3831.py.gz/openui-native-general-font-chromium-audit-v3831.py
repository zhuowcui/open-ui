import fcntl,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui')
BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b')
OUT=BASE/'native-general-font-chromium-v3824'
DRAFT=BASE/'native-general-font-draft-v3822'
DEST=Path('/tmp/openui-native-general-font-chromium-audit-v3831.json')
sys.path.insert(0,'/tmp')
from openui_parallel_source_identity_v3060 import identity
load=lambda p:json.loads(Path(p).read_bytes())
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(2**20),b''):h.update(b)
 return h.hexdigest()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
r=load(OUT/'receipt.json');plan=load(DRAFT/'oracle-plan.json')
assert r['all_commands_terminal'] and r['source_unchanged'] and r['observed_exit_code']==int(sys.argv[1])==0
assert 'failure' not in r and identity(ROOT)==r['source']==r['source_after']
assert subprocess.run(['ps','-p',str(r['owner_pid'])],capture_output=True).returncode==1
assert len(r['cases'])==5 and len(r['steps'])==10
assert sha('/tmp/openui-native-general-font-chromium-v3824.py')==r['driver_sha256']
assert sha(ROOT/'tools/accountability/run_all_pixel_comparisons.py')==r['capture_harness_sha256']
assert sha(ROOT/'chrome/linux-147.0.7727.50/chrome-linux64/chrome')==r['chromium_binary_sha256']
assert sha(DRAFT/'oracle-plan.json')==r['oracle_plan_sha256']
for name in ['cargo','rustc','rustfmt','pixel_compare']:
 assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
for step in r['steps']:
 assert subprocess.run(['ps','-p',str(step['pid'])],capture_output=True).returncode==1
for font,digest in r['fonts_sha256'].items():
 assert sha(ROOT/'bindings/rust/openui-text/fonts'/font)==digest
cases=[]
for i,row in enumerate(r['cases']):
 assert row['profile']==plan['required_profiles'][i]
 directory=OUT/f'profile-{i}'
 for stage in plan['stages']:
  assert sha(directory/('oracle-'+stage+'.html'))==plan['reference_html_sha256'][stage]
  assert load(directory/f'chromium-1-{stage}.json')==load(directory/f'chromium-2-{stage}.json')==row['geometry'][stage]
  assert len(row['geometry'][stage])==14
  for repeat in [1,2]:
   for number in [1,2]:
    assert sha(directory/f'chromium-{repeat}-{stage}-capture-{number}.png')==row['png_sha256'][stage]
 assert row['alias_pixels_equal']==(row['png_sha256']['before']==row['png_sha256']['alias'])
 assert row['alias_bounds_equal']==(row['geometry']['before']==row['geometry']['alias'])
 assert row['different_face_changes_pixels']==(row['png_sha256']['alias']!=row['png_sha256']['after'])
 cases.append({k:row[k] for k in ['profile','alias_pixels_equal','alias_bounds_equal','different_face_changes_pixels','different_face_changes_bounds']})
assert not DEST.exists()
proof=dict(schema_version=1,complete=True,actual_owner_exit_code=0,owner_absent=True,source=r['source'],source_unchanged=True,receipt_sha256=sha(OUT/'receipt.json'),driver_sha256=r['driver_sha256'],audit_driver_sha256=sha(__file__),independent_chromium_processes=10,whole_chromium_images=15,repeated_chromium_screenshots=60,bounds_records=210,cases=cases,pixel_target='pinned Chromium',pixel_tolerance=0,javascript_executed_by_openui=False,scripts_run_only_in_separate_chromium_reference_process=True,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,retired_for_reexecution_after_source_mutation=True)
DEST.write_text(json.dumps(proof,sort_keys=True,indent=2)+'\n')
print(json.dumps(proof),flush=True)
