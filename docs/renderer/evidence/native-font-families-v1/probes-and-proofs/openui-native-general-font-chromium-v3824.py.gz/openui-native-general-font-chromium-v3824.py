import base64, fcntl, hashlib, json, os, shutil, subprocess, sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui')
BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b')
DRAFT=BASE/'native-general-font-draft-v3822'
OUT=BASE/'native-general-font-chromium-v3824'
sys.path[:0]=[str(ROOT),'/tmp']
from openui_parallel_source_identity_v3060 import identity
from tools.accountability import run_all_pixel_comparisons as capture
load=lambda p:json.loads(Path(p).read_bytes())
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(2**20),b''):h.update(b)
 return h.hexdigest()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof=load('/tmp/openui-native-author-alias-renderer-reaped-v3806.json')
assert proof['all_local_commands_terminal'] and proof['owners_absent']
assert not OUT.exists()
for name in ['cargo','rustc','rustfmt','pixel_compare']:
 assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
source=identity(ROOT)
plan=load(DRAFT/'oracle-plan.json')
for font,digest in plan['fonts_sha256'].items():
 assert sha(ROOT/'bindings/rust/openui-text/fonts'/font)==digest
for stage,digest in plan['reference_html_sha256'].items():
 assert sha(DRAFT/('oracle-'+stage+'.html'))==digest
chrome=ROOT/'chrome/linux-147.0.7727.50/chrome-linux64/chrome'
env=capture.chrome_environment(str(chrome.parent),True,False)
env['TMPDIR']='/dev/shm'
version=subprocess.check_output([str(chrome),'--version'],env=env,text=True).strip()
assert version.split()[-1]=='147.0.7727.50'
OUT.mkdir()
r=dict(schema_version=1,owner_pid=os.getpid(),source=source,cases=[],steps=[],
 driver_sha256=sha(__file__),chromium_binary_sha256=sha(chrome),chromium_version=version,
 capture_harness_sha256=sha(ROOT/'tools/accountability/run_all_pixel_comparisons.py'),
 fontconfig_sha256=sha(env['FONTCONFIG_FILE']),oracle_plan_sha256=sha(DRAFT/'oracle-plan.json'),
 fonts_sha256=plan['fonts_sha256'],reference_html_sha256=plan['reference_html_sha256'],
 pixel_target='pinned Chromium',pixel_tolerance=0,javascript_executed_by_openui=False,
 scripts_run_only_in_separate_chromium_reference_process=True,
 historical_openui_archive_is_a_pixel_target=False,all_commands_terminal=False,
 full_renderer_contract_qualified=False,all_native_apis_qualified=False,release_qualified=False)
def save():
 p=OUT/'receipt.tmp';p.write_text(json.dumps(r,sort_keys=True,indent=2)+'\n');os.replace(p,OUT/'receipt.json')
READY="new Promise(resolve=>{const done=()=>document.fonts.ready.then(()=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));if(document.readyState==='complete')done();else addEventListener('load',done,{once:true});})"
QUERY="Array.from(document.querySelectorAll('[id]'),e=>{const b=e.getBoundingClientRect();return {name:e.id,bounds:{x:b.x,y:b.y,width:b.width,height:b.height}};})"
def oracle(directory,repeat,width,height,scale):
 profile=Path('/dev/shm')/f'ou3824-{directory.name}-{repeat}'
 assert not profile.exists();profile.mkdir()
 command=[str(chrome),'--headless','--disable-gpu','--no-sandbox','--no-first-run','--no-default-browser-check','--remote-debugging-port=0',f'--user-data-dir={profile}',f'--window-size={round(width*scale)},{round(height*scale)+87}','about:blank']
 child=subprocess.Popen(command,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
 client=None;values={};r['current_process']=dict(name='chromium',pid=child.pid);save()
 try:
  port=capture._wait_for_devtools_endpoint(profile,child)
  client=capture._CdpWebSocket(capture._page_websocket_url(port));client.command('Page.enable')
  client.command('Emulation.setDeviceMetricsOverride',dict(width=width,height=height,deviceScaleFactor=scale,mobile=False,screenWidth=width,screenHeight=height))
  for stage in plan['stages']:
   html=directory/('oracle-'+stage+'.html')
   client.command('Page.navigate',dict(url=html.resolve().as_uri()))
   observations=[]
   for query in [1,2]:
    answer=client.command('Runtime.evaluate',dict(expression=READY+'.then(()=>'+QUERY+')',awaitPromise=True,returnByValue=True))
    assert 'exceptionDetails' not in answer,answer
    observations.append(answer['result']['value'])
   assert observations[0]==observations[1] and len(observations[0])==14
   values[stage]=observations[0]
   (directory/f'chromium-{repeat}-{stage}.json').write_text(json.dumps(values[stage],sort_keys=True,indent=2)+'\n')
   images=[]
   for number in [1,2]:
    data=base64.b64decode(client.command('Page.captureScreenshot',dict(format='png',fromSurface=True,captureBeyondViewport=False))['data'],validate=True)
    (directory/f'chromium-{repeat}-{stage}-capture-{number}.png').write_bytes(data);images.append(data)
   assert images[0]==images[1],'Both disagreeing captures preserved'
   metrics=client.command('Runtime.evaluate',dict(expression='({width:innerWidth,height:innerHeight,dpr:devicePixelRatio})',returnByValue=True))['result']['value']
   assert capture._device_metrics_match(metrics,width,height,scale)
  return values
 finally:
  if client:client.close()
  capture._stop_chromium_process(child)
  assert child.poll() is not None
  shutil.rmtree(profile)
  r['steps'].append(dict(name=f'{directory.name}-chromium-{repeat}',pid=child.pid,actual_exit_code=child.returncode))
  r.pop('current_process',None);save()
save();code=1
try:
 for i,p in enumerate(plan['required_profiles']):
  assert identity(ROOT)==source
  for path,limit in [(ROOT,128*2**20),(OUT,10*2**30),(Path('/dev/shm'),256*2**20)]:
   assert shutil.disk_usage(path).free>=limit
  directory=OUT/f'profile-{i}';directory.mkdir()
  for stage in plan['stages']:
   shutil.copy2(DRAFT/('oracle-'+stage+'.html'),directory/('oracle-'+stage+'.html'))
  observations=[oracle(directory,n,p['width'],p['height'],p['scale']) for n in [1,2]]
  assert observations[0]==observations[1]
  digests={}
  for stage in plan['stages']:
   digests[stage]=sha(directory/f'chromium-1-{stage}-capture-1.png')
   assert digests[stage]==sha(directory/f'chromium-2-{stage}-capture-1.png')
  row=dict(profile=p,geometry=observations[0],png_sha256=digests,independent_processes_equal=True,
   alias_pixels_equal=digests['before']==digests['alias'],alias_bounds_equal=observations[0]['before']==observations[0]['alias'],
   different_face_changes_pixels=digests['alias']!=digests['after'],different_face_changes_bounds=observations[0]['alias']!=observations[0]['after'])
  r['cases'].append(row);save()
  print(json.dumps(dict(profile=p,alias_pixels_equal=row['alias_pixels_equal'],alias_bounds_equal=row['alias_bounds_equal'],different_face_changes_pixels=row['different_face_changes_pixels'])),flush=True)
 code=0
except BaseException as e:
 r['failure']=repr(e);raise
finally:
 r['source_after']=identity(ROOT);r['source_unchanged']=r['source_after']==source
 r['all_commands_terminal']=True;r['observed_exit_code']=code;save()
print(json.dumps(dict(complete=True,actual_exit_code=code,source_unchanged=r['source_unchanged'])),flush=True)
raise SystemExit(code)
