import hashlib
import io
import json
import subprocess
import sys
import zipfile
from pathlib import Path

MAIN = Path('/home/nero/code/open-ui')
PIN = '6ba3ef5841d043bdb895f7f90068c8624cbe7519'
OUT = Path('/mnt/e/openui-v02-qualification-d174ea0b/hosted-native-disabled-v3285')
assert not OUT.exists()
OUT.mkdir()
sys.path.insert(0, '/tmp')
from openui_parallel_source_identity_v3060 import identity

source = identity(MAIN)
assert source['clean'] and source['commit'] == PIN

def sha(data):
    return hashlib.sha256(data).hexdigest()

def gh(name, args):
    result = subprocess.run(['gh', *args], cwd=MAIN, capture_output=True)
    (OUT / (name + '.stdout')).write_bytes(result.stdout)
    (OUT / (name + '.stderr')).write_bytes(result.stderr)
    assert result.returncode == 0, (name, result.stderr)
    return result.stdout

runs = {}
for label, run_id in [('full-hardening', 37908223751), ('ordinary-ci', 37907783713), ('ordinary-format', 37907783761), ('ordinary-hardening', 37907783717)]:
    data = gh(label, ['run', 'view', str(run_id), '--json', 'headSha,status,conclusion,event,jobs,url'])
    run = json.loads(data)
    assert run['headSha'] == PIN and run['status'] == 'completed' and run['conclusion'] == 'success'
    if label == 'full-hardening':
        assert run['event'] == 'workflow_dispatch' and len(run['jobs']) == 7
        assert all(j['conclusion'] == 'success' for j in run['jobs'])
    elif label == 'ordinary-hardening':
        assert sum(j['conclusion'] == 'success' for j in run['jobs']) == 1
        assert sum(j['conclusion'] == 'skipped' for j in run['jobs']) == 5
    else:
        assert all(j['conclusion'] == 'success' for j in run['jobs'])
    runs[label] = run

listing = json.loads(gh('artifacts', ['api', 'repos/zhuowcui/open-ui/actions/runs/37908223751/artifacts']))
assert listing['total_count'] == 1
artifact = listing['artifacts'][0]
assert artifact['workflow_run']['head_sha'] == PIN and artifact['workflow_run']['id'] == 37908223751
assert artifact['name'] == 'native-c-cpp-window-smokes' and not artifact['expired']
blob = gh('artifact-archive', ['api', f"repos/zhuowcui/open-ui/actions/artifacts/{artifact['id']}/zip"])
assert 'sha256:' + sha(blob) == artifact['digest']
(OUT / 'native-c-cpp-window-smokes.zip').write_bytes(blob)
reports = {}
with zipfile.ZipFile(io.BytesIO(blob)) as archive:
    names = archive.namelist()
    assert sorted(names) == ['native-wayland-software.json', 'native-x11-opengl.json', 'native-x11-software.json']
    for name in names:
        data = archive.read(name)
        (OUT / name).write_bytes(data)
        report = json.loads(data)
        assert report['source_commit'] == PIN and report['source_clean'] and report['source_changes'] == []
        assert report['kind'] == 'native_c_cpp_window_functional_smoke' and report['passed']
        assert report['release_qualification'] is False
        assert report['header_sha256'] == sha((MAIN / 'include/openui.h').read_bytes())
        assert report['tool_sha256'] == sha((MAIN / 'tools/ffi/verify_native_window.py').read_bytes())
        assert len(report['consumers']) == 2
        for consumer in report['consumers']:
            assert consumer['returncode'] == 0 and not consumer['timed_out']
            assert consumer['source_sha256'] == sha((MAIN / consumer['source']).read_bytes())
        assert name == f"native-{report['protocol']}-{report['backend']}.json"
        reports[name] = dict(report=report, sha256=sha(data))
assert len({v['report']['library_sha256'] for v in reports.values()}) == 1
after = identity(MAIN)
assert after == source
result = dict(schema_version=1, source=source, source_after=after, source_unchanged=True,
              observed_exit_code=0, all_commands_terminal=True, runs=runs,
              artifact=artifact, archive_sha256=sha(blob), reports=reports,
              hosted_hardening_jobs_passed=7, virtual_window_reports_verified=3,
              hardware_lab_qualification=False, release_qualified=False,
              renderer_qualified=False, all_native_apis_qualified=False,
              javascript_executed_by_openui=False,
              probe_sha256=sha(Path(__file__).read_bytes()))
(OUT / 'receipt.json').write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
print(json.dumps(dict(observed_exit_code=0, hosted_jobs=7, virtual_window_reports=3,
                      source=PIN, hardware_lab_qualified=False)), flush=True)
