import fcntl
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

MAIN = Path('/home/nero/code/open-ui')
RAW = MAIN / 'out/renderer-evidence/native-viewport-scroll-v1'
PIN = '6ba3ef5841d043bdb895f7f90068c8624cbe7519'
NAME = 'native-disabled-groups-public-v1'
lock = open('/tmp/openui-native-cargo-raster-owner.lock', 'a+')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
for program in ['cargo', 'rustc', 'rustfmt', 'pixel_compare']:
    assert subprocess.run(['pgrep', '-x', program], capture_output=True).returncode == 1
assert subprocess.check_output(['git', '-C', str(MAIN), 'rev-parse', 'HEAD'], text=True).strip() == PIN
assert not subprocess.check_output(['git', '-C', str(MAIN), 'status', '--porcelain'])

def load(path):
    return json.loads(Path(path).read_bytes())

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

native = load(RAW / 'public-native-disabled-groups-v3264/receipt.json')
workspace = load(RAW / 'public-native-disabled-workspace-v3280/receipt.json')
renderer = load(RAW / 'public-native-disabled-renderer-v3296/receipt.json')
native_audit_path = Path('/tmp/openui-public-native-disabled-groups-completed-audit-v3265.json')
workspace_audit_path = Path('/tmp/openui-public-native-disabled-workspace-completed-audit-v3281.json')
renderer_audit_path = Path('/tmp/openui-public-native-disabled-renderer-completed-audit-v3297.json')
native_audit, workspace_audit, renderer_audit = map(load, [native_audit_path, workspace_audit_path, renderer_audit_path])
assert native['source'] == workspace['source'] == renderer['source']
assert native['source']['commit'] == PIN
assert native['observed_exit_code'] == workspace['observed_exit_code'] == 0
assert renderer['observed_exit_code'] == renderer_audit['actual_whole_exit_code']
assert renderer['stage'] == 'terminal' and renderer['source_unchanged']
assert renderer_audit['matrix_rows_verified'] == 48252 and renderer_audit['public_combined_source_nonregression']
assert workspace['workspace_tests'] == dict(passed=8618, failed=0, ignored=13)
assert len(workspace['steps']) == 20 and all(s['observed_exit_code'] == 0 for s in workspace['steps'])
files = []
for suite, receipt, audit, audit_path in [
    ('public-native-disabled-groups-v3264', native, native_audit, native_audit_path),
    ('public-native-disabled-workspace-v3280', workspace, workspace_audit, workspace_audit_path),
    ('public-native-disabled-renderer-v3296', renderer, renderer_audit, renderer_audit_path),
]:
    directory = RAW / suite
    assert receipt['all_commands_terminal']
    assert audit['receipt_sha256'] == sha(directory / 'receipt.json')
    assert subprocess.run(['ps', '-p', str(receipt['owner_pid'])], capture_output=True).returncode == 1
    files.extend([(directory / 'receipt.json', suite + '-receipt.json'), (audit_path, audit_path.name)])
    for step in receipt['steps']:
        path = directory / (step['name'] + '.log')
        assert sha(path) == step['log_sha256']
        files.append((path, suite + '-' + path.name))
build_dir = RAW / 'public-native-disabled-renderer-v3296/trial/guarded-build'
build = load(build_dir / 'receipt.json')
files.append((build_dir / 'receipt.json', 'guarded-build-receipt.json'))
for step in build['steps']:
    for stream in ['stdout', 'stderr']:
        path = build_dir / (step['name'] + '.' + stream)
        assert sha(path) == step[stream + '_sha256']
        files.append((path, 'guarded-build-' + path.name))
for suite in ['focused', 'primitive', 'full', 'expanded']:
    path = RAW / 'public-native-disabled-renderer-v3296/trial' / (suite + '-matrix') / (suite + '-summary.json')
    assert sha(path) == renderer['matrices']['trial-' + suite]['summary_sha256']
    files.append((path, suite + '-summary.json'))
border = RAW / 'public-native-disabled-renderer-v3296/native-border-app-matrix'
border_receipt = load(border / 'receipt.json')
files.append((border / 'receipt.json', 'native-border-receipt.json'))
for step in border_receipt['steps']:
    path = border / (step['name'] + '.log')
    assert sha(path) == step['log_sha256']
    files.append((path, 'native-border-' + path.name))
stopped_dir = RAW / 'public-native-disabled-workspace-v3267'
stopped = load(stopped_dir / 'receipt.json')
stopped_audit_path = Path('/tmp/openui-public-native-disabled-workspace-stopped-audit-v3278.json')
stopped_audit = load(stopped_audit_path)
assert stopped['all_commands_terminal'] and stopped['observed_exit_code'] == 1 and stopped['disk_guard_triggered']
assert stopped_audit['tests_produced_no_results'] and stopped_audit['receipt_sha256'] == sha(stopped_dir / 'receipt.json')
files.extend([(stopped_dir / 'receipt.json', 'stopped-workspace-receipt.json'), (stopped_audit_path, stopped_audit_path.name)])
for step in stopped['steps']:
    path = stopped_dir / (step['name'] + '.log')
    assert sha(path) == step['log_sha256']
    files.append((path, 'stopped-workspace-' + path.name))
hosted_dir = Path('/mnt/e/openui-v02-qualification-d174ea0b/hosted-native-disabled-v3285')
hosted = load(hosted_dir / 'receipt.json')
assert hosted['source'] == native['source'] and hosted['observed_exit_code'] == 0
assert hosted['hosted_hardening_jobs_passed'] == 7 and hosted['virtual_window_reports_verified'] == 3
for path in sorted(hosted_dir.iterdir()):
    if path.is_file():
        files.append((path, 'hosted-' + path.name))
for filename in [
    'openui-retired-cargo-cache-cleanup-v3279.json',
    'openui-public-native-disabled-groups-owner-v3264.py',
    'openui-public-native-disabled-workspace-v3280.py',
    'openui-public-native-disabled-renderer-v3296.py',
    'openui-hosted-native-disabled-collect-v3285.py',
]:
    path = Path('/tmp') / filename
    files.append((path, filename))
failed_dir=RAW/'public-native-disabled-renderer-v3282';failed=load(failed_dir/'receipt.json');failed_audit_path=Path('/tmp/openui-public-native-disabled-renderer-failed-audit-v3289.json');failed_audit=load(failed_audit_path);assert failed_audit['no_pixel_results_produced'] and failed_audit['receipt_sha256']==sha(failed_dir/'receipt.json');files.extend([(failed_dir/'receipt.json','failed-renderer-wrapper-receipt.json'),(failed_audit_path,failed_audit_path.name)]);
for step in failed['steps']:
    path=failed_dir/(step['name']+'.log');assert sha(path)==step['log_sha256'];files.append((path,'failed-renderer-wrapper-'+path.name))
files.extend([(Path('/tmp/openui-public-native-disabled-renderer-v3282.py'),'openui-public-native-disabled-renderer-v3282.py'),(Path('/tmp/openui-public-native-disabled-rounded-batch-v3295.py'),'openui-public-native-disabled-rounded-batch-v3295.py'),(Path('/tmp/openui-native-checkable-source-review-v3288.json'),'openui-native-checkable-source-review-v3288.json')])
files.append((Path(__file__), Path(__file__).name))
assert len({label for _, label in files}) == len(files)
destination = MAIN / 'docs/renderer/evidence' / NAME
index = MAIN / 'docs/renderer/generated' / (NAME + '.json')
assert not destination.exists() and not index.exists()
destination.mkdir()
evidence = []
for original, label in files:
    data = original.read_bytes()
    encoded = gzip.compress(data, compresslevel=9, mtime=0)
    path = destination / (label + '.gz')
    path.write_bytes(encoded)
    assert gzip.decompress(path.read_bytes()) == data
    evidence.append(dict(path=str(path.relative_to(MAIN)), original_path=str(original),
                         sha256=sha(path), decoded_sha256=hashlib.sha256(data).hexdigest()))
result = dict(schema_version=1, measured_public_source=native['source'], implementation_integrated=True,
              native_behavior_qualified=True, rust_exact_scenarios=88, c_exact_scenarios=88,
              cpp_exact_scenarios=88, native_repeated_process_pairs=21,
              old_109_scenarios_each_language_unchanged=True, c_state_projection_explicit=True,
              native_unit_guards=197, native_integration_guards=23, c_exports=127, c_layouts=34,
              c_consumers=24, cpp_consumers=18, previous_125_exports_and_all_layouts_preserved=True,
              workspace=workspace['workspace_tests'], headless_c_tests=workspace_audit['headless_c_tests'],
              all_20_local_stages_passed=True, native_audit=native_audit,
              workspace_audit=workspace_audit, completed_renderer_audit=renderer_audit,
              hosted_hardening_successes=7, hosted_ordinary_successes=6,
              hosted_ordinary_optional_skips=5, source_verified_virtual_window_reports=3,
              prior_workspace_stopped_by_disk_guard=True, prior_workspace_test_results_present=False,
              pixel_target='pinned Chromium', pixel_tolerance=0,
              archived_openui_images_are_history_only=True, chromium_reference_fields_unchanged=True,
              default_disabled_control_appearance_qualified=False,
              new_110_checkable_scenarios_native_qualified=False, composition_qualified=False,
              renderer_release_qualified=False, all_native_apis_qualified=False,
              hardware_and_release_lab_qualification=False, release_qualified=False,
              javascript_executed_by_openui=False, evidence=evidence)
index.write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
print(json.dumps(dict(index=str(index), files=len(files), measured_public_source=PIN,
                      renderer_actual_exit=renderer['observed_exit_code'], release_qualified=False)), flush=True)
