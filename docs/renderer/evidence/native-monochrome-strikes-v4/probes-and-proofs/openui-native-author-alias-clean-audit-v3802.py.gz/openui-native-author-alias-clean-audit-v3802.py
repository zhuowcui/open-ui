import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path

ROOT=Path('/home/nero/code/open-ui')
OUT=Path('/mnt/d/openui-v02-qualification-d174ea0b/native-author-alias-clean-checks-v3801')
TARGET=Path('/mnt/e/openui-v02-cargo-c73754e2/target')
sys.path.insert(0,'/tmp')
from openui_parallel_source_identity_v3060 import identity

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(2**20),b''):
            h.update(block)
    return h.hexdigest()

r=json.loads((OUT/'receipt.json').read_bytes())
assert r['all_commands_terminal'] and r['source_unchanged'] and r['observed_exit_code'] == int(sys.argv[1]) == 0
assert all(s['actual_exit_code'] == 0 for s in r['steps'])
assert subprocess.run(['ps','-p',str(r['owner_pid'])],capture_output=True).returncode==1
for name in ['cargo','rustc','rustfmt','pixel_compare']:
    assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
assert identity(ROOT)==r['source']==r['source_after'] and r['source']['clean']
for step in r['steps']:
    assert sha(OUT/(step['name']+'.log'))==step['log_sha256']
    values=re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored;', (OUT/(step['name']+'.log')).read_text())
    assert [sum(int(v[i]) for v in values) for i in range(3)]==[step['passed'],step['failed'],step['ignored']]
published_aliases=[]
for row in r['local_artifacts']:
    assert row['fresh'] is False
    for path,digest in row['sha256'].items():
        current=sha(path)
        if current!=digest:
            # Cargo's all-targets test build replaces the conventional example
            # launcher. Verify the separate copy used in every application run
            # against the exact original compiler artifact hash; no library or
            # arbitrary missing artifact is allowed to use this route.
            assert Path(path)==TARGET/'debug/examples/native_shaping_wrap'
            assert row['target']['kind']==['example'] and row['target']['name']=='native_shaping_wrap'
            assert sha(OUT/'native_shaping_wrap')==digest==r['native_binary_sha256']
            published_aliases.append(dict(path=path,original_sha256=digest,
                                          current_sha256=current,owned_copy=str(OUT/'native_shaping_wrap'),
                                          owned_copy_verified_against_compiler_record=True,
                                          current_alias_is_application_qualification_target=False))
        else:
            assert current==digest,path
assert len(published_aliases)<=1
assert sha(OUT/'native_shaping_wrap')==r['native_binary_sha256']
assert sha(TARGET/'debug/libopenui_ffi.so')==r['ffi_library_sha256']
for case in r['cases']:
    assert case['runs'][0]['files']==case['runs'][1]['files']
    for run in case['runs']:
        directory=Path(run['directory'])
        assert {p.name:sha(p) for p in sorted(directory.iterdir())}==run['files']
        life=json.loads((directory/'lifecycle.json').read_bytes())
        assert life['callbacks']==1 and life['weak_teardown_passed'] and not life['javascript_executed_by_openui']
steps={s['name']:s for s in r['steps']}
workspace=steps['workspace-all-targets']
docs=steps['workspace-and-docs-all-features']
assert (workspace['passed'],workspace['failed'],workspace['ignored']) == (8642,0,0)
assert (docs['passed'],docs['failed'],docs['ignored']) == (8644,0,13)
assert len(r['cases']) == 5
abi=(OUT/'abi-consumers.log').read_text()
counts=re.search(r'C ABI verified: symbols=(\d+) C_examples=(\d+) C\+\+=(\d+) ran=True',abi)
result=dict(schema_version=1,actual_unified_session=int(sys.argv[2]),actual_owner_exit_code=r['observed_exit_code'],
            all_local_commands_terminal=True,owner_absent=True,source=r['source'],
            receipt_sha256=sha(OUT/'receipt.json'),audit_driver_sha256=sha(__file__),
            native_binary_sha256=r['native_binary_sha256'],ffi_library_sha256=r['ffi_library_sha256'],
            fresh_local_records=len(r['local_artifacts']),compiled_paths=sum(len(a['sha256']) for a in r['local_artifacts']),
            mutable_cargo_example_aliases=published_aliases,live_artifact_paths_verified=sum(len(a['sha256']) for a in r['local_artifacts'])-len(published_aliases),owned_compiler_artifact_copies_verified=len(published_aliases),
            workspace_passed=workspace['passed'],workspace_failed=workspace['failed'],workspace_ignored=workspace['ignored'],
            abi_counts=None if counts is None else [int(v) for v in counts.groups()],
            stages={s['name']:s['actual_exit_code'] for s in r['steps']},
            pixel_comparisons_executed=0,profile_scope='four required profiles plus scale-3 neighbor; pixels qualified separately',workspace_docs_passed=docs['passed'],workspace_docs_ignored=docs['ignored'],
            full_renderer_contract_qualified=False,all_native_apis_qualified=False,release_qualified=False)
sys.path.insert(0,str(ROOT/'tools/qualification'))
from residuals import analyze_image_difference
reference=Path('/mnt/d/openui-v02-qualification-d174ea0b/native-shaping-wrap-candidate-chromium-v3696')
reference_receipt=json.loads((reference/'receipt.json').read_bytes())
assert reference_receipt['all_commands_terminal'] and reference_receipt['source_unchanged']
assert reference_receipt['capture_harness_sha256']==sha(ROOT/'tools/accountability/run_all_pixel_comparisons.py')
assert reference_receipt['chromium_binary_sha256']==sha(ROOT/'chrome/linux-147.0.7727.50/chrome-linux64/chrome')
measurements=[];bounds=exact_bounds=images=exact_images=0
for index,case in enumerate(r['cases']):
 directory=Path(case['runs'][0]['directory'])
 for stage in ['before','after']:
  native=json.loads((directory/(stage+'.json')).read_bytes())
  oracle=json.loads((reference/f'profile-{index}'/f'chromium-1-{stage}.json').read_bytes())
  assert len(native)==len(oracle)==7
  bounds+=len(native);exact_bounds+=sum(a==b for a,b in zip(native,oracle))
  expected=reference_receipt['cases'][index]['stages'][stage]
  png=reference/f'profile-{index}'/f'chromium-1-{stage}-capture-1.png'
  assert sha(png)==expected['chromium_png_sha256']
  analysis=analyze_image_difference(png,directory/(stage+'.png'))
  images+=1;exact_images+=analysis['mismatched_pixels']==0
  assert analysis['mismatched_pixels']==0
  measurements.append(dict(profile=index,stage=stage,bounds_exact=native==oracle,analysis=analysis,native_png_sha256=sha(directory/(stage+'.png')),chromium_png_sha256=sha(png)))
assert bounds==70 and exact_bounds==70 and images==10 and exact_images==10
result.update(native_bounds=bounds,native_exact_bounds=exact_bounds,native_images=images,native_exact_images=exact_images,measurements=measurements,pixel_comparisons_executed=images,pixel_target='pinned Chromium',pixel_tolerance=0,reference_receipt_sha256=sha(reference/'receipt.json'),reference_mode='immutable independently repeated pinned Chromium captures; reference bytes unchanged',javascript_executed_by_openui=False)
p=Path('/tmp/openui-native-author-alias-clean-terminal-v3802.json')
assert not p.exists()
p.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps(result),flush=True)
