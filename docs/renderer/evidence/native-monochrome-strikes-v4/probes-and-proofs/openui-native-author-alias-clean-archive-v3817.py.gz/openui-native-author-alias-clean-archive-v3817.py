import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path('/home/nero/code/open-ui')
BASE = Path('/mnt/d/openui-v02-qualification-d174ea0b')
DEST = ROOT / 'docs/renderer/evidence/native-monochrome-strikes-v4'
INDEX = ROOT / 'docs/renderer/generated/native-monochrome-strikes-v4.json'
load = lambda p: json.loads(Path(p).read_bytes())
sha = lambda b: hashlib.sha256(b).hexdigest()
native = load('/tmp/openui-native-author-alias-clean-terminal-v3802.json')
renderer = load('/tmp/openui-native-author-alias-renderer-completed-audit-v3805.json')
native_reaped = load('/tmp/openui-native-author-alias-clean-reaped-v3803.json')
renderer_reaped = load('/tmp/openui-native-author-alias-renderer-reaped-v3806.json')
assert native['source'] == renderer['source'] and native['source']['clean']
assert native['native_exact_images'] == 10 and native['native_exact_bounds'] == 70
assert native['actual_owner_exit_code'] == 0 and renderer['complete']
assert renderer['matrix_rows_verified'] == 48252
for record in [native_reaped, renderer_reaped]:
    assert record['all_local_commands_terminal'] and record['owners_absent']
    assert record['source'] == native['source']
hosted = load('/tmp/openui-native-author-alias-hosted-observation-v3812.json')
hosted_proof = load('/tmp/openui-native-author-alias-hosted-complete-v3813.json')
assert hosted['head_sha'] == hosted_proof['head_sha'] == native['source']['commit']
assert hosted['all_required_hosted_jobs_passed'] and hosted_proof['all_required_hosted_jobs_passed']
assert hosted_proof['raw_observation_sha256'] == sha(Path('/tmp/openui-native-author-alias-hosted-observation-v3812.json').read_bytes())
assert all(row['actual_reader_exit_code'] == 0 and row['raw']['headSha'] == native['source']['commit'] and row['raw']['status'] == 'completed' and row['raw']['conclusion'] == 'success' and all(j['status'] == 'completed' and j['conclusion'] == 'success' for j in row['raw']['jobs']) for row in hosted['rows'])
assert [len(row['raw']['jobs']) for row in hosted['rows']] == [2, 3, 7]
assert not DEST.exists() and not INDEX.exists()
DEST.mkdir(parents=True)
members = []
excluded = []

def add(data, name):
    p = DEST / name
    compressed = not name.endswith('.png')
    stored = gzip.compress(data, mtime=0) if compressed else data
    if compressed:
        p = p.with_name(p.name + '.gz')
    p.parent.mkdir(parents=True, exist_ok=True)
    assert not p.exists()
    p.write_bytes(stored)
    reread = p.read_bytes()
    assert reread == stored
    assert (gzip.decompress(reread) if compressed else reread) == data
    members.append(dict(path=str(p.relative_to(ROOT)), bytes=len(stored),
                        sha256=sha(stored), raw_bytes=len(data), raw_sha256=sha(data),
                        compression='gzip' if compressed else 'none'))

folder = BASE / 'native-author-alias-clean-checks-v3801'
for p in sorted(folder.rglob('*')):
    if not p.is_file():
        continue
    if p.name == 'native_shaping_wrap':
        excluded.append(dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p.read_bytes()),
                             reason='owned native executable; exact compiler provenance and hash preserved'))
        continue
    add(p.read_bytes(), 'native/' + str(p.relative_to(folder)))

folder = BASE / 'native-shaping-wrap-candidate-chromium-v3696'
add((folder / 'receipt.json').read_bytes(), 'immutable-reference/receipt.json')
for p in sorted(folder.glob('profile-*/*')):
    if p.is_file() and (p.name == 'test.html' or p.name.startswith('chromium-')):
        add(p.read_bytes(), 'immutable-reference/' + str(p.relative_to(folder)))

folder = BASE / 'native-author-alias-renderer-v3804'
build = load(folder / 'guarded-build/receipt.json')
assert build['renderer_library_provenance_verified'] and build['all_commands_terminal']
assert build['observed_exit_code'] == 0 and build['source'] == build['source_after'] == native['source']
assert sha((folder / 'guarded-build/receipt.json').read_bytes()) == renderer['build_receipt_sha256']
excluded.append(dict(path=build['binary'], sha256=build['binary_sha256'],
                     reason='owned renderer executable; exact compiler provenance and hash preserved'))
for p in sorted(folder.iterdir()):
    if p.is_file():
        add(p.read_bytes(), 'renderer/' + p.name)
for p in sorted((folder / 'guarded-build').iterdir()):
    if p.is_file() and p.name != 'pixel_compare':
        add(p.read_bytes(), 'renderer/guarded-build/' + p.name)
for suite in ['focused', 'primitive', 'full', 'expanded']:
    add((folder / (suite + '-matrix') / (suite + '-summary.json')).read_bytes(), 'renderer/' + suite + '-summary.json')

for name in [
    'openui-native-author-alias-clean-checks-v3801.py',
    'openui-native-author-alias-clean-audit-v3802.py',
    'openui-native-author-alias-clean-terminal-v3802.json',
    'openui-native-author-alias-clean-reaping-v3803.py',
    'openui-native-author-alias-clean-reaped-v3803.json',
    'openui-native-author-alias-renderer-v3804.py',
    'openui-native-author-alias-renderer-audit-v3805.py',
    'openui-native-author-alias-renderer-completed-audit-v3805.json',
    'openui-native-author-alias-renderer-reaping-v3806.py',
    'openui-native-author-alias-renderer-reaped-v3806.json',
    'openui-native-author-alias-hosted-observation-v3812.json',
    'openui-native-author-alias-hosted-complete-v3813.json',
    'openui-native-author-alias-pr-clean-verified-v3814.json',
    'openui-native-author-alias-checkpoint-terminal-v3815.json',
    'openui-native-author-alias-residual-inventory-v3816.py',
    'openui-native-author-alias-residual-inventory-v3816.json',
    'openui-native-author-alias-complete-recovery-v3818.py',
    'openui-native-author-alias-complete-recovery-v3818.json',
    'openui-native-font-restrictions-review-v3820.json',
    'openui-native-raster-family-review-v3821.json',
    'openui-native-font-configuration-review-v3826.json',
    'openui-native-author-alias-clean-archive-v3817.py',
    'openui_parallel_source_identity_v3060.py',
]:
    add((Path('/tmp') / name).read_bytes(), 'probes-and-proofs/' + name)

for path in ['bindings/rust/openui-paint/src/text_painter.rs',
             'bindings/rust/openui-text/src/shaping/shape_result.rs',
             'bindings/rust/openui/examples/native_shaping_wrap.rs',
             'tools/qualification/residual-ownership-v2.json']:
    add((ROOT / path).read_bytes(), 'measured-source/' + path)

result = dict(
    schema_version=4,
    status='clean-corrected-measurement-with-open-pixel-gates' if renderer['candidate_nonregression'] else 'rejected-renderer-regression-clean-corrected-measurement',
    diagnostic_only=False, source=native['source'], native=native, renderer=renderer,
    all_local_commands_terminal=True, all_members_hash_verified=True,
    pixel_target='pinned Chromium', pixel_tolerance=0,
    javascript_executed_by_openui=False, historical_openui_archive_is_a_pixel_target=False,
    full_renderer_contract_qualified=False, all_native_apis_qualified=False, release_qualified=False,
    residual_inventory=load('/tmp/openui-native-author-alias-residual-inventory-v3816.json'),
    hosted_proof=hosted_proof,
    hosted_checks=[dict(run=row['run_id'], head=row['raw']['headSha'], conclusion=row['raw']['conclusion'], url=row['raw']['url'], jobs=[dict(name=j['name'], conclusion=j['conclusion'], url=j['url']) for j in row['raw']['jobs']]) for row in hosted['rows']],
    prior_candidate_evidence='docs/renderer/generated/native-monochrome-strikes-v3.json',
    rejected_prior_clean_evidence='docs/renderer/generated/native-monochrome-strikes-v2.json',
    pending=['remaining original and expanded pixel differences',
             'reviewed residual ownership and reduced native reproducers',
             'replace 10px LCD origin/phase exceptions and named-family shaping/paint restrictions with shared behavior',
             'verify Chromium-resolved render parameters and replace font-size/family hinting branches and fixed native-button width ratio with shared behavior',
             'generic font-family shaping and remaining native APIs',
             'compositor, physical lab and release qualification'],
    archive=dict(files=len(members), bytes=sum(m['bytes'] for m in members), members=members, excluded=excluded))
INDEX.write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
print(json.dumps(dict(files=len(members), bytes=result['archive']['bytes'], index=str(INDEX))), flush=True)
