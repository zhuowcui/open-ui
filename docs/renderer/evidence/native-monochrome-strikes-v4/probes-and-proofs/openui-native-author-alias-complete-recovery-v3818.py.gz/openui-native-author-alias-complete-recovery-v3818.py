import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path('/home/nero/code/open-ui')
OUT = Path('/mnt/d/openui-v02-qualification-d174ea0b/native-author-alias-renderer-v3804')
DEST = Path('/tmp/openui-native-author-alias-complete-recovery-v3818.json')
load = lambda p: json.loads(Path(p).read_bytes())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
audit = load('/tmp/openui-native-author-alias-renderer-completed-audit-v3805.json')
receipt = load(OUT / 'receipt.json')
assert audit['complete'] and receipt['all_commands_terminal'] and audit['source'] == receipt['source']
assert audit['receipt_sha256'] == sha(OUT / 'receipt.json')
prior_index = load(ROOT / 'docs/renderer/generated/native-monochrome-strikes-v2.json')
result = dict(schema_version=1, source=audit['source'], scope='complete original and expanded censuses',
              current_audit_sha256=sha('/tmp/openui-native-author-alias-renderer-completed-audit-v3805.json'),
              prior_index_sha256=sha(ROOT / 'docs/renderer/generated/native-monochrome-strikes-v2.json'),
              pixel_target='pinned Chromium', pixel_tolerance=0, suites={},
              renderer_qualified=False, all_native_apis_qualified=False, release_qualified=False)
for suite in ['full', 'expanded']:
    current_path = OUT / (suite + '-matrix') / (suite + '-summary.json')
    assert sha(current_path) == receipt['matrices'][suite]['summary_sha256']
    current = load(current_path)
    packed_path = ROOT / ('docs/renderer/evidence/native-monochrome-strikes-v2/renderer/' + suite + '-summary.json.gz')
    member = next(m for m in prior_index['archive']['members'] if m['path'] == str(packed_path.relative_to(ROOT)))
    packed = packed_path.read_bytes(); raw = gzip.decompress(packed)
    assert hashlib.sha256(packed).hexdigest() == member['sha256']
    assert hashlib.sha256(raw).hexdigest() == member['raw_sha256']
    prior = json.loads(raw)
    baseline_path = Path(receipt['comparisons'][suite]['previous_summary'])
    assert sha(baseline_path) == receipt['comparisons'][suite]['previous_summary_sha256']
    baseline = load(baseline_path)
    key = lambda document: {(p['profile'], t['id']): t for p in document['profiles'] for t in p['tests']}
    now, before, accepted = key(current), key(prior), key(baseline)
    assert now.keys() == before.keys() == accepted.keys()
    lost = [k for k in now if accepted[k]['status'] == 'exact' and before[k]['status'] != 'exact']
    gained = [k for k in now if accepted[k]['status'] != 'exact' and before[k]['status'] == 'exact']
    worsened = [k for k in now if before[k]['mismatched_pixels'] > accepted[k]['mismatched_pixels']]
    restored = sum(now[k]['status'] == 'exact' for k in lost)
    retained = sum(now[k]['status'] == 'exact' for k in gained)
    repaired = sum(now[k]['mismatched_pixels'] <= accepted[k]['mismatched_pixels'] for k in worsened)
    assert len(lost) == prior_index['renderer']['results'][suite]['losses']
    assert len(gained) == prior_index['renderer']['results'][suite]['gains']
    assert len(worsened) == prior_index['renderer']['results'][suite]['worsened']
    fields = receipt['comparisons'][suite]['fields']
    assert all(before[k][field] == now[k][field] for k in now for field in fields if field.startswith('chromium_'))
    result['suites'][suite] = dict(total=len(now), prior_exact_losses=len(lost), restored_exact_losses=restored,
                                 prior_exact_gains=len(gained), retained_exact_gains=retained,
                                 prior_worsened_comparisons=len(worsened), repaired_worsened_comparisons=repaired,
                                 all_prior_losses_restored=restored == len(lost),
                                 all_prior_gains_retained=retained == len(gained),
                                 all_prior_worsening_repaired=repaired == len(worsened),
                                 exact=current['results']['exact'], different=current['results']['different'],
                                 errors=current['results']['errors'], chromium_reference_changed_rows=0,
                                 current_summary_sha256=sha(current_path), rejected_summary_raw_sha256=member['raw_sha256'])
assert not DEST.exists()
DEST.write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
print(json.dumps(result), flush=True)
