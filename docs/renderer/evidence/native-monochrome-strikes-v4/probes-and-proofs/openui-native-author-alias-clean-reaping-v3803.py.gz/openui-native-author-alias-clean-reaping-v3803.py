import fcntl, hashlib, json, subprocess, sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui')
OUT=Path('/mnt/d/openui-v02-qualification-d174ea0b/native-author-alias-clean-checks-v3801')
AUDIT=Path('/tmp/openui-native-author-alias-clean-terminal-v3802.json')
DEST=Path('/tmp/openui-native-author-alias-clean-reaped-v3803.json')
sys.path.insert(0,'/tmp')
from openui_parallel_source_identity_v3060 import identity
load=lambda p:json.loads(Path(p).read_bytes())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=load(OUT/'receipt.json');a=load(AUDIT)
assert int(sys.argv[1])==r['observed_exit_code']==a['actual_owner_exit_code']==0
assert int(sys.argv[2])==0
assert r['all_commands_terminal'] and a['all_local_commands_terminal'] and a['owner_absent']
assert a['source']==r['source']==r['source_after']==identity(ROOT) and r['source']['clean']
assert sha(OUT/'receipt.json')==a['receipt_sha256']
assert subprocess.run(['ps','-p',str(r['owner_pid'])],capture_output=True).returncode==1
for name in ['cargo','rustc','rustfmt','pixel_compare']:
 assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert a['native_exact_images']==10 and a['native_exact_bounds']==70
proof=dict(schema_version=1,source=r['source'],all_local_commands_terminal=True,owners_absent=True,actual_owner_exit_code=int(sys.argv[1]),actual_audit_exit_code=int(sys.argv[2]),actual_sessions=[dict(session=64093,actual_exit_code=int(sys.argv[1]),reaped=True),dict(session=int(sys.argv[3]),actual_exit_code=int(sys.argv[2]),reaped=True)],native_exact_images=a['native_exact_images'],native_exact_bounds=a['native_exact_bounds'],audit_sha256=sha(AUDIT),renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,retired_for_reexecution_after_source_or_target_mutation=True)
assert not DEST.exists();DEST.write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
