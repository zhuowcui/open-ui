import fcntl
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path('/home/nero/code/open-ui')
OUT = Path('/mnt/d/openui-v02-qualification-d174ea0b/native-resolved-raster-matrices-v3850')
AUDIT = Path('/tmp/openui-native-resolved-raster-matrices-audit-v3851.json')
DEST = Path('/tmp/openui-native-resolved-raster-matrices-reaped-v3852.json')
load = lambda p: json.loads(Path(p).read_bytes())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
r = load(OUT / 'receipt.json')
a = load(AUDIT)
assert r['all_commands_terminal'] and a['complete'] and a['owner_absent']
assert r['observed_exit_code'] == a['actual_whole_exit_code'] == int(sys.argv[1])
assert int(sys.argv[2]) == 0
assert a['source'] == r['source'] == r['source_after']
assert sha(OUT / 'receipt.json') == a['receipt_sha256']
assert subprocess.run(['ps', '-p', str(r['owner_pid'])], capture_output=True).returncode == 1
for name in ['cargo', 'rustc', 'rustfmt', 'pixel_compare']:
    assert subprocess.run(['pgrep', '-x', name], capture_output=True).returncode == 1
lock = open('/tmp/openui-native-cargo-raster-owner.lock', 'a+')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
sys.path.insert(0, '/tmp')
from openui_parallel_source_identity_v3060 import identity
assert identity(ROOT) == r['source']
assert not DEST.exists()
proof = dict(schema_version=1, source=r['source'], all_local_commands_terminal=True,
             owners_absent=True, actual_owner_exit_code=int(sys.argv[1]),
             actual_audit_exit_code=int(sys.argv[2]),
             actual_sessions=[dict(session=int(sys.argv[4]), actual_exit_code=int(sys.argv[1]), reaped=True),
                              dict(session=int(sys.argv[3]), actual_exit_code=int(sys.argv[2]), reaped=True)],
             receipt_sha256=sha(OUT / 'receipt.json'), completed_audit_sha256=sha(AUDIT),
             audit_driver_sha256=a['audit_driver_sha256'],
             results=a['results'], candidate_nonregression=a['candidate_nonregression'],
             pixel_target='pinned Chromium', pixel_tolerance=0,
             javascript_executed_by_openui=False, renderer_qualified=False,
             all_native_apis_qualified=False, release_qualified=False,
             retired_for_reexecution_after_source_or_target_mutation=True)
DEST.write_text(json.dumps(proof, sort_keys=True, indent=2) + '\n')
print(json.dumps(dict(proof=str(DEST), actual_owner_exit_code=proof['actual_owner_exit_code'],
                      matrix_rows_verified=a['matrix_rows_verified'])), flush=True)
