import fcntl
import gzip
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

ROOT = Path('/home/nero/code/open-ui')
BASE = Path('/mnt/d/openui-v02-qualification-d174ea0b')
DEST = ROOT / 'docs/renderer/evidence/native-font-families-v2'
INDEX = ROOT / 'docs/renderer/generated/native-font-families-v2.json'
load = lambda p: json.loads(Path(p).read_bytes())
sha = lambda b: hashlib.sha256(b).hexdigest()
lock = open('/tmp/openui-native-cargo-raster-owner.lock', 'a+')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
native = load('/tmp/openui-native-resolved-raster-trial-audit-v3848.json')
matrix = load('/tmp/openui-native-resolved-raster-matrices-audit-v3851.json')
for path, audit in [('/tmp/openui-native-resolved-raster-trial-reaped-v3849.json', native),
                    ('/tmp/openui-native-resolved-raster-matrices-reaped-v3852.json', matrix)]:
    proof = load(path)
    assert proof['all_local_commands_terminal'] and proof['owners_absent']
    assert proof['source'] == audit['source']
assert native['complete'] and matrix['complete'] and native['source'] == matrix['source']
assert native['baseline_comparison']['alias_pixels_equal_all_profiles']
assert native['baseline_comparison']['alias_bounds_equal_all_profiles']
assert native['guard_results'] == dict(actual_exit_code=0, passed=1181, failed=0, ignored=0)
for program in ['cargo', 'rustc', 'rustfmt', 'pixel_compare']:
    assert subprocess.run(['pgrep', '-x', program], capture_output=True).returncode == 1
sys_source = load(BASE / 'native-resolved-raster-source-v3846/source.json')
for row in sys_source['files']:
    for phase in ['before', 'after']:
        assert sha(Path(row[phase]).read_bytes()) == row[phase + '_sha256']
    assert sha((ROOT / row['path']).read_bytes()) == row['after_sha256']
assert not DEST.exists() and not INDEX.exists()
assert shutil.disk_usage(ROOT).free > 192 * 2**20
DEST.mkdir(parents=True)
members = []
excluded = []

def add(data, name):
    path = DEST / name
    compressed = not name.endswith('.png')
    if compressed:
        path = path.with_name(path.name + '.gz')
    path.parent.mkdir(parents=True, exist_ok=True)
    assert not path.exists()
    stored = gzip.compress(data, mtime=0) if compressed else data
    assert shutil.disk_usage(ROOT).free - len(stored) > 128 * 2**20
    path.write_bytes(stored)
    assert path.read_bytes() == stored
    assert (gzip.decompress(stored) if compressed else stored) == data
    members.append(dict(path=str(path.relative_to(ROOT)), compression='gzip' if compressed else 'none',
                        bytes=len(stored), sha256=sha(stored), raw_bytes=len(data), raw_sha256=sha(data)))

for label, folder, audit in [('native', 'native-resolved-raster-trial-v3847', native),
                             ('matrices', 'native-resolved-raster-matrices-v3850', matrix)]:
    parent = BASE / folder
    assert sha((parent / 'receipt.json').read_bytes()) == audit['receipt_sha256']
    paths = list(parent.rglob('*')) if label == 'native' else (
        list(parent.iterdir()) + list((parent / 'guarded-build').rglob('*')) +
        [parent / (suite + '-matrix') / (suite + '-summary.json') for suite in ['focused', 'primitive']])
    for path in sorted(paths):
        if not path.is_file():
            continue
        if path.name == 'native_font_family_probe':
            excluded.append(dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path.read_bytes()),
                                 reason='owned executable; fresh compiler provenance and hash archived'))
            continue
        add(path.read_bytes(), label + '/' + str(path.relative_to(parent)))
    if label == 'matrices':
        excluded.append(dict(path=str(parent),
                             reason='matrix capture PNGs and temporary HTML remain in the qualification directory; complete summaries, audited decoded-image hashes, immutable input identities and all raw build/matrix logs are archived'))
parent = BASE / 'native-resolved-raster-source-v3846'
for path in sorted(parent.rglob('*')):
    if path.is_file():
        add(path.read_bytes(), 'measured-source/' + str(path.relative_to(parent)))
for name in ['openui-native-resolved-raster-trial-v3847.py',
             'openui-native-resolved-raster-trial-audit-v3848.py',
             'openui-native-resolved-raster-trial-audit-v3848.json',
             'openui-native-resolved-raster-trial-reaping-v3849.py',
             'openui-native-resolved-raster-trial-reaped-v3849.json',
             'openui-native-resolved-raster-matrices-v3850.py',
             'openui-native-resolved-raster-matrices-audit-v3851.py',
             'openui-native-resolved-raster-matrices-audit-v3851.json',
             'openui-native-resolved-raster-matrices-reaping-v3852.py',
             'openui-native-resolved-raster-matrices-reaped-v3852.json',
             'openui_parallel_source_identity_v3060.py']:
    add((Path('/tmp') / name).read_bytes(), 'probes-and-proofs/' + name)
previous_index = ROOT / 'docs/renderer/generated/native-font-families-v1.json'
previous = load(previous_index)
assert previous['all_members_hash_verified'] and previous['candidate']['baseline_comparison']['worsened_images'] == 15
research = load(BASE / 'chromium-font-source-review-v3856.json')
assert not research['runtime_changes_applied_from_this_review']
assert not research['chromium_internal_strike_preferences_captured']
for group in research['official_sources']:
    parent = Path(group['directory'])
    assert sha((parent / 'receipt.json').read_bytes()) == group['receipt_sha256']
    for row in group['sources']:
        if row.get('success'):
            assert sha((parent / row['path']).read_bytes()) == row['sha256']
    for path in sorted(parent.rglob('*')):
        if path.is_file():
            add(path.read_bytes(), 'pinned-chromium-source/' + parent.name + '/' + str(path.relative_to(parent)))
add((BASE / 'chromium-font-source-review-v3856.json').read_bytes(), 'pinned-chromium-source/review.json')
prior_hosted = load(BASE / 'native-resolved-raster-prior-hosted-v3860/receipt.json')
assert prior_hosted['all_readers_terminal'] and prior_hosted['previous_clean_checkpoint_only']
assert not prior_hosted['current_dirty_candidate_qualified']
for path in sorted((BASE / 'native-resolved-raster-prior-hosted-v3860').iterdir()):
    if path.is_file():
        add(path.read_bytes(), 'prior-checkpoint-hosted/' + path.name)
add(Path(__file__).read_bytes(), 'archive-writer/driver.py')
result = dict(schema_version=1,
    status='resolved-font-raster-candidate-awaits-clean-complete-qualification',
    diagnostic_only=True, native=native, matrices=matrix,
    source_preparation=sys_source,
    actual_scope='two runtime files: select ordinary author raster policy independently from each resolved font',
    intrinsic_or_shaping_changes_applied=False,
    legacy_baseline_before_generic_fixes_field_is_not_a_source_scope_claim=True,
    previous_evidence=dict(path=str(previous_index.relative_to(ROOT)), sha256=sha(previous_index.read_bytes())),
    pinned_chromium_source_review=research,
    prior_checkpoint_hosted=prior_hosted,
    public_native_rust_consumer='bindings/rust/openui/examples/native_font_family_probe.rs',
    native_callback_count=2, process_repeats=True, unchanged_frame_repeats=True, weak_teardown=True,
    all_local_commands_terminal=True, all_members_hash_verified=True,
    pixel_target='pinned Chromium', pixel_tolerance=0, javascript_executed_by_openui=False,
    scripts_run_only_in_separate_chromium_reference_process=True,
    historical_openui_archive_is_a_pixel_target=False,
    full_renderer_contract_qualified=False, all_native_apis_qualified=False, release_qualified=False,
    pending=['clean original and expanded censuses with no exact losses or worsened differences',
             'clean native application, complete workspace, ABI and hosted checks on the new checkpoint',
             'all 15 native font-family images remain different; four worsen against baseline',
             'shared intrinsic text widths, consecutive floats and fallback line height',
             'replace remaining named-family, size, phase and hinting exceptions with shared behavior',
             'every remaining native API, physical lab and release qualification'],
    archive=dict(files=len(members), bytes=sum(row['bytes'] for row in members), members=members, excluded=excluded))
INDEX.write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
print(json.dumps(dict(index=str(INDEX), files=len(members), bytes=result['archive']['bytes'],
                      matrix_nonregression=matrix['candidate_nonregression'],
                      full_renderer_contract_qualified=False)), flush=True)
