import gzip
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path('/home/nero/code/open-ui')
INDEX = ROOT / 'docs/renderer/generated/native-font-families-v2.json'
assert int(sys.argv[1]) == 0
r = json.loads(INDEX.read_bytes())
assert 'archive_writer_terminal' not in r
for program in ['cargo', 'rustc', 'rustfmt', 'pixel_compare']:
    assert subprocess.run(['pgrep', '-x', program], capture_output=True).returncode == 1
sha = lambda data: hashlib.sha256(data).hexdigest()
for row in r['archive']['members']:
    stored = (ROOT / row['path']).read_bytes()
    raw = gzip.decompress(stored) if row['compression'] == 'gzip' else stored
    assert len(stored) == row['bytes'] and sha(stored) == row['sha256']
    assert len(raw) == row['raw_bytes'] and sha(raw) == row['raw_sha256']
initial_archive = dict(files=r['archive']['files'], bytes=r['archive']['bytes'])
binary_members = [row for row in r['archive']['members']
                  if row['path'].endswith('/matrices/guarded-build/pixel_compare.gz')]
assert len(binary_members) == 1
binary_row = binary_members[0]
build_receipt_path = Path('/mnt/d/openui-v02-qualification-d174ea0b/native-resolved-raster-matrices-v3850/guarded-build/receipt.json')
build_receipt = json.loads(build_receipt_path.read_bytes())
assert sha(build_receipt_path.read_bytes()) == r['matrices']['build_receipt_sha256']
assert binary_row['raw_sha256'] == build_receipt['binary_sha256']
# Keep the immutable owned executable in the qualification directory. Its
# exact hash and fresh linked-library provenance are already archived.
r['archive']['members'].remove(binary_row)
r['archive']['excluded'].append(dict(path=build_receipt['binary'],
                                    bytes=binary_row['raw_bytes'], sha256=binary_row['raw_sha256'],
                                    reason='owned renderer executable; archived build receipt, fresh compiler records and verified binary hash identify the retained qualification executable'))
(ROOT / binary_row['path']).unlink()
terminal = dict(schema_version=1, actual_exit_code=int(sys.argv[1]), reaped=True,
                session=None if sys.argv[2] == 'none' else int(sys.argv[2]),
                archive_writer_sha256=sha(Path('/tmp/openui-native-resolved-raster-archive-v3857.py').read_bytes()),
                index_before_terminal_sha256=sha(INDEX.read_bytes()),
                actual_archive_writer_initial_result=initial_archive,
                verified_duplicate_owned_executable_omitted=binary_row,
                all_existing_stored_and_raw_hashes_verified=True,
                verification_driver_sha256=sha(Path(__file__).read_bytes()))
path = ROOT / 'docs/renderer/evidence/native-font-families-v2/archive-writer/terminal.json.gz'
assert not path.exists()
raw = (json.dumps(terminal, sort_keys=True, indent=2) + '\n').encode()
stored = gzip.compress(raw, mtime=0)
path.write_bytes(stored)
assert gzip.decompress(path.read_bytes()) == raw
r['archive']['members'].append(dict(path=str(path.relative_to(ROOT)), compression='gzip',
                                   bytes=len(stored), sha256=sha(stored), raw_bytes=len(raw), raw_sha256=sha(raw)))
r['archive']['files'] = len(r['archive']['members'])
r['archive']['bytes'] = sum(row['bytes'] for row in r['archive']['members'])
r['archive_writer_terminal'] = terminal
INDEX.write_text(json.dumps(r, sort_keys=True, indent=2) + '\n')
print(json.dumps(dict(files=r['archive']['files'], bytes=r['archive']['bytes'],
                      archive_writer_actual_exit_code=terminal['actual_exit_code'],
                      all_members_verified=True)), flush=True)
