import hashlib
import json
from pathlib import Path

ROOT = Path('/home/nero/code/open-ui')
INDEX = ROOT / 'docs/renderer/generated/native-font-families-v2.json'
r = json.loads(INDEX.read_bytes())
assert r['all_local_commands_terminal'] and r['all_members_hash_verified']
assert r['matrices']['candidate_nonregression']
assert r['matrices']['results']['focused']['exact'] == 640
assert r['matrices']['results']['primitive']['exact'] == 960
assert all(row['changed_rows'] == 0 for row in r['matrices']['results'].values())
assert r['native']['baseline_comparison']['worsened_images'] == 4
assert r['native']['totals'] == dict(images=15, exact_images=0, bounds=210, exact_bounds=165)
assert not r['full_renderer_contract_qualified'] and not r['all_native_apis_qualified']

paragraph = '''### Resolved font raster selection (candidate, complete qualification pending)

Ordinary author text now selects its raster policy from each resolved font
run, replacing the rule based on the first authored family name. Aliased,
grayscale and LCD runs retain their own edging when mixed in one text blob.
The two-file change adds no font-name, size, scale or test-ID exception.

The public Rust font-family consumer now preserves both pixels and bounds
when the same font bytes are registered under another name, at all four
required profiles and a 3× neighbor. Different font bytes still change pixels
at all five profiles. Both native Rust callbacks, process/frame repeats and
weak teardown pass. All **1,181 layout/text/paint tests** pass with no failures
or ignores. Fresh focused **640/640** and primitive **960/960** comparisons
are exact, with all 1,600 native images and Chromium references unchanged.

The font-family consumer remains **0/15 whole images and 165/210 bounds exact**;
four images worsen against its baseline. Intrinsic width, consecutive floats,
fallback line height and other raster differences remain open. These are
dirty-source diagnostics. Clean original/expanded censuses, complete workspace,
ABI and hosted checks on this candidate remain pending. The earlier clean
`ccb2dfa9` census below is not a measurement of this candidate. No renderer,
complete native API or release qualification is claimed.
[Immutable candidate evidence](LINK).

'''
changes = []
for name, anchor, link in [
    ('README.md', '## Verified status\n\n', 'docs/renderer/generated/native-font-families-v2.json'),
    ('docs/progress/current-status.md', '## Current implementation checkpoint\n\n', '../renderer/generated/native-font-families-v2.json'),
    ('docs/renderer/contract.md', '## Native font family API probe (failures remain)\n', 'generated/native-font-families-v2.json')]:
    p = ROOT / name
    before = p.read_bytes()
    text = before.decode()
    block = paragraph.replace('LINK', link)
    assert paragraph.splitlines()[0] not in text and text.count(anchor) == 1
    if name == 'docs/renderer/contract.md':
        block = block.replace('### Resolved', '## Resolved', 1)
        text = text.replace(anchor, block + anchor, 1)
    else:
        text = text.replace(anchor, anchor + block, 1)
    p.write_text(text)
    changes.append(dict(path=name, before_sha256=hashlib.sha256(before).hexdigest(),
                        after_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
p = ROOT / 'docs/v02/unsupported-features.md'
before = p.read_bytes()
text = before.decode()
anchor = '- clean `ccb2dfa9` matches all ten measured native shaping images and 70\n'
assert text.count(anchor) == 1
text = text.replace(anchor, '''- a shared candidate removes first-authored-family raster selection and
  preserves pixels/bounds under same-byte font aliases at five profiles. Its
  1,181 layout/text/paint tests and 640/960 raster matrices pass, with all 1,600
  raster comparisons unchanged. Native font-family images remain 0/15 exact,
  bounds remain 165/210 exact, and four images worsen from baseline. Clean
  full censuses, workspace, ABI and hosted checks remain pending; no complete
  renderer or native API qualification is claimed.
  [Candidate evidence](../renderer/generated/native-font-families-v2.json);
''' + anchor, 1)
p.write_text(text)
changes.append(dict(path=str(p.relative_to(ROOT)), before_sha256=hashlib.sha256(before).hexdigest(),
                    after_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
proof = Path('/tmp/openui-native-resolved-raster-docs-v3858.json')
assert not proof.exists()
proof.write_text(json.dumps(dict(schema_version=1, evidence_sha256=hashlib.sha256(INDEX.read_bytes()).hexdigest(),
                                 files=changes, qualification_claimed=False), sort_keys=True, indent=2) + '\n')
print(json.dumps(dict(documents_updated=len(changes), qualification_claimed=False)), flush=True)
