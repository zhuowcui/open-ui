import gzip
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/home/nero/code/open-ui')
INDEX = ROOT / 'docs/renderer/generated/native-font-families-v2.json'
DEST = ROOT / 'docs/renderer/evidence/native-font-families-v2'
CHECKS = Path('/mnt/d/openui-v02-qualification-d174ea0b/native-resolved-raster-checks-v3861')
sha = lambda b: hashlib.sha256(b).hexdigest()
load = lambda p: json.loads(Path(p).read_bytes())
r = load(INDEX)
assert 'checkpoint_read_only_checks' not in r
assert r['archive_writer_terminal']['actual_exit_code'] == 0
for program in ['cargo', 'rustc', 'rustfmt', 'pixel_compare']:
    assert subprocess.run(['pgrep', '-x', program], capture_output=True).returncode == 1
for row in r['source_preparation']['files']:
    assert sha((ROOT / row['path']).read_bytes()) == row['after_sha256']
records = []

def add(data, name):
    p = DEST / (name + '.gz')
    p.parent.mkdir(parents=True, exist_ok=True)
    assert not p.exists()
    stored = gzip.compress(data, mtime=0)
    p.write_bytes(stored)
    assert gzip.decompress(p.read_bytes()) == data
    r['archive']['members'].append(dict(path=str(p.relative_to(ROOT)), compression='gzip',
                                      bytes=len(stored), sha256=sha(stored), raw_bytes=len(data), raw_sha256=sha(data)))

for name in ['ffi', 'style', 'renderer', 'release', 'accountability', 'whitespace']:
    step = load(CHECKS / (name + '.json'))
    assert step['actual_exit_code'] == 0 and step['reaped']
    for suffix in ['json', 'stdout', 'stderr']:
        path = CHECKS / (name + '.' + suffix)
        data = path.read_bytes()
        add(data, 'checkpoint-checks/' + path.name)
        step[suffix + '_sha256'] = sha(data)
    records.append(step)
for name in ['openui-native-resolved-raster-docs-v3858.py', 'openui-native-resolved-raster-docs-v3858.json',
             'openui-native-resolved-raster-archive-terminal-v3859.py']:
    add((Path('/tmp') / name).read_bytes(), 'checkpoint-checks/' + name)
add(Path(__file__).read_bytes(), 'checkpoint-checks/evidence-writer.py')
r['checkpoint_read_only_checks'] = dict(steps=records, all_actual_exit_codes_zero=True,
                                       all_children_reaped=True, accountability_session=23440,
                                       archive_writer_session=31700, archive_terminal_writer_session=62275,
                                       scope='read-only generators, repository accountability and whitespace; not full workspace/ABI/hosted qualification')
r['source_preparation_is_pretest_receipt'] = True
r['candidate_executed_and_audited'] = True
r['archive']['files'] = len(r['archive']['members'])
r['archive']['bytes'] = sum(row['bytes'] for row in r['archive']['members'])
for row in r['archive']['members']:
    stored = (ROOT / row['path']).read_bytes()
    raw = gzip.decompress(stored) if row['compression'] == 'gzip' else stored
    assert sha(stored) == row['sha256'] and len(stored) == row['bytes']
    assert sha(raw) == row['raw_sha256'] and len(raw) == row['raw_bytes']
INDEX.write_text(json.dumps(r, sort_keys=True, indent=2) + '\n')
print(json.dumps(dict(files=r['archive']['files'], bytes=r['archive']['bytes'], all_members_verified=True,
                      read_only_checks_passed=len(records), full_qualification_claimed=False)), flush=True)
