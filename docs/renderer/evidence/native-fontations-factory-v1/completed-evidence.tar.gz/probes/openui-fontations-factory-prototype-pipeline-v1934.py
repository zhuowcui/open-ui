"""Own dependency resolution, clean committed native factory compilation and probes."""
import fcntl,hashlib,json,os,shutil,signal,subprocess,time
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');ROOT=Path('/dev/shm/openui-fontations-factory-prototype-v1933');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';NAME='native-fontations-factory-prototype-v1934'
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for program in ['cargo','rustc','pixel_compare','native_glyph_coverage']:assert subprocess.run(['pgrep','-x',program],capture_output=True).returncode==1
OUT=RAW/NAME;STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/NAME;assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
TMP=STORE/'compiler-tmp';TMP.mkdir()
env=dict(os.environ,CARGO_TARGET_DIR='/mnt/e/openui-v02-cargo-c73754e2/target',CARGO_INCREMENTAL='0',RUST_MIN_STACK='4194304',CARGO_BUILD_JOBS='4',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(TMP),CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',OPENUI_PINNED_SKIA_INCLUDE='/home/nero/.cargo/git/checkouts/rust-skia-b4d79b6a888cdb4c/a31b86b/skia-bindings/skia')
base=['cargo','--config',str(MAIN/'bindings/rust/.cargo/config.chromium.toml')]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=dict(schema_version=1,all_commands_terminal=False,owner_pid=os.getpid(),whole_pipeline_lock_covers_all_stages_and_gaps=True,release_qualification=False,prototype_not_engine_application=True,renderer_matrices_not_run=True,javascript_executed_by_openui=False,skia_pin_unchanged='a31b86ba3b767344d39af3b8c30043003d8fc991',steps=[],probe_sha256=sha(Path(__file__)))
save=lambda:(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
save()
def run(name,command):
 log=OUT/(name+'.log')
 with log.open('xb') as stream:
  child=subprocess.Popen(command,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True);report['current_process']=dict(pid=child.pid,stage=name);save();guard=False
  while child.poll() is None:
   if shutil.disk_usage(MAIN).free<512*2**20 or shutil.disk_usage(STORE).free<10*2**30:
    guard=True;os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=20);break
   time.sleep(1)
  child.wait()
 report.pop('current_process');report['steps'].append(dict(name=name,actual_exit_code=child.returncode,log_sha256=sha(log),disk_guard_triggered=guard));save();print(json.dumps(dict(stage=name,actual_exit=child.returncode)),flush=True)
 assert child.returncode==0 and not guard,'factory prototype stage failed'
try:
 run('resolve-lockfile',base+['generate-lockfile'])
 run('format',['bash','-c','ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true build.rs src/ports/fontations/src/factory.rs examples/factory_probe.rs'])
 subprocess.run(['git','add','.'],cwd=ROOT,check=True,capture_output=True);subprocess.run(['git','commit','-m','Build the existing pinned Skia Fontations factory through owned wrappers'],cwd=ROOT,check=True,capture_output=True)
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
 report['source']=dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=ROOT,text=True).strip(),clean=True,lockfile_sha256=sha(ROOT/'Cargo.lock'));save()
 run('factory-build',base+['build','--locked','--example','factory_probe'])
 binary=OUT/'factory_probe';shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/examples/factory_probe',binary);report['binary_sha256']=sha(binary);save()
 for family,name in [('Ahem','Ahem.ttf'),('DejaVu-Sans','DejaVuSans.ttf')]:
  font=MAIN/'bindings/rust/openui-text/fonts'/name;assert font.exists();run('probe-'+family,[str(binary),str(font)])
 report['observed_exit_code']=0
except BaseException as error:
 report.update(observed_exit_code=1,failure=str(error));raise
finally:
 report['all_commands_terminal']=True
 if 'source' in report:
  report['source_after']=dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=ROOT,text=True).strip(),clean=not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT),lockfile_sha256=sha(ROOT/'Cargo.lock'));assert report['source']==report['source_after']
 save()
