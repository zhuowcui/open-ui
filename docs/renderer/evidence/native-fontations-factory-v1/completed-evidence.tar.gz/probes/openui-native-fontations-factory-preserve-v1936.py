"""Preserve terminal factory experiments and exact standalone source bytes."""
import hashlib,json,subprocess,tarfile
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1'
DEST=MAIN/'docs/renderer/evidence/native-fontations-factory-v1';INDEX=MAIN/'docs/renderer/generated/native-fontations-factory-v1.json'
assert not DEST.exists() and not INDEX.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
names=['native-fontations-factory-prototype-v1920','native-fontations-factory-prototype-v1922','native-fontations-factory-prototype-v1927','native-fontations-factory-prototype-v1930','native-fontations-factory-prototype-v1932','native-fontations-factory-prototype-v1934']
receipts={name:read(RAW/name/'receipt.json') for name in names}
assert all(r['all_commands_terminal'] for r in receipts.values())
final=receipts[names[-1]];assert final['observed_exit_code']==0 and final['source']==final['source_after'] and final['source']['clean']
assert len(final['steps'])==5 and all(s['actual_exit_code']==0 for s in final['steps'])
assert all(receipts[n]['observed_exit_code']==1 for n in names[:-1])
hosted=read(RAW/'native-fontations-umbrella-hosted-v1928/receipt.json');assert hosted['all_commands_terminal'] and hosted['source']=='9f0d22112136bc8b5325d0b0619031bdd8b9adcf' and hosted['failed_jobs']==0
sources={}
for name in names+['native-fontations-umbrella-hosted-v1928']:
 for p in sorted((RAW/name).iterdir()):
  if p.is_file() and p.suffix in ['.json','.log']:sources[str(p.relative_to(RAW))]=p
for root in ['v1918','v1919','v1921','v1924','v1926','v1929','v1931','v1933']:
 base=Path('/dev/shm/openui-fontations-factory-prototype-'+root)
 assert base.exists()
 for p in sorted(base.rglob('*')):
  rel=p.relative_to(base)
  if '.git' not in rel.parts and p.is_file():sources['standalone-source/'+root+'/'+str(rel)]=p
for pattern in ['openui-fontations-factory-prototype-*.py','openui-fontations-factory-prototype-*.json','openui-fontations-upstream-source-comparison-v1923.json','openui-native-fontations-umbrella-hosted-collect-v1928.py']:
 for p in sorted(Path('/tmp').glob(pattern)):sources['probes/'+p.name]=p
sources['probes/'+Path(__file__).name]=Path(__file__)
skia=Path('/home/nero/.cargo/git/checkouts/rust-skia-b4d79b6a888cdb4c/a31b86b/skia-bindings/skia')
for rel in ['include/ports/SkTypeface_fontations.h','src/core/SkFontDescriptor.h','src/ports/SkTypeface_fontations.cpp','src/ports/fontations/src/base.rs','src/ports/fontations/src/hinting.rs','src/ports/fontations/src/ffi.rs']:
 sources['pinned-skia-source/'+rel]=skia/rel
for rel in ['src/ports/SkTypeface_fontations.cpp','src/ports/fontations/src/base.rs','src/ports/fontations/src/hinting.rs','src/ports/fontations/src/ffi.rs']:
 sources['reviewed-chromium-skia-source/'+rel]=Path('/home/nero/chromium/src/third_party/skia')/rel
for rel in ['wrapper.rs','core/font_arguments.rs']:
 sources['pinned-skia-safe/'+rel]=skia.parent.parent/'skia-safe/src'/rel
comparison=read(Path('/tmp/openui-fontations-upstream-source-comparison-v1923.json'));assert all(row['same_bytes'] for row in comparison['rows'])
for row in comparison['rows']:assert sha(sources['pinned-skia-source/'+row['path']])==row['pinned_sha256']==sha(sources['reviewed-chromium-skia-source/'+row['path']])
DEST.mkdir();archive=DEST/'completed-evidence.tar.gz';members=[];first={}
with tarfile.open(archive,'w:gz',compresslevel=6,format=tarfile.PAX_FORMAT) as tar:
 for name,p in sorted(sources.items()):
  digest=sha(p);members.append(dict(path=name,bytes=p.stat().st_size,sha256=digest));info=tar.gettarinfo(str(p),arcname=name)
  if digest in first:info.type=tarfile.LNKTYPE;info.linkname=first[digest];info.size=0;tar.addfile(info)
  else:
   first[digest]=name
   with p.open('rb') as stream:tar.addfile(info,stream)
with tarfile.open(archive,'r:gz') as tar:
 assert len(tar.getmembers())==len(members)
 for info,row in zip(tar.getmembers(),members):
  content=tar.extractfile(info).read();assert info.name==row['path'] and len(content)==row['bytes'] and hashlib.sha256(content).hexdigest()==row['sha256']
manifest=DEST/'archive-members.json';manifest.write_text(json.dumps(members,sort_keys=True,indent=2)+'\n')
source_archive=DEST/'standalone-source.tar.gz';root=Path('/dev/shm/openui-fontations-factory-prototype-v1933')
source_archive.write_bytes(subprocess.check_output(['git','archive','--format=tar.gz','HEAD'],cwd=root))
with tarfile.open(source_archive,'r:gz') as tar:
 archived={i.name:hashlib.sha256(tar.extractfile(i).read()).hexdigest() for i in tar.getmembers() if i.isfile()}
 tracked=subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0');assert {name:sha(root/name) for name in tracked if name}==archived
binary=RAW/names[-1]/'factory_probe';assert sha(binary)==final['binary_sha256']
index=dict(schema_version=1,release_qualification=False,promotion_allowed=False,all_commands_terminal=True,javascript_executed_by_openui=False,chromium_is_only_pixel_target=True,new_release_states_admitted=0,formal_original_renderer_residual_ownership_assigned=0,
 source=final['source'],source_after=final['source_after'],standalone_typeface_factory_prototype=True,engine_and_consuming_ui_application_not_measured=True,
 full_original_expanded_focused_primitive_matrices_not_run=True,workspace_msrv_miri_and_c_abi_not_run=True,chromium_pixel_comparisons_run=0,original_renderer_totals_unchanged=True,
 skia_pin_unchanged=final['skia_pin_unchanged'],skrifa_version='0.36.0',read_fonts_version='0.34.0',font_types_version='0.9.0',cxx_version='1.0.168',
 full_native_factory_returns_fnta=True,freetype_control_factory_is_distinct=True,malformed_font_returns_none=True,compiled_source_matches_four_reviewed_chromium_source_files=True,reviewed_chromium_source_version='147.0.7727.24',pinned_chromium_binary_version='147.0.7727.50',chromium_binary_dispatch_trace_not_measured=True,
 uses_documented_skia_safe_wrapper_traits=True,rust_code_does_not_transmute_opaque_layouts=True,global_typeface_registry_not_mutated=True,native_factory_owns_copied_font_bytes=True,font_arguments_borrowed_through_native_wrapper=True,
 variation_ttc_and_palette_arguments_transported_by_factory=True,variation_ttc_palette_behavior_not_yet_probed=True,
 probes=[dict(name=s['name'],actual_exit_code=s['actual_exit_code'],log_sha256=s['log_sha256']) for s in final['steps']],
 advance_observations={family:(RAW/names[-1]/('probe-'+family+'.log')).read_text().splitlines() for family in ['Ahem','DejaVu-Sans']},
 failed_attempts=[dict(name=n,observed_exit_code=receipts[n]['observed_exit_code'],steps=receipts[n]['steps'],receipt_sha256=sha(RAW/n/'receipt.json')) for n in names[:-1]],
 partial_v1924_prepare_failure_preserved=True,
 hosted_umbrella_observation={k:hosted[k] for k in ['source','successful_jobs','skipped_jobs','failed_jobs','all_seven_native_guards_executed_and_passed_in_hosted_parity']},full_hardening_not_run_on_9f0d2211=True,
 artifacts=[dict(path=str(p.relative_to(MAIN)),bytes=p.stat().st_size,sha256=sha(p)) for p in [archive,manifest,source_archive]],archived_members=len(members),all_archived_members_hash_verified=True,
 retained_binary=dict(path=str(binary),bytes=binary.stat().st_size,sha256=sha(binary)),preserver_sha256=sha(Path(__file__)))
INDEX.write_text(json.dumps(index,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(index=str(INDEX),sha256=sha(INDEX),members=len(members),archive_bytes=archive.stat().st_size,source_archive_bytes=source_archive.stat().st_size,actual_exit=0)),flush=True)
