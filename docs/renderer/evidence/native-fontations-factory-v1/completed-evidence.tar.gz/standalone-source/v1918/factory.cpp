#include "factory.h"
#include "include/core/SkData.h"
#include "include/core/SkFontArguments.h"
#include "include/core/SkStream.h"
#include "include/ports/SkTypeface_fontations.h"
#include "src/core/SkFontDescriptor.h"
#include <cmath>
#include <vector>
namespace openui_fontations {
SkTypeface* make_typeface(rust::Slice<const uint8_t> data, uint32_t collection_index,
                         rust::Slice<const uint32_t> tags, rust::Slice<const float> values) {
    if (data.empty() || tags.size() != values.size() || tags.size() > INT32_MAX) return nullptr;
    std::vector<SkFontArguments::VariationPosition::Coordinate> coordinates;
    coordinates.reserve(tags.size());
    for (size_t index = 0; index < tags.size(); ++index) {
        if (!std::isfinite(values[index])) return nullptr;
        coordinates.push_back({tags[index], values[index]});
    }
    SkFontArguments args;
    args.setCollectionIndex(static_cast<int>(collection_index));
    args.setVariationDesignPosition({coordinates.data(), static_cast<int>(coordinates.size())});
    // Transfers exactly one owned reference to skia-safe's documented wrapper.
    return SkTypeface_Make_Fontations(SkData::MakeWithCopy(data.data(), data.size()), args).release();
}
uint32_t factory_id(const SkTypeface& face) {
    auto data = face.serialize(SkTypeface::SerializeBehavior::kDoIncludeData);
    if (!data) return 0;
    SkMemoryStream stream(data);
    SkFontDescriptor descriptor(SkFontStyle::Normal());
    return descriptor.deserialize(&stream) ? descriptor.getFactoryId() : 0;
}
}
