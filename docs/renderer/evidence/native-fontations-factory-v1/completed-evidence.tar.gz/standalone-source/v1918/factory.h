#pragma once
#include "include/core/SkTypeface.h"
#include "rust/cxx.h"
namespace openui_fontations {
SkTypeface* make_typeface(rust::Slice<const uint8_t> data, uint32_t collection_index,
                         rust::Slice<const uint32_t> tags, rust::Slice<const float> values);
uint32_t factory_id(const SkTypeface& face);
}
