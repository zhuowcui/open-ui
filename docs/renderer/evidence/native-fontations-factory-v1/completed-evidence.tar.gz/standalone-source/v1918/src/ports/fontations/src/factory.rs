#[cxx::bridge(namespace = "openui_fontations")]
mod bridge {
    unsafe extern "C++" {
        include!("factory.h");
        type SkTypeface;
        unsafe fn make_typeface(data: &[u8], collection_index: u32,
                               tags: &[u32], values: &[f32]) -> *mut SkTypeface;
        fn factory_id(face: &SkTypeface) -> u32;
    }
}

pub fn from_data(data: &[u8], collection_index: u32, coordinates: &[(u32, f32)]) -> Option<skia_safe::Typeface> {
    use skia_safe::wrapper::PointerWrapper;
    let (tags, values): (Vec<_>, Vec<_>) = coordinates.iter().copied().unzip();
    // SAFETY: C++ copies all slices and releases exactly one owned SkTypeface
    // reference. The documented wrapper takes that reference and drops it.
    // The pointee stays opaque; no layout assumption or global registration.
    let pointer = unsafe { bridge::make_typeface(data, collection_index, &tags, &values) };
    skia_safe::Typeface::wrap(pointer.cast())
}

pub fn typeface_factory_id(face: &skia_safe::Typeface) -> u32 {
    use skia_safe::wrapper::PointerWrapper;
    // SAFETY: the bridge and wrapper refer to the same pinned SkTypeface;
    // it remains borrowed and immutable throughout this call.
    let pointer = face.inner() as *const _ as *const bridge::SkTypeface;
    unsafe { bridge::factory_id(&*pointer) }
}
