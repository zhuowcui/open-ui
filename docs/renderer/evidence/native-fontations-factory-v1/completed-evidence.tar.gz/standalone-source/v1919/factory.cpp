#include "factory.h"
#include "include/core/SkData.h"
#include "include/core/SkStream.h"
#include "include/ports/SkTypeface_fontations.h"
#include "src/core/SkFontDescriptor.h"
namespace openui_fontations {
SkTypeface* make_typeface(rust::Slice<const uint8_t> data, const SkFontArguments* arguments) {
    if (data.empty() || !arguments) return nullptr;
    // Skia copies font bytes and retains variation/palette instance data.
    // Transfers exactly one owned reference to the documented Rust wrapper.
    return SkTypeface_Make_Fontations(SkData::MakeWithCopy(data.data(), data.size()), *arguments).release();
}
uint32_t factory_id(const SkTypeface& face) {
    auto data = face.serialize(SkTypeface::SerializeBehavior::kDoIncludeData);
    if (!data) return 0;
    SkMemoryStream stream(data);
    SkFontDescriptor descriptor(SkFontStyle::Normal());
    return descriptor.deserialize(&stream) ? descriptor.getFactoryId() : 0;
}
}
