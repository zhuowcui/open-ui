use std::{env, fs, path::PathBuf};
fn main() {
    let skia = PathBuf::from(env::var("OPENUI_PINNED_SKIA_INCLUDE").expect("pinned Skia source"));
    let out = PathBuf::from(env::var_os("OUT_DIR").unwrap());
    let alias = out.join("include/src/ports/fontations/src");
    fs::create_dir_all(&alias).unwrap();
    fs::write(
        alias.join("ffi.rs.h"),
        "#include \"openui-fontations-factory-prototype/src/ports/fontations/src/ffi.rs.h\"\n",
    )
    .unwrap();
    cxx_build::bridges([
        "src/ports/fontations/src/ffi.rs",
        "src/ports/fontations/src/factory.rs",
    ])
    .file("SkTypeface_fontations.cpp")
    .file("factory.cpp")
    .include(out.join("include"))
    .include(&skia)
    .include(".")
    .std("c++17")
    .define("NDEBUG", None)
    .define("SK_NDEBUG", None)
    .define("SK_GAMMA_EXPONENT", "1.2")
    .define("SK_GAMMA_CONTRAST", "0.2")
    .compile("openui_pinned_fontations");
    println!("cargo:rerun-if-env-changed=OPENUI_PINNED_SKIA_INCLUDE");
    println!("cargo:rerun-if-changed=SkTypeface_fontations.cpp");
    println!("cargo:rerun-if-changed=factory.cpp");
    println!("cargo:rerun-if-changed=factory.h");
}
