#[cxx::bridge(namespace = "openui_fontations")]
mod bridge {
    unsafe extern "C++" {
        include!("factory.h");
        #[namespace = ""]
        type SkTypeface;
        #[namespace = ""]
        type SkFontArguments;
        unsafe fn make_typeface(data: &[u8], arguments: *const SkFontArguments) -> *mut SkTypeface;
        fn factory_id(face: &SkTypeface) -> u32;
    }
}

pub fn from_data(
    data: &[u8],
    arguments: &skia_safe::FontArguments<'_, '_>,
) -> Option<skia_safe::Typeface> {
    use skia_safe::wrapper::{NativeTransmutableWrapper, PointerWrapper};
    let args = arguments.inner() as *const _ as *const bridge::SkFontArguments;
    // SAFETY: both bridge and wrapper use the same pinned opaque types. C++
    // copies font bytes and retains the full variation/palette instance. It
    // releases exactly one owned reference, taken by the documented wrapper.
    let pointer = unsafe { bridge::make_typeface(data, args) };
    skia_safe::Typeface::wrap(pointer.cast())
}

pub fn typeface_factory_id(face: &skia_safe::Typeface) -> u32 {
    use skia_safe::wrapper::PointerWrapper;
    // SAFETY: the bridge borrows the same pinned immutable SkTypeface.
    let pointer = face.inner() as *const _ as *const bridge::SkTypeface;
    unsafe { bridge::factory_id(&*pointer) }
}
