use fontations_ffi::factory::{from_data, typeface_factory_id};
use skia_safe::{Font, FontArguments, FontMgr};
fn main() {
    let path = std::env::args().nth(1).expect("font path");
    let bytes = std::fs::read(path).unwrap();
    let face = from_data(&bytes, &FontArguments::new()).expect("true Fontations face");
    assert_eq!(typeface_factory_id(&face), u32::from_be_bytes(*b"fnta"));
    assert!(from_data(&[0, 1, 2], &FontArguments::new()).is_none());
    let glyph = face.unichar_to_glyph('X' as i32);
    assert_ne!(glyph, 0);
    let freetype = FontMgr::default().new_from_data(&bytes, None).unwrap();
    assert_ne!(typeface_factory_id(&freetype), u32::from_be_bytes(*b"fnta"));
    for size in [10.0, 12.0, 16.0, 20.0, 24.0] {
        let mut font = Font::from_typeface(&face, size);
        font.set_hinting(skia_safe::FontHinting::None)
            .set_subpixel(true)
            .set_linear_metrics(true);
        let mut widths = [0.0];
        font.get_widths(&[glyph], &mut widths);
        println!("size={size} advance={:.9} factory=fnta", widths[0]);
    }
}
