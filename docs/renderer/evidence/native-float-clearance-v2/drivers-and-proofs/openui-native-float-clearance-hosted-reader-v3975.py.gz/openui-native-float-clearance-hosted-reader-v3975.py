import hashlib,json,subprocess
from pathlib import Path
OUT=Path('/mnt/d/openui-v02-qualification-d174ea0b/native-float-clearance-hosted-v3975')
assert not OUT.exists();OUT.mkdir()
HEAD='8138171358b403c99ba88590ca83d3ca8cafb073'
runs=[]
for rid in [38125581678,38125581680,38125591990]:
 data=[]
 for suffix in ['', '/jobs?per_page=100']:
  p=subprocess.run(['gh','api','repos/zhuowcui/open-ui/actions/runs/'+str(rid)+suffix],capture_output=True,timeout=60)
  assert p.returncode==0,p.stderr.decode()
  name=str(rid)+('-jobs.json' if suffix else '-run.json')
  (OUT/name).write_bytes(p.stdout);data.append(json.loads(p.stdout))
 run,jobs=data;assert run['head_sha']==HEAD
 rows=[dict(name=j['name'],status=j['status'],conclusion=j['conclusion']) for j in jobs['jobs']]
 runs.append(dict(run=rid,workflow=run['name'],head=run['head_sha'],event=run['event'],status=run['status'],conclusion=run['conclusion'],jobs=rows))
rows=[j for r in runs for j in r['jobs']];assert len(rows)==12
r=dict(source_commit=HEAD,runs=runs,jobs=len(rows),successes=sum(j['conclusion']=='success' for j in rows),pending=sum(j['status']!='completed' for j in rows),failures=sum(j['status']=='completed' and j['conclusion'] not in ['success','skipped'] for j in rows),skips=sum(j['conclusion']=='skipped' for j in rows),all_jobs_success=all(j['conclusion']=='success' for j in rows),all_reader_commands_terminal=True,reader_reaped=True,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False)
(OUT/'receipt.json').write_text(json.dumps(r,sort_keys=True,indent=2)+'\n')
print(json.dumps(r),flush=True)
