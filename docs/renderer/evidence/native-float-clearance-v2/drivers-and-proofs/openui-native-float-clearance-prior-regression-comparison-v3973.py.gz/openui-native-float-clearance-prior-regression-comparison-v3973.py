import hashlib,json
from pathlib import Path
BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b')
OUT=BASE/'native-float-clearance-clean-full-v3967'
load=lambda p:json.loads(Path(p).read_bytes())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=load(OUT/'receipt.json');a=load('/tmp/openui-native-float-clearance-clean-full-audit-v3968.json');p=load('/tmp/openui-native-float-clearance-clean-full-reaped-v3969.json')
assert r['all_commands_terminal'] and a['complete'] and p['all_local_commands_terminal'] and p['owners_absent']
assert sha(OUT/'receipt.json')==a['receipt_sha256']==p['receipt_sha256']
fields=['openui_png_sha256','openui_rgba_sha256','chromium_png_sha256','chromium_rgba_sha256','chromium_oracle_identity_sha256','chromium_oracle_rgba_sha256','mismatched_pixels','status','diff_signature']
result=dict(source=r['source'],comparison_baseline='Previous rejected atomic implementation b21; accepted98d primary comparison remains authoritative',primary_comparison=r['comparisons'],secondary_comparisons={},renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False)
for suite in ['focused','primitive','full','expanded']:
 path=OUT/(suite+'-matrix')/(suite+'-summary.json');prev=BASE/'native-atomic-sizing-clean-full-v3918'/(suite+'-matrix')/(suite+'-summary.json')
 m=load(path);oldm=load(prev);old={(p['profile'],t['id']):t for p in oldm['profiles'] for t in p['tests']}
 gains=losses=worsened=count=0;changes=[]
 for profile in m['profiles']:
  for t in profile['tests']:
   prior=old.pop((profile['profile'],t['id']));count+=1
   assert all(prior[k]==t[k] for k in fields if k.startswith('chromium_'))
   gains+=prior['status']!='exact' and t['status']=='exact';losses+=prior['status']=='exact' and t['status']!='exact';worsened+=t['mismatched_pixels']>prior['mismatched_pixels']
   changed=[k for k in fields if prior[k]!=t[k]]
   if changed:changes.append(dict(profile=profile['profile'],id=t['id'],fields=changed,before={k:prior[k] for k in changed},after={k:t[k] for k in changed}))
 assert not old
 result['secondary_comparisons'][suite]=dict(rows=count,gains=gains,losses=losses,worsened=worsened,changes=changes,prior_summary_sha256=sha(prev),current_summary_sha256=sha(path))
dest=BASE/'native-float-clearance-prior-regression-comparison-v3973.json';assert not dest.exists();dest.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps({s:{k:v for k,v in c.items() if k not in ['changes']} for s,c in result['secondary_comparisons'].items()}),flush=True)
