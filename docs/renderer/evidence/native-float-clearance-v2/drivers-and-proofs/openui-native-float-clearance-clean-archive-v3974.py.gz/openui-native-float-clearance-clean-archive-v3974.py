import fcntl,gzip,hashlib,json,shutil,subprocess
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b');OUT=BASE/'native-float-clearance-clean-full-v3967'
DEST=ROOT/'docs/renderer/evidence/native-float-clearance-v2';INDEX=ROOT/'docs/renderer/generated/native-float-clearance-v2.json'
load=lambda p:json.loads(Path(p).read_bytes());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof=load('/tmp/openui-native-float-clearance-clean-full-reaped-v3969.json');audit=load('/tmp/openui-native-float-clearance-clean-full-audit-v3968.json');r=load(OUT/'receipt.json');native=load(BASE/'native-float-clearance-clean-consumer-v3964/receipt.json');np=load('/tmp/openui-native-float-clearance-clean-consumer-reaped-v3966.json')
assert proof['all_local_commands_terminal'] and proof['owners_absent'] and audit['complete'] and r['all_commands_terminal'] and native['all_commands_terminal']
assert r['source']['clean'] and r['source']==audit['source']==proof['source']==native['source']==np['source']
assert sha(OUT/'receipt.json')==audit['receipt_sha256']==proof['receipt_sha256']
assert native['totals']==dict(images=8,exact_images=8,bounds=320,exact_bounds=320) and native['guard_results']==dict(actual_exit_code=0,passed=1182,failed=0,ignored=0)
for receipt in [r,native]:assert subprocess.run(['ps','-p',str(receipt['owner_pid'])],capture_output=True).returncode==1
for name in ['cargo','rustc','rustfmt','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
sys_source=r['source'];previous=ROOT/'docs/renderer/generated/native-float-clearance-v1.json';prior=load(previous);previous_hash=sha(previous)
for member in prior['archive']['members']:assert sha(ROOT/member['path'])==member['sha256']
assert sha(ROOT/'bindings/rust/openui-layout/src/block.rs')==prior['runtime_source']['after_sha256']
assert not DEST.exists() and not INDEX.exists() and shutil.disk_usage(ROOT).free>128*2**20
DEST.mkdir();members=[];excluded=[]
def add(path,label):
 raw=Path(path).read_bytes();data=gzip.compress(raw,compresslevel=9,mtime=0);out=DEST/(label+'.gz');assert not out.exists();out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data);assert gzip.decompress(out.read_bytes())==raw
 members.append(dict(path=str(out.relative_to(ROOT)),compression='gzip',bytes=len(data),sha256=sha(out),raw_bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest()))
for directory,label in [('native-float-clearance-clean-consumer-source-v3963','consumer-source'),('native-float-clearance-clean-consumer-v3964','clean-native')]:
 for path in sorted((BASE/directory).rglob('*')):
  if path.is_file():
   if path.name in ['native_clearance_consumer','pixel_compare']:excluded.append(dict(path=str(path),sha256=sha(path),reason='Owned executable retained outside Git with fresh compiler hashes.'));continue
   add(path,label+'/'+str(path.relative_to(BASE/directory)))
for path in sorted((OUT/'guarded-build').iterdir()):
 if path.is_file():
  if path.name=='pixel_compare':excluded.append(dict(path=str(path),sha256=sha(path),reason='Owned renderer executable retained outside Git with fresh compiler hashes.'));continue
  add(path,'renderer-build/'+path.name)
for suite in ['focused','primitive','full','expanded']:add(OUT/(suite+'-matrix')/(suite+'-summary.json'),suite+'-summary.json');add(OUT/(suite+'.log'),suite+'.log')
add(OUT/'receipt.json','renderer-receipt.json')
for pattern in ['openui-native-float-clearance-clean-consumer-v3964.py','openui-native-float-clearance-clean-consumer-audit-v3965.*','openui-native-float-clearance-clean-consumer-reaped-v3966.json','openui-native-float-clearance-clean-full-v3967.py','openui-native-float-clearance-clean-full-audit-v3968.*','openui-native-float-clearance-clean-full-reap*-v3969.*','openui-native-float-clearance-residual-inventory-v3972.*','openui-native-float-clearance-prior-regression-comparison-v3973.py']:
 for path in sorted(Path('/tmp').glob(pattern)):add(path,'drivers-and-proofs/'+path.name)
add(BASE/'native-float-clearance-prior-regression-comparison-v3973.json','previous-rejected-regression-comparison.json')
for path in sorted((BASE/'native-float-clearance-hosted-v3975').iterdir()):
 if path.is_file():add(path,'hosted/'+path.name)
add('/tmp/openui-native-float-clearance-hosted-reader-v3975.py','drivers-and-proofs/openui-native-float-clearance-hosted-reader-v3975.py')
add(__file__,'drivers-and-proofs/'+Path(__file__).name)
assert sha(previous)==previous_hash
result=dict(schema_version=1,measured_source=sys_source,previous_immutable_evidence=dict(path=str(previous.relative_to(ROOT)),sha256=previous_hash,unchanged=True),native_clean=dict(totals=native['totals'],actual_exit_code=0,guards=native['guard_results'],repeat_and_lifecycle_passed=True,scoped_eight_image_qualification=True,all_native_api_qualification=False),renderer_clean=dict(audit=audit,results=audit['results'],rows_audited=audit['matrix_rows_verified'],candidate_nonregression=audit['candidate_nonregression'],qualification=False),residual_inventory=load('/tmp/openui-native-float-clearance-residual-inventory-v3972.json'),secondary_comparison=load(BASE/'native-float-clearance-prior-regression-comparison-v3973.json'),hosted=load(BASE/'native-float-clearance-hosted-v3975/receipt.json'),all_local_commands_terminal=True,all_members_hash_verified=True,pixel_target='pinned Chromium',pixel_tolerance=0,historical_openui_archive_is_a_pixel_target=False,javascript_executed_by_openui=False,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,pending=['Remaining original and expanded Chromium differences and strict nonregression gate.','Every required native API, reviewed residual ownership, clean full workspace/ABI qualification.','Compositor/3D, physical lab, packaging, signing and publication.'],archive=dict(files=len(members),bytes=sum(m['bytes'] for m in members),members=members,excluded=excluded))
INDEX.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(index=str(INDEX),members=len(members),stored_bytes=result['archive']['bytes'],qualified=False)),flush=True)
