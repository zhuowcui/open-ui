import hashlib,json,os
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');INDEX=ROOT/'docs/renderer/generated/native-float-clearance-v2.json';r=json.loads(INDEX.read_bytes());proof=json.loads(Path('/tmp/openui-native-float-clearance-clean-archive-terminal-v3976.json').read_bytes());assert proof['archive_writer_reaped'] and proof['actual_archive_writer_exit_code']==0 and r['all_local_commands_terminal']
assert r['native_clean']['totals']==dict(images=8,exact_images=8,bounds=320,exact_bounds=320) and r['native_clean']['guards']['passed']==1182
m=r['renderer_clean']['results'];assert m['full']['exact']==21350 and m['expanded']['exact']==22153 and m['full']['worsened']==m['expanded']['worsened']==1
assert r['hosted']['all_jobs_success'] and r['hosted']['jobs']==12
text="""## Cleared empty boxes (clean verification; pixel gate still failed)

The shared block layout calculates clearance using the complete collapsed
margin group of an empty cleared box. The native repair is now verified at
clean `81381713`: **8/8 images and 320/320 bounds exact** against pinned
Chromium across all four required profiles. The consuming Rust app creates
eight reduced cases and removes margins through a Rust click callback.
Independent process and unchanged-frame repeats, callback counts and weak
teardown pass. All **1,182 layout/text/paint tests** pass, with zero failures
or ignores. This verifies these eight pictures and bounds; other native APIs
remain unqualified.

Fresh complete CPU verification at that same clean source measures
**21,350/22,924 original** and **22,153/23,728 expanded** exact comparisons,
with **1,574 / 1,575 differences**, zero errors and actual exits **1 / 1**.
Focused **640/640** and primitive **960/960** are exact and unchanged. All
**48,252 rows**, 14 fresh compiler records, 26 compiled paths and unchanged
Chromium reference fields are independently audited. Owners and audits are
terminal and reaped before later source or build changes.

Against rejected `b21ece15`, each complete census restores **all 16 lost exact
comparisons**, with zero losses or worsened differences. Against accepted
`98d18982`, each census has zero exact gains or losses, but **one existing
scroll-button comparison still worsens**. Three scroll-button images change;
their other two differing profiles improve. The strict nonregression gate
therefore still fails. The shared float width calculation remains in place.

All **12 hosted jobs** pass on measured `81381713`, with zero skips: format,
ordinary CI and all seven explicitly dispatched hardening jobs, including
hosted X11/Mesa and pure Wayland native consumers.
[Hardening run 38125591990](https://github.com/zhuowcui/open-ui/actions/runs/38125591990).
Later checkpoints need their own hosted results; physical lab checks remain
open.

There are **875 residual original test IDs**, all without a reviewed ownership
entry. **200/201** added cases are exact at all four profiles; the dynamic
fieldset/legend case still differs at scale 1.25. The other **35** AST-lowered
cases remain outside the current manifest and unqualified. Full local
workspace/ABI, shared font/control behavior, every needed native API,
compositor/3D, hardware and release qualification remain open.

Open UI never executes JavaScript. Applications use public Rust operations and
Rust callbacks over the shared Engine. Chromium alone defines expected pixels;
old Open UI images preserve history. No full renderer, complete native API or
release pass is claimed.
[Immutable clean evidence]({link}). Earlier dirty repair evidence remains
unchanged in its versioned archive.

"""
changes=[]
for name,link in [('README.md','docs/renderer/generated/native-float-clearance-v2.json'),('docs/progress/current-status.md','../renderer/generated/native-float-clearance-v2.json'),('docs/renderer/contract.md','generated/native-float-clearance-v2.json'),('docs/v02/release.md','../renderer/generated/native-float-clearance-v2.json')]:
 p=ROOT/name;old=p.read_text();start=old.index('### Cleared empty boxes' if name=='README.md' else '## Cleared empty boxes');end=old.index('### Shared atomic sizing' if name=='README.md' else '## Shared atomic sizing',start);section=text.format(link=link)
 if name=='README.md':section=section.replace('## Cleared empty boxes','### Cleared empty boxes',1)
 new=old[:start]+section+old[end:];tmp=p.with_name(p.name+'.tmp');tmp.write_text(new);os.replace(tmp,p);changes.append(name)
p=ROOT/'docs/v02/unsupported-features.md';old=p.read_text();start=old.index('- the cleared-empty-box repair');end=old.index('- shared atomic sizing',start);bullet="""- clean `81381713` verifies the cleared-empty-box repair: 8/8 native images,
  320/320 bounds and all 1,182 layout/text/paint tests pass. Original
  21,350/22,924 and expanded 22,153/23,728 still fail with 1,574/1,575
  differences and zero errors; focused 640/640 and primitive 960/960 are exact.
  All 48,252 rows and unchanged Chromium references are audited. All 16 lost
  exact comparisons are restored against rejected `b21ece15`; one existing
  scroll-button difference still worsens against accepted `98d18982`, so the
  strict regression gate fails. All 12 hosted jobs pass, with zero skips.
  There are 875 residual original IDs, all lacking reviewed ownership entries;
  200/201 additions are exact at all four profiles. Full workspace/ABI,
  remaining native APIs, compositor/3D, physical lab and release checks remain
  open. [Clean evidence](../renderer/generated/native-float-clearance-v2.json);
""";new=old[:start]+bullet+old[end:];tmp=p.with_name(p.name+'.tmp');tmp.write_text(new);os.replace(tmp,p);changes.append(str(p.relative_to(ROOT)))
dest=Path('/tmp/openui-native-float-clearance-clean-docs-v3977.json');assert not dest.exists();dest.write_text(json.dumps(dict(schema_version=1,edited_documents=changes,measured_source=r['measured_source'],all_commands_terminal=True,qualified=False),sort_keys=True,indent=2)+'\n');print(json.dumps(dict(edited_documents=len(changes),qualified=False)))
