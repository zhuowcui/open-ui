import fcntl,gzip,hashlib,json,os,subprocess
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b');INDEX=ROOT/'docs/renderer/generated/native-float-clearance-v2.json';DEST=ROOT/'docs/renderer/evidence/native-float-clearance-v2'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_bytes())
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
r=load(INDEX);terminal=load('/tmp/openui-native-float-clearance-clean-archive-terminal-v3976.json');assert terminal['archive_writer_reaped'] and terminal['actual_archive_writer_exit_code']==0 and sha(INDEX)==terminal['index_sha256']
for name in ['cargo','rustc','rustfmt','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
members=r['archive']['members']
def add(p,label):
 raw=Path(p).read_bytes();data=gzip.compress(raw,compresslevel=9,mtime=0);out=DEST/(label+'.gz');assert not out.exists();out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data)
 members.append(dict(path=str(out.relative_to(ROOT)),compression='gzip',bytes=len(data),sha256=sha(out),raw_bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest()))
checks=BASE/'native-float-clearance-clean-checks-v3979'
for name in ['style','ffi','renderer','release','accountability','whitespace','format']:
 c=load(checks/(name+'.json'));assert c['actual_exit_code']==c['check_exit_code']==0 and c['reaped']
for p in sorted(checks.iterdir()):
 if p.is_file():add(p,'checkpoint-checks/'+p.name)
for pattern in ['openui-native-float-clearance-clean-archive-terminal-v3976.*','openui-native-float-clearance-clean-docs-v3977.*','openui-native-float-clearance-clean-release-table-v3978.*','openui-native-float-clearance-clean-check-v3979.py']:
 for p in sorted(Path('/tmp').glob(pattern)):add(p,'checkpoint-proofs/'+p.name)
add(__file__,'checkpoint-proofs/'+Path(__file__).name)
r['expanded_additions']=terminal['expanded_additions'];r['checkpoint_read_only_checks']=dict(passed=7,failed=0,actual_terminal=True);r['archive']['files']=len(members);r['archive']['bytes']=sum(m['bytes'] for m in members)
for m in members:
 p=ROOT/m['path'];assert sha(p)==m['sha256'];raw=gzip.decompress(p.read_bytes());assert len(raw)==m['raw_bytes'] and hashlib.sha256(raw).hexdigest()==m['raw_sha256']
assert sha(ROOT/r['previous_immutable_evidence']['path'])==r['previous_immutable_evidence']['sha256']
temp=INDEX.with_name(INDEX.name+'.tmp');temp.write_text(json.dumps(r,sort_keys=True,indent=2)+'\n');os.replace(temp,INDEX)
proof=dict(schema_version=1,index_sha256=sha(INDEX),members=len(members),stored_bytes=r['archive']['bytes'],all_raw_stored_hashes_verified=True,previous_archive_unchanged=True,all_prerequisite_helpers_reaped=True,actual_archive_writer_session=51502,actual_archive_writer_exit_code=0,actual_archive_terminal_session=43235,actual_archive_terminal_exit_code=0,actual_accountability_session=64035,actual_accountability_exit_code=0,qualified=False)
dest=Path('/tmp/openui-native-float-clearance-clean-archive-supplement-v3980.json');assert not dest.exists();dest.write_text(json.dumps(proof,sort_keys=True,indent=2)+'\n');print(json.dumps(proof),flush=True)
