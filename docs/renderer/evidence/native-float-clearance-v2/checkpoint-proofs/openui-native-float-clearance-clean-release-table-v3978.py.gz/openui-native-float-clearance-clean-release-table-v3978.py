import json,os
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');p=ROOT/'docs/v02/release.md';old=p.read_text();rows={
'Four-profile renderer matrix':'[Clean clearance census](../renderer/generated/native-float-clearance-v2.json) at clean `81381713`: 21,350/22,924 exact, 1,574 different, zero errors; actual exit 1. No exact losses against accepted `98d18982`, but one scroll-button difference worsens; 875 residual IDs still need reviewed ownership and closure | fail',
'Focused and primitive raster':'[Clean clearance census](../renderer/generated/native-float-clearance-v2.json) at clean `81381713`: 640/640 focused and 960/960 primitive exact; all 1,600 native images and Chromium references remain unchanged | source-attributed scoped pass',
'Expanded native final-state fixtures':'[Clean clearance census](../renderer/generated/native-float-clearance-v2.json) at clean `81381713`: 22,153/23,728 exact, 1,575 different, zero errors; actual exit 1. 200/201 additions exact at all four profiles; 35 AST-lowered cases remain outside the current manifest and unqualified. Open UI runs no JavaScript | open',
'Rust 1.85 MSRV':'[Same-source explicit hardening](https://github.com/zhuowcui/open-ui/actions/runs/38125591990): MSRV passes at `81381713`; all seven jobs succeed, zero skips | source-attributed pass',
'X11/Wayland software and Mesa GL':'[Same-source hardening](https://github.com/zhuowcui/open-ui/actions/runs/38125591990) passes native C/C++ X11 software/Mesa windows and pure Wayland presentation at `81381713`; physical release lab remains open | provisional pass',
'Miri C handle ownership':'[Same-source hardening](https://github.com/zhuowcui/open-ui/actions/runs/38125591990): opaque-handle ownership passes pinned Miri at `81381713` | source-attributed pass',
'ASan/LSan/fuzz':'[Same-source explicit hardening](https://github.com/zhuowcui/open-ui/actions/runs/38125591990) at `81381713` passes address/leak sanitizers, C UBSan and all fuzz targets; all seven jobs succeed with zero skips | source-attributed pass',
'Native C UBSan':'[Same-source explicit hardening](https://github.com/zhuowcui/open-ui/actions/runs/38125591990): ABI consumers pass at `81381713` | source-attributed pass'}
lines=old.splitlines()
for name,body in rows.items():
 match=[i for i,line in enumerate(lines) if line.startswith('| '+name+' |')];assert len(match)==1
 lines[match[0]]='| '+name+' | '+body+' |'
new='\n'.join(lines)+'\n';temp=p.with_name(p.name+'.tmp');temp.write_text(new);os.replace(temp,p)
proof=Path('/tmp/openui-native-float-clearance-clean-release-table-v3978.json');assert not proof.exists();proof.write_text(json.dumps(dict(rows_updated=list(rows),qualified=False),sort_keys=True,indent=2)+'\n');print(json.dumps(dict(rows_updated=len(rows),qualified=False)))
