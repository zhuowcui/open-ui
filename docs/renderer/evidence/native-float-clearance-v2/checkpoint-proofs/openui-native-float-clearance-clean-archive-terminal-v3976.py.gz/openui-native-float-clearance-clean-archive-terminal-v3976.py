import gzip,hashlib,json,subprocess
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b');INDEX=ROOT/'docs/renderer/generated/native-float-clearance-v2.json'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_bytes())
r=load(INDEX)
for m in r['archive']['members']:
 p=ROOT/m['path'];assert sha(p)==m['sha256'];raw=gzip.decompress(p.read_bytes());assert len(raw)==m['raw_bytes'] and hashlib.sha256(raw).hexdigest()==m['raw_sha256']
assert sha(ROOT/r['previous_immutable_evidence']['path'])==r['previous_immutable_evidence']['sha256']
f=load(BASE/'native-float-clearance-clean-full-v3967/full-matrix/full-summary.json');e=load(BASE/'native-float-clearance-clean-full-v3967/expanded-matrix/expanded-summary.json')
fids={t['id'] for p in f['profiles'] for t in p['tests']};adds=sorted({t['id'] for p in e['profiles'] for t in p['tests']}-fids)
rows={i:[dict(profile=p['profile'],status=t['status'],mismatched_pixels=t['mismatched_pixels']) for p in e['profiles'] for t in p['tests'] if t['id']==i] for i in adds};fail={i:rr for i,rr in rows.items() if not all(t['status']=='exact' for t in rr)}
assert len(adds)==201 and len(fail)==1
for name in ['cargo','rustc','rustfmt','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
proof=dict(schema_version=1,archive_writer_reaped=True,actual_archive_writer_session=51502,actual_archive_writer_exit_code=0,index_sha256=sha(INDEX),members_verified=len(r['archive']['members']),stored_bytes=r['archive']['bytes'],all_raw_stored_hashes_verified=True,source=r['measured_source'],expanded_additions=dict(total=len(adds),all_four_exact=len(adds)-len(fail),differing=fail),all_local_commands_terminal=True,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False)
dest=Path('/tmp/openui-native-float-clearance-clean-archive-terminal-v3976.json');assert not dest.exists();dest.write_text(json.dumps(proof,sort_keys=True,indent=2)+'\n');print(json.dumps(proof),flush=True)
