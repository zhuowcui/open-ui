import hashlib
import json
import subprocess
import sys
from pathlib import Path
from PIL import Image

ROOT = Path('/home/nero/code/open-ui')
OUT = Path('/mnt/d/openui-v02-qualification-d174ea0b/native-table-origin-v4152')
PROOF = Path('/tmp/openui-native-table-origin-audit-v4153.json')
assert not PROOF.exists()
sys.path[:0] = [str(ROOT / 'tools/qualification'), '/tmp']
from openui_parallel_source_identity_v3060 import identity
from residuals import analyze_image_difference
load = lambda path: json.loads(Path(path).read_bytes())
def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

r = load(OUT / 'receipt.json')
assert r['all_commands_terminal'] and r['source_unchanged'] and r['inputs_unchanged']
assert r['source'] == r['source_after'] == identity(ROOT)
assert subprocess.run(['ps', '-p', str(r['owner_pid'])], capture_output=True).returncode == 1
assert sha('/tmp/openui-native-table-origin-owner-v4152.py') == r['driver_sha256']
for path, expected in r['input_sha256'].items():
    assert sha(path) == expected, path
for step in r['steps']:
    if 'log_sha256' in step:
        assert sha(OUT / (step['name'] + '.log')) == step['log_sha256']
assert sha(ROOT / 'chrome/linux-147.0.7727.50/chrome-linux64/chrome') == r['chromium_binary_sha256']
compiled = 0
for path, expected in r.get('compiled_artifact_sha256', {}).items():
    assert sha(path) == expected, path
    compiled += 1
artifacts = r.get('compiler_artifacts', [])
if not artifacts and r.get('failure') and (OUT/'native-build.log').exists():
    metadata = load(OUT/'metadata.log')
    local_ids = {p['id'] for p in metadata['packages'] if Path(p['manifest_path']).resolve().is_relative_to(ROOT) or Path(p['manifest_path']).resolve().is_relative_to(Path('/mnt/d/openui-v02-qualification-d174ea0b/native-table-origin-source-v4148/project'))}
    for line in (OUT/'native-build.log').read_text().splitlines():
        try: row = json.loads(line)
        except json.JSONDecodeError: continue
        if row.get('reason') == 'compiler-artifact' and row['package_id'] in local_ids:
            artifacts.append(row)
            for path in row['filenames']:
                assert Path(path).is_file(); sha(path); compiled += 1
assert all(row['fresh'] is False for row in artifacts)
if artifacts:
    metadata = load(OUT / 'metadata.log')
    packages = {row['id']:row for row in metadata['packages']}
    for row in artifacts:
        manifest = Path(packages[row['package_id']]['manifest_path']).resolve()
        assert manifest.is_relative_to(ROOT) or manifest.is_relative_to(Path('/mnt/d/openui-v02-qualification-d174ea0b/native-table-origin-source-v4148/project'))
    if 'binary' in r:
        assert sha(r['binary']) == sha(r['retained_binary']) == r['binary_sha256']
images = {}; comparisons = 0; observations = []
def picture(path, profile):
    path = Path(path)
    if str(path) not in images:
        with Image.open(path) as image:
            assert image.size == tuple(round(profile[key]*profile['scale']) for key in ['width', 'height'])
            images[str(path)] = dict(sha256=sha(path), rgba_sha256=hashlib.sha256(image.convert('RGBA').tobytes()).hexdigest())
    return images[str(path)]
for index, row in enumerate(r['cases']):
    directory = OUT / f'profile-{index}'; profile = row['profile']
    for markers in ['no', 'yes']:
        first = load(directory / f'chromium-1-{markers}-bounds.json')
        assert first == load(directory / f'chromium-2-{markers}-bounds.json') == row['chromium_bounds'][markers]
        expected = {node['name']:node for node in first}
        assert len(expected) == (7 if markers == 'no' else 10)
        browser = [picture(directory/f'chromium-{repeat}-{markers}-{number}.png', profile) for repeat in [1,2] for number in [1,2]]
        assert all(image == browser[0] for image in browser)
        for policy, result in row['native'].items():
            if markers not in result.get('comparisons', {}):
                continue
            runs = result['runs'][markers]
            assert len(runs) == 2 and runs[0]['files'] == runs[1]['files']
            for run in runs:
                native = Path(run['directory'])
                for name, expected_sha in run['files'].items():
                    assert sha(native/name) == expected_sha
                lifecycle = load(native/'lifecycle.json')
                assert lifecycle['native_click_callbacks'] == 1
                assert lifecycle['unchanged_frame_byte_repeat'] and lifecycle['count_only_callback_preserved_pixels']
                assert lifecycle['weak_teardown_passed'] and not lifecycle['javascript_executed_by_openui']
                picture(native/'frame.png', profile)
            native = Path(runs[0]['directory']); snapshot = load(native/'bounds.json')
            assert snapshot['policy'] == policy and snapshot['markers'] == markers
            nodes = snapshot['nodes']; observed = {node['name']:node for node in nodes}
            assert expected.keys() == observed.keys()
            comparison = result['comparisons'][markers]
            assert comparison['native_bounds'] == nodes
            assert comparison['bounds_count'] == len(nodes)
            assert comparison['exact_bounds'] == sum(expected[name] == observed[name] for name in expected)
            assert comparison['analysis'] == analyze_image_difference(directory/f'chromium-1-{markers}-1.png', native/'frame.png')
            comparisons += 1
    assert row['chromium_marker_delta'] == analyze_image_difference(directory/'chromium-1-no-1.png', directory/'chromium-1-yes-1.png')
    for policy, result in row['native'].items():
        if 'marker_delta' in result:
            assert result['marker_delta'] == analyze_image_difference(Path(result['runs']['no'][0]['directory'])/'frame.png', Path(result['runs']['yes'][0]['directory'])/'frame.png')
    if 'policy_delta' in row:
        assert row['policy_delta'] == analyze_image_difference(Path(row['native']['auto']['runs']['no'][0]['directory'])/'frame.png', Path(row['native']['fitted']['runs']['no'][0]['directory'])/'frame.png')
    observations.append(dict(profile=profile, chromium_marker_changed_pixels=row['chromium_marker_delta']['mismatched_pixels'],
                             native={policy:dict(marker_changed_pixels=result.get('marker_delta',{}).get('mismatched_pixels'),
                                      different_pixels={stage:comparison['analysis']['mismatched_pixels'] for stage,comparison in result.get('comparisons',{}).items()},
                                      exact_bounds={stage:comparison['exact_bounds'] for stage,comparison in result.get('comparisons',{}).items()}) for policy,result in row['native'].items()},
                             policy_changed_pixels=row.get('policy_delta',{}).get('mismatched_pixels')))
if 'failure' not in r:
    assert len(r['cases']) == 5 and comparisons == 20
    expected_code = int(any(c['analysis']['mismatched_pixels'] or c['exact_bounds'] != c['bounds_count'] for row in r['cases'] for result in row['native'].values() for c in result['comparisons'].values()))
    assert r['observed_exit_code'] == expected_code
for name in ['cargo', 'rustc', 'rustfmt', 'pixel_compare']:
    assert subprocess.run(['pgrep', '-x', name], capture_output=True).returncode == 1
proof = dict(schema_version=1, complete=True, source=r['source'], owner_terminal=True, owner_absent=True,
             receipt_sha256=sha(OUT/'receipt.json'), audit_driver_sha256=sha(__file__),
             actual_owner_exit_code=r['observed_exit_code'], measurement_failure=r.get('failure'),
             fresh_compiler_records=len(artifacts), compiled_paths_verified=compiled,
             comparisons_verified=comparisons, image_hashes=images, observations=observations,
             renderer_qualified=False, all_native_apis_qualified=False, release_qualified=False,
             retired_for_reexecution_after_source_or_target_mutation=True)
PROOF.write_text(json.dumps(proof, sort_keys=True, indent=2)+'\n')
print(json.dumps(dict(proof=str(PROOF), cases=len(observations), comparisons=comparisons, images=len(images), observations=observations)), flush=True)
