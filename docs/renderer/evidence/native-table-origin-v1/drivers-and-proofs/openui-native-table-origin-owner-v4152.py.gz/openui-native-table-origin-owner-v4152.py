import base64
import fcntl
import hashlib
import json
import os
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path('/home/nero/code/open-ui')
BASE = Path('/mnt/d/openui-v02-qualification-d174ea0b')
DRAFT = BASE / 'native-table-origin-source-v4148'
PROJECT = DRAFT / 'project'
OUT = BASE / 'native-table-origin-v4152'
TARGET = Path('/mnt/e/openui-v02-cargo-c73754e2/target')
TEMP = Path('/dev/shm/ou4152')
sys.path[:0] = [str(ROOT), str(ROOT / 'tools/qualification'), '/tmp']
from openui_parallel_source_identity_v3060 import identity
from tools.accountability import run_all_pixel_comparisons as capture
from residuals import analyze_image_difference

load = lambda path: json.loads(Path(path).read_bytes())
def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

lock = open('/tmp/openui-native-cargo-raster-owner.lock', 'a+')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
for name in ['cargo', 'rustc', 'rustfmt', 'pixel_compare']:
    assert subprocess.run(['pgrep', '-x', name], capture_output=True).returncode == 1
prior = load('/tmp/openui-monochrome-policy-reaped-v4131.json')
assert prior['all_local_commands_terminal'] and prior['owners_absent']
source = identity(ROOT)
assert source['clean'] and source['commit'] == sys.argv[1]
assert not OUT.exists() and not TEMP.exists()
OUT.mkdir(); TEMP.mkdir()
inputs = {str(path): sha(path) for path in sorted(DRAFT.rglob('*')) if path.is_file()}
assert str(PROJECT / 'src/main.rs') in inputs and str(PROJECT / 'Cargo.lock') in inputs
profiles = [dict(width=400, height=240, scale=scale) for scale in [1, 1.25, 1.5, 2, 3]]
env = dict(os.environ, CARGO_TARGET_DIR=str(TARGET), CARGO_PROFILE_DEV_DEBUG='0',
           CARGO_PROFILE_TEST_DEBUG='0', CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='4',
           RUST_MIN_STACK='4194304', PYTHONDONTWRITEBYTECODE='1', TMPDIR=str(TEMP))
env.pop('LD_PRELOAD', None); env.pop('LD_LIBRARY_PATH', None)
chrome = ROOT / 'chrome/linux-147.0.7727.50/chrome-linux64/chrome'
chrome_env = capture.chrome_environment(str(chrome.parent), True, False)
chrome_env['TMPDIR'] = str(TEMP)
report = dict(schema_version=1, owner_pid=os.getpid(), source=source,
              driver_sha256=sha(__file__), input_sha256=inputs, steps=[], cases=[],
              chromium_binary_sha256=sha(chrome),
              chromium_version=subprocess.check_output([str(chrome), '--version'], env=chrome_env, text=True).strip(),
              capture_harness_sha256=sha(ROOT / 'tools/accountability/run_all_pixel_comparisons.py'),
              fontconfig_sha256=sha(chrome_env['FONTCONFIG_FILE']),
              all_commands_terminal=False, pixel_target='pinned Chromium', pixel_tolerance=0,
              javascript_executed_by_openui=False, renderer_qualified=False,
              all_native_apis_qualified=False, release_qualified=False)
assert report['chromium_version'].split()[-1] == '147.0.7727.50'

def save():
    temporary = OUT / 'receipt.tmp'
    temporary.write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
    os.replace(temporary, OUT / 'receipt.json')

def guard():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip() == source['commit']
    assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT) == b''
    for path, expected in inputs.items():
        assert sha(path) == expected, path
    for path, limit in [(ROOT, 128*2**20), (OUT, 10*2**30), (TARGET, 10*2**30), (TEMP, 256*2**20)]:
        assert shutil.disk_usage(path).free > limit, str(path)

def run(name, command, timeout=1200):
    guard(); print('Starting ' + name, flush=True)
    log = OUT / (name + '.log'); child = None
    try:
        with log.open('xb') as stream:
            child = subprocess.Popen(command, cwd=ROOT / 'bindings/rust', env=env,
                                     stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
            report['current_process'] = dict(name=name, pid=child.pid); save()
            started = time.monotonic()
            while child.poll() is None:
                assert time.monotonic() - started < timeout, name
                guard(); time.sleep(1)
            code = child.wait()
    finally:
        if child is not None and child.poll() is None:
            os.killpg(child.pid, signal.SIGTERM)
            try: child.wait(timeout=20)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL); child.wait()
        report.pop('current_process', None)
        report['steps'].append(dict(name=name, command=command, pid=None if child is None else child.pid,
                                   actual_exit_code=None if child is None else child.returncode, log_sha256=sha(log)))
        save()
    guard(); print(json.dumps(dict(stage=name, actual_exit_code=code)), flush=True)
    return code, log

READY = "new Promise(resolve=>{const done=()=>document.fonts.ready.then(()=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));if(document.readyState==='complete')done();else addEventListener('load',done,{once:true});})"
SETUP = "()=>{const b=document.querySelector('#caption').getBoundingClientRect();document.documentElement.style.setProperty('--probe-plain-left',b.x+'px');document.documentElement.style.setProperty('--probe-plain-width',b.width+'px');return true;}"
QUERY = "Array.from(document.querySelectorAll('[id]'),e=>{const box=r=>({x:r.x,y:r.y,width:r.width,height:r.height});const b=e.getBoundingClientRect();return {name:e.id,bounds:box(b),client_rects:Array.from(e.getClientRects(),box),baseline_css_y:e.id.endsWith('-baseline')?b.y:null,baseline_physical_y:e.id.endsWith('-baseline')?b.y*devicePixelRatio:null};})"

def oracle(directory, repeat, profile):
    guard(); browser_profile = TEMP / f'chrome-{directory.name}-{repeat}'; browser_profile.mkdir()
    width, height, scale = [profile[key] for key in ['width', 'height', 'scale']]
    command = [str(chrome), '--headless', '--disable-gpu', '--no-sandbox', '--no-first-run',
               '--no-default-browser-check', '--remote-debugging-port=0',
               f'--user-data-dir={browser_profile}',
               f'--window-size={round(width*scale)},{round(height*scale)+87}', 'about:blank']
    child = subprocess.Popen(command, env=chrome_env, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, start_new_session=True)
    client = None; values = {}; report['current_process'] = dict(name='chromium', pid=child.pid); save()
    try:
        port = capture._wait_for_devtools_endpoint(browser_profile, child)
        client = capture._CdpWebSocket(capture._page_websocket_url(port))
        client.command('Page.enable'); client.command('DOM.enable'); client.command('CSS.enable')
        client.command('Emulation.setDeviceMetricsOverride', dict(width=width, height=height,
                       deviceScaleFactor=scale, mobile=False, screenWidth=width, screenHeight=height))
        for markers in ['no', 'yes']:
            client.command('Page.navigate', dict(url=(DRAFT / f'oracle-{markers}.html').resolve().as_uri()))
            setup = client.command('Runtime.evaluate', dict(expression=READY+'.then('+SETUP+')', awaitPromise=True, returnByValue=True))
            assert 'exceptionDetails' not in setup and setup['result']['value'] is True, setup
            observations = []
            for _ in [1, 2]:
                answer = client.command('Runtime.evaluate', dict(expression=READY+'.then(()=>'+QUERY+')', awaitPromise=True, returnByValue=True))
                assert 'exceptionDetails' not in answer, answer
                observations.append(answer['result']['value'])
            assert observations[0] == observations[1]
            values[markers] = observations[0]
            (directory / f'chromium-{repeat}-{markers}-bounds.json').write_text(json.dumps(values[markers], sort_keys=True, indent=2)+'\n')
            pictures = []
            for number in [1, 2]:
                raw = base64.b64decode(client.command('Page.captureScreenshot', dict(format='png', fromSurface=True, captureBeyondViewport=False))['data'], validate=True)
                (directory / f'chromium-{repeat}-{markers}-{number}.png').write_bytes(raw); pictures.append(raw)
            assert pictures[0] == pictures[1]
            actual = client.command('Runtime.evaluate', dict(expression='({width:innerWidth,height:innerHeight,dpr:devicePixelRatio})', returnByValue=True))['result']['value']
            assert capture._device_metrics_match(actual, width, height, scale)
        return values
    finally:
        if client: client.close()
        capture._stop_chromium_process(child)
        assert child.poll() is not None
        shutil.rmtree(browser_profile)
        report['steps'].append(dict(name=f'{directory.name}-chromium-{repeat}', command=command,
                                   pid=child.pid, actual_exit_code=child.returncode))
        report.pop('current_process', None); save()

save(); code = 1
try:
    cargo = ['cargo', '--config', str(ROOT / 'bindings/rust/.cargo/config.chromium.toml')]
    manifest = ['--manifest-path', str(PROJECT / 'Cargo.toml')]
    status, log = run('metadata', cargo+['metadata', '--locked', '--offline', '--format-version', '1']+manifest); assert status == 0
    metadata = load(log)
    local_ids = {p['id'] for p in metadata['packages'] if Path(p['manifest_path']).resolve().is_relative_to(ROOT) or Path(p['manifest_path']).resolve().is_relative_to(PROJECT)}
    status, _ = run('clean-local-packages', cargo+['clean', '--locked', '--offline']+manifest+[arg for pid in sorted(local_ids) for arg in ['-p', pid]]); assert status == 0
    status, log = run('native-build', cargo+['build', '--locked', '--offline', '--message-format=json-render-diagnostics']+manifest); assert status == 0
    artifacts = []; compiled = {}; binary = None
    for line in log.read_text().splitlines():
        try: row = json.loads(line)
        except json.JSONDecodeError: continue
        if row.get('reason') == 'compiler-artifact' and row['package_id'] in local_ids:
            assert not row['fresh']; artifacts.append(row)
            for path in row['filenames']: compiled[path] = sha(path)
            if row.get('executable') and Path(row['target']['src_path']).resolve().is_relative_to(PROJECT):
                binary = Path(row['executable'])
    assert binary and len({row['package_id'] for row in artifacts}) == len(local_ids)
    retained = OUT / 'native-consumer'; shutil.copyfile(binary, retained); retained.chmod(0o755)
    assert sha(retained) == sha(binary)
    report.update(binary=str(binary), binary_sha256=sha(binary), retained_binary=str(retained),
                  compiler_artifacts=artifacts, compiled_artifact_sha256=compiled); save()
    for index, profile in enumerate(profiles):
        directory = OUT / f'profile-{index}'; directory.mkdir()
        geometry = [oracle(directory, repeat, profile) for repeat in [1, 2]]
        assert geometry[0] == geometry[1]
        for markers in ['no', 'yes']:
            assert sha(directory/f'chromium-1-{markers}-1.png') == sha(directory/f'chromium-2-{markers}-1.png')
        row = dict(profile=profile, chromium_bounds=geometry[0], chromium_marker_delta=analyze_image_difference(directory/'chromium-1-no-1.png', directory/'chromium-1-yes-1.png'), native={})
        report['cases'].append(row); save()
        for policy in ['auto', 'fitted']:
            result = dict(runs={}, comparisons={}); row['native'][policy] = result
            for markers in ['no', 'yes']:
                runs = []
                for repeat in [1, 2]:
                    native = directory / f'native-{policy}-{markers}-{repeat}'
                    status, _ = run(f'profile-{index}-{policy}-{markers}-{repeat}', [str(retained), str(native), str(profile['width']), str(profile['height']), str(profile['scale']), policy, markers], timeout=120)
                    assert status == 0
                    runs.append(dict(directory=str(native), files={p.name:sha(p) for p in sorted(native.iterdir()) if p.is_file()}))
                assert runs[0]['files'] == runs[1]['files']
                result['runs'][markers] = runs
                native = Path(runs[0]['directory']); snapshot = load(native/'bounds.json'); bounds = snapshot['nodes']
                expected = {b['name']:b for b in geometry[0][markers]}
                observed = {b['name']:b for b in bounds}
                assert expected.keys() == observed.keys(), (expected.keys(), observed.keys())
                result['comparisons'][markers] = dict(native_bounds=bounds,
                     bounds_count=len(bounds), exact_bounds=sum(observed[name]==expected[name] for name in expected),
                     analysis=analyze_image_difference(directory/f'chromium-1-{markers}-1.png', native/'frame.png'))
                save()
            result['marker_delta'] = analyze_image_difference(Path(result['runs']['no'][0]['directory'])/'frame.png', Path(result['runs']['yes'][0]['directory'])/'frame.png')
            print(json.dumps(dict(profile=profile, policy=policy, exact_bounds={k:v['exact_bounds'] for k,v in result['comparisons'].items()}, different_pixels={k:v['analysis']['mismatched_pixels'] for k,v in result['comparisons'].items()}, marker_changed_pixels=result['marker_delta']['mismatched_pixels'])), flush=True); save()
        row['policy_delta'] = analyze_image_difference(Path(row['native']['auto']['runs']['no'][0]['directory'])/'frame.png', Path(row['native']['fitted']['runs']['no'][0]['directory'])/'frame.png')
        save()
    code = int(any(c['analysis']['mismatched_pixels'] or c['exact_bounds'] != c['bounds_count'] for row in report['cases'] for result in row['native'].values() for c in result['comparisons'].values()))
except BaseException as exc:
    report['failure'] = repr(exc); raise
finally:
    report['source_after'] = identity(ROOT)
    report['source_unchanged'] = report['source_after'] == source
    report['inputs_unchanged'] = all(sha(path) == value for path,value in inputs.items())
    report['all_commands_terminal'] = True; report['observed_exit_code'] = code; save()
print(json.dumps(dict(actual_exit_code=code, cases=len(report['cases']), source_unchanged=report['source_unchanged'])), flush=True)
raise SystemExit(code)
