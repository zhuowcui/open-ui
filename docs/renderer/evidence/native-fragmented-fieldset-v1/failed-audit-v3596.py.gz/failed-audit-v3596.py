import fcntl, hashlib, json, subprocess, sys
from pathlib import Path

MAIN = Path('/home/nero/code/open-ui')
SDK = Path('/dev/shm/openui-native-fragmented-fieldset-source-v3593')
OUT = Path('/mnt/d/openui-v02-qualification-d174ea0b/native-fragmented-fieldset-candidate-compare-v3595')
BASE = Path('/mnt/d/openui-v02-qualification-d174ea0b/native-fragmented-fieldset-sweep-v3585')
BUILD = Path('/mnt/d/openui-v02-qualification-d174ea0b/native-fragmented-fieldset-build-v3593')
PROOF = Path('/tmp/openui-native-fragmented-fieldset-candidate-compare-terminal-v3596.json')
NEIGHBORS = Path('/mnt/d/openui-v02-qualification-d174ea0b/native-fragmented-fieldset-sweep-v3591')
BORDER = Path('/mnt/d/openui-v02-qualification-d174ea0b/native-fragmented-fieldset-candidate-compare-v3589')
sys.path.insert(0, str(MAIN)); sys.path.insert(0, '/tmp')
from openui_parallel_source_identity_v3060 import identity
from tools.qualification.residuals import analyze_image_difference

sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda p: json.loads(Path(p).read_bytes())
lock = open('/tmp/openui-native-cargo-raster-owner.lock', 'a+')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
r = load(OUT / 'receipt.json')
assert r['all_commands_terminal']
assert subprocess.run(['ps', '-p', str(r['owner_pid'])], capture_output=True).returncode == 1
for name in ['cargo', 'rustc', 'rustfmt', 'pixel_compare', 'native_fragmente']:
    assert subprocess.run(['pgrep', '-x', name], capture_output=True).returncode == 1
assert identity(MAIN) == r['main_source'] == r['main_source_after']
assert identity(SDK) == r['source'] == r['source_after']
assert sha('/tmp/openui-native-fragmented-fieldset-candidate-compare-v3595.py') == r['driver_sha256']
assert sha('/tmp/openui_parallel_source_identity_v3060.py') == r['source_identity_reader_sha256']
for path, key in [(BUILD / 'receipt.json', 'build_receipt_sha256'),
                  (BUILD / 'native_fragmente', 'native_binary_sha256'),
                  (BASE / 'receipt.json', 'baseline_receipt_sha256'),
                  (Path('/tmp/openui-native-fragmented-fieldset-build-terminal-v3594.json'), 'build_audit_sha256'),
                  (Path('/tmp/openui-native-fragmented-fieldset-sweep-terminal-v3586.json'), 'baseline_terminal_sha256'),
                  (NEIGHBORS / 'receipt.json', 'neighbor_receipt_sha256'),
                  (Path('/tmp/openui-native-fragmented-fieldset-sweep-terminal-v3592.json'), 'neighbor_terminal_sha256'),
                  (BORDER / 'receipt.json', 'border_receipt_sha256')]:
    assert sha(path) == r[key]
baseline = load(BASE / 'receipt.json')
old_proof = load('/tmp/openui-native-fragmented-fieldset-sweep-terminal-v3586.json')
for path, digest in old_proof['all_preserved_file_sha256'].items():
    assert sha(BASE / path) == digest
for path, digest in load('/tmp/openui-native-fragmented-fieldset-sweep-terminal-v3592.json')['all_preserved_file_sha256'].items():
    assert sha(NEIGHBORS / path) == digest
border = load(BORDER / 'receipt.json')
results = []
for row in r['cases']:
    directory = OUT / row['directory']
    base = Path(row['reference_base']); assert base in [BASE, NEIGHBORS]
    original = load(base / 'receipt.json')
    old = next(case for case in original['cases'] if case.get('directory',f"scale-{case['scale']:g}") == row['directory'])
    assert (row['scale'], row['phase'], row['alpha'], row['mode']) == (old['scale'], old['phase'], old['alpha'], old['mode'])
    assert len(row['native_runs']) == 2
    for i, run in enumerate(row['native_runs'], 1):
        assert run['actual_exit_code'] == 0
        assert sha(directory / f'native-{i}.log') == run['log_sha256']
        assert load(directory / f'native-{i}/geometry.json') == row['native_geometry']
    assert row['native_geometry']['callbacks'] == 4
    assert (directory / 'native-1/openui.png').read_bytes() == (directory / 'native-2/openui.png').read_bytes()
    assert row['chromium_geometry'] == old['chromium_geometry']
    reference = base / row['directory'] / old['chromium_reference_runs'][0]['selected_reference']
    assert Path(row['reference_png']) == reference
    assert sha(reference) == row['chromium_png_sha256'] == old['chromium_png_sha256']
    assert sha(directory / 'native-1/openui.png') == row['native_png_sha256']
    assert row['analysis'] == analyze_image_difference(reference, directory / 'native-1/openui.png')
    assert row['geometry_exact'] == (row['native_geometry']['nodes'] == old['chromium_geometry']['nodes'])
    assert row['fragment_rects_exact'] == (row['native_geometry']['rects'] == old['chromium_geometry']['rects'])
    assert row['baseline_wrong_pixels'] == old['analysis']['mismatched_pixels']
    before = (next(case['analysis']['mismatched_pixels'] for case in border['cases'] if case['scale'] == row['scale']) if base == BASE else old['analysis']['mismatched_pixels'])
    assert row['border_candidate_wrong_pixels'] == before
    results.append(dict(scale=row['scale'], phase=row['phase'], alpha=row['alpha'], border_candidate_wrong_pixels=before, geometry_exact=row['geometry_exact'],
                        fragment_rects_exact=row['fragment_rects_exact'],
                        baseline_wrong_pixels=row['baseline_wrong_pixels'],
                        candidate_wrong_pixels=row['analysis']['mismatched_pixels']))
if r['observed_exit_code'] == 0:
    assert len(results) == r['expected_cases'] and 'failure' not in r
proof = dict(schema_version=1, owner_absent=True, all_local_commands_terminal=True,
             actual_exit_code=r['observed_exit_code'], source=r['source'], main_source=r['main_source'],
             receipt_sha256=sha(OUT / 'receipt.json'), results=results,
             all_preserved_file_sha256={str(path.relative_to(OUT)): sha(path)
                                       for path in sorted(OUT.rglob('*')) if path.is_file()},
             pinned_chromium_references_unchanged=True, diagnostic_only=True, release_qualified=False,
             retired_for_reexecution_after_source_or_target_mutation=True, audit_driver_sha256=sha(__file__))
assert not PROOF.exists()
PROOF.write_text(json.dumps(proof, sort_keys=True, indent=2) + '\n')
print(json.dumps(dict(proof=str(PROOF), results=results, actual_exit_code=r['observed_exit_code'])), flush=True)
