"""Record terminal observations after the whole renderer and audit are reaped."""
import argparse
import fcntl
import hashlib
import json
import subprocess
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--owner-exit', type=int, required=True)
parser.add_argument('--audit-exit', type=int, required=True)
parser.add_argument('--audit-session', type=int, required=True)
args = parser.parse_args()
out = Path('/mnt/d/openui-v02-qualification-d174ea0b/private-fragmented-fieldset-renderer-v3597')
audit_path = Path('/tmp/openui-private-fragmented-fieldset-renderer-completed-audit-v3598.json')
proof_path = Path('/tmp/openui-private-fragmented-fieldset-renderer-terminal-v3604.json')

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

lock = open('/tmp/openui-native-cargo-raster-owner.lock', 'a+')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
receipt = json.loads((out / 'receipt.json').read_bytes())
audit = json.loads(audit_path.read_bytes())
assert receipt['all_commands_terminal'] and receipt['source_unchanged'] and receipt['public_source_unchanged']
assert audit['complete'] and audit['owner_terminal'] and audit['owner_absent']
assert args.owner_exit == receipt['observed_exit_code'] == audit['actual_whole_exit_code']
assert args.audit_exit == 0
assert audit['receipt_sha256'] == sha(out / 'receipt.json')
assert subprocess.run(['ps', '-p', str(receipt['owner_pid'])], capture_output=True).returncode == 1
for name in ['cargo', 'rustc', 'rustfmt', 'pixel_compare']:
    assert subprocess.run(['pgrep', '-x', name], capture_output=True).returncode == 1
owned = [b'openui-private-fragmented-fieldset-renderer-v3597.py',
         b'openui-private-fragmented-fieldset-renderer-audit-v3598.py']
for entry in Path('/proc').iterdir():
    if not entry.name.isdigit():
        continue
    try:
        command = (entry / 'cmdline').read_bytes()
    except (FileNotFoundError, ProcessLookupError, PermissionError):
        continue
    assert not any(name in command for name in owned), command
assert not proof_path.exists()
proof = dict(schema_version=1, owner_pid=receipt['owner_pid'], owner_session=60389,
             audit_session=args.audit_session, actual_owner_exit_code=args.owner_exit,
             actual_audit_exit_code=args.audit_exit, all_local_commands_terminal=True,
             owner_absent=True, receipt_sha256=sha(out / 'receipt.json'),
             audit_sha256=sha(audit_path), source=audit['source'], public_source=audit['public_source'],
             results=audit['results'], candidate_nonregression=audit['candidate_nonregression'],
             preserved_chronological_native_and_renderer_proofs=True,
             retired_for_reexecution_after_source_or_target_mutation=True,
             implementation_integrated=False, renderer_qualified=False,
             all_native_apis_qualified=False, release_qualified=False)
proof_path.write_text(json.dumps(proof, sort_keys=True, indent=2) + '\n')
print(json.dumps(proof), flush=True)
