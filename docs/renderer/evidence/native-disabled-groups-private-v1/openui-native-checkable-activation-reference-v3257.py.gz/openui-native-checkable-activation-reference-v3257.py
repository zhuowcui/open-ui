import fcntl,hashlib,json,os,subprocess,sys,tempfile
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');NAME='native-checkable-activation-reference-v3257';RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';OUT=Path('/mnt/e/openui-v02-qualification-d174ea0b')/NAME
lock=open('/tmp/'+NAME+'.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert not OUT.exists() and not (RAW/NAME).exists();OUT.mkdir();(RAW/NAME).symlink_to(OUT,target_is_directory=True)
sys.path.insert(0,str(MAIN/'tools/accountability'));import run_all_pixel_comparisons as capture
sys.path.insert(0,'/tmp');from openui_parallel_source_identity_v3060 import identity
source=identity(MAIN);assert source['clean'] and source['commit']=='1d54fc50f7b225d8a39b6a8962fe7159d7651852'
prior_reference=json.loads((RAW/'native-checkable-default-reference-v3249/receipt.json').read_bytes());assert prior_reference['all_commands_terminal'] and prior_reference['observed_exit_code']==0 and prior_reference['source_unchanged']
chrome=MAIN/'chrome/linux-147.0.7727.50/chrome-linux64/chrome';scratch=Path('/dev/shm/ou3257');scratch.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
cases=[('neighbor-click', 'a.checked=true', 'b.click()'), ('already-checked-click', 'b.checked=true', 'b.click()'), ('neighbor-callback-check-old', 'a.checked=true;b.addEventListener("click",()=>a.checked=true)', 'b.click()'), ('neighbor-callback-check-other', 'a.checked=true;b.addEventListener("click",()=>second.checked=true)', 'b.click()'), ('neighbor-callback-disable', 'a.checked=true;b.addEventListener("click",()=>b.disabled=true)', 'b.click()'), ('neighbor-callback-rename', 'a.checked=true;b.addEventListener("click",()=>b.name="other")', 'b.click()'), ('neighbor-callback-form', 'a.checked=true;b.addEventListener("click",()=>document.getElementById("fb").appendChild(b))', 'b.click()'), ('neighbor-callback-detach', 'a.checked=true;b.addEventListener("click",()=>b.remove())', 'b.click()'), ('neighbor-callback-default', 'a.checked=true;b.addEventListener("click",()=>a.setAttribute("checked",""))', 'b.click()'), ('neighbor-cancel-detach', 'a.checked=true;b.addEventListener("click",e=>{b.remove();e.preventDefault()})', 'b.click()'), ('neighbor-cancel-check-other', 'a.checked=true;b.addEventListener("click",e=>{second.checked=true;e.preventDefault()})', 'b.click()'), ('neighbor-cancel-rename', 'a.checked=true;b.addEventListener("click",e=>{b.name="other";e.preventDefault()})', 'b.click()'), ('neighbor-cancel-form', 'a.checked=true;b.addEventListener("click",e=>{document.getElementById("fb").appendChild(b);e.preventDefault()})', 'b.click()'), ('neighbor-cancel-default', 'a.checked=true;b.addEventListener("click",e=>{a.setAttribute("checked","");e.preventDefault()})', 'b.click()'), ('indeterminate-click', 'b.indeterminate=true', 'b.click()'), ('indeterminate-cancel', 'b.indeterminate=true;b.addEventListener("click",e=>e.preventDefault())', 'b.click()'), ('indeterminate-callback', 'b.indeterminate=true;b.addEventListener("click",()=>b.indeterminate=true)', 'b.click()'), ('disabled-neighbor-click', 'a.checked=true;a.disabled=true', 'b.click()'), ('fieldset-disabled-neighbor-click', 'a.checked=true;f.disabled=true', 'b.click()'), ('default-checked-neighbor-click', 'a.setAttribute("checked","")', 'b.click()')]


setup="""document.body.innerHTML='<form id=fa></form><form id=fb></form><fieldset id=f><legend><input id=first type=TYPE name=g></legend><legend><input id=second type=TYPE name=g></legend><input id=a type=TYPE name=g></fieldset><input id=b type=TYPE name=g>';
for(const id of ['f','first','second','a','b'])window[id]=document.getElementById(id);
window.fields=[first,second,a,b];window.rows=[];
window.snapshot=()=>({controls:Object.fromEntries(fields.map(node=>[node.id,{checked:node.checked,checkedAttribute:node.hasAttribute('checked'),defaultChecked:node.defaultChecked,indeterminate:node.indeterminate,own:node.disabled,effective:node.matches(':disabled'),connected:node.isConnected}])),active:document.activeElement.id||'body'});
for(const node of fields)for(const type of ['click','input','change','focus','focusin','blur','focusout'])node.addEventListener(type,event=>rows.push({type,target:event.target.id,bubbles:event.bubbles,cancelable:event.cancelable,...snapshot()}));true"""
report=dict(schema_version=1,source=source,owner_pid=os.getpid(),all_commands_terminal=False,script_runs_only_in_offline_chromium=True,javascript_executed_by_openui=False,native_api_behavior_measured=False,release_qualified=False,diagnostic_only=True,probe_sha256=sha(__file__),chrome_sha256=sha(chrome),harness_sha256=sha(MAIN/'tools/accountability/run_all_pixel_comparisons.py'),runs=[])
assert report['chrome_sha256']==prior_reference['chrome_sha256'] and report['harness_sha256']==prior_reference['harness_sha256']
report['prior_reference_receipt_sha256']=sha(RAW/'native-checkable-default-reference-v3249/receipt.json')
def save():(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
def evaluate(client,text,promise=False):
 r=client.command('Runtime.evaluate',dict(expression=text,returnByValue=True,awaitPromise=promise));assert 'exceptionDetails' not in r,r;return r['result'].get('value')
def barrier(client):return evaluate(client,'new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve(true))))',True)
save()
try:
 for repeat in [1,2]:
  observations=[]
  process=None;client=None
  with tempfile.TemporaryDirectory(prefix='chrome-',dir=scratch) as profile:
   try:
    command=[str(chrome),'--headless','--disable-gpu','--no-sandbox','--no-first-run','--no-default-browser-check','--remote-debugging-port=0','--user-data-dir='+profile,'--window-size=800,687','about:blank'];process=subprocess.Popen(command,env=capture.chrome_environment(str(chrome.parent)),stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True);report['current_process']=dict(pid=process.pid,repeat=repeat);save();port=capture._wait_for_devtools_endpoint(profile,process);client=capture._CdpWebSocket(capture._page_websocket_url(port));client.command('Page.enable');client.command('Page.bringToFront');client.command('Emulation.setFocusEmulationEnabled',dict(enabled=True))
    for tag in ['radio','checkbox']:
     for name,pre,action in cases:
      evaluate(client,setup.replace('TYPE',tag));barrier(client);evaluate(client,pre+';rows.length=0;true');initial=evaluate(client,'snapshot()');synchronous=evaluate(client,'(()=>{'+action+'})();({rows:rows.slice(),state:snapshot()})');barrier(client);observed=evaluate(client,'({rows:rows.slice(),state:snapshot()})');observations.append(dict(scenario=tag+'-'+name,control=tag,variant=name,initial=initial,synchronous=synchronous,observed=observed));report['current_scenario']=tag+'-'+name;save()
   finally:capture._close_chromium_client(client);capture._stop_chromium_process(process);report.pop('current_process',None);save()
  report.pop('current_scenario',None);path=OUT/('observations-'+str(repeat)+'.json');path.write_text(json.dumps(observations,sort_keys=True,indent=2)+'\n');report['runs'].append(dict(repeat=repeat,scenarios=len(observations),callback_rows=sum(len(x['observed']['rows']) for x in observations),observations_sha256=sha(path)));save();print(json.dumps(report['runs'][-1]),flush=True)
 assert (OUT/'observations-1.json').read_bytes()==(OUT/'observations-2.json').read_bytes();report['repeated_observations_identical']=True;report['observed_exit_code']=0
except BaseException as error:report.update(observed_exit_code=1,failure=repr(error));raise
finally:
 report.update(source_after=identity(MAIN),all_commands_terminal=True);report['source_unchanged']=report['source_after']==source;assert report['source_unchanged'];assert sha(chrome)==report['chrome_sha256'] and sha(MAIN/'tools/accountability/run_all_pixel_comparisons.py')==report['harness_sha256'];save()
print(json.dumps(dict(all_commands_terminal=True,observed_exit_code=report['observed_exit_code'],scenarios=report['runs'])),flush=True)
raise SystemExit(report['observed_exit_code'])
