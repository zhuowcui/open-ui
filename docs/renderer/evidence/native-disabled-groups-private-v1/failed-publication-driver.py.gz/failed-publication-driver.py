import fcntl,gzip,hashlib,json,os,subprocess
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');SDK=Path('/mnt/e/openui-v02-qualification-d174ea0b/private-native-effective-disabled-source-v3210');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1'
NAME='native-disabled-groups-private-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for program in ['cargo','rustc','pixel_compare','rustfmt']:assert subprocess.run(['pgrep','-x',program],capture_output=True).returncode==1
assert subprocess.check_output(['git','-C',str(MAIN),'rev-parse','HEAD'],text=True).strip()=='1d54fc50f7b225d8a39b6a8962fe7159d7651852'
assert not subprocess.check_output(['git','-C',str(MAIN),'status','--porcelain'])
r=read(RAW/'private-native-group-renderer-v3244/receipt.json');a=read('/tmp/openui-private-native-group-renderer-completed-audit-v3254.json')
assert r['all_commands_terminal'] and r['stage']=='terminal' and r['candidate_nonregression_verified'] and r['source_unchanged'] and r['public_source_unchanged']
assert a['owner_terminal'] and a['receipt_sha256']==sha(RAW/'private-native-group-renderer-v3244/receipt.json')
assert subprocess.run(['ps','-p',str(r['owner_pid'])],capture_output=True).returncode==1
n=read(RAW/'private-native-effective-disabled-v3238/receipt.json');na=read('/tmp/openui-native-effective-disabled-completed-audit-v3241.json')
assert n['all_commands_terminal'] and n['observed_exit_code']==0 and na['owner_terminal'] and na['receipt_sha256']==sha(RAW/'private-native-effective-disabled-v3238/receipt.json')
assert n['source']==r['source'] and n['main_source']==r['public_source']
assert a['matrix_rows_verified']==48252 and a['chromium_reference_fields_unchanged']
assert n['scenario_counts']=={language:dict(total=88,exact=88) for language in ['rust','c','cpp']}
ready=read('/tmp/openui-native-disabled-integration-readiness-v3259.json');assert ready['private_source']==n['source']['commit'] and len(ready['files'])==19
assert sha('/tmp/openui-native-disabled-integration-patch-v3259.diff')==ready['patch_sha256']
for item in ready['files']:
    target=MAIN/item['path'];assert sha(SDK/item['path'])==item['after_sha256']
    if item['before_sha256'] is None:assert not target.exists()
    else:assert sha(target)==item['before_sha256']
# Atomically replace existing files: the private checkout can share hardlinks.
for item in ready['files']:
    target=MAIN/item['path'];target.parent.mkdir(parents=True,exist_ok=True)
    temp=target.with_name(target.name+'.native-disabled-integration');assert not temp.exists()
    temp.write_bytes((SDK/item['path']).read_bytes());os.replace(temp,target)
    assert sha(target)==item['after_sha256']
files=[]
def commands(name,prefix):
    directory=RAW/name;receipt=read(directory/'receipt.json')
    assert receipt['all_commands_terminal']
    files.append((directory/'receipt.json',prefix+'-receipt.json'))
    for step in receipt.get('steps',[]):
        path=directory/(step['name']+'.log');assert sha(path)==step['log_sha256'];files.append((path,prefix+'-'+path.name))
    return receipt
commands('private-native-effective-disabled-v3231','failed-native');commands('private-native-effective-disabled-v3238','private-native');commands('private-native-group-renderer-v3244','private-renderer')
for filename in ['openui-native-effective-disabled-failed-audit-v3236.json','openui-native-effective-disabled-completed-audit-v3241.json','openui-private-native-group-renderer-completed-audit-v3254.json','openui-native-checkable-reference-audit-v3250.json','openui-native-checkable-reference-audit-v3258.json','openui-native-disabled-integration-readiness-v3259.json','openui-native-disabled-integration-patch-v3259.diff','openui-native-checkable-investigation-v3261.json','openui-public-doc-checkpoint-hosted-v3245.json']:
    files.append((Path('/tmp')/filename,filename))
renderer=RAW/'private-native-group-renderer-v3244'
for suite in ['focused','primitive','full','expanded']:
    path=renderer/'trial'/(suite+'-matrix')/(suite+'-summary.json');assert sha(path)==r['matrices']['trial-'+suite]['summary_sha256'];files.append((path,suite+'-summary.json'))
build_dir=renderer/'trial/guarded-build';build=read(build_dir/'receipt.json');assert sha(build_dir/'receipt.json')==r['guarded_build_receipt_sha256']
files.append((build_dir/'receipt.json','guarded-build-receipt.json'));files.append((renderer/'embedded-source-identity.json','embedded-source-identity.json'))
for step in build['steps']:
    for stream in ['stdout','stderr']:
        path=build_dir/(step['name']+'.'+stream);assert sha(path)==step[stream+'_sha256'];files.append((path,'guarded-build-'+path.name))
for name in ['native-radio-programmatic-reference-v3242','native-checkable-default-reference-v3248','native-checkable-default-reference-v3249','native-checkable-activation-reference-v3257']:
    directory=RAW/name;ref=read(directory/'receipt.json');assert ref['all_commands_terminal'] and ref['source_unchanged']
    files.append((directory/'receipt.json',name+'-receipt.json'))
    if ref['observed_exit_code']==0:
        assert (directory/'observations-1.json').read_bytes()==(directory/'observations-2.json').read_bytes()
        for repeat in [1,2]:files.append((directory/('observations-'+str(repeat)+'.json'),name+'-observations-'+str(repeat)+'.json'))
for filename in ['openui-private-native-effective-disabled-owner-v3238.py','openui-private-native-group-renderer-v3244.py','openui-private-native-group-renderer-completed-audit-v3254.py','openui-native-checkable-activation-reference-v3257.py','openui-native-checkable-reference-audit-v3258.py','openui-public-native-disabled-groups-owner-v3264.py','openui-public-native-disabled-groups-completed-audit-v3265.py']:
    files.append((Path('/tmp')/filename,filename))
assert len({label for _,label in files})==len(files)
destination=MAIN/'docs/renderer/evidence'/NAME;index=MAIN/'docs/renderer/generated'/(NAME+'.json');assert not destination.exists() and not index.exists();destination.mkdir()
evidence=[]
for original,label in files:
    data=original.read_bytes();path=destination/(label+'.gz');path.write_bytes(gzip.compress(data,compresslevel=9,mtime=0));assert gzip.decompress(path.read_bytes())==data
    evidence.append(dict(path=str(path.relative_to(MAIN)),original_path=str(original),sha256=sha(path),decoded_sha256=hashlib.sha256(data).hexdigest()))
report=dict(schema_version=1,measured_private_source=n['source'],public_source_before_integration=r['public_source'],implementation_present_on_public_branch=True,public_combined_source_qualified=False,private_native_actual_whole_exit_code=0,native_counts=n['scenario_counts'],prior_109_rust_c_cpp_scenarios_unchanged=True,repeated_process_pairs=21,unit_guards=197,integration_guards=23,c_exports=127,c_layouts=34,old_125_exports_and_all_layouts_preserved=True,c_consumers=24,cpp_consumers=18,c_state_projection='five common fields: own,property,effective,enabled,connected; kind and parent observed by Rust only',private_completed_native_audit=na,private_completed_renderer_audit=a,measured_renderer_results=a['results'],chromium_reference_fields_unchanged=True,pixel_target='pinned Chromium',pixel_tolerance=0,archived_openui_images_are_history_only=True,javascript_executed_by_openui=False,checkable_reference_cases=110,checkable_native_behavior_qualified=False,default_disabled_control_appearance_qualified=False,all_native_apis_qualified=False,renderer_qualified=False,release_qualified=False,hardware_qualified=False,evidence=evidence)
index.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(index=str(index),files=len(evidence),implementation_files=len(ready['files']),new_public_qualification_claimed=False)),flush=True)
