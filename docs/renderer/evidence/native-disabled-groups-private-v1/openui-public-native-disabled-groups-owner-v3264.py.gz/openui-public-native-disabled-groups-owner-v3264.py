import fcntl,hashlib,json,os,shutil,signal,subprocess,sys,time
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');SDK=MAIN;RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1'
NAME='public-native-disabled-groups-v3264';OUT=Path('/mnt/e/openui-v02-qualification-d174ea0b')/NAME
assert json.loads((RAW/'public-native-api-renderer-v3190/receipt.json').read_bytes())['all_commands_terminal']
assert json.loads(Path('/tmp/openui-public-native-api-renderer-completed-audit-v3204.json').read_bytes())['owner_terminal']
failed=json.loads((RAW/'private-native-effective-disabled-v3231/receipt.json').read_bytes());assert failed['all_commands_terminal'] and failed['observed_exit_code']==1 and failed['source_unchanged'] and failed['main_source_unchanged'];assert Path('/tmp/openui-private-native-effective-disabled-failed-audit-v3236.json').exists()
renderer=json.loads((RAW/'private-native-group-renderer-v3244/receipt.json').read_bytes());completed=json.loads(Path('/tmp/openui-private-native-group-renderer-completed-audit-v3254.json').read_bytes());assert renderer['all_commands_terminal'] and renderer['source_unchanged'] and renderer['public_source_unchanged'] and renderer['candidate_nonregression_verified'] and completed['owner_terminal']
assert completed['receipt_sha256']==hashlib.sha256((RAW/'private-native-group-renderer-v3244/receipt.json').read_bytes()).hexdigest()
assert subprocess.run(['ps','-p',str(renderer['owner_pid'])],capture_output=True).returncode==1
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','pixel_compare','rustfmt']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
assert not OUT.exists() and not (RAW/NAME).exists();OUT.mkdir();(RAW/NAME).symlink_to(OUT,target_is_directory=True)
sys.path.insert(0,'/tmp');from openui_parallel_source_identity_v3060 import identity
source=identity(SDK);assert source['clean'] and source['commit']==Path('/tmp/openui-native-disabled-public-pin-v3263.txt').read_text().strip()
main_source=identity(MAIN);assert main_source['clean']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
references={}
for name in ['native-fieldset-reference-v3192','native-fieldset-neighbors-reference-v3211','native-disabled-state-reference-v3212']:
 directory=RAW/name;r=json.loads((directory/'receipt.json').read_bytes());assert r['all_commands_terminal'] and r['observed_exit_code']==0 and r['source_unchanged'];assert (directory/'observations-1.json').read_bytes()==(directory/'observations-2.json').read_bytes()
 for file in ['receipt.json','observations-1.json','observations-2.json']:references[str(directory/file)]=sha(directory/file)
regression=RAW/'public-native-selection-v3182';prior=json.loads((regression/'receipt.json').read_bytes());assert prior['all_commands_terminal'] and prior['observed_exit_code']==0
reference_modes=dict(focus='native-fieldset-reference-v3192',neighbors='native-fieldset-neighbors-reference-v3211',state='native-disabled-state-reference-v3212')
report=dict(schema_version=1,source=source,main_source=main_source,steps=[],owner_pid=os.getpid(),all_commands_terminal=False,driver_sha256=sha(__file__),reference_inputs_sha256=references,pixel_tolerance=0,javascript_executed_by_openui=False,all_native_apis_qualified=False,release_qualified=False,renderer_qualified=False,implementation_integrated=True)
env=dict(os.environ,CARGO_TARGET_DIR='/mnt/e/openui-v02-cargo-c73754e2/target',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='4',RUST_MIN_STACK='4194304',PYTHONDONTWRITEBYTECODE='1',TMPDIR='/dev/shm')
env.pop('LD_PRELOAD',None);env.pop('LD_LIBRARY_PATH',None);local={};proof={}
def save():(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
def run(name,command):
 with (OUT/(name+'.log')).open('xb') as log:
  child=subprocess.Popen(command,cwd=SDK/'bindings/rust',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);report['current_process']=dict(pid=child.pid,name=name);save()
  try:
   while child.poll() is None:
    if shutil.disk_usage(MAIN).free<128*2**20 or shutil.disk_usage(OUT).free<8*2**30:
     report['disk_guard_triggered']=True;os.killpg(child.pid,signal.SIGTERM);break
    time.sleep(1)
   code=child.wait()
  except BaseException:
   if child.poll() is None:os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=20)
   raise
  finally:
   report.pop('current_process',None);report['steps'].append(dict(name=name,command=command,actual_exit_code=child.returncode,log_sha256=sha(OUT/(name+'.log'))));save()
 print(json.dumps(report['steps'][-1]),flush=True);assert code==0,name
 data=(OUT/(name+'.log')).read_bytes()
 if local and command[0]=='cargo':
  artifacts=[]
  for line in data.splitlines():
   if not line.startswith(b'{'):continue
   record=json.loads(line)
   if record.get('reason')!='compiler-artifact' or record['target']['kind']==['custom-build'] or record['package_id'] not in local:continue
   assert Path(record['manifest_path']).resolve()==Path(local[record['package_id']]['manifest_path']).resolve()
   assert Path(record['target']['src_path']).resolve().is_relative_to(SDK.resolve())
   hashes={p:sha(p) for p in record['filenames']}
   if record['fresh']:assert name!='control-tests' and all(proof.get(p)==h for p,h in hashes.items()),record
   proof.update(hashes);artifacts.append(dict(record=record,sha256=hashes))
  if artifacts:report.setdefault('local_artifacts',{})[name]=artifacts;save()
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=SDK,text=True).strip()==source['commit'] and not subprocess.check_output(['git','status','--porcelain'],cwd=SDK)
 return data
save()
try:
 cargo=['cargo','--config',str(SDK/'bindings/rust/.cargo/config.chromium.toml')]
 metadata=json.loads(run('locked-metadata',cargo+['metadata','--locked','--offline','--format-version','1']))
 local={p['id']:p for p in metadata['packages'] if p['source'] is None};assert all(Path(p['manifest_path']).resolve().is_relative_to(SDK.resolve()) for p in local.values())
 run('clean-local-packages',cargo+['clean','--locked']+[a for p in local for a in ['-p',p]])
 run('control-tests',cargo+['test','--locked','--offline','-p','openui-engine','-p','openui','-p','openui-ffi','--features','openui-ffi/linux','--lib','--message-format=json'])
 run('native-focus-integration-guards',cargo+['test','--locked','--offline','-p','openui','--features','linux,ffi-integration','--test','native_focus','--test','native_input_notifications','--test','native_disabled_groups','--message-format=json'])
 app_names=['native_fieldset','native_input_metadata','native_selection_phases','native_selection_values','native_range_scalar','native_range_modes','native_disabled_focus']
 run('native-app-build',cargo+['build','--locked','--offline','-p','openui',*[arg for name in app_names for arg in ['--example',name]],'--features','linux,ffi-integration','--message-format=json'])
 report['binaries']={}
 for name in app_names:
  binary=OUT/name;shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/examples'/name,binary);assert sha(binary) in proof.values();report['binaries'][name]=dict(sha256=sha(binary));save()
  for mode in (['focus','neighbors','state'] if name=='native_fieldset' else ['regression']):
   for repeat in [1,2]:
    label=name+'-'+mode+'-'+str(repeat);command=[str(binary)]+([mode] if name=='native_fieldset' else []);data=run(label,command);json.loads(data);(OUT/(label+'.json')).write_bytes(data)
   assert (OUT/(name+'-'+mode+'-1.json')).read_bytes()==(OUT/(name+'-'+mode+'-2.json')).read_bytes()
 run('ffi-library-build',cargo+['build','--locked','--offline','-p','openui-ffi','--features','linux','--message-format=json'])
 library=OUT/'libopenui_ffi.so';shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/libopenui_ffi.so',library);(OUT/'libopenui.so.0').symlink_to(library.name);report['ffi_library_sha256']=sha(library);assert sha(library) in proof.values();save()
 run('all-c-cpp-consumers',[sys.executable,str(SDK/'tools/ffi/verify_abi.py'),'--library',str(library)])
 sys.path.insert(0,str(SDK/'tools/ffi'));import verify_abi
 cc,cxx,c_flags,cxx_flags,link_flags=verify_abi.compilers()
 for language,compiler,flags,standard in [('c',cc,c_flags,'c11'),('cpp',cxx,cxx_flags,'c++17')]:
  for stem in ['fieldset','fieldset_state','selection_tasks','disabled_focus','input_metadata']:
   example=SDK/'examples/c_v02'/(stem+('.c' if language=='c' else '.cc'));obj=OUT/(stem+'-'+language+'.o');binary=OUT/(stem+'-'+language)
   run('compile-'+stem+'-'+language,[compiler,'-std='+standard,'-Wall','-Wextra','-Werror','-pthread',*flags,'-I'+str(SDK/'include'),str(example),'-c','-o',str(obj)])
   run('link-'+stem+'-'+language,[cxx,'-pthread',*cxx_flags,*link_flags,'-fuse-ld=lld',str(obj),str(library),'-Wl,-rpath,'+str(OUT),'-o',str(binary)])
   report['binaries'][stem+'-'+language]=dict(sha256=sha(binary));save()
   for mode in (['focus','neighbors'] if stem=='fieldset' else ['state'] if stem=='fieldset_state' else ['regression']):
    for repeat in [1,2]:
     label=stem+'-'+language+'-'+mode+'-'+str(repeat);data=run(label,[str(binary)]+([mode] if stem=='fieldset' else []));json.loads(data);(OUT/(label+'.json')).write_bytes(data)
    assert (OUT/(stem+'-'+language+'-'+mode+'-1.json')).read_bytes()==(OUT/(stem+'-'+language+'-'+mode+'-2.json')).read_bytes()
 comparisons=[]
 for mode,name in reference_modes.items():
  expected=json.loads((RAW/name/'observations-1.json').read_bytes())
  for language,label in [('rust','native_fieldset-'+mode),('c',('fieldset_state-c-state' if mode=='state' else 'fieldset-c-'+mode)),('cpp',('fieldset_state-cpp-state' if mode=='state' else 'fieldset-cpp-'+mode))]:
   actual=json.loads((OUT/(label+'-1.json')).read_bytes());assert len(actual)==len(expected)
   for a,e in zip(actual,expected):
    reference=e
    if mode=='state' and language!='rust':
     reference=json.loads(json.dumps(e))
     for phase in ['initial','synchronous','observed']:
      for state in reference[phase].values():state.pop('kind');state.pop('parent')
    comparisons.append(dict(language=language,mode=mode,scenario=a['scenario'],exact=a==reference,native=a,chromium=reference,projection=('own/property/effective/enabled/connected only; kind and parent Rust-only' if mode=='state' and language!='rust' else 'complete reference row')))
 regression_rows=[]
 for name in app_names[1:]:
  a=json.loads((OUT/(name+'-regression-1.json')).read_bytes());e=json.loads((regression/(name+'-1.json')).read_bytes());regression_rows.append(dict(language='rust',name=name,scenarios=len(a),unchanged=a==e,reference_sha256=sha(regression/(name+'-1.json'))))
 for stem in ['selection_tasks','disabled_focus','input_metadata']:
  for language in ['c','cpp']:
   a=json.loads((OUT/(stem+'-'+language+'-regression-1.json')).read_bytes());e=json.loads((regression/(stem+'-'+language+'-1.json')).read_bytes());regression_rows.append(dict(language=language,name=stem,scenarios=len(a),unchanged=a==e,reference_sha256=sha(regression/(stem+'-'+language+'-1.json'))))
 report.update(comparisons=comparisons,scenario_counts={language:dict(total=sum(x['language']==language for x in comparisons),exact=sum(x['language']==language and x['exact'] for x in comparisons)) for language in ['rust','c','cpp']},regression_comparisons=regression_rows,all_regression_rows_unchanged=all(x['unchanged'] for x in regression_rows),fresh_local_library_provenance_verified=True)
 report['observed_exit_code']=int(not all(x['exact'] for x in comparisons) or not report['all_regression_rows_unchanged']);save()
except BaseException as error:
 report.update(observed_exit_code=130 if isinstance(error,KeyboardInterrupt) else 1,failure=repr(error));raise
finally:
 report.update(source_after=identity(SDK),main_source_after=identity(MAIN));report['source_unchanged']=report['source_after']==source;report['main_source_unchanged']=report['main_source_after']==main_source
 assert all(sha(p)==h for p,h in references.items());report['all_commands_terminal']=True;save()
print(json.dumps({k:report[k] for k in ['observed_exit_code','scenario_counts','all_regression_rows_unchanged','source_unchanged','main_source_unchanged']}),flush=True)
raise SystemExit(report['observed_exit_code'])
