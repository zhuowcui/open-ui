import fcntl,hashlib,json,subprocess,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';OUT=Path('/tmp/openui-native-checkable-reference-audit-v3258.json')
assert not OUT.exists()
sys.path.insert(0,'/tmp');from openui_parallel_source_identity_v3060 import identity
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=identity(MAIN);assert source['clean'] and source['commit']=='1d54fc50f7b225d8a39b6a8962fe7159d7651852'
records=[];rows=0
for name,count,driver in [('native-radio-programmatic-reference-v3242',34,'openui-native-radio-programmatic-reference-v3242.py'),('native-checkable-default-reference-v3249',36,'openui-native-checkable-default-reference-v3249.py'),('native-checkable-activation-reference-v3257',40,'openui-native-checkable-activation-reference-v3257.py')]:
    lock=open('/tmp/'+name+'.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    directory=RAW/name;r=json.loads((directory/'receipt.json').read_bytes())
    assert r['all_commands_terminal'] and r['observed_exit_code']==0 and r['source_unchanged']
    assert r['source']==r['source_after']==source
    assert subprocess.run(['ps','-p',str(r['owner_pid'])],capture_output=True).returncode==1
    assert r['script_runs_only_in_offline_chromium'] and not r['javascript_executed_by_openui'] and not r['native_api_behavior_measured']
    assert sha(Path('/tmp')/driver)==r['probe_sha256']
    assert sha(MAIN/'chrome/linux-147.0.7727.50/chrome-linux64/chrome')==r['chrome_sha256']
    assert sha(MAIN/'tools/accountability/run_all_pixel_comparisons.py')==r['harness_sha256']
    assert (directory/'observations-1.json').read_bytes()==(directory/'observations-2.json').read_bytes()
    observations=json.loads((directory/'observations-1.json').read_bytes())
    assert len(observations)==count and len({x['scenario'] for x in observations})==count
    for run in r['runs']:
        assert run['scenarios']==count and sha(directory/('observations-'+str(run['repeat'])+'.json'))==run['observations_sha256']
    records.append(dict(name=name,scenarios=count,receipt_sha256=sha(directory/'receipt.json'),observations_sha256=sha(directory/'observations-1.json'),driver_sha256=sha(Path('/tmp')/driver),chrome_sha256=r['chrome_sha256'],harness_sha256=r['harness_sha256'],actual_whole_exit_code=0))
    rows+=count;lock.close()
assert rows==110
failed=RAW/'native-checkable-default-reference-v3248/receipt.json';f=json.loads(failed.read_bytes())
assert f['all_commands_terminal'] and f['observed_exit_code']==1 and f['source_unchanged'] and f['failure'].find('exceptionDetails')>=0
assert identity(MAIN)==source
result=dict(schema_version=1,source=source,source_unchanged=True,reference_cases=rows,repeated_reference_observations_identical=True,owners_terminal=True,references=records,failed_reference_preserved=dict(receipt_sha256=sha(failed),actual_whole_exit_code=1),native_execution=False,native_behavior_qualified=False,javascript_executed_by_openui=False,all_native_apis_qualified=False,release_qualified=False)
OUT.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps(result),flush=True)
