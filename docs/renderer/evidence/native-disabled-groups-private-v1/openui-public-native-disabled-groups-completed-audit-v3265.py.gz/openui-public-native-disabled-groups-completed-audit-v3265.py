import fcntl,hashlib,json,subprocess,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');SDK=MAIN;RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';DIR=RAW/'public-native-disabled-groups-v3264';OUT=Path('/tmp/openui-public-native-disabled-groups-completed-audit-v3265.json');assert not OUT.exists()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
r=read(DIR/'receipt.json');assert r['all_commands_terminal'] and r['observed_exit_code']==0 and r['source_unchanged'] and r['main_source_unchanged']
assert subprocess.run(['ps','-p',str(r['owner_pid'])],capture_output=True).returncode==1
for name in ['cargo','rustc','pixel_compare','rustfmt']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
assert r['source']['commit']==r['main_source']['commit']==Path('/tmp/openui-native-disabled-public-pin-v3263.txt').read_text().strip()
assert sha('/tmp/openui-public-native-disabled-groups-owner-v3264.py')==r['driver_sha256']
for step in r['steps']:assert step['actual_exit_code']==0 and sha(DIR/(step['name']+'.log'))==step['log_sha256']
proof={};records=0
for step in r['steps']:
 stage=step['name'];artifacts=r['local_artifacts'].get(stage,[])
 for a in artifacts:
  row=a['record'];assert Path(row['manifest_path']).is_relative_to(SDK) and Path(row['target']['src_path']).is_relative_to(SDK)
  if row['fresh']:assert all(proof.get(p)==h for p,h in a['sha256'].items())
  else:assert stage!='control-tests' or not row['fresh']
  proof.update(a['sha256']);records+=1
for p,h in proof.items():assert sha(p)==h,p
for name,b in r['binaries'].items():assert sha(DIR/name)==b['sha256'],name
assert sha(DIR/'libopenui_ffi.so')==r['ffi_library_sha256'] and r['fresh_local_library_provenance_verified']
for p,h in r['reference_inputs_sha256'].items():assert sha(p)==h,p
for c in r['comparisons']:assert c['exact'] and c['native']==c['chromium']
assert r['scenario_counts']=={name:dict(total=88,exact=88) for name in ['rust','c','cpp']}
for row in r['regression_comparisons']:assert row['unchanged']
assert r['all_regression_rows_unchanged']
repeats=0
for first in sorted(DIR.glob('*-1.json')):
 second=first.with_name(first.name[:-7]+'-2.json');assert second.exists(),second;assert first.read_bytes()==second.read_bytes();repeats+=1
assert repeats==21,repeats
assert not r['javascript_executed_by_openui'] and not r['renderer_qualified'] and r['implementation_integrated'] and not r['all_native_apis_qualified'] and not r['release_qualified']
sys.path.insert(0,'/tmp');from openui_parallel_source_identity_v3060 import identity
assert identity(SDK)==r['source']==r['source_after'] and identity(MAIN)==r['main_source']==r['main_source_after']
old=subprocess.check_output(['git','-C',str(MAIN),'show','1d54fc50f7b225d8a39b6a8962fe7159d7651852:docs/v02/generated/openui-ffi-symbols.txt'],text=True).splitlines();new=(SDK/'docs/v02/generated/openui-ffi-symbols.txt').read_text().splitlines();assert len(old)==125 and len(new)==127 and set(old)<=set(new)
assert json.loads(subprocess.check_output(['git','-C',str(MAIN),'show','1d54fc50f7b225d8a39b6a8962fe7159d7651852:docs/v02/generated/openui-ffi-layout.json']))['types']==read(SDK/'docs/v02/generated/openui-ffi-layout.json')['types']
units=integration=0
import re
for name in ['control-tests','native-focus-integration-guards']:
 data=(DIR/(name+'.log')).read_text();summaries=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',data);assert summaries and all(int(f)==int(i)==0 for _,f,i in summaries)
 count=sum(int(p) for p,_,_ in summaries)
 if name=='control-tests':units=count;assert count==197
 else:integration=count;assert count==23
abi=(DIR/'all-c-cpp-consumers.log').read_text();assert 'symbols=127 C_examples=24 C++=18 ran=True' in abi
report=dict(schema_version=1,actual_whole_exit_code=0,owner_terminal=True,source=r['source'],main_source=r['main_source'],receipt_sha256=sha(DIR/'receipt.json'),all_source_bytes_unchanged=True,fresh_local_artifact_records_verified=records,current_artifact_paths_verified=len(proof),binary_hashes_verified=len(r['binaries']),native_repeated_process_pairs=repeats,rust_scenarios=88,c_scenarios=88,cpp_scenarios=88,old_109_rust_c_cpp_scenarios_unchanged=True,c_state_projection_explicit=True,unit_guards=units,integration_guards=integration,c_exports=127,c_layouts=34,all_old_125_exports_and_layouts_preserved=True,c_consumers=24,cpp_consumers=18,implementation_integrated=True,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,javascript_executed_by_openui=False)
OUT.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(report),flush=True)
