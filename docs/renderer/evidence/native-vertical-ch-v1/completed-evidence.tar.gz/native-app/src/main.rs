use openui::prelude::*;
use openui_text::{FontRelativeLengthResolver, FontRelativeUnit};
use serde_json::{json, Value};
use std::{cell::Cell, error::Error, rc::Rc, sync::Arc};

fn geometry(element: &Element) -> Result<Value, Box<dyn Error>> {
    let bounds = element.bounding_rect()?.ok_or("owned bounds required")?;
    Ok(json!({"x": bounds.x, "y": bounds.y, "width": bounds.width, "height": bounds.height}))
}

fn resolve_and_assign(
    element: &Element,
    fonts: Arc<FontCollection>,
    coefficient: f32,
    unit: FontRelativeUnit,
) -> Result<Value, Box<dyn Error>> {
    let style = element.computed_style()?;
    let resolver = FontRelativeLengthResolver::from_style_in_collection(&style, fonts);
    let pixels = resolver.resolve(coefficient, unit);
    element.set_width(LengthValue::px(pixels))?;
    Ok(
        json!({"resolved_pixels": pixels, "computed_font_size": style.font_size, "bounds": geometry(element)?}),
    )
}

fn main() -> Result<(), Box<dyn Error>> {
    let fonts = FontCollection::deterministic_test();
    for scale in [1.0, 1.25, 1.5, 2.0, 3.0] {
        for family in ["Ahem", "DejaVu Sans"] {
            for size in [15.0, 16.0, 18.72, 18.73] {
                for (line_name, line_height) in [("normal", LineHeight::Normal)] {
                    for (unit_name, unit) in [("ch", FontRelativeUnit::Ch)] {
                        for coefficient in [1.0, 2.5] {
                            for (writing_name, writing) in [
                                ("horizontal-tb", WritingMode::HorizontalTb),
                                ("vertical-lr", WritingMode::VerticalLr),
                                ("vertical-rl", WritingMode::VerticalRl),
                            ] {
                                for (orientation_name, orientation) in [
                                    ("mixed", TextOrientation::Mixed),
                                    ("upright", TextOrientation::Upright),
                                    ("sideways", TextOrientation::Sideways),
                                ] {
                                    let document = Document::with_font_collection_and_options(
                                        ViewportMetrics::from_logical_size(800.0, 600.0, scale)?,
                                        fonts.clone(),
                                        EngineOptions {
                                            raster_configuration:
                                                RasterConfiguration::deterministic_aliased(false),
                                        },
                                    )?;
                                    document.body().set_overflow_x(Overflow::Hidden)?;
                                    document.body().set_overflow_y(Overflow::Hidden)?;
                                    let element = Element::create(&document, "div")?;
                                    element.set_position(Position::Absolute)?;
                                    element.set_writing_mode(writing)?;
                                    element.set_text_orientation(orientation)?;
                                    element.set_left(Length::px(0.0))?;
                                    element.set_top(Length::px(0.0))?;
                                    element.set_height(LengthValue::px(10.0))?;
                                    element.set_font_family(FontFamilyList::single(family))?;
                                    element.set_font_size(LengthValue::px(size))?;
                                    element.set_line_height(line_height)?;
                                    element.set_text("X")?;
                                    document.body().append_child(&element)?;
                                    let before = resolve_and_assign(
                                        &element,
                                        fonts.clone(),
                                        coefficient,
                                        unit,
                                    )?;
                                    let owned_style = element.computed_style()?;
                                    let owned_bounds =
                                        element.bounding_rect()?.ok_or("snapshot required")?;
                                    let weak = element.downgrade();
                                    let target = weak.clone();
                                    let calls = Rc::new(Cell::new(0));
                                    let callback_calls = calls.clone();
                                    element.on("click", move |_| {
                                        target
                                            .upgrade()
                                            .unwrap()
                                            .set_font_size(LengthValue::px(20.37))
                                            .unwrap();
                                        callback_calls.set(callback_calls.get() + 1);
                                    })?;
                                    element.click()?;
                                    assert_eq!(calls.get(), 1);
                                    assert_eq!(owned_style.font_size, size);
                                    assert_eq!(
                                        before["bounds"],
                                        json!({"x": owned_bounds.x, "y": owned_bounds.y, "width": owned_bounds.width, "height": owned_bounds.height})
                                    );
                                    let after = resolve_and_assign(
                                        &element,
                                        fonts.clone(),
                                        coefficient,
                                        unit,
                                    )?;
                                    println!(
                                        "{}",
                                        json!({"scale":scale,"family":family,"size":size,"writing":writing_name,"orientation":orientation_name,"line_height":line_name,"unit":unit_name,"coefficient":coefficient,"before":before,"after":after,"callback_calls":calls.get(),"owned_snapshots_unchanged":true,"manual_resolution_not_an_automatic_length_declaration":true})
                                    );
                                    drop(element);
                                    drop(document);
                                    assert!(weak.upgrade().is_none());
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    Ok(())
}
