"""Prepare a consuming native Rust app for the reviewed vertical ch risk."""
import hashlib,json,shutil,subprocess
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');SDK=MAIN/'out/private-native-relative-api-v2202'
OLD=MAIN/'out/private-native-apps/native-relative-units-v2203'
APP=MAIN/'out/private-native-apps/native-vertical-ch-v2213'
OUT=Path('/tmp/openui-native-vertical-ch-prepare-v2213.json')
assert not APP.exists() and not OUT.exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=SDK,text=True).strip()=='4046d366eab0a9fc6aa161dc63d8e646104eab84'
APP.mkdir()
for name in ['Cargo.toml','Cargo.lock','src/main.rs']:
    p=APP/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(OLD/name,p)
for name in ['Cargo.toml','Cargo.lock']:
    p=APP/name;s=p.read_text();assert 'openui-native-relative-units-api' in s
    p.write_text(s.replace('openui-native-relative-units-api','openui-native-vertical-ch-api'))
p=APP/'src/main.rs';s=p.read_text()
old='''                    ("number_1_2", LineHeight::Number(1.2)),
                    ("number_1_275", LineHeight::Number(1.275)),
                    ("percent_127_5", LineHeight::Percentage(127.5)),
                    ("fixed_19_2", LineHeight::Length(19.2)),
'''
assert old in s;s=s.replace(old,'')
old='''                        ("ex", FontRelativeUnit::Ex),
                        ("lh", FontRelativeUnit::Lh),
'''
assert old in s;s=s.replace(old,'')
old='''                        for coefficient in [1.0, 2.5] {
'''
assert old in s;s=s.replace(old,old+'''                            for (writing_name, writing) in [
                                ("horizontal-tb", WritingMode::HorizontalTb),
                                ("vertical-lr", WritingMode::VerticalLr),
                                ("vertical-rl", WritingMode::VerticalRl),
                            ] {
                                for (orientation_name, orientation) in [
                                    ("mixed", TextOrientation::Mixed),
                                    ("upright", TextOrientation::Upright),
                                    ("sideways", TextOrientation::Sideways),
                                ] {
''')
old='''                            element.set_position(Position::Absolute)?;'''
assert old in s;s=s.replace(old,old+'''
                            element.set_writing_mode(writing)?;
                            element.set_text_orientation(orientation)?;''')
old='''"scale":scale,"family":family,"size":size'''
assert old in s;s=s.replace(old,'''"scale":scale,"family":family,"size":size,"writing":writing_name,"orientation":orientation_name''')
old='''                            assert!(weak.upgrade().is_none());'''
assert old in s;s=s.replace(old,old+'''
                                }
                            }''')
p.write_text(s)
subprocess.run(['bash','-c','ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true src/main.rs'],cwd=APP,check=True,capture_output=True)
subprocess.run(['git','init'],cwd=APP,check=True,capture_output=True)
for name in ['user.name','user.email']:
    value=subprocess.check_output(['git','config','--get',name],cwd=MAIN,text=True).strip()
    subprocess.run(['git','config',name,value],cwd=APP,check=True,capture_output=True)
subprocess.run(['git','add','.'],cwd=APP,check=True,capture_output=True)
subprocess.run(['git','commit','-m','Prepare native Rust vertical ch queries and callback ownership checks'],cwd=APP,check=True,capture_output=True)
r=dict(schema_version=1,sdk_commit='4046d366eab0a9fc6aa161dc63d8e646104eab84',
    app_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=APP,text=True).strip(),
    app_source_sha256=hashlib.sha256((APP/'src/main.rs').read_bytes()).hexdigest(),
    cases_planned=720,bounds_states_planned=1440,rust_callbacks_planned_per_run=720,
    source_only_preparation=True,cargo_commands_run=0,native_queries_started=0,chromium_processes_started=0,
    known_risk='VerticalUpright ch uses the primary zero glyph vertical advance in pinned Chromium; the scalar resolver currently reads a horizontal metric.',
    source_only_review_is_not_runtime_evidence=True,javascript_executed_by_openui=False,
    release_qualification=False,promotion_allowed=False,all_commands_terminal=True,
    probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
OUT.write_text(json.dumps(r,sort_keys=True,indent=2)+'\n');print(json.dumps(r),flush=True)
