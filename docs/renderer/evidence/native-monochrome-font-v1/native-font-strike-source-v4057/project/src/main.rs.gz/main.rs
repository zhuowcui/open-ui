use openui::prelude::*;
use openui_text::{Font, FontDescription};
use skia_safe::{font::Edging, FontHinting};
use std::path::PathBuf;
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let out = PathBuf::from(std::env::args().nth(1).ok_or("output")?);
    let mut rows = Vec::new();
    for (origin, fonts) in [
        ("registered", FontCollection::deterministic_test()),
        ("system", FontCollection::system()),
    ] {
        for scale in [1.0, 1.25, 1.5, 2.0, 3.0] {
            for family in ["Ahem", "DejaVu Sans", "Droid Sans Fallback"] {
                for size in [8.0, 10.0, 12.0, 16.0, 20.0, 24.0] {
                    let mut description =
                        FontDescription::with_family_and_size(FontFamilyList::single(family), size);
                    description.device_scale_factor = scale;
                    description.raster_configuration =
                        RasterConfiguration::deterministic_aliased(false);
                    let font = Font::new_in_collection(description, fonts.clone());
                    let data = font.primary_font().ok_or("missing primary font")?;
                    for edging in [Edging::Alias, Edging::AntiAlias, Edging::SubpixelAntiAlias] {
                        for hinting in [
                            FontHinting::None,
                            FontHinting::Slight,
                            FontHinting::Normal,
                            FontHinting::Full,
                        ] {
                            for subpixel in [false, true] {
                                for linear in [false, true] {
                                    let mut probe = data.sk_font().clone();
                                    probe.set_edging(edging);
                                    probe.set_hinting(hinting);
                                    probe.set_subpixel(subpixel);
                                    probe.set_linear_metrics(linear);
                                    let samples=["\u{a0}","ABCDEFGHI","XX","BC"].iter().map(|text| {
                                        let glyphs=probe.str_to_glyphs_vec(text);
                                        let mut advances=vec![0.0;glyphs.len()];probe.get_widths(&glyphs,&mut advances);
                                        let (width,b)=probe.measure_str(text,None);
                                        serde_json::json!({"text":text,"width":width,"ceil":(width*64.0).ceil()/64.0,"glyphs":glyphs,"advances":advances,"ink":{"left":b.left,"top":b.top,"right":b.right,"bottom":b.bottom}})
                                    }).collect::<Vec<_>>();
                                    rows.push(serde_json::json!({"origin":origin,"scale":scale,"requested_family":family,"resolved_family":data.typeface().family_name(),"size":size,"edging":format!("{edging:?}"),"hinting":format!("{hinting:?}"),"subpixel":subpixel,"linear_metrics":linear,"samples":samples}));
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    assert_eq!(rows.len(), 8640);
    std::fs::create_dir_all(&out)?;
    std::fs::write(out.join("samples.json"), serde_json::to_vec_pretty(&rows)?)?;
    println!(
        "{} font configurations; {} advance samples",
        rows.len(),
        rows.len() * 4
    );
    Ok(())
}
