import gzip, hashlib, json, shutil, sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui')
BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b')
OUT=ROOT/'docs/renderer/evidence/native-monochrome-font-v1'
INDEX=ROOT/'docs/renderer/generated/native-monochrome-font-v1.json'
load=lambda p:json.loads(Path(p).read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
assert not OUT.exists() and not INDEX.exists()
proof=load('/tmp/openui-native-monochrome-regression-reaped-v4079.json')
assert proof['all_local_commands_terminal'] and proof['owners_absent']
native=load(BASE/'native-monochrome-font-v4074/receipt.json')
assert native['source']['clean'] and native['all_commands_terminal']
assert native['source']==proof['source'] and native['observed_exit_code']==1
assert native['totals']=={mode:dict(images=10,exact_images=8,bounds=480,exact_bounds=480) for mode in ['registered','system']}
assert native['original_cached_oracle_matches_fresh']
assert native['input_sha256'][str(BASE/'native-monochrome-font-source-v4073/project/src/main.rs')]==sha((ROOT/'bindings/rust/openui/examples/native_monochrome_font.rs').read_bytes())
previous=ROOT/'docs/renderer/generated/native-font-origin-v1.json'
assert sha(previous.read_bytes())=='b509eb250454a6b449201aa5236dc56f36a9602dbc7b1866d99260157217ff6b'
for row in load(previous)['archive']['members']:
    data=(ROOT/row['path']).read_bytes()
    assert sha(data)==row['sha256']
    raw=gzip.decompress(data) if row['compression']=='gzip' else data
    assert sha(raw)==row['raw_sha256']
members=[];excluded=[]
def add(source,relative):
    source=Path(source);raw=source.read_bytes()
    compressed=source.suffix not in ['.png','.gz']
    data=gzip.compress(raw,compresslevel=9,mtime=0) if compressed else raw
    path=OUT/(relative+('.gz' if compressed else ''))
    assert not path.exists();path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
    assert (gzip.decompress(data) if compressed else data)==raw
    members.append(dict(path=str(path.relative_to(ROOT)),compression='gzip' if compressed else 'none',bytes=len(data),sha256=sha(data),raw_bytes=len(raw),raw_sha256=sha(raw)))
for name in ['native-font-strike-source-v4053','native-font-strike-v4054','native-font-strike-source-v4057','native-font-strike-v4058','chromium-font-style-source-v4059','native-monochrome-font-source-v4066','native-monochrome-font-v4067','native-monochrome-api-source-v4071','native-monochrome-checks-v4072','native-monochrome-font-source-v4073','native-monochrome-font-v4074','native-monochrome-regression-guards-v4077']:
    for path in sorted((BASE/name).rglob('*')):
        if not path.is_file():continue
        if path.name=='native-consumer':
            receipt=load(BASE/name/'receipt.json')
            assert hashlib.file_digest(path.open('rb'),'sha256').hexdigest()==receipt['binary_sha256']
            excluded.append(dict(path=str(path),sha256=receipt['binary_sha256'],reason='Owned measured executable retained outside Git.'))
        else:add(path,str(Path(name)/path.relative_to(BASE/name)))
for name in ['openui-native-font-strike-failure-audit-v4055','openui-native-font-strike-reaped-v4056','openui-native-font-strike-audit-v4060','openui-native-font-strike-reaped-v4061','openui-native-monochrome-font-failure-audit-v4069','openui-native-monochrome-font-reaped-v4070','openui-native-monochrome-font-audit-v4075','openui-native-monochrome-font-reaped-v4076','openui-native-monochrome-regression-audit-v4078','openui-native-monochrome-regression-reaped-v4079']:
    add(Path('/tmp')/(name+'.json'),'proofs/'+name+'.json')
for name in ['openui-native-font-strike-v4054','openui-native-font-strike-v4058','openui-native-font-strike-audit-v4060','openui-native-monochrome-font-v4067','openui-native-monochrome-font-v4074','openui-native-monochrome-font-audit-v4075','openui-native-monochrome-regression-guards-v4077','openui-native-monochrome-regression-audit-v4078','openui-native-monochrome-checks-v4072','openui-native-monochrome-archive-v4080']:
    add(Path('/tmp')/(name+'.py'),'drivers/'+name+'.py')
add('/home/nero/.cargo/git/checkouts/rust-skia-b4d79b6a888cdb4c/a31b86b/skia-bindings/skia/src/ports/SkFontHost_FreeType.cpp','primary-skia/SkFontHost_FreeType.cpp')
required=[row for row in native['cases'] if row['profile']['scale']!=3]
assert len(required)==4 and all(stage['analysis']['mismatched_pixels']==0 for row in required for result in row['native'].values() for stage in result['stages'].values())
index=dict(schema_version=1,measured_source=native['source'],all_measurement_commands_terminal=True,all_archive_hashes_verified=True,pixel_target='pinned Chromium',pixel_tolerance=0,javascript_executed_by_openui=False,historical_openui_archive_is_a_pixel_target=False,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,
    archive=dict(files=len(members),bytes=sum(row['bytes'] for row in members),members=members,excluded=excluded),
    native_consumer=dict(public_example='bindings/rust/openui/examples/native_monochrome_font.rs',source_sha256=sha((ROOT/'bindings/rust/openui/examples/native_monochrome_font.rs').read_bytes()),configuration='RasterConfiguration::chromium_linux_monochrome()',totals=native['totals'],required_profiles=dict(images=16,exact_images=16,bounds=768,exact_bounds=768),extra_3x=dict(images=4,exact_images=0,bounds=192,exact_bounds=192,mismatched_pixels_before=6672,mismatched_pixels_after=6720),fresh_compiler_records=16,compiled_paths=29,independent_native_processes=20,callbacks_process_repeats_and_weak_teardown=True),
    direct_font_probe=dict(configurations=8640,advance_samples=34560,independent_processes=2,repeated_bytes_identical=True,source=load(BASE/'native-font-strike-v4058/receipt.json')['source']['commit'],diagnostic_measured_source=load(BASE/'native-font-strike-v4058/receipt.json')['source']),
    preserved_fractional_native_api_tests=dict(passed=3,failed=0,ignored=0),
    original_cached_chromium_references=dict(comparisons=4,exact=4,unchanged=True),
    previous_immutable_evidence=dict(path=str(previous.relative_to(ROOT)),sha256=sha(previous.read_bytes())),
    scope='Explicit full-hint monochrome native Rust profile fixes installed-font advances in the reduced app. Four required profiles are exact; the extra 3x glyph raster check fails. Existing profile selection and full-census status are unchanged.',
    pending=['Resolve and review the extra 3x glyph raster difference.','Qualify the focused and primitive 40-profile matrices and complete original/expanded census with correctly matched font profiles.','Implement and verify every remaining needed native API and all release gates.'])
INDEX.write_text(json.dumps(index,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(index=str(INDEX),members=len(members),bytes=index['archive']['bytes'],sha256=sha(INDEX.read_bytes()))),flush=True)
