import fcntl, hashlib, json, subprocess, sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui')
OUT=Path('/mnt/d/openui-v02-qualification-d174ea0b/native-font-strike-v4058')
DEST=Path('/tmp/openui-native-font-strike-audit-v4060.json')
sys.path.insert(0,'/tmp')
from openui_parallel_source_identity_v3060 import identity
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(2**20),b''): h.update(block)
    return h.hexdigest()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
r=json.loads((OUT/'receipt.json').read_bytes())
assert not DEST.exists() and r['observed_exit_code']==int(sys.argv[1])==0
assert r['all_commands_terminal'] and 'failure' not in r
assert identity(ROOT)==r['source']==r['source_after'] and r['source_unchanged'] and r['inputs_unchanged']
assert sha('/tmp/openui-native-font-strike-v4058.py')==r['driver_sha256']
for path,digest in r['input_sha256'].items(): assert sha(path)==digest
for name in ['cargo','rustc','rustfmt','pixel_compare']:
    assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
for pid in [r['owner_pid']]+[s['pid'] for s in r['steps']]:
    assert subprocess.run(['ps','-p',str(pid)],capture_output=True).returncode==1
for s in r['steps']:
    assert s['actual_exit_code']==0 and sha(OUT/(s['name']+'.log'))==s['log_sha256']
for path,digest in r['compiled_artifact_sha256'].items(): assert sha(path)==digest
for artifact in r['compiler_artifacts']: assert artifact['fresh'] is False
assert sha(r['binary'])==sha(r['retained_binary'])==r['binary_sha256']
for run in r['runs']:
    assert sha(run['samples_path'])==run['samples_sha256']
    rows=json.loads(Path(run['samples_path']).read_bytes())
    assert len(rows)==8640 and sum(len(row['samples']) for row in rows)==34560
assert len(r['runs'])==2 and r['runs'][0]['samples_sha256']==r['runs'][1]['samples_sha256']
selected=[row for row in rows if row['requested_family']=='Ahem' and row['size']==16 and row['edging']=='Alias' and not row['subpixel'] and not row['linear_metrics']]
assert len(selected)==40
for row in selected:
    expected=16.000030517578125 if row['hinting']=='None' else 16.0
    assert row['samples'][0]['text']=='\u00a0' and row['samples'][0]['width']==expected
p=dict(schema_version=1,complete=True,owner_absent=True,source=r['source'],actual_owner_exit_code=0,receipt_sha256=sha(OUT/'receipt.json'),audit_driver_sha256=sha(__file__),fresh_compiler_records=len(r['compiler_artifacts']),compiled_paths_verified=len(r['compiled_artifact_sha256']),totals=r['totals'],font_configurations_repeat_identically=True,installed_monochrome_advance_reproduced=True,production_source_unchanged=True,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,retired_for_reexecution_after_source_or_target_mutation=True)
DEST.write_text(json.dumps(p,sort_keys=True,indent=2)+'\n')
print(json.dumps(p),flush=True)
