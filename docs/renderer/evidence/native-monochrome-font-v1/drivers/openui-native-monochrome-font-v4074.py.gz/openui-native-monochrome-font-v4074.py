import base64, fcntl, hashlib, json, os, shutil, signal, subprocess, sys, time, tomllib
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b')
DRAFT=BASE/'native-monochrome-font-source-v4073';PROJECT=DRAFT/'project'
OUT=BASE/'native-monochrome-font-v4074';TARGET=Path('/mnt/e/openui-v02-cargo-c73754e2/target')
sys.path[:0]=[str(ROOT),str(ROOT/'tools/qualification'),'/tmp']
from openui_parallel_source_identity_v3060 import identity
from tools.accountability import run_all_pixel_comparisons as capture
from residuals import analyze_image_difference
load=lambda p:json.loads(Path(p).read_bytes())
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(2**20),b''):h.update(block)
    return h.hexdigest()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
prior=load('/tmp/openui-native-monochrome-font-reaped-v4070.json')
assert prior['all_local_commands_terminal'] and prior['owners_absent']
for name in ['cargo','rustc','rustfmt','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
plan=load(DRAFT/'plan.json');source=identity(ROOT)
assert source==plan['source'] and source['clean'] and not OUT.exists()
OUT.mkdir()
inputs={str(PROJECT/'src/main.rs'):plan['consumer_source_sha256'],str(PROJECT/'Cargo.toml'):plan['consumer_manifest_sha256'],str(PROJECT/'Cargo.lock'):plan['consumer_lock_sha256'],str(DRAFT/'plan.json'):sha(DRAFT/'plan.json'),str(DRAFT/'workspace-lock-template.txt'):plan['workspace_lock_template_sha256']}
inputs.update({str(DRAFT/f'oracle-{stage}.html'):digest for stage,digest in plan['reference_html_sha256'].items()})
inputs.update({str(ROOT/'bindings/rust/openui-text/fonts'/name):digest for name,digest in plan['fonts_sha256'].items()})
inputs[plan['installed_font_path']]=plan['installed_font_sha256']
inputs[str(ROOT/'tools/accountability/data/wpt_ported/all_wpt_templates.json')]=plan['original_templates_sha256']
def guard():
    assert identity(ROOT)==source
    for path,digest in inputs.items():assert sha(path)==digest,path
    for path,limit in [(ROOT,128*2**20),(OUT,10*2**30),(TARGET,10*2**30),(Path('/dev/shm'),256*2**20)]:assert shutil.disk_usage(path).free>limit,str(path)
env=dict(os.environ,CARGO_TARGET_DIR=str(TARGET),CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='4',RUST_MIN_STACK='4194304',PYTHONDONTWRITEBYTECODE='1',TMPDIR='/dev/shm')
env.pop('LD_PRELOAD',None);env.pop('LD_LIBRARY_PATH',None)
cargo=['cargo','--config',str(ROOT/'bindings/rust/.cargo/config.chromium.toml')]
manifest=['--manifest-path',str(PROJECT/'Cargo.toml')]
chrome=ROOT/'chrome/linux-147.0.7727.50/chrome-linux64/chrome'
chrome_env=capture.chrome_environment(str(chrome.parent),True,False);chrome_env['TMPDIR']='/dev/shm'
r=dict(schema_version=1,owner_pid=os.getpid(),source=source,input_sha256=inputs,driver_sha256=sha(__file__),prior_terminal_proof_sha256=sha('/tmp/openui-native-monochrome-font-reaped-v4070.json'),cases=[],steps=[],all_commands_terminal=False,chromium_binary_sha256=sha(chrome),chromium_version=subprocess.check_output([str(chrome),'--version'],env=chrome_env,text=True).strip(),capture_harness_sha256=sha(ROOT/'tools/accountability/run_all_pixel_comparisons.py'),fontconfig_sha256=sha(chrome_env['FONTCONFIG_FILE']),pixel_target='pinned Chromium',pixel_tolerance=0,javascript_executed_by_openui=False,scripts_run_only_in_separate_chromium_reference_process=True,historical_openui_archive_is_a_pixel_target=False,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False)
assert r['chromium_version'].split()[-1]=='147.0.7727.50'
def save():
    p=OUT/'receipt.tmp';p.write_text(json.dumps(r,sort_keys=True,indent=2)+'\n');os.replace(p,OUT/'receipt.json')
def run(name,command,cwd=ROOT,timeout=1200):
    guard();print('Starting '+name,flush=True);log=OUT/(name+'.log');child=None
    try:
        with log.open('xb') as stream:
            child=subprocess.Popen(command,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
            r['current_process']=dict(name=name,pid=child.pid);save();start=time.monotonic()
            while child.poll() is None:
                assert time.monotonic()-start<timeout,name
                for path,limit in [(ROOT,128*2**20),(OUT,10*2**30),(TARGET,10*2**30),(Path('/dev/shm'),256*2**20)]:assert shutil.disk_usage(path).free>limit,str(path)
                time.sleep(1)
            code=child.wait()
    finally:
        if child is not None and child.poll() is None:
            os.killpg(child.pid,signal.SIGTERM)
            try:child.wait(timeout=20)
            except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
        r.pop('current_process',None);r['steps'].append(dict(name=name,command=command,pid=None if child is None else child.pid,actual_exit_code=None if child is None else child.returncode,log_sha256=sha(log)));save()
    guard();print(json.dumps(dict(stage=name,actual_exit_code=code)),flush=True);return code,log
READY="new Promise(resolve=>{const done=()=>document.fonts.ready.then(()=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));if(document.readyState==='complete')done();else addEventListener('load',done,{once:true});})"
QUERY="Array.from(document.querySelectorAll('[id],#flexbox>.item'),(e,index)=>{const b=e.getBoundingClientRect();return {name:e.id||'original-item-'+index,bounds:{x:b.x,y:b.y,width:b.width,height:b.height}};})"
PROBE="Array.from(document.querySelectorAll('.flex,[id^=word-]'),e=>{const s=getComputedStyle(e),c=new OffscreenCanvas(1,1).getContext('2d');c.font=[s.fontStyle,s.fontWeight,s.fontSize,s.fontFamily].join(' ');c.fontKerning=s.fontKerning;return {name:e.id,computedFont:s.font,canvasFont:c.font,fontSize:s.fontSize,fontFamily:s.fontFamily,fontKerning:s.fontKerning,advances:['\\u00a0','A','DIV1','ABCDEFGHI',' \\u00a0 '].map(text=>({text,width:c.measureText(text).width})),textNodes:Array.from(e.childNodes).filter(n=>n.nodeType===Node.TEXT_NODE).map(n=>{const range=document.createRange();range.selectNodeContents(n);const b=range.getBoundingClientRect();return {text:n.data,bounds:{x:b.x,y:b.y,width:b.width,height:b.height}};})};})"
def oracle(directory,repeat,p):
    guard();profile=Path('/dev/shm')/f'ou4041-{directory.name}-{repeat}';assert not profile.exists();profile.mkdir()
    width,height,scale=p['width'],p['height'],p['scale']
    command=[str(chrome),'--headless','--disable-gpu','--no-sandbox','--no-first-run','--no-default-browser-check','--remote-debugging-port=0',f'--user-data-dir={profile}',f'--window-size={round(width*scale)},{round(height*scale)+87}','about:blank']
    child=subprocess.Popen(command,env=chrome_env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True);client=None;values={};r['current_process']=dict(name='chromium',pid=child.pid);save()
    try:
        port=capture._wait_for_devtools_endpoint(profile,child);client=capture._CdpWebSocket(capture._page_websocket_url(port));client.command('Page.enable');client.command('DOM.enable');client.command('CSS.enable')
        client.command('Emulation.setDeviceMetricsOverride',dict(width=width,height=height,deviceScaleFactor=scale,mobile=False,screenWidth=width,screenHeight=height))
        for stage in plan['stages']:
            client.command('Page.navigate',dict(url=(DRAFT/f'oracle-{stage}.html').resolve().as_uri()))
            observations=[]
            for number in [1,2]:
                answer=client.command('Runtime.evaluate',dict(expression=READY+'.then(()=>'+QUERY+')',awaitPromise=True,returnByValue=True));assert 'exceptionDetails' not in answer,answer
                observations.append(answer['result']['value'])
            assert observations[0]==observations[1] and len(observations[0])==(6 if stage=='original' else plan['native_node_count'])
            values[stage]=observations[0];(directory/f'chromium-{repeat}-{stage}.json').write_text(json.dumps(values[stage],sort_keys=True,indent=2)+'\n')
            answer=client.command('Runtime.evaluate',dict(expression=PROBE,returnByValue=True));assert 'exceptionDetails' not in answer,answer
            (directory/f'chromium-{repeat}-{stage}-metrics.json').write_text(json.dumps(answer['result']['value'],sort_keys=True,indent=2)+'\n')
            root_node=client.command('DOM.getDocument')['root']['nodeId']
            node=client.command('DOM.querySelector',dict(nodeId=root_node,selector='#flexbox' if stage=='original' else '#word-0'))['nodeId']
            platform_fonts=client.command('CSS.getPlatformFontsForNode',dict(nodeId=node))
            (directory/f'chromium-{repeat}-{stage}-platform-fonts.json').write_text(json.dumps(platform_fonts,sort_keys=True,indent=2)+'\n')
            images=[]
            for number in [1,2]:
                data=base64.b64decode(client.command('Page.captureScreenshot',dict(format='png',fromSurface=True,captureBeyondViewport=False))['data'],validate=True)
                (directory/f'chromium-{repeat}-{stage}-capture-{number}.png').write_bytes(data);images.append(data)
            assert images[0]==images[1]
            metrics=client.command('Runtime.evaluate',dict(expression='({width:innerWidth,height:innerHeight,dpr:devicePixelRatio})',returnByValue=True))['result']['value'];assert capture._device_metrics_match(metrics,width,height,scale)
        return values
    finally:
        if client:client.close()
        capture._stop_chromium_process(child);assert child.poll() is not None;shutil.rmtree(profile)
        r['steps'].append(dict(name=f'{directory.name}-chromium-{repeat}',command=command,pid=child.pid,actual_exit_code=child.returncode));r.pop('current_process',None);save()
save();code=1
try:
    for i,p in enumerate(plan['required_profiles']):
        directory=OUT/f'profile-{i}';directory.mkdir();observations=[oracle(directory,repeat,p) for repeat in [1,2]];assert observations[0]==observations[1]
        for stage in plan['stages']:assert sha(directory/f'chromium-1-{stage}-capture-1.png')==sha(directory/f'chromium-2-{stage}-capture-1.png')
        r['cases'].append(dict(profile=p,chromium_geometry=observations[0],chromium_process_repeats_equal=True));save();print(json.dumps(dict(stage='chromium',profile=p,complete=True)),flush=True)
    status,log=run('metadata',cargo+['metadata','--locked','--offline','--format-version','1']+manifest,ROOT/'bindings/rust');assert status==0
    key=lambda p:(p['name'],p['version'],p.get('source'),p.get('checksum'))
    expected={key(p) for p in tomllib.loads((DRAFT/'workspace-lock-template.txt').read_text())['package']}
    assert all(key(p) in expected or key(p)==('openui-native-flex-measurement','0.1.0',None,None) for p in tomllib.loads((PROJECT/'Cargo.lock').read_text())['package'])
    metadata=load(log);local_ids={p['id'] for p in metadata['packages'] if Path(p['manifest_path']).resolve().is_relative_to(ROOT) or Path(p['manifest_path']).resolve().is_relative_to(PROJECT)}
    status,_=run('clean-local-packages',cargo+['clean','--locked','--offline']+manifest+[a for pid in sorted(local_ids) for a in ['-p',pid]],ROOT/'bindings/rust');assert status==0
    status,log=run('native-build',cargo+['build','--locked','--offline','--message-format=json-render-diagnostics']+manifest,ROOT/'bindings/rust');assert status==0
    artifacts=[];compiled={}
    for line in log.read_text().splitlines():
        try:row=json.loads(line)
        except json.JSONDecodeError:continue
        if row.get('reason')=='compiler-artifact' and row['package_id'] in local_ids:
            assert row['fresh'] is False;artifacts.append(row)
            for path in row['filenames']:compiled[path]=sha(path)
    assert len({row['package_id'] for row in artifacts})==len(local_ids)
    binary=TARGET/'debug/openui-native-flex-measurement';r['binary']=str(binary);r['binary_sha256']=sha(binary);r['compiler_artifacts']=artifacts;r['compiled_artifact_sha256']=compiled;save()
    for i,row in enumerate(r['cases']):
        p=row['profile'];directory=OUT/f'profile-{i}';row['native']={}
        for mode in plan['native_modes']:
            result=dict(runs=[],stages={});row['native'][mode]=result
            for repeat in [1,2]:
                native=directory/f'native-{mode}-{repeat}'
                status,_=run(f'profile-{i}-native-{mode}-{repeat}',[str(binary),str(native),str(p['width']),str(p['height']),str(p['scale']),mode],timeout=120);assert status==0
                lifecycle=load(native/'lifecycle.json');assert lifecycle==dict(callbacks=1,weak_teardown_passed=True,javascript_executed_by_openui=False)
                result['runs'].append(dict(directory=str(native),files={path.name:sha(path) for path in sorted(native.iterdir())}));save()
            assert result['runs'][0]['files']==result['runs'][1]['files']
            for stage in plan['native_stages']:
                bounds=load(directory/f'native-{mode}-1/{stage}.json');reference=row['chromium_geometry'][f'system-{stage}']
                assert len(bounds)==len(reference)==48 and [v['name'] for v in bounds]==[v['name'] for v in reference]
                result['stages'][stage]=dict(native_bounds=bounds,chromium_bounds=reference,exact_bounds=sum(a==b for a,b in zip(bounds,reference)),bounds_count=48,analysis=analyze_image_difference(directory/f'chromium-1-system-{stage}-capture-1.png',directory/f'native-{mode}-1/{stage}.png'))
            save();print(json.dumps(dict(profile=p,mode=mode,exact_bounds={k:v['exact_bounds'] for k,v in result['stages'].items()},different_pixels={k:v['analysis']['mismatched_pixels'] for k,v in result['stages'].items()})),flush=True)
    snapshot=OUT/'native-consumer';shutil.copyfile(binary,snapshot);assert sha(snapshot)==r['binary_sha256'];r['retained_binary']=str(snapshot);save()
    r['totals']={mode:dict(images=10,exact_images=sum(stage['analysis']['mismatched_pixels']==0 for row in r['cases'] for stage in row['native'][mode]['stages'].values()),bounds=480,exact_bounds=sum(stage['exact_bounds'] for row in r['cases'] for stage in row['native'][mode]['stages'].values())) for mode in plan['native_modes']}
    full_path=BASE/'native-strict-intrinsic-ceil-clean-full-v4012/full-matrix/full-summary.json';full=load(full_path);r['original_full_summary_sha256']=sha(full_path);r['original_oracle_comparisons']=[]
    for i,row in enumerate(r['cases']):
        p=row['profile'];matching=[profile for profile in full['profiles'] if profile['device_scale']==p['scale'] and profile['logical_size_css_px']==[p['width'],p['height']]]
        if not matching:continue
        test=next(t for t in matching[0]['tests'] if t['id']==plan['original_test_id'])
        reference=Path('/mnt/e/openui-v02-qualification-d174ea0b/renderer-cache')/test['chromium_png_cache_path'];assert sha(reference)==test['chromium_png_sha256']
        actual=OUT/f'profile-{i}/chromium-1-original-capture-1.png'
        r['original_oracle_comparisons'].append(dict(profile=matching[0]['profile'],reference_png=str(reference),reference_png_sha256=sha(reference),actual_png_sha256=sha(actual),analysis=analyze_image_difference(reference,actual),fresh_geometry=row['chromium_geometry']['original']))
    assert len(r['original_oracle_comparisons'])==4
    r['original_cached_oracle_matches_fresh']=all(row['analysis']['mismatched_pixels']==0 for row in r['original_oracle_comparisons'])
    code=int(any(result['exact_images']!=result['images'] or result['exact_bounds']!=result['bounds'] for result in r['totals'].values()) or not r['original_cached_oracle_matches_fresh'])
except BaseException as exc:
    r['failure']=repr(exc);raise
finally:
    r['source_after']=identity(ROOT);r['source_unchanged']=r['source_after']==source;r['inputs_unchanged']=all(sha(path)==digest for path,digest in inputs.items());r['all_commands_terminal']=True;r['observed_exit_code']=code;save()
print(json.dumps(dict(actual_exit_code=code,totals=r.get('totals'),source_unchanged=r['source_unchanged'])),flush=True)
raise SystemExit(code)
