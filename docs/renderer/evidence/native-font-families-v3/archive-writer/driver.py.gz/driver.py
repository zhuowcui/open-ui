import fcntl
import gzip
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

ROOT = Path('/home/nero/code/open-ui')
BASE = Path('/mnt/d/openui-v02-qualification-d174ea0b')
OUT = BASE / 'native-resolved-raster-clean-full-v3865'
DEST = ROOT / 'docs/renderer/evidence/native-font-families-v3'
INDEX = ROOT / 'docs/renderer/generated/native-font-families-v3.json'
load = lambda p: json.loads(Path(p).read_bytes())
sha = lambda b: hashlib.sha256(b).hexdigest()
lock = open('/tmp/openui-native-cargo-raster-owner.lock', 'a+')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
r = load(OUT / 'receipt.json')
audit = load('/tmp/openui-native-resolved-raster-clean-full-audit-v3866.json')
reaped = load('/tmp/openui-native-resolved-raster-clean-full-reaped-v3867.json')
inventory = load('/tmp/openui-native-resolved-raster-residual-inventory-v3872.json')
assert r['all_commands_terminal'] and audit['complete'] and reaped['all_local_commands_terminal']
assert reaped['owners_absent'] and r['source'] == audit['source'] == reaped['source'] == inventory['source']
assert r['source']['clean'] and sha((OUT / 'receipt.json').read_bytes()) == audit['receipt_sha256']
for name in ['cargo', 'rustc', 'rustfmt', 'pixel_compare']:
    assert subprocess.run(['pgrep', '-x', name], capture_output=True).returncode == 1
assert subprocess.run(['ps', '-p', str(r['owner_pid'])], capture_output=True).returncode == 1
assert not DEST.exists() and not INDEX.exists() and shutil.disk_usage(ROOT).free > 192 * 2**20
previous_index = ROOT / 'docs/renderer/generated/native-font-families-v2.json'
previous = load(previous_index)
assert sha(previous_index.read_bytes()) == r['candidate_index_sha256']
for row in previous['source_preparation']['files']:
    assert sha((ROOT / row['path']).read_bytes()) == row['after_sha256']
DEST.mkdir(parents=True)
members = []

def add(data, name):
    p = DEST / (name + '.gz')
    p.parent.mkdir(parents=True, exist_ok=True)
    assert not p.exists()
    stored = gzip.compress(data, mtime=0)
    assert shutil.disk_usage(ROOT).free - len(stored) > 128 * 2**20
    p.write_bytes(stored)
    assert p.read_bytes() == stored and gzip.decompress(stored) == data
    members.append(dict(path=str(p.relative_to(ROOT)), compression='gzip', bytes=len(stored),
                        sha256=sha(stored), raw_bytes=len(data), raw_sha256=sha(data)))

for path in sorted(OUT.iterdir()):
    if path.is_file():
        add(path.read_bytes(), 'matrices/' + path.name)
for suite in ['focused', 'primitive', 'full', 'expanded']:
    path = OUT / (suite + '-matrix') / (suite + '-summary.json')
    assert sha(path.read_bytes()) == r['matrices'][suite]['summary_sha256']
    add(path.read_bytes(), 'matrices/' + suite + '-summary.json')
build = load(OUT / 'guarded-build/receipt.json')
for path in sorted((OUT / 'guarded-build').iterdir()):
    if path.is_file() and str(path) != build['binary']:
        add(path.read_bytes(), 'guarded-build/' + path.name)
for name in ['openui-native-resolved-raster-clean-full-v3865.py',
             'openui-native-resolved-raster-clean-full-audit-v3866.py',
             'openui-native-resolved-raster-clean-full-audit-v3866.json',
             'openui-native-resolved-raster-clean-full-reaping-v3867.py',
             'openui-native-resolved-raster-clean-full-reaped-v3867.json',
             'openui-native-resolved-raster-residual-inventory-v3872.py',
             'openui-native-resolved-raster-residual-inventory-v3872.json',
             'openui-native-font-cell-analysis-v3871.py',
             'openui_parallel_source_identity_v3060.py']:
    add((Path('/tmp') / name).read_bytes(), 'probes-and-proofs/' + name)
cells = load(BASE / 'native-font-cell-analysis-v3871.json')
assert not cells['production_code_changed'] and not cells['native_app_rerun']
assert cells['native_receipt_sha256'] == previous['native']['receipt_sha256']
add((BASE / 'native-font-cell-analysis-v3871.json').read_bytes(), 'prior-native-diagnostic/cells.json')
crosswalk_path = BASE / 'native-style-api-crosswalk-v3881.json'
crosswalk = load(crosswalk_path)
assert crosswalk['source_commit'] == r['source']['commit']
assert not crosswalk['production_code_changed'] and not crosswalk['native_api_qualification']
assert sha((ROOT / 'docs/renderer/generated/javascript-mutation-audit-v4.json').read_bytes()) == crosswalk['audit_sha256']
assert sha((ROOT / 'bindings/rust/openui/src/generated_style_setters.rs').read_bytes()) == crosswalk['public_setters_sha256']
add(crosswalk_path.read_bytes(), 'native-api-review/style-signatures.json')
add((ROOT / 'bindings/rust/openui/src/generated_style_setters.rs').read_bytes(), 'native-api-review/generated_style_setters.rs')
position_review_path = BASE / 'native-harfbuzz-position-source-review-v3882.json'
position_review = load(position_review_path)
assert not position_review['production_code_changed'] and not position_review['measured_pixel_root_cause']
add(position_review_path.read_bytes(), 'shaping-source-review/positions.json')
for index, source in enumerate(position_review['inputs']):
    data = Path(source['path']).read_bytes()
    assert sha(data) == source['sha256']
    add(data, 'shaping-source-review/' + str(index) + '-' + Path(source['path']).name)
hosted_path = Path('/tmp/openui-native-resolved-raster-hosted-complete-v3878.json')
hosted = load(hosted_path)
assert hosted['source_commit'] == r['source']['commit'] and hosted['all_required_hosted_jobs_passed']
assert hosted['total_jobs'] == 12 and hosted['skipped_jobs'] == 0
add(hosted_path.read_bytes(), 'hosted/completed.json')
for run in hosted['runs']:
    path = Path(run['raw_path'])
    assert sha(path.read_bytes()) == run['raw_sha256']
    add(path.read_bytes(), 'hosted/' + str(run['run']) + '.json')
for row in previous['source_preparation']['files']:
    add((ROOT / row['path']).read_bytes(), 'measured-source/' + row['path'])
add(Path(__file__).read_bytes(), 'archive-writer/driver.py')
result = dict(schema_version=1,
    status='clean-complete-census-observed-native-font-and-full-release-gates-open',
    actual_measured_source=r['source'], renderer=audit, residual_inventory=inventory,
    hosted=hosted,
    previous_native_diagnostic_evidence=dict(path=str(previous_index.relative_to(ROOT)),
                                           sha256=sha(previous_index.read_bytes()), source=previous['native']['source']),
    prior_native_cell_analysis=cells, clean_native_application_verification_complete=False,
    native_style_signature_crosswalk=crosswalk,
    shaping_position_source_review=position_review,
    all_local_commands_terminal=True, all_members_hash_verified=True,
    source_or_reference_images_rewritten=False, pixel_target='pinned Chromium', pixel_tolerance=0,
    historical_openui_archive_is_a_pixel_target=False, javascript_executed_by_openui=False,
    full_renderer_contract_qualified=False, all_native_apis_qualified=False, release_qualified=False,
    pending=['all complete original and expanded comparisons exact with zero errors',
             'all remaining residuals need reviewed causes, owners and minimized Engine-backed reproducers',
             'native font-family whole images, intrinsic widths, floats and fallback line metrics',
             'clean native application, complete workspace and ABI checks on this source',
             'replace legacy font-name, size, phase and hinting exceptions with shared behavior',
             'all other required native APIs, compositor/3D, physical lab and release qualification'],
    archive=dict(files=len(members), bytes=sum(row['bytes'] for row in members), members=members,
                 excluded=[dict(path=build['binary'], sha256=build['binary_sha256'],
                                reason='owned executable retained in qualification directory; archived exact hash and fresh linked-library provenance'),
                           dict(path=str(OUT), reason='matrix capture PNGs and temporary HTML retained outside Git; complete decoded-image hashes, input identities and exact difference signatures archived')]))
INDEX.write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
print(json.dumps(dict(index=str(INDEX), files=len(members), bytes=result['archive']['bytes'],
                      results=audit['results'], candidate_nonregression=audit['candidate_nonregression'])), flush=True)
