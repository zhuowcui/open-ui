import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path('/home/nero/code/open-ui')
OUT = Path('/mnt/d/openui-v02-qualification-d174ea0b/native-resolved-raster-final-checks-v3884')
OUT.mkdir(exist_ok=True)
commands = {
    'style': ['python3', '-B', 'tools/style/generate_properties.py', '--check'],
    'ffi': ['python3', '-B', 'tools/ffi/generate_ffi.py', '--check'],
    'renderer': ['python3', '-B', 'tools/qualification/generate_renderer_contract.py', '--check'],
    'release': ['python3', '-B', 'tools/release/generate_v02_contract.py', '--check'],
    'accountability': ['python3', '-B', 'tools/accountability/audit.py', '--repository-only'],
    'whitespace': ['git', 'diff', '--check'],
}
name = sys.argv[1]
assert name in commands
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
with (OUT / (name + '.stdout')).open('xb') as stdout, (OUT / (name + '.stderr')).open('xb') as stderr:
    result = subprocess.run(commands[name], cwd=ROOT, env=env, stdout=stdout, stderr=stderr)
record = dict(name=name, command=commands[name], actual_exit_code=result.returncode,
              child_reaped=True, driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
for channel in ['stdout', 'stderr']:
    record[channel + '_sha256'] = hashlib.sha256((OUT / (name + '.' + channel)).read_bytes()).hexdigest()
(OUT / (name + '.json')).write_text(json.dumps(record, sort_keys=True, indent=2) + '\n')
print(json.dumps(dict(name=name, actual_exit_code=result.returncode, child_reaped=True)), flush=True)
raise SystemExit(result.returncode)
