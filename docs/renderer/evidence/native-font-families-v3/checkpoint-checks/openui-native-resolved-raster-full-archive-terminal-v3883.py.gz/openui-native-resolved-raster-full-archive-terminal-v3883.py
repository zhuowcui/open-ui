import gzip
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path('/home/nero/code/open-ui')
INDEX = ROOT / 'docs/renderer/generated/native-font-families-v3.json'
load = lambda p: json.loads(Path(p).read_bytes())
sha = lambda data: hashlib.sha256(data).hexdigest()
assert int(sys.argv[1]) == 0
r = load(INDEX)
assert r['all_local_commands_terminal'] and r['all_members_hash_verified']
assert 'archive_writer_terminal' not in r
proof = load('/tmp/openui-native-resolved-raster-clean-full-reaped-v3867.json')
assert proof['all_local_commands_terminal'] and proof['owners_absent']
assert proof['source'] == r['actual_measured_source']
for row in r['archive']['members']:
    data = (ROOT / row['path']).read_bytes()
    assert len(data) == row['bytes'] and sha(data) == row['sha256']
    raw = gzip.decompress(data)
    assert len(raw) == row['raw_bytes'] and sha(raw) == row['raw_sha256']
assert r['archive']['files'] == len(r['archive']['members'])
assert r['archive']['bytes'] == sum(row['bytes'] for row in r['archive']['members'])
r['archive_writer_terminal'] = dict(actual_exit_code=int(sys.argv[1]),
                                    actual_session=int(sys.argv[2]), reaped=True,
                                    all_archive_members_raw_and_stored_hash_verified=True,
                                    prior_owner_audit_sessions=proof['actual_sessions'])
INDEX.write_text(json.dumps(r, sort_keys=True, indent=2) + '\n')
print(json.dumps(dict(index=str(INDEX), files=r['archive']['files'],
                      bytes=r['archive']['bytes'], writer_actual_exit_code=int(sys.argv[1]),
                      writer_reaped=True, all_members_verified=True)), flush=True)
