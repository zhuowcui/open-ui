import hashlib
import json
from pathlib import Path

ROOT = Path('/home/nero/code/open-ui')
INDEX = ROOT / 'docs/renderer/generated/native-font-families-v3.json'
load = lambda p: json.loads(Path(p).read_bytes())
r = load(INDEX)
assert r['all_local_commands_terminal'] and r['all_members_hash_verified']
assert r['archive_writer_terminal']['actual_exit_code'] == 0
assert r['archive_writer_terminal']['reaped']
a = r['renderer']
assert a['complete'] and a['source']['clean']
assert a['matrix_rows_verified'] == 48252
assert r['hosted']['all_required_hosted_jobs_passed']
assert r['hosted']['total_jobs'] == 12 and r['hosted']['skipped_jobs'] == 0
assert not r['full_renderer_contract_qualified']
f, e = a['results']['full'], a['results']['expanded']
assert f['errors'] == e['errors'] == 0
assert f['different'] > 0 and e['different'] > 0
assert a['results']['focused']['exact'] == 640
assert a['results']['primitive']['exact'] == 960
inventory = r['residual_inventory']
commit = a['source']['commit'][:8]
base = Path('/mnt/d/openui-v02-qualification-d174ea0b/native-resolved-raster-clean-full-v3865')
original = load(base / 'full-matrix/full-summary.json')
expanded = load(base / 'expanded-matrix/expanded-summary.json')
original_ids = {t['id'] for p in original['profiles'] for t in p['tests']}
additional = {}
for profile in expanded['profiles']:
    for test in profile['tests']:
        if test['id'] not in original_ids:
            additional.setdefault(test['id'], []).append(test['status'])
assert all(len(values) == 4 for values in additional.values())
exact_additions = sum(all(s == 'exact' for s in values) for values in additional.values())

def n(value):
    return f'{value:,}'

comparison = '\n'.join(
    f"The {name} census gains **{v['gains']}** exact comparisons, loses **{v['losses']}**, "
    f"and worsens **{v['worsened']}** differences against the previous clean source."
    for name, v in [('original', f), ('expanded', e)]
)

def section(level, link):
    return f'''{level} Resolved font raster selection (clean census; remaining gates open)

Ordinary author text now selects its raster policy from each resolved font
run, replacing the rule based on the first authored family name. Aliased,
grayscale and LCD runs retain their own edging when mixed in one text blob.
The two-file change adds no font-name, size, scale or test-ID exception.

Fresh CPU verification at clean `{commit}` measures **{n(f['exact'])}/{n(f['total'])}
original** and **{n(e['exact'])}/{n(e['total'])} expanded** exact comparisons,
with **{n(f['different'])} / {n(e['different'])} differences**, zero errors and
actual exits **{f['actual_exit_code']} / {e['actual_exit_code']}**. Focused **640/640** and primitive
**960/960** are exact. All **48,252 rows**, fresh linked artifacts and unchanged
Chromium references are audited.
{comparison}

All **12 hosted jobs** pass on this source, with zero skipped jobs: format,
ordinary CI and all seven explicitly dispatched hardening jobs. The hosted
X11 software/Mesa and pure Wayland consumers pass; physical lab qualification
remains open.
[Hardening run 38100438813](https://github.com/zhuowcui/open-ui/actions/runs/38100438813).

Earlier dirty-source native diagnostics preserve pixels and bounds when the
same font bytes are registered under another name, at five profiles, and
different font bytes still change pixels. Both Rust callbacks, repeats and
weak teardown pass, as do **1,181 layout/text/paint tests**. That application
remains **0/15 whole images and 165/210 bounds exact**, with four images worse
than its baseline. These are earlier diagnostics, not a clean application
measurement at `{commit}`. Intrinsic width, consecutive floats, fallback line
height and other raster differences remain open.

There are **{n(inventory['remaining_test_ids'])} residual original test IDs**, including
**{n(len(inventory['residual_ids_without_ledger_entry']))} without a reviewed ownership entry**.
Clean native application, complete workspace and ABI checks remain pending.
The full Chromium pixel, complete native API, compositor, physical lab and
release gates remain open. Open UI never executes JavaScript; apps use public
native Rust APIs and Rust callbacks. Chromium alone defines expected pixels.
[Immutable clean census evidence]({link}).

'''

changes = []

def replace_row(text, prefix, replacement):
    lines = text.splitlines(keepends=True)
    matched = [i for i, line in enumerate(lines) if line.startswith(prefix)]
    assert len(matched) == 1, prefix
    lines[matched[0]] = replacement + '\n'
    return ''.join(lines)

for relative, level, link in [
    ('README.md', '###', 'docs/renderer/generated/native-font-families-v3.json'),
    ('docs/progress/current-status.md', '###', '../renderer/generated/native-font-families-v3.json'),
    ('docs/renderer/contract.md', '##', 'generated/native-font-families-v3.json'),
]:
    p = ROOT / relative
    before = p.read_text()
    marker = level + ' Resolved font raster selection (candidate, complete qualification pending)\n'
    start = before.index(marker)
    end = before.index('\n' + level + ' ', start + len(marker)) + 1
    after = before[:start] + section(level, link) + before[end:]
    if relative == 'docs/progress/current-status.md':
        after = replace_row(after, '| Latest complete clean umbrella census |',
            f"| Latest complete clean umbrella census | [Clean resolved-font census]({link}) at `{commit}`: {n(f['exact'])}/{n(f['total'])} exact, {n(f['different'])} different, 0 errors; expanded {n(e['exact'])}/{n(e['total'])} exact, {n(e['different'])} different; both actual exits 1; {n(inventory['remaining_test_ids'])} residual original IDs |")
        after = replace_row(after, '| Focused / primitive 40-profile matrices |',
            f"| Focused / primitive 40-profile matrices | 640/640 / 960/960 exact at clean `{commit}`; all 1,600 native images and Chromium reference fields unchanged. [Clean resolved-font census]({link}) |")
        after = replace_row(after, '| Expanded native final-state additions |',
            f"| Expanded native final-state additions | {exact_additions}/{len(additional)} additional cases exact at all four profiles in the clean `{commit}` run |")
        after = replace_row(after, '| Pending native final-state candidates |',
            f"| Pending native final-state candidates | 35 AST-lowered cases remain outside this clean manifest and unqualified on `{commit}` |")
        old = '''- The [current hardening run](https://github.com/zhuowcui/open-ui/actions/runs/36365378115)
  still fails AddressSanitizer, LeakSanitizer, and fuzz on process-exit
  Fontconfig allocations. Its MSRV, Miri, Linux platform, and C UBSan jobs
  passed.
- The four-profile Chromium census fails exactness; 914 residual test IDs
  have no reviewed owner. Both 40-profile CPU raster matrices are exact.
'''
        assert after.count(old) == 1
        new = f'''- The four-profile Chromium census fails exactness at clean `{commit}`;
  {n(len(inventory['residual_ids_without_ledger_entry']))} residual test IDs have no reviewed owner.
  Both 40-profile CPU raster matrices are exact. All 12 hosted jobs, including
  all seven explicitly dispatched hardening jobs, pass with zero skips.
  [Same-source hardening](https://github.com/zhuowcui/open-ui/actions/runs/38100438813).
'''
        after = after.replace(old, new)
    p.write_text(after)
    changes.append(dict(path=relative, before_sha256=hashlib.sha256(before.encode()).hexdigest(),
                        after_sha256=hashlib.sha256(after.encode()).hexdigest()))

p = ROOT / 'docs/v02/release.md'
before = p.read_text()
position = before.index('## Corrected text raster policy (clean verification)')
after = before[:position] + section('##', '../renderer/generated/native-font-families-v3.json') + before[position:]
link = '../renderer/generated/native-font-families-v3.json'
after = replace_row(after, '| Four-profile renderer matrix |',
    f"| Four-profile renderer matrix | [Clean resolved-font census]({link}) at clean `{commit}`: {n(f['exact'])}/{n(f['total'])} exact, {n(f['different'])} different, zero errors; actual exit 1. Chromium references are unchanged; {n(inventory['remaining_test_ids'])} residual original IDs need closure | fail |")
after = replace_row(after, '| Focused and primitive raster |',
    f"| Focused and primitive raster | [Clean resolved-font census]({link}) at clean `{commit}`: 640/640 focused and 960/960 primitive exact; all 1,600 native images and Chromium reference fields remain unchanged | source-attributed scoped pass |")
after = replace_row(after, '| Expanded native final-state fixtures |',
    f"| Expanded native final-state fixtures | [Clean resolved-font census]({link}) at clean `{commit}`: {n(e['exact'])}/{n(e['total'])} exact, {n(e['different'])} different, zero errors; actual exit 1. {exact_additions}/{len(additional)} additions exact at all four profiles; 35 AST-lowered cases remain outside the current manifest and unqualified on this source. Open UI runs no JavaScript | open |")
p.write_text(after)
changes.append(dict(path=str(p.relative_to(ROOT)), before_sha256=hashlib.sha256(before.encode()).hexdigest(),
                    after_sha256=hashlib.sha256(after.encode()).hexdigest()))

p = ROOT / 'docs/v02/unsupported-features.md'
before = p.read_text()
start = before.index('- a shared candidate removes first-authored-family raster selection')
end = before.index('- clean `ccb2dfa9`', start)
replacement = f'''- resolved-font raster selection is measured at clean `{commit}`. Focused
  640/640 and primitive 960/960 comparisons are exact. Original
  {n(f['exact'])}/{n(f['total'])} and expanded {n(e['exact'])}/{n(e['total'])} remain failed,
  with zero errors. All 48,252 rows and unchanged Chromium references are
  audited. All 12 hosted jobs pass, with zero skips. Earlier dirty native
  font-family diagnostics remain 0/15 images and 165/210 bounds exact, with
  four images worse than baseline; no clean native app qualification is
  claimed. Clean app, full workspace and ABI checks remain pending.
  [Clean census evidence](../renderer/generated/native-font-families-v3.json);
'''
after = before[:start] + replacement + before[end:]
p.write_text(after)
changes.append(dict(path=str(p.relative_to(ROOT)), before_sha256=hashlib.sha256(before.encode()).hexdigest(),
                    after_sha256=hashlib.sha256(after.encode()).hexdigest()))

proof = Path('/tmp/openui-native-resolved-raster-clean-docs-v3879.json')
assert not proof.exists()
proof.write_text(json.dumps(dict(schema_version=1, measured_source=a['source'],
                                evidence_sha256=hashlib.sha256(INDEX.read_bytes()).hexdigest(),
                                documents=changes, renderer_qualified=False,
                                all_native_apis_qualified=False, release_qualified=False),
                            sort_keys=True, indent=2) + '\n')
print(json.dumps(dict(updated=[x['path'] for x in changes], measured_source=commit)), flush=True)
