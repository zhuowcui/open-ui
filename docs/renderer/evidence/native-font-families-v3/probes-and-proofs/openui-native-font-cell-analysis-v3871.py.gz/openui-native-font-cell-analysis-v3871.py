import collections
import hashlib
import json
import math
from pathlib import Path

from PIL import Image, ImageChops

BASE = Path('/mnt/d/openui-v02-qualification-d174ea0b')
NEW = BASE / 'native-resolved-raster-trial-v3847'
OLD = BASE / 'native-general-font-baseline-v3833'
REF = BASE / 'native-general-font-chromium-v3824'
DEST = BASE / 'native-font-cell-analysis-v3871.json'
load = lambda p: json.loads(Path(p).read_bytes())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
new = load(NEW / 'receipt.json')
old = load(OLD / 'receipt.json')
reference = load(REF / 'receipt.json')
assert new['all_commands_terminal'] and old['all_commands_terminal'] and reference['all_commands_terminal']
assert new['reference_receipt_sha256'] == sha(REF / 'receipt.json')
assert len(new['cases']) == len(old['cases']) == len(reference['cases']) == 5
assert not DEST.exists()
rows = []
images = []

def mask(expected, actual):
    diff = ImageChops.difference(expected, actual)
    result = diff.getchannel('R')
    for channel in ['G', 'B', 'A']:
        result = ImageChops.lighter(result, diff.getchannel(channel))
    return result.point(lambda value: int(value != 0))

for i, case in enumerate(new['cases']):
    profile = case['profile']
    assert profile == old['cases'][i]['profile'] == reference['cases'][i]['profile']
    scale = profile['scale']
    for stage in ['before', 'alias', 'after']:
        expected_path = REF / f'profile-{i}/chromium-1-{stage}-capture-1.png'
        actual_path = NEW / f'profile-{i}/native-1/{stage}.png'
        baseline_path = OLD / f'profile-{i}/native-1/{stage}.png'
        current = case['stages'][stage]
        prior = old['cases'][i]['stages'][stage]
        assert sha(expected_path) == current['chromium_png_sha256'] == prior['chromium_png_sha256']
        assert sha(actual_path) == current['native_png_sha256']
        assert sha(baseline_path) == prior['native_png_sha256']
        with Image.open(expected_path) as e, Image.open(actual_path) as a, Image.open(baseline_path) as b:
            expected = e.convert('RGBA'); actual = a.convert('RGBA'); baseline = b.convert('RGBA')
        assert expected.size == actual.size == baseline.size
        width, height = expected.size
        actual_mask = mask(expected, actual)
        baseline_mask = mask(expected, baseline)
        total_current = actual_mask.histogram()[1]
        total_prior = baseline_mask.histogram()[1]
        assert total_current == current['analysis']['mismatched_pixels']
        assert total_prior == prior['analysis']['mismatched_pixels']
        current_bounds = {r['name']: r['bounds'] for r in current['native_bounds']}
        expected_bounds = {r['name']: r['bounds'] for r in current['chromium_bounds']}
        cells = []
        for row, size in enumerate([10, 12, 16, 23]):
            for col in range(3):
                left, right = [(0, 117), (117, 229), (229, 350)][col]
                top, bottom = [(0, 115), (115, 230), (230, 345), (345, 475)][row]
                face = ['Ahem.ttf', 'DejaVuSans.ttf', 'DejaVuSansMono.ttf'][(col + int(stage == 'after')) % 3]
                cells.append((f'case-{row}-{col}', face, size, left, top, right, bottom))
        cells += [('atomic-word', 'DejaVuSans.ttf' if stage == 'after' else 'Ahem.ttf', 16, 0, 475, 165, 560),
                  ('atomic-floats', None, None, 165, 475, 350, 560)]
        sums = [0, 0]
        for name, face, size, left, top, right, bottom in cells:
            rect = tuple(min(limit, max(0, math.floor(value * scale)))
                         for value, limit in [(left, width), (top, height), (right, width), (bottom, height)])
            current_pixels = actual_mask.crop(rect).histogram()[1]
            prior_pixels = baseline_mask.crop(rect).histogram()[1]
            sums[0] += current_pixels; sums[1] += prior_pixels
            rows.append(dict(profile=profile, stage=stage, node=name, primary_font_bytes=face, font_size=size,
                             diagnostic_cell_physical_bounds=list(rect), mismatched_pixels=current_pixels,
                             baseline_mismatched_pixels=prior_pixels, pixel_count_change=current_pixels-prior_pixels,
                             native_bounds=current_bounds[name], chromium_bounds=expected_bounds[name],
                             bounds_exact=current_bounds[name] == expected_bounds[name]))
        assert sums[0] <= total_current and sums[1] <= total_prior
        images.append(dict(profile=profile, stage=stage, mismatched_pixels=total_current,
                           baseline_mismatched_pixels=total_prior, outside_diagnostic_cells=total_current-sums[0],
                           baseline_outside_diagnostic_cells=total_prior-sums[1],
                           actual_png_sha256=current['native_png_sha256'], chromium_png_sha256=current['chromium_png_sha256'],
                           baseline_png_sha256=prior['native_png_sha256']))
        print(json.dumps(dict(profile=profile, stage=stage, current=total_current, baseline=total_prior,
                              outside=total_current-sums[0])), flush=True)
groups = collections.defaultdict(lambda: dict(current=0, baseline=0, rows=0))
for row in rows:
    key = (row['primary_font_bytes'] or 'floats') + '@' + str(row['font_size'])
    group = groups[key]
    group['current'] += row['mismatched_pixels']; group['baseline'] += row['baseline_mismatched_pixels']; group['rows'] += 1
result = dict(schema_version=1, measured_source=new['source'], baseline_source=old['source'],
              native_receipt_sha256=sha(NEW / 'receipt.json'), baseline_receipt_sha256=sha(OLD / 'receipt.json'),
              chromium_receipt_sha256=sha(REF / 'receipt.json'), driver_sha256=sha(__file__),
              comparison_kind='exact pixel counts partitioned by diagnostic cells from the native font-family consumer',
              diagnostic_cell_boundaries_are_not_rendering_rules=True, expected_images_unchanged=True,
              production_code_changed=False, native_app_rerun=False, chromium_internal_preferences_captured=False,
              reviewed_residual_owners_assigned=0, images=images, cells=rows, font_groups=dict(groups),
              totals=dict(images=len(images), cells=len(rows), mismatched_pixels=sum(r['mismatched_pixels'] for r in images),
                          baseline_mismatched_pixels=sum(r['baseline_mismatched_pixels'] for r in images)),
              pixel_target='pinned Chromium', pixel_tolerance=0, javascript_executed_by_openui=False,
              renderer_qualified=False, all_native_apis_qualified=False, release_qualified=False)
DEST.write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
print(json.dumps(dict(output=str(DEST), totals=result['totals'], font_groups=result['font_groups'])), flush=True)
