import gzip,hashlib,json,os,shutil,subprocess,sys,tarfile
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1'
OUT=RAW/'native-editor-scrollport-archive-v2372';STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/OUT.name
assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
sys.path.insert(0,str(MAIN/'tools/qualification'));from renderer_source_identity import repository_source_identity
public=repository_source_identity(MAIN);assert public['clean'] and public['commit']=='2827a03d2798eeee94eb75a9a2af358938e752b7'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_bytes())
baseline=load(RAW/'native-glyph-regression-pipeline-v2366/receipt.json')
before={(c['label'],c['state']):c for c in baseline['cases']}
names=['native-glyph-regression-pipeline-v2353','native-glyph-regression-pipeline-v2359','native-glyph-regression-pipeline-v2366','native-glyph-regression-pipeline-v2364']
cases=[];files={}
def add(path,name):
    assert path.is_file() and name not in files;files[name]=path
def directory(path,prefix):
    for p in sorted(path.rglob('*')):
        if p.is_file() and p.suffix in ['.json','.png','.html','.log','.py']:
            add(p,prefix+'/'+str(p.relative_to(path)))
for name in names:
    p=RAW/name/'receipt.json';r=load(p)
    assert r['all_commands_terminal'] and r['source_unchanged'] and r['public_source_unchanged']
    assert not Path('/proc',str(r['owner_pid'])).exists()
    native_first=RAW/name/'native-first';native_second=RAW/name/'native-second'
    changed=[]
    for c in r['cases']:
        key=(c['label'],c['state']);old=before[key]
        picture=native_first/c['label']/(c['state']+'.png')
        assert sha(picture)==c['native']['png_sha256'] and sha(native_second/c['label']/(c['state']+'.png'))==sha(picture)
        expected=RAW/name/(c['label']+'-'+c['state'])/'1.png'
        assert sha(expected)==c['chromium']['png_sha256']
        assert c['chromium']==old['chromium']
        changed.append(dict(label=c['label'],state=c['state'],before_wrong_pixels=old['difference']['mismatched_pixels'],wrong_pixels=c['difference']['mismatched_pixels'],exact_gain=not old['exact'] and c['exact'],exact_loss=old['exact'] and not c['exact'],more_wrong_pixels=c['difference']['mismatched_pixels']>old['difference']['mismatched_pixels']))
    row=dict(name=name,source=r['source'],receipt_sha256=sha(p),observed_exit_code=r['observed_exit_code'],totals=r['totals'],exact_gains=sum(x['exact_gain'] for x in changed),exact_losses=sum(x['exact_loss'] for x in changed),more_wrong_states=sum(x['more_wrong_pixels'] for x in changed),changes=changed,all_commands_terminal=True)
    cases.append(row);directory(RAW/name,'runs/'+name)
for name in ['native-input-raster-checks-v2354','native-editor-clipping-primary-v2355','native-editor-shadow-bounds-v2356','native-editor-clip-checks-v2361','native-editor-clip-main-checks-v2367']:
    directory(RAW/name,'support/'+name)
    for p in sorted((RAW/name).rglob('*.cc')):add(p,'primary/'+name+'/'+str(p.relative_to(RAW/name)))
gates=RAW/'native-editor-clip-renderer-gates-v2369';gate_receipt=load(gates/'receipt.json')
assert gate_receipt['all_commands_terminal'] and gate_receipt['source_unchanged'] and gate_receipt['public_source_unchanged']
assert not Path('/proc',str(gate_receipt['owner_pid'])).exists()
for p in sorted(gates.glob('*')):
    if p.is_file() and p.suffix in ['.json','.log']:add(p,'renderer-gates/'+p.name)
for p in sorted(gates.glob('*-matrix/*-summary.json')):add(p,'renderer-gates/'+str(p.relative_to(gates)))
retry=RAW/'native-editor-clip-renderer-retry-v2374';retry_receipt=load(retry/'receipt.json')
assert retry_receipt['all_commands_terminal'] and retry_receipt['source_unchanged'] and retry_receipt['public_source_unchanged']
assert not Path('/proc',str(retry_receipt['owner_pid'])).exists()
for p in sorted(retry.glob('*')):
    if p.is_file() and p.suffix in ['.json','.log']:add(p,'renderer-retry/'+p.name)
for p in sorted(retry.glob('*-matrix/*-summary.json')):add(p,'renderer-retry/'+str(p.relative_to(retry)))
attribution=RAW/'native-editor-main-attribution-v2378';attribution_receipt=load(attribution/'receipt.json')
assert attribution_receipt['all_commands_terminal'] and attribution_receipt['source_unchanged'] and attribution_receipt['public_source_unchanged']
assert not Path('/proc',str(attribution_receipt['owner_pid'])).exists()
for p in sorted(attribution.glob('*')):
    if p.is_file() and p.suffix in ['.json','.log']:add(p,'main-attribution/'+p.name)
for p in sorted(attribution.glob('*-matrix/*-summary.json')):add(p,'main-attribution/'+str(p.relative_to(attribution)))
fresh_main=RAW/'native-editor-main-fresh-libraries-v2385';fresh_main_receipt=load(fresh_main/'receipt.json')
fresh_clip=RAW/'native-editor-clip-fresh-libraries-v2386';fresh_clip_receipt=load(fresh_clip/'receipt.json')
for root,receipt,prefix in [(fresh_main,fresh_main_receipt,'fresh-main'),(fresh_clip,fresh_clip_receipt,'fresh-clip')]:
    assert receipt['all_commands_terminal'] and receipt['source_unchanged'] and receipt['public_source_unchanged']
    assert not Path('/proc',str(receipt['owner_pid'])).exists()
    for p in sorted(root.glob('*')):
        if p.is_file() and p.suffix in ['.json','.log']:add(p,prefix+'/'+p.name)
    for p in sorted(root.glob('*-matrix/*-summary.json')):add(p,prefix+'/'+str(p.relative_to(root)))
add(Path('/tmp/openui-build-renderer-v2387.py'),'build-provenance/build_renderer.py')
add(Path('/tmp/openui-test-build-renderer-v2388.py'),'build-provenance/test_build_renderer.py')
add(Path('/tmp/openui-renderer-matrix-library-proof-v2392.py'),'build-provenance/run_renderer_matrix.py')
add(Path('/tmp/openui-native-input-editor-docs-checks-v2393.py'),'probes/own-source-read-only-checks.py')
add(Path('/tmp/openui-native-editor-cargo-dependency-audit-v2383.json'),'build-provenance/dependency-path-audit.json')
add(Path('/tmp/openui-native-editor-workspace-cache-review-v2384.json'),'build-provenance/workspace-cache-review.json')
add(MAIN/'bindings/rust/openui-paint/src/painter.rs','sources/accepted-main/bindings/rust/openui-paint/src/painter.rs')
add(RAW/'native-editor-input-review-v2370.json','review/native-editor-input-review-v2370.json')
for version in [2352,2358,2363,2365]:
    root=MAIN/f'out/private-native-apps/native-glyph-regression-v{version}'
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
    for name in ['Cargo.toml','Cargo.lock','src/main.rs']:add(root/name,f'apps/v{version}/'+name)
roots=['private-native-input-raster-v2351','private-native-editor-clip-v2357','private-native-editor-clip-main-v2362']
sources=[]
for name in roots:
    root=MAIN/'out'/name;identity=repository_source_identity(root);assert identity['clean']
    sources.append(dict(root=name,identity=identity))
    for file in ['bindings/rust/openui-paint/src/painter.rs','bindings/rust/openui-text/src/shaping/shape_result.rs','bindings/rust/openui-paint/src/text_painter.rs']:
        add(root/file,'sources/'+name+'/'+file)
for p in sorted(Path('/tmp').glob('openui-native-*.py')):
    if any('v'+str(v) in p.name for v in range(2351,2393)):add(p,'probes/'+p.name)
for p in sorted(Path('/tmp').glob('openui-native-*.json')):
    if any('v'+str(v) in p.name for v in range(2351,2393)):add(p,'preparation/'+p.name)
for p in sorted(Path('/tmp').glob('openui-native-*.patch')):
    if any('v'+str(v) in p.name for v in [2351,2357,2362]):add(p,'patches/'+p.name)
fontconfig=MAIN/'tools/accountability/data/fonts/ahem_noaa.conf';add(fontconfig,'inputs/ahem_noaa.conf')
manifest=[dict(path=name,bytes=path.stat().st_size,sha256=sha(path)) for name,path in sorted(files.items())]
(OUT/'manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
archive=OUT/'completed-evidence.tar.gz'
with archive.open('xb') as stream:
    with gzip.GzipFile(filename='',mode='wb',fileobj=stream,mtime=0) as gz:
        with tarfile.open(fileobj=gz,mode='w') as tar:
            for name,path in sorted(files.items()):
                info=tar.gettarinfo(str(path),arcname=name);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
                with path.open('rb') as content:tar.addfile(info,content)
            info=tar.gettarinfo(str(OUT/'manifest.json'),arcname='manifest.json');info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
            with (OUT/'manifest.json').open('rb') as content:tar.addfile(info,content)
with tarfile.open(archive,'r:gz') as tar:
    for item in manifest:
        f=tar.extractfile(item['path']);assert f is not None
        assert hashlib.sha256(f.read()).hexdigest()==item['sha256']
assert repository_source_identity(MAIN)==public
review=load(RAW/'native-editor-input-review-v2370.json')
report=dict(schema_version=1,public_source=public,sources=sources,runs=cases,
    archive=dict(path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive),members=len(manifest)+1,all_member_bytes_verified=True),
    baseline_images_exact=22,latest_images_exact=28,latest_geometry_exact=30,
    own_parent_comparisons=review['comparisons'],remaining_native_residuals=review['remaining_native_residuals'],
    renderer_gates=fresh_clip_receipt,earlier_mixed_dependency_renderer_gates=retry_receipt,
    interrupted_renderer_gates=gate_receipt,earlier_mixed_dependency_main_attribution=attribution_receipt,
    accepted_main_attribution=fresh_main_receipt,
    fresh_libraries_own_parent_comparison=fresh_clip_receipt['clip_vs_fresh_main_selection'],
    stale_workspace_library_reuse_reproduced=True,earlier_library_dependency_provenance_not_established=True,
    accepted_original_exact=21334,accepted_original_total=22924,
    workspace_and_c_abi_not_run_on_new_sources=True,all_candidates_private_and_unapplied=True,
    no_new_release_state_admitted=True,chromium_reference_bytes_preserved=True,pixel_tolerance=0,
    javascript_executed_by_openui=False,all_commands_terminal=True,release_qualification=False,promotion_allowed=False,
    full_census_individual_image_caches_not_duplicated=True,full_census_summaries_archived=True,
    two_extra_format_checks_referenced_unintegrated_private_tests=True,probe_sha256=sha(Path(__file__)))
(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(archive=report['archive'],runs=[dict(name=r['name'],exact=r['totals']['exact_images'],geometry=r['totals']['exact_geometry']) for r in cases],all_commands_terminal=True)))
