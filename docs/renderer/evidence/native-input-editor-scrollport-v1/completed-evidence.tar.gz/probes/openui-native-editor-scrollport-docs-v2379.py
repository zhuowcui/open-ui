import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1'
sys.path.insert(0,str(MAIN/'tools/qualification'))
from renderer_source_identity import repository_source_identity
before=repository_source_identity(MAIN)
assert before['clean'] and before['commit']=='2827a03d2798eeee94eb75a9a2af358938e752b7'
for name in ['native-editor-clip-renderer-retry-v2374','native-editor-main-attribution-v2378','native-editor-main-fresh-libraries-v2385','native-editor-clip-fresh-libraries-v2386']:
    r=json.loads((RAW/name/'receipt.json').read_bytes())
    assert r['all_commands_terminal'] and r['source_unchanged'] and r['public_source_unchanged']
    assert not Path('/proc',str(r['owner_pid'])).exists()
for program in ['cargo','rustc','ninja','pixel_compare']:
    assert subprocess.run(['pgrep','-x',program],capture_output=True).returncode==1
report=json.loads((RAW/'native-editor-scrollport-archive-v2372/receipt.json').read_bytes())
g=report['renderer_gates'];a=report['accepted_main_attribution'];pair=report['fresh_libraries_own_parent_comparison']
full=g['matrices']['full'];expanded=g['matrices']['expanded']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
directory=MAIN/'docs/renderer/evidence/native-input-editor-scrollport-v1'
assert not directory.exists();directory.mkdir()
archive=directory/'completed-evidence.tar.gz'
shutil.copy2(report['archive']['path'],archive)
assert sha(archive)==report['archive']['sha256']
shutil.copy2(RAW/'native-editor-scrollport-archive-v2372/manifest.json',directory/'archive-members.json')
report['archive']['path']=str(archive.relative_to(MAIN))
report.update(accepted_main_vs_clip_selected_comparisons=pair,
    full_gates_failed=True,workspace_and_c_abi_not_run_on_new_sources=True,
    public_native_api_signatures_changed=False,stale_build_library_cause_reviewed=True)
index=MAIN/'docs/renderer/generated/native-input-editor-scrollport-v1.json'
assert not index.exists();index.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
def owned(path):
    if path.stat().st_nlink>1:
        temporary=path.with_name(path.name+'.owned-v2379');shutil.copy2(path,temporary);os.replace(temporary,path)
def summary(link):
    return f'''The [native input editor follow-up]({link}) corrects the private
single-line editor clip. Its consuming Rust app improves from **22/30 to
28/30 exact images**, with all thirty rectangles exact. Focused **640/640**
and primitive **960/960** pass. Complete original and expanded runs finish at
**{full['results']['exact']:,}/22,924** and **{expanded['results']['exact']:,}/23,728** exact,
zero errors and actual exits 1. Against the accepted census, the original has
{full['exact_gains']} exact gains, {full['exact_losses']} exact losses and
{full['worsened_comparisons']} more-wrong comparisons. A fresh clean
umbrella selection compares those changes with the patch's own parent.
The renderer implementation remains private and unapplied; two native glyph rows and
full qualification remain open. Accepted results are unchanged.
'''
old='''The [native glyph regression follow-up]({link})
reproduces the input and large-text failures through Rust callbacks. Its latest
private trials match **20/30 images and 30/30 rectangles**, with eight exact
gains and no exact losses, but two existing input differences worsen. All five
new sources pass eighteen read-only checks each. All trials remain private,
unapplied and rejected; their complete renderer and workspace gates are not
run. The relevant large-text baselines match Chromium, narrowing those failures
to paint origins, strike construction or raster coverage. Accepted results are unchanged.
'''
for name,old_link,new_link in [
    ('README.md','docs/renderer/native-glyph-regressions.md','docs/renderer/native-input-editor-scrollport.md'),
    ('docs/progress/current-status.md','../renderer/native-glyph-regressions.md','../renderer/native-input-editor-scrollport.md'),
    ('docs/renderer/contract.md','native-glyph-regressions.md','native-input-editor-scrollport.md')]:
    p=MAIN/name;content=p.read_text();needle=old.format(link=old_link)
    assert content.count(needle)==1,name;owned(p);p.write_text(content.replace(needle,summary(new_link)))
rows=[]
for n in ['focused','primitive','full','expanded']:
    e=g['matrices'][n];r=e['results'];rows.append(f"| {n.capitalize()} | {r['exact']:,}/{r['total']:,} | {r['different']:,} | {r['errors']} | {e['observed_exit_code']} |")
if pair['more_wrong_comparisons']==0:
    attribution=f"The patch changes {len(pair['changes'])} selected comparisons against its own freshly compiled umbrella parent, with {pair['exact_gains']} exact gains, {pair['exact_losses']} exact losses and no more-wrong comparison. The earlier six noninput differences do not establish regressions caused by the editor clip."
else:
    attribution=f"The patch changes {len(pair['changes'])} selected comparisons against its own clean umbrella parent, with {pair['exact_gains']} exact gains, {pair['exact_losses']} exact losses and {pair['more_wrong_comparisons']} more-wrong comparisons. The precise raster cause of the noninput changes remains open."
doc=f'''# Native single-line input editing clip

Open UI never executes JavaScript. The consuming app creates elements, handles
Rust callbacks, changes typed properties, and reads owned bounds through public
Rust APIs. Needed element behavior must be implemented in the shared engine
and exposed to native apps. Pinned Chromium alone defines expected pixels.

## Reviewed cause and implementation

Chromium's anonymous single-line editor uses its own line box as a scrollport.
Its pinned [anonymous editor style](https://chromium.googlesource.com/chromium/src/+/147.0.7727.50/third_party/blink/renderer/core/html/forms/text_control_inner_elements.cc)
(`TextControlInnerEditorElement::CustomStyleForLayoutObject`) clears
authored line height under specific host-height conditions, sets scrolling
overflow, hides scrollbars and creates a flow root. The native input painter
previously clipped text to a larger part of the host box.

Ten fresh Chromium captures, repeated across five profiles, keep every PNG
byte identical to the original reference. Read-only shadow-tree observations
measure the editor at x=31, y=26, width=78 and height=18 logical pixels, with
normal line height. At scale 1.25 its upper clip edge crosses a physical pixel;
Chromium paints that edge gray rather than solid black.

Clean private `e0f0e577` applies shared line-height handling and an antialiased
editor clip on the unchanged umbrella parent `2827a03d`. It subtracts right
padding from the editor width. It changes no font raster policy, public API,
test reference, or output pixels after rasterization. No font-name, font-size,
or test-ID rule is added. This remains a painter implementation; retained
anonymous layout, calculated-height neighbors, placeholder styles, native
editor scrolling, selection and other contexts still need qualification.

## Native application results

| Clean source | Exact images | Exact rectangles | Outcome |
|---|---:|---:|---|
| Umbrella `2827a03d` | 22/30 | 30/30 | Own-parent baseline |
| Editor clip `e0f0e577` | 28/30 | 30/30 | Six gains, no exact losses or more-wrong states |
| Text raster policy `a062ef3c` on the earlier glyph trial | 18/30 | 30/30 | Rejected: two exact losses and ten more-wrong states against its own parent |
| Editor clip `31def449` on the earlier glyph trial | 26/30 | 30/30 | Six gains against its own parent; still unqualified |

All thirty native images and geometry snapshots repeat byte for byte within
each source. The unchanged app executes fifteen Rust callbacks per run and
checks retained snapshots and teardown. Every corresponding Chromium PNG and
RGBA identity remains unchanged. Both remaining `e0f0e577` failures are at
scale 1.25: before x=39/y=54 and after x=40/y=55, each a 68-pixel black row
where Chromium is white. Text and paint, with native controls, own these open
glyph-mask failures. The accepted parent's ordinary and sticky large-text
states are already exact; the earlier glyph trial introduced those failures.

## Complete renderer checks

| Suite | Exact | Different | Errors | Actual exit |
|---|---:|---:|---:|---:|
{chr(10).join(rows)}

Both complete censuses retain their actual results above. The original gains
{full['exact_gains']} exact comparisons, loses {full['exact_losses']} and has
{full['worsened_comparisons']} more-wrong comparisons against the accepted census.
Earlier diagnostics showed six worsened noninput rows in three
`block-size-with-min-or-max-content-1` variants at the desktop profiles.
Their build attribution was not trustworthy, as described below.

The fresh clean umbrella runner checks all twelve changed test IDs across four
profiles ({pair['comparisons']} comparisons). {attribution}
This selection is a diagnostic, not a new complete umbrella census.

Every Chromium PNG, RGBA and oracle identity agrees with the prior complete
censuses. Focused and primitive preserve all native bytes. Every current stage
runs with freshly compiled workspace libraries and its own measured source.
Pixel tolerance is zero.

## Build cache diagnosis

Cleaning only `pixel-compare` produced a new executable with the correct
embedded checkout identity, but did not bind its cached workspace libraries
to that checkout. An apparent clean umbrella baseline then produced the same
48 selected images as the private trial, including its input changes and six
noninput differences. The library dependency files used relative workspace
paths. Earlier source identity checks alone could not prove those libraries'
source.

After all local workspace packages are cleaned, the baseline freshly compiles
all nine linked crates from the umbrella checkout. Its 48 selected comparisons
match every accepted pixel and oracle invariant. This reproduces stale library
reuse; there is no contradictory Chromium image. Earlier mixed-library runs
are preserved as unqualified diagnostics, with their actual exits and bytes.
The current trial also freshly compiles all nine linked crates before rendering.

The build safeguard cleans local packages and verifies Cargo artifact
records for fresh compilation and the measured manifest and source paths.
It also requires an unchanged checkout and hashes the copied runner. Cached,
foreign or missing library records cannot qualify a new source identity.
Future matrix runs require its successful receipt and check its binary hash
and source identity; the receipt must stay unchanged through the whole matrix.
This is a build safeguard, not a new pixel pass or native API completion.

## Failures and qualification limits

The first full run stops at its disk-space guard and remains incomplete. It
does not run expanded. Its entire process group is stopped before retry. Eight
unused historical binaries are moved to a larger filesystem only after process
and inode audits; their original paths remain symlinks and every hash is
verified. Live Codex history, reference bytes and active resources are untouched.
The retry completes both censuses using the same source-verified runner.

The editor source passes sixteen applicable read-only checks. Two additional
format commands fail because they name tests that exist only in a rejected
private glyph lineage; those errors are preserved and are not passes. The
workspace and C/ABI suite are not run on this source. Every pipeline retains
clean, unchanged source identities for its whole lifetime, including stage gaps.

The [versioned index](generated/native-input-editor-scrollport-v1.json) and
[completed archive](evidence/native-input-editor-scrollport-v1/completed-evidence.tar.gz)
preserve applications, lockfiles, reviewable patches, primary source bytes,
fresh shadow observations, repeated captures, difference regions and channel
deltas, actual exits, logs and complete matrix summaries. Every archive member
is independently hash verified. Existing archives remain unchanged.

All local owners are terminal. The implementation remains **private and
unapplied**, with no newly admitted release state. Accepted results remain
**21,334/22,924 original** and **22,137/23,728 expanded** exact. Full native
APIs, original pixel parity, residual ownership and release qualification
remain unfinished. Aggregate improvements do not establish a passing gate.
'''
p=MAIN/'docs/renderer/native-input-editor-scrollport.md';assert not p.exists();p.write_text(doc)
p=MAIN/'docs/renderer/native-glyph-regressions.md';owned(p);s=p.read_text();marker='## Completed result\n'
assert s.count(marker)==1
s=s.replace(marker,'''## Later editor-clip investigation

The [native editor follow-up](native-input-editor-scrollport.md) separates the
anonymous input clip from the rejected glyph changes. On the unchanged umbrella
parent, it improves 22/30 native images to 28/30, with all thirty rectangles
exact. Its own complete renderer checks and remaining failures are recorded
there. The sources below remain historical, private and rejected.

## Earlier completed result
''');p.write_text(s)
# Install the source-bound build safeguard after all measured owners have stopped.
helper=MAIN/'tools/qualification/build_renderer.py';tests=MAIN/'tools/qualification/test_build_renderer.py'
assert not helper.exists() and not tests.exists()
shutil.copy2('/tmp/openui-build-renderer-v2387.py',helper)
t=Path('/tmp/openui-test-build-renderer-v2388.py').read_text()
t=t.replace('SPEC = importlib.util.spec_from_file_location("build_renderer", "/tmp/openui-build-renderer-v2387.py")', 'ROOT = Path(__file__).resolve().parents[2]\nSPEC = importlib.util.spec_from_file_location("build_renderer", ROOT / "tools/qualification/build_renderer.py")')
compile(t,str(tests),'exec');tests.write_text(t)
matrix=MAIN/'tools/qualification/run_renderer_matrix.py';owned(matrix);shutil.copyfile('/tmp/openui-renderer-matrix-library-proof-v2392.py',matrix)
p=MAIN/'.github/workflows/ci.yml';owned(p);s=p.read_text()
marker='            tools.qualification.test_renderer_matrix '
assert s.count(marker)==1
s=s.replace(marker,'            tools.qualification.test_build_renderer '+chr(92)+'\n'+marker);p.write_text(s)
# Keep historical commands intact; publish the current source-bound procedure.
p=MAIN/'docs/renderer/contract.md';owned(p);s=p.read_text()
marker='`tools/qualification/run_renderer_matrix.py` uses separate, contract-pinned'
assert s.count(marker)==1
procedure="""## Build proof for current matrix runs

Build from a clean checkout with `tools/qualification/build_renderer.py`.
It cleans local Rust dependencies and checks Cargo's fresh artifact records;
the embedded executable identity alone does not prove cached library sources.
Use the qualification lab's pinned compiler and Skia configuration. For example:

```sh
python3 tools/qualification/build_renderer.py --offline \\
  --target-dir bindings/rust/target \\
  --results-dir out/renderer-build
python3 tools/qualification/run_renderer_matrix.py --suite focused \\
  --pixel-compare out/renderer-build/pixel_compare \\
  --build-receipt out/renderer-build/receipt.json \\
  --results-dir out/renderer-focused
```

The build receipt must agree with the measured source and executable hash and
remain unchanged through the matrix. Keep Main and the SDK clean and unchanged
for the whole pipeline, including the gaps between commands. Existing historical
commands and reports retain their original source and status; they do not waive
this requirement for a new run. Explicit dirty diagnostics cannot qualify a
release. No pixel tolerance or reference byte is changed.

"""
s=s.replace(marker,procedure+marker);p.write_text(s)
p=MAIN/'docs/renderer/frozen-oracle-audit.md';owned(p);s=p.read_text()
marker='```sh\npython3 tools/qualification/run_renderer_matrix.py --suite full '
assert s.count(marker)==1
replacement='```sh\npython3 tools/qualification/build_renderer.py --offline '+chr(92)+'\n  --target-dir bindings/rust/target '+chr(92)+'\n  --results-dir out/frozen-conflict-build\npython3 tools/qualification/run_renderer_matrix.py --suite full '
s=s.replace(marker,replacement)
s=s.replace('--pixel-compare bindings/rust/target/debug/pixel_compare '+chr(92), '--pixel-compare out/frozen-conflict-build/pixel_compare '+chr(92)+'\n  --build-receipt out/frozen-conflict-build/receipt.json '+chr(92));p.write_text(s)
subprocess.run(['python3','/tmp/openui-nojavascript-policy-v2391.py'],cwd=MAIN,check=True)
print(json.dumps(dict(archive_sha256=sha(archive),archive_members=report['archive']['members'],index=str(index),all_measured_owners_terminal=True)))
