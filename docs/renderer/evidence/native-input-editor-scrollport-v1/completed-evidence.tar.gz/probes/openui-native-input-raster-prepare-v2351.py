import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');BASE=MAIN/'out/private-native-glyph-em-outlines-v2334'
ROOT=MAIN/'out/private-native-input-raster-v2351'
OLDAPP=MAIN/'out/private-native-apps/native-glyph-regression-v2308'
APP=MAIN/'out/private-native-apps/native-glyph-regression-v2352'
OUT=Path('/tmp/openui-native-input-raster-prepare-v2351.json')
assert not ROOT.exists() and not APP.exists() and not OUT.exists()
sys.path.insert(0,str(MAIN/'tools/qualification'))
from renderer_source_identity import repository_source_identity
before=repository_source_identity(BASE);public=repository_source_identity(MAIN)
assert before['clean'] and before['commit']=='e811f3d9a9c8f12c49a2ad918e763c72f042a2b9' and public['clean']
assert shutil.disk_usage(MAIN).free>700*2**20
subprocess.run(['git','clone','--shared','--no-checkout',str(BASE),str(ROOT)],check=True,capture_output=True)
stores=[];pending=[(BASE/'.git/objects').resolve()]
while pending:
    store=pending.pop(0)
    if store in stores:continue
    stores.append(store);alternates=store/'info/alternates'
    if alternates.exists():
        for line in alternates.read_text().splitlines():
            path=Path(line);pending.append((path if path.is_absolute() else store/path).resolve())
(ROOT/'.git/objects/info/alternates').write_text('\n'.join(map(str,stores))+'\n')
for key in ['user.name','user.email']:
    value=subprocess.check_output(['git','config','--get',key],cwd=MAIN,text=True).strip()
    subprocess.run(['git','config',key,value],cwd=ROOT,check=True)
subprocess.run(['git','read-tree',before['commit']],cwd=ROOT,check=True)
for name in filter(None,subprocess.check_output(['git','ls-files','-z'],cwd=BASE).decode().split('\0')):
    src=BASE/name;dst=ROOT/name;dst.parent.mkdir(parents=True,exist_ok=True)
    if src.is_symlink():dst.symlink_to(os.readlink(src))
    else:os.link(src,dst)
assert repository_source_identity(ROOT)==before
name='bindings/rust/openui-paint/src/painter.rs'
p=ROOT/name;t=p.with_name(p.name+'.owned-v2351');shutil.copy2(p,t);os.replace(t,p)
s=p.read_text()
start=s.index('fn paint_text_input_control(');end=s.index('fn paint_single_line_control_text(',start)
part=s[start:end]
old='        control_style.native_button_text_metrics = true;'
new="        // The value and placeholder belong to the native anonymous editor,\n        // even when the application supplies the field's font and colors.\n        control_style.native_control_text = true;\n        control_style.native_button_text_metrics = true;"
assert part.count(old)==1;p.write_text(s[:start]+part.replace(old,new)+s[end:])
subprocess.run(['bash','-c','ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true '+name],cwd=ROOT,check=True)
subprocess.run(['git','add',name],cwd=ROOT,check=True)
patch=Path('/tmp/openui-native-input-raster-v2351.patch');assert not patch.exists()
patch.write_bytes(subprocess.check_output(['git','diff','--cached','--binary','--full-index'],cwd=ROOT))
subprocess.run(['git','commit','-m','Use native editing-content text policy for single-line controls'],cwd=ROOT,check=True,capture_output=True)
source=repository_source_identity(ROOT);assert source['clean'] and repository_source_identity(BASE)==before and repository_source_identity(MAIN)==public
APP.mkdir()
for name in ['Cargo.toml','Cargo.lock','src/main.rs']:
    p=APP/name;p.parent.mkdir(parents=True,exist_ok=True);content=(OLDAPP/name).read_bytes()
    if name=='Cargo.toml':content=content.replace(str(MAIN/'out/private-native-aliased-mask-v2268').encode(),str(ROOT).encode())
    p.write_bytes(content)
subprocess.run(['git','init','-q'],cwd=APP,check=True)
for key in ['user.name','user.email']:
    value=subprocess.check_output(['git','config','--get',key],cwd=MAIN,text=True).strip()
    subprocess.run(['git','config',key,value],cwd=APP,check=True)
subprocess.run(['git','add','.'],cwd=APP,check=True)
subprocess.run(['git','commit','-q','-m','Lock unchanged native glyph reductions against resolved hinting correction'],cwd=APP,check=True)
s=Path('/tmp/openui-native-glyph-regression-pipeline-v2309.py').read_text()
s=s.replace('private-native-aliased-mask-v2268','private-native-input-raster-v2351').replace('native-glyph-regression-v2308','native-glyph-regression-v2352').replace('native-glyph-regression-pipeline-v2309','native-glyph-regression-pipeline-v2353').replace('4839e107fee5ae07e28fcda990f3433216263580',source['commit']).replace('b20f92432d3bece41c83935becbe258959f78174',public['commit'])
s=s.replace('offline_javascript_executed_only_in_chromium=True','offline_javascript_executed_only_in_chromium=False')
start=s.index('            queries=[]');end=s.index("            assert queries[0]==queries[1]",start)
s=s[:start]+'''            frozen=RAW/'native-glyph-regression-pipeline-v2309'
            frozen_receipt=json.loads((frozen/'receipt.json').read_bytes())
            assert frozen_receipt['all_commands_terminal'] and frozen_receipt['source_unchanged'] and frozen_receipt['public_source_unchanged']
            old_case=next(c for c in frozen_receipt['cases'] if c['label']==label and c['state']==state)
            original=frozen/(label+'-'+state)
            assert page.read_bytes()==(original/'test.html').read_bytes() and sha(page)==old_case['fixture_sha256']
            queries=[]
            for repeat in [1,2]:
                picture=directory/(str(repeat)+'.png')
                assert identity(original/(str(repeat)+'.png'))==old_case['chromium']
                shutil.copy2(original/(str(repeat)+'.png'),picture)
                query=json.loads((original/(str(repeat)+'-geometry.json')).read_bytes())
                assert query==old_case['chromium_bounds']
                shutil.copy2(original/(str(repeat)+'-geometry.json'),directory/(str(repeat)+'-geometry.json'))
                queries.append(query)
''' + s[end:]
s=s.replace('shared_renderer_patch_applied=False','shared_renderer_patch_applied=True')
pipeline=Path('/tmp/openui-native-glyph-regression-pipeline-v2353.py');assert not pipeline.exists()
compile(s,str(pipeline),'exec');pipeline.write_text(s)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=dict(source=source,parent_source=before,public_source=public,root=str(ROOT),app_root=str(APP),source_patch=str(patch),source_patch_sha256=sha(patch),app_source_unchanged_from_baseline=sha(APP/'src/main.rs')==sha(OLDAPP/'src/main.rs'),resolved_hinting_and_interpreter_requirement_based=True,native_editing_content_uses_native_text_policy=True,new_font_name_size_or_test_id_conditions=False,all_commands_terminal=True,source_only_preparation=True,cargo_commands_run=0,native_commands_run=0,chromium_commands_run=0,release_qualification=False,promotion_allowed=False,javascript_executed_by_openui=False,pipeline=str(pipeline),pipeline_sha256=sha(pipeline),probe_sha256=sha(Path(__file__)))
OUT.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(report))
