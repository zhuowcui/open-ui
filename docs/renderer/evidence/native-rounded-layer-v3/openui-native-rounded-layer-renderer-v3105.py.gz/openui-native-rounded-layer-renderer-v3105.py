import fcntl,hashlib,json,os,shutil,signal,subprocess,sys,time
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');SDK=MAIN/'out/private-native-input-metadata-source-v2767';RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';NAME='native-rounded-layer-renderer-v3105';OUT=RAW/NAME;STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/NAME
lock=open('/tmp/'+NAME+'.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for program in ['cargo','rustc','pixel_compare','rustfmt']:assert subprocess.run(['pgrep','-x',program],capture_output=True).returncode==1
assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
TEMP=Path('/dev/shm/ou3105');assert not TEMP.exists();TEMP.mkdir()
sys.path.insert(0,'/tmp');from openui_parallel_source_identity_v3060 import identity as repository_source_identity
sys.path.insert(0,str(SDK/'tools/qualification'));from residuals import canonical_sha256
print('Preflight: reading all public and private source bytes',flush=True)
public=repository_source_identity(MAIN);source=repository_source_identity(SDK);assert public['clean'] and public['commit']=='aae023a931da72c5d8782b018348d2851e6d425d';assert source['clean'] and source['commit']=='6cc132dc88f63dd39a79ac3d98054d5d820e892f'
print('Preflight source identities verified',flush=True)
refs=['tools/qualification/manifests/complete-5731.json','tools/qualification/manifests/expanded-v35.json','tools/accountability/data/wpt_ported/all_wpt_templates.json']
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for data in iter(lambda:f.read(2**20),b''):h.update(data)
 return h.hexdigest()
reference_hashes={p:sha(MAIN/p) for p in refs};assert all(sha(SDK/p)==h for p,h in reference_hashes.items())
env=dict(os.environ,CARGO_TARGET_DIR='/mnt/e/openui-v02-cargo-c73754e2/target',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='4',RUST_MIN_STACK='4194304',PYTHONDONTWRITEBYTECODE='1',TMPDIR='/dev/shm/ou3105',OPENUI_NATIVE_WHOLE_OWNER=NAME)
report=dict(schema_version=1,source=source,public_source=public,steps=[],matrices={},all_commands_terminal=False,owner_pid=os.getpid(),probe_sha256=sha(__file__),reference_inputs=reference_hashes,javascript_executed_by_openui=False,pixel_tolerance=0,release_qualification=False,implementation_integrated=False,root_free_guard_bytes=128*2**20,all_build_logs_artifacts_cache_on_external_volume=True,promotion_allowed=False,new_release_comparisons_admitted=0)
io_inputs={str(p):sha(p) for p in [Path('/tmp/openui-qualified-source-reader-executor-v3104.py'),Path('/tmp/openui-parallel-source-identity-v3047.py'),Path('/tmp/openui-source-reader-current-proof-v3103.json')]}
proof=json.loads(Path('/tmp/openui-source-reader-current-proof-v3103.json').read_bytes());assert proof['all_fields_identical'] and proof['unchanged_official_serial_reader_source_identity']==source
report['source_identity_io_executor']=dict(input_sha256=io_inputs,all_source_bytes_read=True,hash_framing_order_preserved=True,official_current_source_crosscheck=True,unchanged_build_script_uses_serial_reader=True,pixel_and_oracle_gates_unchanged=True)
def save():(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
def check():
 report['stage']='source-byte-audit';save()
 assert all(sha(p)==h for p,h in io_inputs.items())
 assert repository_source_identity(MAIN)==public and repository_source_identity(SDK)==source
 assert all(sha(MAIN/p)==sha(SDK/p)==h for p,h in reference_hashes.items())
 report['stage']='source-byte-audit-complete';save()
def sweep_profiles():
 # Only this owner's private capture scratch directory. These directories are
 # browser runtime state, not fixtures, oracle entries, PNGs or source files.
 profiles=[p for p in TEMP.glob('openui-chrome-profile-*') if p.is_dir() and not p.is_symlink() and time.time()-p.stat().st_mtime>10]
 if not profiles:return
 process_commands=[]
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  try:process_commands.append((proc/'cmdline').read_bytes())
  except (FileNotFoundError,ProcessLookupError):continue
  except PermissionError:
   # Other users cannot own a profile created in our private directory.
   if proc.stat().st_uid==os.getuid():return
 removed=[]
 for profile in profiles:
  if any(str(profile).encode() in command for command in process_commands):continue
  # Re-check all live Chromium processes immediately before removing scratch.
  active=False
  for proc in Path('/proc').iterdir():
   if not proc.name.isdigit():continue
   try:
    if str(profile).encode() in (proc/'cmdline').read_bytes():active=True;break
   except (FileNotFoundError,ProcessLookupError):continue
   except PermissionError:
    if proc.stat().st_uid==os.getuid():active=True;break
  if active:continue
  removed.append(profile.name);shutil.rmtree(profile)
 if removed:
  report.setdefault('scratch_cleanup',[]).append(dict(time_utc_epoch=time.time(),profiles=removed,only_owned_temporary_browser_profiles=True));save()
def sweep_sockets():
 # Closed Chromium sockets in this owner's private temporary directory only.
 def active_paths():
  return [line.split(maxsplit=7)[-1] for line in Path('/proc/net/unix').read_text().splitlines()[1:] if len(line.split(maxsplit=7))==8]
 active=active_paths();removed=[]
 for p in TEMP.glob('org.chromium.Chromium.*'):
  if not p.is_dir() or p.is_symlink() or time.time()-p.stat().st_mtime<30:continue
  if any(x.startswith(str(p)+'/') for x in active):continue
  children=list(p.iterdir())
  if any(not x.is_symlink() and not x.is_socket() for x in children):continue
  if any(x.startswith(str(p)+'/') for x in active_paths()):continue
  for x in children:x.unlink()
  p.rmdir();removed.append(p.name)
 if removed:
  report.setdefault('socket_scratch_cleanup',[]).append(dict(time_utc_epoch=time.time(),directories=removed,only_owned_closed_temporary_sockets=True));save()

def run(name,command,cwd,allowed=(0,)):
 print('Preparing '+name,flush=True);check();log=OUT/(name+'.log')
 with log.open('xb') as f:
  child=subprocess.Popen(command,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);report['current_process']=dict(pid=child.pid,stage=name);save()
  try:
   while child.poll() is None:
    sweep_profiles();sweep_sockets()
    if shutil.disk_usage(MAIN).free<128*2**20 or shutil.disk_usage(STORE).free<10*2**30 or shutil.disk_usage(TEMP).free<256*2**20:
     report['disk_guard_triggered']=True;os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=20);break
    time.sleep(1)
   code=child.wait()
  except BaseException:
   if child.poll() is None:
    os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=20)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
   raise
  finally:
   report.pop('current_process',None)
   row=dict(name=name,command=command,observed_exit_code=child.returncode,log_sha256=sha(log))
   report['steps'].append(row);save();print(json.dumps(row),flush=True)
 check();assert code in allowed,name
 return code
load=lambda p:json.loads(Path(p).read_bytes())
def build(root,label):
 out=OUT/label/'guarded-build';out.parent.mkdir()
 run(label+'-build',[sys.executable,'/tmp/openui-qualified-source-reader-executor-v3104.py','--tool-path',str(root/'tools/qualification/build_renderer.py'),'--source-root',str(root),'--offline','--source-root',str(root),'--cargo-config',str(root/'bindings/rust/.cargo/config.chromium.toml'),'--target-dir',env['CARGO_TARGET_DIR'],'--results-dir',str(out)],root)
 r=load(out/'receipt.json');assert r['all_commands_terminal'] and r['renderer_library_provenance_verified'] and r['source_unchanged'];assert r['source']==(public if root==MAIN else source)
 return Path(r['binary']),out/'receipt.json'
def matrix(root,label,suite,binary,build_receipt):
 result=OUT/label/(suite+'-matrix');result.mkdir(parents=True)
 command=[sys.executable,'/tmp/openui-qualified-source-reader-executor-v3104.py','--tool-path',str(root/'tools/qualification/run_renderer_matrix.py'),'--source-root',str(root),'--suite',suite,'--results-dir',str(result),'--cache-dir','/mnt/e/openui-v02-qualification-d174ea0b/renderer-cache','--oracle-cache-dir',str(MAIN/'out/renderer-qualification-cache/chromium-oracle'),'--pixel-compare',str(binary),'--build-receipt',str(build_receipt),'--chrome',str(MAIN/'chrome/linux-147.0.7727.50/chrome-linux64/chrome'),'--raster-backend','cpu-skia','--jobs',str(2 if suite in ['focused','primitive'] else 8)]
 code=run(label+'-'+suite,command,root,allowed=(0,1));path=result/(suite+'-summary.json');r=load(path)
 assert r['source']==r['source_after']==(public if root==MAIN else source) and r['complete_contract_scope']
 assert r['results']['total']==dict(full=22924,expanded=23728,focused=640,primitive=960)[suite] and r['results']['errors']==0
 assert code==int(r['results']['different']!=0)
 report['matrices'][label+'-'+suite]=dict(summary_sha256=sha(path),results=r['results'],observed_exit_code=code);save();print(json.dumps(dict(label=label,suite=suite,results=r['results'])),flush=True)
 return r
save()
try:
 # The child guarded builder owns the global lock through its own preflight,
 # compilation and final source audit. This parent remains live through that
 # phase and claims the global lock once the child is terminal.
 binary,build_receipt=build(SDK,'trial')
 global_lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+')
 fcntl.flock(global_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 report['guarded_build_receipt_sha256']=sha(build_receipt);save()
 baseline_source=load(RAW/'native-combined-renderer-v2644/receipt.json')['source']
 for suite in ['focused','primitive','full','expanded']:
  before_path=RAW/'native-combined-renderer-v2644/trial'/(suite+'-matrix')/(suite+'-summary.json')
  before=load(before_path)
  assert before['source']==before['source_after']==baseline_source and before['complete_contract_scope'] and before['results']['errors']==0
  after=matrix(SDK,'trial',suite,binary,build_receipt)
  assert before['contract_sha256']==after['contract_sha256']
  for key in ['resource_hashes','font_byte_hashes','raster']:
   assert before[key]==after[key],key
  assert before['id_manifest']['sha256']==after['id_manifest']['sha256']
  assert before['chromium']['build_identity']==after['chromium']['build_identity']
  assert before['chromium']['binary_sha256']==after['chromium']['binary_sha256']
  old={(p['profile'],t['id']):t for p in before['profiles'] for t in p['tests']}
  fields=['openui_png_sha256','openui_rgba_sha256','chromium_png_sha256','chromium_rgba_sha256','chromium_oracle_identity_sha256','chromium_oracle_rgba_sha256','mismatched_pixels','status','diff_signature']
  changes=[];gains=losses=worsened=0
  for p in after['profiles']:
   assert p['result_sha256']==canonical_sha256(p['tests'])
   for t in p['tests']:
    prior=old[p['profile'],t['id']]
    assert all(key in prior and key in t for key in fields)
    assert all(prior[k]==t[k] for k in fields if k.startswith('chromium_')), 'immutable Chromium comparison changed'
    gains+=prior['status']!='exact' and t['status']=='exact'
    losses+=prior['status']=='exact' and t['status']!='exact'
    worsened+=t['mismatched_pixels']>prior['mismatched_pixels']
    changed=[key for key in fields if prior[key]!=t[key]]
    if changed:changes.append(dict(profile=p['profile'],id=t['id'],fields=changed,prior={k:prior.get(k) for k in changed},after={k:t.get(k) for k in changed}))
  report.setdefault('comparisons',{})[suite]=dict(baseline_summary=str(before_path),baseline_summary_sha256=sha(before_path),rows_audited=len(old),fields=fields,changes=changes,nine_invariants_preserved=not changes,exact_gains=gains,exact_losses=losses,worsened=worsened)
  save()
 report['candidate_nonregression_verified']=all(r['exact_losses']==0 and r['worsened']==0 for r in report['comparisons'].values())
 report['private_candidate_measured']=True
 report['actual_combined_umbrella_source_measured']=False
 report['implementation_integrated']=False
 report['remaining_full_pixel_gate_open']=True
 report['oracle_reconciliation_open']=True
 report['promotion_allowed']=False
 report['observed_exit_code']=int(any(r['observed_exit_code'] for r in report['matrices'].values()) or not report['candidate_nonregression_verified'])
except BaseException as e:report.update(observed_exit_code=130 if isinstance(e,KeyboardInterrupt) else 1,failure=repr(e));raise
finally:
 sweep_profiles();sweep_sockets()
 print('Final audit: rereading all source bytes',flush=True)
 report['stage']='final-source-byte-audit';save()
 report.update(all_commands_terminal=True,source_after=repository_source_identity(SDK),public_source_after=repository_source_identity(MAIN));report['source_unchanged']=report['source_after']==source;report['public_source_unchanged']=report['public_source_after']==public;report['stage']='terminal';save()
print(json.dumps({k:report.get(k) for k in ['all_commands_terminal','observed_exit_code','nonregression_gate','promotion_allowed']}),flush=True)
raise SystemExit(report['observed_exit_code'])
