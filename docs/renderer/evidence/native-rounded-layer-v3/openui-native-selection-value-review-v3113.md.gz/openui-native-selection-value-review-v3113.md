# Native value and selection callback obligations

Pinned Chromium v3111: 24 input/textarea cases, 26 callback rows, two identical full traces, whole exit0, cleanMainaae023a9 byte identity unchanged before/after. No callbacks occur synchronously. All selectionchange/select notifications bubble and are noncancelable. JavaScript runs only inside the separate offline Chromium oracle; Open UI executes none.

Programmatic value setters emit selectionchange when the value changes, even if a same-length replacement leaves a collapsed caret at the same numeric offset. They do not emit select. Assigning the same value preserves the current selection and direction and emits neither notification. Existing native Engine.set_control_value resets selection even for equal values: implementation work remains.

Range replacement with changed text emits selectionchange even when preserve mode leaves the same endpoints/direction. It emits select only when selection/direction changes. Replacing identical text in a forward selection emits no events; the same operation in a backward selection resets direction to forward and emits both notifications. An explicit none selection direction normalizes to forward on the pinned Linux reference. Value change followed by restoring the earlier selection coalesces one selectionchange and one select; final state alone does not erase intervening mutations.

Queue candidate3102 is corrected to accept an explicit request_select flag. Property value setters must pass false; explicit selection/range operations may request select. Selectionchange coalescing and phased delivery remain defined by v3006/v3062/v3084. No candidate source is applied or compiled and no native API is qualified by this browser reference.
