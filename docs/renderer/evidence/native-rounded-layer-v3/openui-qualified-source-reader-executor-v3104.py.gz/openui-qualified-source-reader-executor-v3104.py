# Read all source bytes concurrently; execute the unchanged qualification tool.
# Recorded as an extra measurement input. Pixel and oracle gates are unchanged.
import hashlib, importlib.util, json, sys
from pathlib import Path
args=sys.argv[1:]; assert len(args)>=4 and args[0]=='--tool-path' and args[2]=='--source-root'
tool=Path(args[1]); root=Path(args[3]); tail=args[4:]
allowed={'/home/nero/code/open-ui/out/private-native-input-metadata-source-v2767/tools/qualification/build_renderer.py': 'dbc7f874fd3df5603197c8d74a1d938e4ab275f5f05b562ccb1e293d1909dd9a', '/home/nero/code/open-ui/out/private-native-input-metadata-source-v2767/tools/qualification/run_renderer_matrix.py': '6ee5b815dae0fcf006f6a6e3d8b04df225abd6ad9d1f0c3ad3ad8f3a1bc362ec'}
assert str(tool) in allowed and hashlib.sha256(tool.read_bytes()).hexdigest()==allowed[str(tool)]
reader=Path('/tmp/openui-parallel-source-identity-v3047.py')
assert hashlib.sha256(reader.read_bytes()).hexdigest()=='d034540153e35cad3cbfc63a13e0bcfb17df4cbdb89a6d22e1439f7bc39435ec'
spec=importlib.util.spec_from_file_location('concurrent_source_reader',reader)
module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
sys.path.insert(0,str(root/'tools/qualification'))
import renderer_source_identity
assert renderer_source_identity.ROOT.resolve()==root.resolve()
def repository_source_identity(measured_root=root):
    return module.identity(measured_root)
renderer_source_identity.repository_source_identity=repository_source_identity
sys.argv=[str(tool),*tail]
exec(compile(tool.read_bytes(),str(tool),'exec'),{'__name__':'__main__','__file__':str(tool),'__package__':None})
