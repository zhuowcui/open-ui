import fcntl, hashlib, json, subprocess, sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui')
SDK=MAIN/'out/private-native-input-metadata-source-v2767'
RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1/native-rounded-layer-renderer-v3105'
OUT=Path('/tmp/openui-rounded-layer-completed-audit-v3115.json')
assert not OUT.exists()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert subprocess.run(['ps','-p','3619547'],capture_output=True).returncode==1
for name in ['cargo','rustc','pixel_compare','rustfmt']:
    assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(2**20),b''):h.update(b)
    return h.hexdigest()
def load(p):return json.loads(Path(p).read_bytes())
receipt=load(RAW/'receipt.json')
assert receipt['all_commands_terminal'] and receipt['stage']=='terminal'
assert receipt['observed_exit_code']==1 and receipt['candidate_nonregression_verified']
assert receipt['source']==receipt['source_after'] and receipt['public_source']==receipt['public_source_after']
for p,h in load('/tmp/openui-owner3105-extra-inputs-v3108.json')['input_sha256'].items():assert sha(p)==h,p
for step in receipt['steps']:assert sha(RAW/(step['name']+'.log'))==step['log_sha256']
build=load(RAW/'trial/guarded-build/receipt.json')
assert sha(RAW/'trial/guarded-build/receipt.json')==receipt['guarded_build_receipt_sha256']
assert build['all_commands_terminal'] and build['source_unchanged'] and build['renderer_library_provenance_verified']
assert build['source']==build['source_after']==receipt['source'] and build['observed_exit_code']==0
for step in build['steps']:
    assert step['observed_exit_code']==0
    for stream in ['stdout','stderr']:
        assert sha(RAW/'trial/guarded-build'/(step['name']+'.'+stream))==step[stream+'_sha256']
for p,h in build['compiled_artifact_sha256'].items():assert sha(p)==h,p
for name,artifacts in build['artifacts'].items():
    for a in artifacts:
        assert a['fresh'] is False,name
        assert Path(a['manifest_path']).is_relative_to(SDK.resolve())
        assert Path(a['target']['src_path']).is_relative_to(SDK.resolve())
assert sha(build['binary'])==build['binary_sha256']
sys.path.insert(0,'/tmp')
from openui_parallel_source_identity_v3060 import identity
sys.path.insert(0,str(SDK/'tools/qualification'))
from residuals import canonical_sha256
print('Verifying complete source identities and matrix rows',flush=True)
assert identity(MAIN)==receipt['public_source'] and identity(SDK)==receipt['source']
rows=0; results={}
for suite in ['focused','primitive','full','expanded']:
    path=RAW/'trial'/(suite+'-matrix')/(suite+'-summary.json')
    matrix=load(path); m=receipt['matrices']['trial-'+suite]
    assert sha(path)==m['summary_sha256']
    assert matrix['source']==matrix['source_after']==receipt['source'] and matrix['complete_contract_scope']
    baseline=load(receipt['comparisons'][suite]['baseline_summary'])
    assert sha(receipt['comparisons'][suite]['baseline_summary'])==receipt['comparisons'][suite]['baseline_summary_sha256']
    old={(p['profile'],t['id']):t for p in baseline['profiles'] for t in p['tests']}
    exact=different=errors=gains=losses=worsened=0
    for p in matrix['profiles']:
        assert p['result_sha256']==canonical_sha256(p['tests'])
        for t in p['tests']:
            prior=old.pop((p['profile'],t['id']))
            for field in receipt['comparisons'][suite]['fields']:
                if field.startswith('chromium_'):assert prior[field]==t[field]
            exact+=t['status']=='exact'; different+=t['status']=='different'; errors+=t['status']=='error'
            gains+=prior['status']!='exact' and t['status']=='exact'
            losses+=prior['status']=='exact' and t['status']!='exact'
            worsened+=t['mismatched_pixels']>prior['mismatched_pixels']
    assert not old and errors==0 and losses==0 and worsened==0
    assert exact==matrix['results']['exact'] and exact+different==matrix['results']['total']
    assert gains==receipt['comparisons'][suite]['exact_gains']
    results[suite]=dict(total=exact+different,exact=exact,different=different,errors=errors,gains=gains,losses=losses,worsened=worsened,actual_exit_code=m['observed_exit_code'])
    rows+=exact+different
out=dict(schema_version=1,owner_terminal=True,actual_whole_exit_code=1,all_source_bytes_unchanged=True,compiled_artifacts_verified=len(build['compiled_artifact_sha256']),fresh_local_packages=len(build['artifacts']),logs_verified=len(receipt['steps'])+2*len(build['steps']),matrix_rows_verified=rows,chromium_reference_fields_unchanged=True,extra_executor_inputs_verified=True,pixel_tolerance=0,results=results,private_candidate_nonregression=True,implementation_integrated=False,all_native_apis_qualified=False,release_qualified=False,javascript_executed_by_openui=False,receipt_sha256=sha(RAW/'receipt.json'))
OUT.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
print(json.dumps(out),flush=True)
