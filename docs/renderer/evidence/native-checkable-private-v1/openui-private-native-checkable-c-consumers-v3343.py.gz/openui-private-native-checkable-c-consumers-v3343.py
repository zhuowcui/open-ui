import fcntl,hashlib,json,os,shutil,signal,subprocess,sys,time
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');SDK=Path('/mnt/e/openui-v02-qualification-d174ea0b/private-native-checkable-source-v3303')
RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';OUT=Path('/mnt/e/openui-v02-qualification-d174ea0b/private-native-checkable-c-consumers-v3343')
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','pixel_compare','rustfmt']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=json.loads((RAW/'private-native-checkable-v3331/receipt.json').read_bytes());audit=json.loads(Path('/tmp/openui-private-native-checkable-failed-audit-v3333.json').read_bytes())
assert old['all_commands_terminal'] and old['observed_exit_code']==1 and old['source_unchanged'] and old['main_source_unchanged']
assert audit['owner_terminal'] and audit['receipt_sha256']==sha(RAW/'private-native-checkable-v3331/receipt.json')
assert subprocess.run(['ps','-p',str(old['owner_pid'])],capture_output=True).returncode==1
assert old['source']['commit']=='a17f8a33bbf1ce6b2c4b20bf02d39adfca48b73c'
prior_c_audit=json.loads(Path('/tmp/openui-private-native-checkable-c-consumers-completed-audit-v3340.json').read_bytes())
assert prior_c_audit['owner_terminal'] and prior_c_audit['actual_whole_exit_code']==1
assert prior_c_audit['receipt_sha256']==sha(RAW/'private-native-checkable-c-consumers-v3339/receipt.json')
assert subprocess.check_output(['git','diff','--name-only',old['source']['commit'],'HEAD'],cwd=SDK,text=True).splitlines()==['examples/c_v02/checkable.c']
sys.path.insert(0,'/tmp');from openui_parallel_source_identity_v3060 import identity
source=identity(SDK);main_source=identity(MAIN);assert source['clean'] and main_source['clean'];assert source['commit']==Path('/tmp/openui-native-checkable-c-private-pin-v3343.txt').read_text().strip()
assert not OUT.exists() and not (RAW/OUT.name).exists();OUT.mkdir();(RAW/OUT.name).symlink_to(OUT,target_is_directory=True)
refs=dict(programmatic='native-radio-programmatic-reference-v3242',default='native-checkable-default-reference-v3249',activation='native-checkable-activation-reference-v3257');inputs={}
for name in list(refs.values())+['native-checkable-dispatch-reference-v3315']:
 for filename in ['receipt.json','observations-1.json','observations-2.json']:
  p=RAW/name/filename;inputs[str(p)]=sha(p)
 assert (RAW/name/'observations-1.json').read_bytes()==(RAW/name/'observations-2.json').read_bytes()
library=OUT/'libopenui_ffi.so';shutil.copy2(RAW/'private-native-checkable-v3331/libopenui_ffi.so',library);assert sha(library)==old['ffi_library_sha256'];(OUT/'libopenui.so.0').symlink_to(library.name)
header=SDK/'include/openui.h';assert header.read_bytes()==subprocess.check_output(['git','show',old['source']['commit']+':include/openui.h'],cwd=SDK)
report=dict(schema_version=1,owner_pid=os.getpid(),source=source,main_source=main_source,runtime_source=old['source'],runtime_owner_receipt_sha256=sha(RAW/'private-native-checkable-v3331/receipt.json'),runtime_completed_failed_audit_sha256=sha('/tmp/openui-private-native-checkable-failed-audit-v3333.json'),runtime_inputs_unchanged=True,ffi_library_sha256=sha(library),public_header_sha256=sha(header),steps=[],binaries={},reference_inputs_sha256=inputs,driver_sha256=sha(__file__),all_commands_terminal=False,whole_native_qualification_completed=False,renderer_qualified=False,implementation_integrated=False,all_native_apis_qualified=False,release_qualified=False,javascript_executed_by_openui=False)
env=dict(os.environ,TMPDIR='/dev/shm',PYTHONDONTWRITEBYTECODE='1');env.pop('LD_PRELOAD',None);env.pop('LD_LIBRARY_PATH',None)
def save():(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
def run(name,command):
 with (OUT/(name+'.log')).open('xb') as log:
  child=subprocess.Popen(command,cwd=SDK,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);report['current_process']=dict(pid=child.pid,name=name);save()
  try:
   while child.poll() is None:
    if shutil.disk_usage(MAIN).free<128*2**20 or shutil.disk_usage(OUT).free<10*2**30:report['disk_guard_triggered']=True;os.killpg(child.pid,signal.SIGTERM);break
    time.sleep(.1)
   code=child.wait()
  except BaseException:
   if child.poll() is None:os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=20)
   raise
  finally:
   report.pop('current_process',None);report['steps'].append(dict(name=name,command=command,actual_exit_code=child.returncode,log_sha256=sha(OUT/(name+'.log'))));save()
 print(json.dumps(dict(name=name,actual_exit_code=code)),flush=True);assert code==0,name
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=SDK,text=True).strip()==source['commit'] and not subprocess.check_output(['git','status','--porcelain'],cwd=SDK)
 return (OUT/(name+'.log')).read_bytes()
save()
try:
 run('all-c-cpp-consumers',[sys.executable,str(SDK/'tools/ffi/verify_abi.py'),'--library',str(library)])
 sys.path.insert(0,str(SDK/'tools/ffi'));import verify_abi
 cc,cxx,c_flags,cxx_flags,link_flags=verify_abi.compilers();report['compiler_configuration']=dict(cc=cc,cxx=cxx,c_flags=c_flags,cxx_flags=cxx_flags,link_flags=link_flags);save()
 for language,compiler,flags,standard in [('c',cc,c_flags,'c11'),('cpp',cxx,cxx_flags,'c++17')]:
  example=SDK/'examples/c_v02'/('checkable.c' if language=='c' else 'checkable.cc');obj=OUT/('checkable-'+language+'.o');binary=OUT/('checkable-'+language)
  run('compile-'+language,[compiler,'-std='+standard,'-Wall','-Wextra','-Werror','-pthread',*flags,'-I'+str(SDK/'include'),str(example),'-c','-o',str(obj)])
  run('link-'+language,[cxx,'-pthread',*cxx_flags,*link_flags,'-fuse-ld=lld',str(obj),str(library),'-Wl,-rpath,'+str(OUT),'-o',str(binary)])
  report['binaries'][binary.name]=dict(sha256=sha(binary),object_sha256=sha(obj),source_sha256=sha(example));save()
  for mode in ['accessibility','dispatch']:
   for repeat in [1,2]:
    label='checkable-'+language+'-'+mode+'-'+str(repeat);data=run(label,[str(binary)]+(['dispatch'] if mode=='dispatch' else []));json.loads(data);(OUT/(label+'.json')).write_bytes(data)
   assert (OUT/('checkable-'+language+'-'+mode+'-1.json')).read_bytes()==(OUT/('checkable-'+language+'-'+mode+'-2.json')).read_bytes()
 comparisons=[]
 for language in ['c','cpp']:
  for mode in ['accessibility','dispatch']:
   actual=json.loads((OUT/('checkable-'+language+'-'+mode+'-1.json')).read_bytes());assert set(actual)==set(refs)
   for suite,name in refs.items():
    if mode=='dispatch':expected=[{k:v for k,v in e.items() if k!='suite'} for e in json.loads((RAW/'native-checkable-dispatch-reference-v3315/observations-1.json').read_bytes()) if e['suite']==suite]
    else:expected=json.loads((RAW/name/'observations-1.json').read_bytes())
    assert len(actual[suite])==len(expected)
    for original,e in zip(actual[suite],expected):
     assert original['api_errors']==[],original;a={k:v for k,v in original.items() if k!='api_errors'};assert a['scenario']==e['scenario']
     comparisons.append(dict(language=language,operation=mode,suite=suite,scenario=a['scenario'],exact=a==e,native=a,chromium=e,projection='complete behavior row; native API errors must be empty; raw suite marker moved to group key'))
 report.update(comparisons=comparisons,scenario_counts={language:dict(total=sum(x['language']==language for x in comparisons),exact=sum(x['language']==language and x['exact'] for x in comparisons)) for language in ['c','cpp']},native_api_errors_verified_empty=True,observed_exit_code=int(not all(x['exact'] for x in comparisons)));save()
except BaseException as error:
 report.update(observed_exit_code=130 if isinstance(error,KeyboardInterrupt) else 1,failure=repr(error));raise
finally:
 report.update(source_after=identity(SDK),main_source_after=identity(MAIN));report['source_unchanged']=report['source_after']==source;report['main_source_unchanged']=report['main_source_after']==main_source
 assert all(sha(p)==h for p,h in inputs.items()) and sha(library)==old['ffi_library_sha256'];report['all_commands_terminal']=True;save()
print(json.dumps({k:report[k] for k in ['observed_exit_code','scenario_counts','source_unchanged','main_source_unchanged','whole_native_qualification_completed']}),flush=True)
raise SystemExit(report['observed_exit_code'])
