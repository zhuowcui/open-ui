import fcntl,gzip,hashlib,json,os,re,subprocess,tempfile
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');SDK=Path('/mnt/e/openui-v02-qualification-d174ea0b/private-native-checkable-source-v3303');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1'
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','pixel_compare','rustfmt']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
assert not subprocess.check_output(['git','status','--porcelain'],cwd=MAIN)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=SDK)
audit=json.loads(Path('/tmp/openui-private-native-checkable-c-consumers-completed-audit-v3344.json').read_bytes());assert audit['owner_terminal'] and audit['actual_whole_exit_code']==0 and audit['exact_comparison_rows']==440
c=json.loads((RAW/'private-native-checkable-c-consumers-v3343/receipt.json').read_bytes());rust=json.loads((RAW/'private-native-checkable-v3331/receipt.json').read_bytes())
for r in [c,rust]:assert r['all_commands_terminal'] and r['source_unchanged'] and r['main_source_unchanged'];assert subprocess.run(['ps','-p',str(r['owner_pid'])],capture_output=True).returncode==1
rust_observed=json.loads(Path('/tmp/openui-private-native-checkable-rust-observations-v3336.json').read_bytes());assert rust_observed['owner_all_commands_terminal'] and len(rust_observed['consumers'])==2 and sum(x['exact'] for x in rust_observed['consumers'])==220 and all(not x['differences'] for x in rust_observed['consumers'])
assert c['scenario_counts']=={'c':dict(total=220,exact=220),'cpp':dict(total=220,exact=220)}
assert subprocess.check_output(['git','diff','--name-only',rust['source']['commit'],c['source']['commit']],cwd=SDK,text=True).splitlines()==['examples/c_v02/checkable.c']
sha=lambda b:hashlib.sha256(b).hexdigest()
folder=MAIN/'docs/renderer/evidence/native-checkable-private-v1';index=MAIN/'docs/renderer/generated/native-checkable-private-v1.json';assert not folder.exists() and not index.exists();folder.mkdir()
files=[]
for name in ['private-native-checkable-v3312','private-native-checkable-v3331','private-native-checkable-c-consumers-v3339','private-native-checkable-c-consumers-v3343','native-radio-programmatic-reference-v3242','native-checkable-default-reference-v3249','native-checkable-activation-reference-v3257','native-checkable-dispatch-reference-v3315']:
 for p in sorted((RAW/name).iterdir()):
  if p.is_file() and p.suffix in ['.log','.json']:files.append((p,name+'-'+p.name+'.gz'))
external=['openui-native-checkable-private-checkpoint-v3328.json','openui-native-checkable-private-format-v3325.json','openui-native-checkable-null-guard-correction-v3330.json','openui-private-native-checkable-owner-v3312.py','openui-private-native-checkable-failed-audit-v3314.json','openui-private-native-checkable-owner-v3331.py','openui-private-native-checkable-failed-audit-v3333.json','openui-native-checkable-source-review-v3288.json','openui-native-checkable-dispatch-reference-completed-audit-v3316.json','openui-native-checkable-c-public-flag-correction-v3337.json','openui-private-native-checkable-c-consumers-v3339.py','openui-private-native-checkable-c-consumers-completed-audit-v3340.json','openui-native-checkable-cpp-action-correction-v3342.json','openui-private-native-checkable-c-consumers-v3343.py','openui-private-native-checkable-c-consumers-completed-audit-v3344.py','openui-private-native-checkable-c-consumers-completed-audit-v3344.json','openui-private-native-checkable-rust-observations-v3336.json','openui-private-native-checkable-c-observations-v3345.json','openui-private-native-checkable-partial-diagnostics-v3336.py','openui-private-native-checkable-c-partial-diagnostics-v3345.py']
for name in external:p=Path('/tmp')/name;assert p.exists(),p;files.append((p,name+'.gz'))
items=[]
for p,name in files:
 b=p.read_bytes();encoded=gzip.compress(b,mtime=0);target=folder/name;assert not target.exists();target.write_bytes(encoded);assert gzip.decompress(target.read_bytes())==b
 items.append(dict(original_path=str(p),path=str(target.relative_to(MAIN)),sha256=sha(encoded),decoded_sha256=sha(b)))
patch=subprocess.check_output(['git','diff','--binary','6ba3ef5841d043bdb895f7f90068c8624cbe7519',c['source']['commit']],cwd=SDK)
patch_path=folder/'native-checkable-private-v1.patch';patch_path.write_bytes(patch)
report=dict(schema_version=1,implementation_integrated=False,whole_native_qualification_completed=False,native_appearance_qualified=False,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,javascript_executed_by_openui=False,pixel_target='pinned Chromium',archived_openui_images_are_history_only=True,runtime_source=rust['source'],c_cpp_app_source=c['source'],main_evidence_source=c['main_source'],runtime_inputs_unchanged_between_private_checkpoints=True,rust_exact_behavior_rows=220,c_exact_behavior_rows=220,cpp_exact_behavior_rows=220,reference_cases_by_operation=220,total_exact_behavior_rows=660,unit_guards=198,integration_guards=27,c_exports=128,c_layouts=34,c_consumers=25,cpp_consumers=19,code_patch=dict(path=str(patch_path.relative_to(MAIN)),sha256=sha(patch),base_commit='6ba3ef5841d043bdb895f7f90068c8624cbe7519',private_commit=c['source']['commit']),source_and_artifact_audits_completed=True,old_109_rust_app_rows_repeated_identically=True,unqualified=['default control appearance','fresh complete native owner on final private commit','fresh focused/primitive/full/expanded rendering','form-owner resets through ID and associated-tree changes','radio arrow-key and complete keyboard behavior','composition and other needed native APIs','physical hardware, compositor and release'],failed_attempts_preserved=['3312: wrong new NULL-source guard expectation; registry returns InvalidArgument','3331: new C app used internal Rust event flag name','3339: C++ rejects integer accessibility action; use public enum'],evidence=items)
index.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
path=MAIN/'docs/v02/native-disabled-groups.md';before=path.read_text();old='''110 separate Chromium checkbox/radio reference cases repeat identically for
assignment, authored defaults, group ownership, clones, callback state,
cancellation and indeterminate state. New native comparisons have not run.
The current Rust radio assignment path rejects disabled assignment through
activation, conflates live state with authored attributes, and groups controls
without form/tree ownership. Click callbacks precede checkable mutation.
Explicit C dispatch also needs the shared activation lifecycle. These remain
required native implementation work. Fixture lowering does not complete a
public app API.
'''
new='''The public implementation still needs the checkbox/radio follow-up. A private
implementation now matches **220/220 behavior cases in each of Rust, C and
C++**, with identical repeated output. These measure programmatic assignment,
authored defaults, form/tree grouping, clones, callback state, cancellation,
indeterminate state and the distinction between ordinary activation and raw
click events. Apps call actual native APIs. Open UI executes no JavaScript.

The private runtime is clean `a17f8a33`; the corrected C/C++ app source is clean
`cef6a7eb`. Their only difference is the consuming C example; framework and
header bytes are unchanged. All 198 unit guards, 27 integration guards, 25 C
and 19 C++ consumers pass. The private ABI has 128 exports and the same 34
layouts; the public ABI remains 127 exports. Failed attempts and completed
source/artifact audits are preserved. This is scoped behavior evidence, with
no complete native-owner or renderer qualification on the final private source.

The private code adds Rust `Element::dispatch_click_event` and C
`oui_element_clone_subtree_v1`, and routes checkable activation through the
shared Rust Document. It separates live state from authored attributes and
runs preactivation before callbacks, restoring state when canceled. These
changes are unapplied. Default appearance, additional form-owner resets,
radio keyboard behavior and complete API coverage remain open. Fixture
lowering does not complete a public app API.
[Private observations, code patch and provenance](../renderer/generated/native-checkable-private-v1.json).
'''
assert before.count(old)==1;after=before.replace(old,new);fd,tmp=tempfile.mkstemp(dir=path.parent,prefix='.native-checkable-evidence-');os.close(fd);Path(tmp).write_text(after);os.replace(tmp,path)
Path('/tmp/openui-native-checkable-private-evidence-v3346.json').write_text(json.dumps(dict(evidence_files=len(items),index_sha256=sha(index.read_bytes()),patch_sha256=sha(patch),implementation_integrated=False,release_qualified=False),indent=2)+'\n')
print(json.dumps(dict(evidence_files=len(items),exact_scoped_behavior_rows=660,implementation_integrated=False,whole_native_qualification_completed=False)),flush=True)
