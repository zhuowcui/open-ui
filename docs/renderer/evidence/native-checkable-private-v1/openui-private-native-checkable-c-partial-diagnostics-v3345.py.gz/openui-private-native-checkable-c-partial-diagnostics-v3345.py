import hashlib,json
from pathlib import Path
RAW=Path('/home/nero/code/open-ui/out/renderer-evidence/native-viewport-scroll-v1');DIR=RAW/'private-native-checkable-c-consumers-v3343'
r=json.loads((DIR/'receipt.json').read_bytes());steps={s['name']:s for s in r['steps']}
refs=dict(programmatic='native-radio-programmatic-reference-v3242',default='native-checkable-default-reference-v3249',activation='native-checkable-activation-reference-v3257')
rows=[]
for language,label in [('rust','native_checkable-reference'),('rust','native_checkable-dispatch'),('c','checkable-c-accessibility'),('c','checkable-c-dispatch'),('cpp','checkable-cpp-accessibility'),('cpp','checkable-cpp-dispatch')]:
 p=DIR/(label+'-1.json');name=label+'-1'
 if not p.exists() or name not in steps:continue
 data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==steps[name]['log_sha256'] and steps[name]['actual_exit_code']==0
 actual=json.loads(data);summary=[];diff=[]
 for suite,ref in refs.items():
  if label.endswith('dispatch'):
   expected=[{k:v for k,v in x.items() if k!='suite'} for x in json.loads((RAW/'native-checkable-dispatch-reference-v3315/observations-1.json').read_bytes()) if x['suite']==suite]
  else:expected=json.loads((RAW/ref/'observations-1.json').read_bytes())
  assert len(actual[suite])==len(expected)
  for a,e in zip(actual[suite],expected):
   assert a['scenario']==e['scenario']
   clean=a['api_errors']==[];native={k:v for k,v in a.items() if k!='api_errors'}
   exact=clean and native==e;summary.append(exact)
   if not exact:diff.append(dict(suite=suite,scenario=a['scenario'],api_errors=a['api_errors'],native=native,chromium=e))
 rows.append(dict(language=language,consumer=label,total=len(summary),exact=sum(summary),differences=diff))
print(json.dumps(dict(owner_all_commands_terminal=r['all_commands_terminal'],partial_observation_only=True,qualification_completed=False,consumers=rows),sort_keys=True,indent=2))
