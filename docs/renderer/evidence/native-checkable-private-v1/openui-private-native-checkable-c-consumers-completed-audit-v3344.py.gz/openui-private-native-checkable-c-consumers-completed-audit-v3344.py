import fcntl,hashlib,json,subprocess,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');SDK=Path('/mnt/e/openui-v02-qualification-d174ea0b/private-native-checkable-source-v3303');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';DIR=RAW/'private-native-checkable-c-consumers-v3343';OUT=Path('/tmp/openui-private-native-checkable-c-consumers-completed-audit-v3344.json');assert not OUT.exists()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();r=json.loads((DIR/'receipt.json').read_bytes());assert r['all_commands_terminal'] and r['observed_exit_code'] in [0,1,130]
assert subprocess.run(['ps','-p',str(r['owner_pid'])],capture_output=True).returncode==1
for name in ['cargo','rustc','pixel_compare','rustfmt']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
assert sha('/tmp/openui-private-native-checkable-c-consumers-v3343.py')==r['driver_sha256']
assert r['source_unchanged'] and r['main_source_unchanged']
for step in r['steps']:assert sha(DIR/(step['name']+'.log'))==step['log_sha256']
assert sha(DIR/'libopenui_ffi.so')==r['ffi_library_sha256'] and sha(SDK/'include/openui.h')==r['public_header_sha256']
assert sha(RAW/'private-native-checkable-v3331/receipt.json')==r['runtime_owner_receipt_sha256']
assert sha('/tmp/openui-private-native-checkable-failed-audit-v3333.json')==r['runtime_completed_failed_audit_sha256']
assert subprocess.check_output(['git','diff','--name-only',r['runtime_source']['commit'],r['source']['commit']],cwd=SDK,text=True).splitlines()==['examples/c_v02/checkable.c']
for p,h in r['reference_inputs_sha256'].items():assert sha(p)==h
artifacts={}
for step in r['steps']:
 if step['name'].startswith(('compile-','link-')):
  p=Path(step['command'][-1])
  if p.exists():artifacts[str(p)]=sha(p)
for name,b in r['binaries'].items():
 assert sha(DIR/name)==b['sha256'] and sha(DIR/(name+'.o'))==b['object_sha256']
repeats=0
for first in DIR.glob('*-1.json'):
 second=first.with_name(first.name[:-7]+'-2.json')
 if second.exists():assert first.read_bytes()==second.read_bytes();repeats+=1
refs=dict(programmatic='native-radio-programmatic-reference-v3242',default='native-checkable-default-reference-v3249',activation='native-checkable-activation-reference-v3257')
comparisons=r.get('comparisons',[])
for row in comparisons:
 if row['operation']=='dispatch':expected=[{k:v for k,v in e.items() if k!='suite'} for e in json.loads((RAW/'native-checkable-dispatch-reference-v3315/observations-1.json').read_bytes()) if e['suite']==row['suite']]
 else:expected=json.loads((RAW/refs[row['suite']]/'observations-1.json').read_bytes())
 e=next(e for e in expected if e['scenario']==row['scenario']);assert e==row['chromium'];assert row['exact']==(row['native']==e)
complete=(not r.get('failure') and len(comparisons)==440 and all(s['actual_exit_code']==0 for s in r['steps']))
if r['observed_exit_code']==0:
 assert complete and all(x['exact'] for x in comparisons) and repeats==4
 assert r['scenario_counts']=={'c':dict(total=220,exact=220),'cpp':dict(total=220,exact=220)}
 assert 'symbols=128 C_examples=25 C++=19 ran=True' in (DIR/'all-c-cpp-consumers.log').read_text()
sys.path.insert(0,'/tmp');from openui_parallel_source_identity_v3060 import identity
assert identity(SDK)==r['source']==r['source_after'] and identity(MAIN)==r['main_source']==r['main_source_after']
result=dict(schema_version=1,owner_terminal=True,actual_whole_exit_code=r['observed_exit_code'],source=r['source'],runtime_source=r['runtime_source'],main_source=r['main_source'],receipt_sha256=sha(DIR/'receipt.json'),all_source_bytes_unchanged=True,runtime_inputs_unchanged=True,library_sha256=r['ffi_library_sha256'],current_preserved_c_artifacts=artifacts,command_logs_verified=len(r['steps']),completed_comparison_rows=len(comparisons),exact_comparison_rows=sum(x['exact'] for x in comparisons),repeated_process_pairs=repeats,c_consumers=25 if r['observed_exit_code']==0 else None,cpp_consumers=19 if r['observed_exit_code']==0 else None,whole_native_qualification_completed=False,implementation_integrated=False,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,javascript_executed_by_openui=False)
OUT.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['owner_terminal','actual_whole_exit_code','command_logs_verified','completed_comparison_rows','exact_comparison_rows','whole_native_qualification_completed']}),flush=True)
