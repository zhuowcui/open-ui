import hashlib,json,re,subprocess,sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');OUT=Path('/mnt/d/openui-v02-qualification-d174ea0b/native-author-alias-guards-v3787')
sys.path.insert(0,'/tmp')
from openui_parallel_source_identity_v3060 import identity
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=json.loads((OUT/'receipt.json').read_bytes());assert r['all_commands_terminal'] and r['source_unchanged'] and r['observed_exit_code']==int(sys.argv[1])==0
assert identity(ROOT)==r['source']==r['source_after'] and not r['source']['clean']
assert subprocess.run(['ps','-p',str(r['owner_pid'])],capture_output=True).returncode==1
for n in ['cargo','rustc','rustfmt','pixel_compare']:assert subprocess.run(['pgrep','-x',n],capture_output=True).returncode==1
assert sha('/tmp/openui-native-author-alias-guards-v3787.py')==r['driver_sha256']
for s in r['steps']:
 assert s['actual_exit_code']==0 and sha(OUT/(s['name']+'.log'))==s['log_sha256']
 values=re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored;', (OUT/(s['name']+'.log')).read_text())
 assert [sum(int(row[i]) for row in values) for i in range(3)]==[s['passed'],s['failed'],s['ignored']]
paths=set()
for a in r['local_artifacts']:
 assert a['fresh'] is False and Path(a['manifest_path']).resolve().is_relative_to(ROOT) and Path(a['target']['src_path']).resolve().is_relative_to(ROOT)
 for p,h in a['sha256'].items():assert sha(p)==h;paths.add(p)
step=next(s for s in r['steps'] if s['name']=='text-paint-guards');assert step['passed']>0 and step['failed']==step['ignored']==0
assert all(any(a['target']['name']==n and a['profile']['test'] for a in r['local_artifacts']) for n in ['openui_text','openui_paint'])
p=Path('/tmp/openui-native-author-alias-guards-terminal-v3788.json');assert not p.exists()
result=dict(schema_version=1,source=r['source'],actual_owner_exit_code=0,all_local_commands_terminal=True,owner_absent=True,receipt_sha256=sha(OUT/'receipt.json'),audit_sha256=sha(__file__),passed=step['passed'],failed=step['failed'],ignored=step['ignored'],fresh_records=len(r['local_artifacts']),compiled_paths=len(paths),diagnostic_only=True,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,retired_for_reexecution_after_source_or_target_mutation=True)
p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
