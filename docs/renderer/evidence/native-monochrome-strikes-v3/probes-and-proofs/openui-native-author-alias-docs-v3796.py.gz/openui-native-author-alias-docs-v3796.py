import json
import os
from pathlib import Path

ROOT = Path('/home/nero/code/open-ui')
e = json.loads((ROOT / 'docs/renderer/generated/native-monochrome-strikes-v3.json').read_bytes())
assert e['diagnostic_only'] and e['renderer']['candidate_nonregression']
assert e['regression_recovery']['restored_exact_comparisons'] == 16
assert e['regression_recovery']['retained_exact_gains'] == 7
assert e['guards']['passed'] == 510 and e['guards']['failed'] == e['guards']['ignored'] == 0

def atomic(path, text):
    temp = path.with_name(path.name + '.author-policy.tmp')
    assert not temp.exists()
    temp.write_text(text)
    os.replace(temp, path)

for file, level, link in [
    ('README.md', '###', 'docs/renderer/generated/'),
    ('docs/progress/current-status.md', '###', '../renderer/generated/'),
    ('docs/renderer/contract.md', '##', 'generated/'),
    ('docs/v02/release.md', '##', '../renderer/generated/'),
]:
    path = ROOT / file
    text = path.read_text()
    anchor = level + ' Monochrome text regression (rejected)\n'
    assert text.count(anchor) == 1
    block = f'''{level} Ordinary text raster policy correction

The shared raster path now selects a separate policy for ordinary author
monochrome text. It respects the resolved font hinting setting and integer
glyph positions. Rotated and ruby text retain their physical strike and
fractional local positions. This fixes the coupling that caused the rejected
full-census regression below, without a test ID, font name, scale or output
exception.

Fresh dirty-source diagnostics match **10/10 native images and 70/70 bounds**
against unchanged, independently repeated Chromium captures. Process repeats,
unchanged-frame repeats, the Rust click callback and teardown pass at the four
required profiles and a 3× neighbor.

All 40 affected original test IDs run at all four profiles: **121/160 exact,
39 different, zero errors**. Every one of the **16 lost exact comparisons is
restored**, all **7 exact gains are retained**, and all **34 worsened
comparisons are repaired**. Compared with the earlier accepted source, this
partial scope has 7 gains, no exact losses and no worsened differences. The
39 existing mismatches remain failures.

Focused **640/640** and primitive **960/960** are exact, with every native
image and Chromium reference unchanged. All **1,760 diagnostic rows** and
fresh compiled artifacts are audited. All **510 shared text and paint tests**
pass with zero failures or ignored tests. The initial wrapper failure on a
wrong report filename is preserved; the continuation uses the same verified
binary and frozen source.

These are candidate diagnostics. Fresh clean complete original/expanded
censuses, workspace, ABI and hosted checks on the committed correction remain
pending. Full renderer equality, general font-family shaping, reviewed
residual ownership, remaining native APIs, compositor, physical lab and
release qualification remain open. Open UI never runs JavaScript; consuming
apps use public Rust methods and Rust callbacks.
[Corrected policy evidence]({link}native-monochrome-strikes-v3.json).

'''
    atomic(path, text.replace(anchor, block + anchor, 1))

path = ROOT / 'docs/v02/supported-platforms.md'
text = path.read_text()
anchor = '\n## No JavaScript runtime\n'
assert text.count(anchor) == 1
block = '''
The corrected ordinary-author raster policy keeps all ten native images and
70 bounds exact in dirty-source diagnostics. In all 160 affected original
comparisons it restores the 16 lost exact results, retains all seven gains and
repairs all 34 worsened differences. Focused 640/640, primitive 960/960 and 510
shared text/paint tests pass. The 39 existing affected mismatches still fail;
fresh clean complete qualification remains required.
[Correction diagnostics](../renderer/generated/native-monochrome-strikes-v3.json).
'''
atomic(path, text.replace(anchor, block + anchor, 1))

path = ROOT / 'docs/v02/unsupported-features.md'
text = path.read_text()
anchor = '  [Failed full census and clean checks](../renderer/generated/native-monochrome-strikes-v2.json).\n'
assert text.count(anchor) == 1
block = '''  The subsequent shared policy correction restores all 16 lost exact
  comparisons and retains the seven gains in 160 dirty-source diagnostics.
  All ten native images, focused/primitive suites and 510 shared tests pass;
  fresh clean complete qualification remains pending.
  [Correction diagnostics](../renderer/generated/native-monochrome-strikes-v3.json).
'''
atomic(path, text.replace(anchor, anchor + block, 1))
print('Updated six existing documents with the corrected diagnostic scope.', flush=True)
