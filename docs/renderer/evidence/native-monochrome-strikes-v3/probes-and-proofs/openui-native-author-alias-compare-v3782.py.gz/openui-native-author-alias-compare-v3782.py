import hashlib,json,sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui')
BUILD=Path('/mnt/d/openui-v02-qualification-d174ea0b/native-author-alias-build-v3780')
REF=Path('/mnt/d/openui-v02-qualification-d174ea0b/native-shaping-wrap-candidate-chromium-v3696')
sys.path[:0]=['/tmp',str(ROOT/'tools/qualification')]
from openui_parallel_source_identity_v3060 import identity
from residuals import analyze_image_difference

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(2**20),b''):h.update(b)
 return h.hexdigest()

b=json.loads((BUILD/'receipt.json').read_bytes())
a=json.loads(Path('/tmp/openui-native-author-alias-terminal-v3781.json').read_bytes())
r=json.loads((REF/'receipt.json').read_bytes())
assert b['all_commands_terminal'] and b['source_unchanged'] and b['source']==identity(ROOT)
assert a['source']==b['source'] and a['receipt_sha256']==sha(BUILD/'receipt.json')
assert r['all_commands_terminal'] and r['source_unchanged']
assert r['capture_harness_sha256']==sha(ROOT/'tools/accountability/run_all_pixel_comparisons.py')
assert r['chromium_binary_sha256']==sha(ROOT/'chrome/linux-147.0.7727.50/chrome-linux64/chrome')
assert r['ahem_font_sha256']==sha(ROOT/'bindings/rust/openui-text/fonts/Ahem.ttf')
measurements=[]; bounds=exact_bounds=images=exact_images=improved=worsened=0
for i,c in enumerate(b['cases']):
 d=Path(c['runs'][0]['directory']); rc=r['cases'][i]
 assert [c[k] for k in ['width','height','scale']]==[rc[k] for k in ['width','height','scale']]
 assert sha(REF/f'profile-{i}'/'test.html')==rc['input_sha256']
 for stage in ['before','after']:
  native=json.loads((d/(stage+'.json')).read_bytes())
  oracle=json.loads((REF/f'profile-{i}'/f'chromium-1-{stage}.json').read_bytes())
  assert oracle==rc['stages'][stage]['chromium_bounds']
  assert oracle==json.loads((REF/f'profile-{i}'/f'chromium-2-{stage}.json').read_bytes())
  assert len(native)==len(oracle)==7
  bounds+=len(native); exact_bounds+=sum(x==y for x,y in zip(native,oracle))
  png=REF/f'profile-{i}'/f'chromium-1-{stage}-capture-1.png'
  for rep in [1,2]:
   for cap in [1,2]:assert sha(REF/f'profile-{i}'/f'chromium-{rep}-{stage}-capture-{cap}.png')==rc['stages'][stage]['chromium_png_sha256']
  analysis=analyze_image_difference(png,d/(stage+'.png'))
  old=rc['stages'][stage]['analysis']['mismatched_pixels']; new=analysis['mismatched_pixels']
  images+=1;exact_images+=new==0;improved+=new<old;worsened+=new>old
  measurements.append(dict(profile=rc['profile'],stage=stage,bounds_exact=native==oracle,previous_wrong_pixels=old,analysis=analysis,native_png_sha256=sha(d/(stage+'.png')),chromium_png_sha256=sha(png)))
result=dict(schema_version=1,source=b['source'],diagnostic_only=True,bounds=bounds,exact_bounds=exact_bounds,images=images,exact_images=exact_images,images_improved=improved,images_worsened=worsened,measurements=measurements,native_receipt_sha256=sha(BUILD/'receipt.json'),reference_receipt_sha256=sha(REF/'receipt.json'),pixel_target='pinned Chromium',pixel_tolerance=0,chromium_references_changed=0,reference_repeats_stable=True,javascript_executed_by_openui=False,all_native_apis_qualified=False,renderer_qualified=False,release_qualified=False,actual_comparison_exit_code=int(bounds!=exact_bounds or images!=exact_images),retired_for_reexecution_after_source_or_target_mutation=True)
p=Path('/tmp/openui-native-author-alias-comparison-v3782.json'); assert not p.exists()
p.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['bounds','exact_bounds','images','exact_images','images_improved','images_worsened','actual_comparison_exit_code']}),flush=True)
for m in measurements:print(json.dumps({'profile':m['profile'],'stage':m['stage'],'previous':m['previous_wrong_pixels'],'now':m['analysis']['mismatched_pixels']}),flush=True)
sys.exit(result['actual_comparison_exit_code'])
