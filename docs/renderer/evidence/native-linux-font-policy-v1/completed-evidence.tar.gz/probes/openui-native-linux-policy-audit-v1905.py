"""Audit every native Fontations row against the previous immutable trial."""
import hashlib,json
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
newpath=RAW/'native-linux-policy-consumer-v1903/receipt.json'
oldpath=RAW/'native-linux-font-consumer-v1898/receipt.json'
new=json.loads(newpath.read_text());old=json.loads(oldpath.read_text())
assert new['all_commands_terminal'] and old['all_commands_terminal'] and not new.get('failure')
assert new['source']==new['source_after'] and new['source']['clean']
assert new['totals']['images']==200 and new['totals']['native_processes']==200
assert new['native_binary_sha256'] and new['reference_bytes_reused_unchanged']
key=lambda c,i:(c['family'],c['size'],c['scale'],i['state'])
prior={key(c,i):i for c in old['cases'] if c['raster']=='fontations' for i in c['images']}
rows=[]
for c in new['cases']:
 for i in c['images']:
  k=key(c,i);o=prior.pop(k)
  assert i['chromium_png_sha256']==o['chromium_png_sha256']
  assert i['independent_reference_runs']==o['independent_reference_runs']
  assert len(i['phases'])==len(o['phases'])==64
  p=i['analysis']['mismatched_pixels'];q=o['analysis']['mismatched_pixels']
  rows.append(dict(family=c['family'],size=c['size'],scale=c['scale'],state=i['state'],prior_mismatched_pixels=q,candidate_mismatched_pixels=p,prior_exact=q==0,candidate_exact=p==0,unchanged_native_png=i['native_png_sha256']==o['native_png_sha256'],geometry_exact=sum(x['geometry_exact'] for x in i['phases']),prior_geometry_exact=sum(x['geometry_exact'] for x in o['phases']),phase_exact=sum(x['mismatched_pixels']==0 for x in i['phases']),prior_phase_exact=sum(x['mismatched_pixels']==0 for x in o['phases'])))
assert not prior and len(rows)==200
summarize=lambda r:dict(images=len(r),exact=sum(x['candidate_exact'] for x in r),prior_exact=sum(x['prior_exact'] for x in r),exact_gains=sum(x['candidate_exact'] and not x['prior_exact'] for x in r),exact_losses=sum(x['prior_exact'] and not x['candidate_exact'] for x in r),mismatched_pixels=sum(x['candidate_mismatched_pixels'] for x in r),prior_mismatched_pixels=sum(x['prior_mismatched_pixels'] for x in r),geometry_exact=sum(x['geometry_exact'] for x in r),prior_geometry_exact=sum(x['prior_geometry_exact'] for x in r),phase_exact=sum(x['phase_exact'] for x in r),prior_phase_exact=sum(x['prior_phase_exact'] for x in r),unchanged_native_pngs=sum(x['unchanged_native_png'] for x in r))
report=dict(schema_version=1,source=new['source'],source_after=new['source_after'],all_commands_terminal=True,release_qualification=False,promotion_allowed=False,source_predates_current_variable_font_correction=True,inherited_rejected_descriptor_change=True,full_original_expanded_focused_primitive_matrices_not_measured=True,all_chromium_inputs_unchanged=True,javascript_executed_by_openui=False,pixel_tolerance=0,prior_receipt_sha256=sha(oldpath),candidate_receipt_sha256=sha(newpath),probe_sha256=sha(Path(__file__)),totals=summarize(rows),per_scale={str(scale):summarize([x for x in rows if x['scale']==scale]) for scale in [1,1.25,1.5,2,3]},rows=rows)
report['observed_exit_code']=int(report['totals']['exact']!=200 or report['totals']['geometry_exact']!=12800)
p=RAW/'native-linux-policy-audit-v1905.json';assert not p.exists();p.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(totals=report['totals'],per_scale=report['per_scale'],actual_pixel_gate=report['observed_exit_code'],receipt_sha256=sha(p))),flush=True)
