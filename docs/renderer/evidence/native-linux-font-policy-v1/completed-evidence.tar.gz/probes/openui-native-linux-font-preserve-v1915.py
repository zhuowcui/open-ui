"""Archive complete paired Linux font-policy evidence without qualifying it."""
import hashlib,json,subprocess,tarfile
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');RAW=ROOT/'out/renderer-evidence/native-viewport-scroll-v1'
DEST=ROOT/'docs/renderer/evidence/native-linux-font-policy-v1';INDEX=ROOT/'docs/renderer/generated/native-linux-font-policy-v1.json'
assert not DEST.exists() and not INDEX.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
paths={
 'first-owner':RAW/'native-linux-font-pipeline-v1898/receipt.json',
 'first-baseline':RAW/'native-linux-font-baseline-build-v1898/build.json',
 'first-candidate':RAW/'native-linux-font-candidate-build-v1898/build.json',
 'first-consumer':RAW/'native-linux-font-consumer-v1898/receipt.json',
 'first-audit':RAW/'native-linux-font-audit-v1899.json',
 'failed-owner':RAW/'native-linux-policy-pipeline-v1903/receipt.json',
 'failed-baseline':RAW/'native-linux-policy-baseline-build-v1903/build.json',
 'owner':RAW/'native-linux-policy-pipeline-v1909/receipt.json',
 'baseline':RAW/'native-linux-policy-baseline-build-v1909/build.json',
 'candidate':RAW/'native-linux-policy-candidate-build-v1909/build.json',
 'consumer':RAW/'native-linux-policy-consumer-v1909/receipt.json',
 'audit':RAW/'native-linux-policy-audit-v1910.json',
}
data={k:read(p) for k,p in paths.items()}
assert all(d['all_commands_terminal'] for d in data.values())
assert data['failed-owner']['observed_exit_code']==1 and data['failed-baseline']['steps'][0]['disk_guard_triggered'] and len(data['failed-baseline']['steps'])==1
assert data['first-baseline']['baseline_regression_reproduced'] and data['baseline']['baseline_regression_reproduced']
assert data['first-candidate']['observed_exit_code']==data['candidate']['observed_exit_code']==0
assert next(s for s in data['first-candidate']['steps'] if s['name']=='all-text-tests')['passed']==344
assert next(s for s in data['candidate']['steps'] if s['name']=='all-text-tests')['passed']==345
assert data['first-audit']['totals']['exact']==162 and data['first-audit']['totals']['exact_gains']==100 and data['first-audit']['totals']['exact_losses']==0
assert data['audit']['totals']['exact']==162 and data['audit']['totals']['unchanged_native_pngs']==200
assert data['audit']['totals']['exact_gains']==data['audit']['totals']['exact_losses']==0
assert data['consumer']['observed_exit_code']==1 and data['consumer']['totals']['geometry_exact']==11520
assert data['consumer']['source']==data['consumer']['source_after'] and data['consumer']['source']['clean']
assert data['first-consumer']['totals']['native_processes']==data['consumer']['totals']['native_processes']==200
sources={}
for name in [
 'native-linux-font-pipeline-v1898','native-linux-font-baseline-build-v1898','native-linux-font-candidate-build-v1898','native-linux-font-consumer-v1898','native-linux-font-baseline-checks-v1897','native-linux-font-candidate-checks-v1897',
 'native-linux-policy-pipeline-v1903','native-linux-policy-baseline-build-v1903','native-linux-policy-baseline-checks-v1902','native-linux-policy-candidate-checks-v1902',
 'native-linux-policy-pipeline-v1909','native-linux-policy-baseline-build-v1909','native-linux-policy-candidate-build-v1909','native-linux-policy-consumer-v1909','native-linux-policy-baseline-checks-v1908','native-linux-policy-candidate-checks-v1908']:
 for p in sorted((RAW/name).rglob('*')):
  if p.is_file() and not p.is_symlink() and p.suffix in ['.json','.log','.png','.html']:
   sources[str(p.relative_to(RAW))]=p
for name in ['native-linux-font-audit-v1899.json','native-linux-policy-audit-v1910.json']:
 sources[name]=RAW/name
for pattern in ['openui-native-linux-font-*-v189*.py','openui-native-linux-policy-*-v190*.py']:
 for p in Path('/tmp').glob(pattern):sources['probes/'+p.name]=p
for name in ['openui-native-linux-font-roots-v1895.json','openui-native-linux-font-sources-v1896.json','openui-native-linux-policy-sources-v1901.json','openui-native-linux-policy-sources-v1907.json','openui-native-linux-font-reviewed-sources-v1900.json','openui-verified-terminal-binary-relocation-v1906.json','openui-native-fontations-scaler-review-v1913.json']:
 p=Path('/tmp')/name;sources['probes/'+p.name]=p
sources['probes/'+Path(__file__).name]=Path(__file__)
for relative in ['ui/gfx/font_render_params_linux.cc','third_party/blink/renderer/platform/fonts/font_metrics.cc','third_party/blink/renderer/platform/fonts/web_font_render_style.cc','content/common/features.cc','chrome/VERSION']:
 sources['reviewed-chromium-source/'+relative]=Path('/home/nero/chromium/src')/relative
skia=Path('/home/nero/.cargo/git/checkouts/rust-skia-b4d79b6a888cdb4c/a31b86b/skia-bindings/skia')
for relative in ['src/ports/SkTypeface_fontations.cpp','include/ports/SkTypeface_fontations.h','gn/skia.gni','src/utils/SkCustomTypeface.cpp','src/core/SkScalerContext.cpp','src/core/SkScalerContext.h']:
 sources['pinned-skia-source/'+relative]=skia/relative
hosted_path=RAW/'native-linux-font-umbrella-hosted-v1904/receipt.json'
hosted=read(hosted_path) if hosted_path.exists() else None
if hosted:
 assert hosted['all_commands_terminal'] and hosted['source']=='0c39998c94eb64ee283055f8be8961a89b54f300'
 for p in (hosted_path.parent).iterdir():
  if p.is_file():sources[str(p.relative_to(RAW))]=p
 sources['probes/openui-native-linux-font-umbrella-hosted-collect-v1904.py']=Path('/tmp/openui-native-linux-font-umbrella-hosted-collect-v1904.py')
DEST.mkdir()
source_meta=read(Path('/tmp/openui-native-linux-policy-sources-v1907.json'))['sources']
for label,value in source_meta.items():
 for relative in ['bindings/rust/openui-text/src/font/platform.rs','bindings/rust/openui-geometry/src/raster.rs','bindings/rust/openui-paint/src/emphasis_painter.rs']:
  p=Path(value['root'])/relative;sources['source/'+label+'/'+relative]=p
patch=DEST/'shared-linux-policy.patch'
patch.write_bytes(subprocess.check_output(['git','diff','ef8880b083876319df54599416c0fe11c543a26c',source_meta['candidate']['commit'],'--','bindings/rust/openui-text/src/font/platform.rs','bindings/rust/openui-geometry/src/raster.rs','bindings/rust/openui-paint/src/emphasis_painter.rs'],cwd=ROOT))
sources['source/shared-linux-policy.patch']=patch
archive=DEST/'completed-evidence.tar.gz';members=[];first={}
with tarfile.open(archive,'w:gz',compresslevel=6,format=tarfile.PAX_FORMAT) as tar:
 for name,p in sorted(sources.items()):
  digest=sha(p);members.append(dict(path=name,bytes=p.stat().st_size,sha256=digest));info=tar.gettarinfo(str(p),arcname=name)
  if digest in first:
   info.type=tarfile.LNKTYPE;info.linkname=first[digest];info.size=0;tar.addfile(info)
  else:
   first[digest]=name
   with p.open('rb') as stream:tar.addfile(info,stream)
with tarfile.open(archive,'r:gz') as tar:
 assert len(tar.getmembers())==len(members)
 for info,row in zip(tar.getmembers(),members):
  content=tar.extractfile(info).read();assert info.name==row['path'] and len(content)==row['bytes'] and hashlib.sha256(content).hexdigest()==row['sha256']
manifest=DEST/'archive-members.json';manifest.write_text(json.dumps(members,sort_keys=True,indent=2)+'\n')
index=dict(schema_version=1,source=data['consumer']['source'],source_after=data['consumer']['source_after'],all_commands_terminal=True,private_unintegrated_candidate=True,release_qualification=False,promotion_allowed=False,pixel_tolerance=0,new_release_states_admitted=0,javascript_executed_by_openui=False,chromium_is_only_pixel_target=True,
 independent_repeated_chromium_metric_observations=30,baseline_metric_mismatches=12,candidate_metric_mismatches=0,
 first_trial_text_tests_passed=344,final_trial_text_tests_passed=345,full_workspace_and_ffi_consumers_not_run_on_these_sources=True,
 explicit_fixed_hinting_baseline_failure_reproduced=True,explicit_fixed_hinting_guard_passed=True,automatic_policy_is_separate_public_rust_selection=True,
 native_images_exact=162,native_images_total=200,prior_fontations_images_exact=62,exact_gains=100,exact_losses=0,
 final_native_pngs_equal_first_trial=200,all_reference_images_unchanged=True,repeated_native_processes=400,repeated_native_pairs_identical=True,
 native_geometry_exact=11520,native_geometry_total=12800,native_pixel_gate_actual_exit=1,
 full_original_expanded_focused_primitive_matrices_not_measured=True,inherits_rejected_descriptor_candidate=True,inherited_full_census_losses=29,
 matching_and_shaping_still_use_freetype=True,full_fontations_typeface_factory_not_implemented=True,source_predates_current_variable_font_correction=True,
 failed_policy_preflight_disk_guard_preserved=True,compiled_binary_relocation_verified_unchanged=True,
 formal_original_renderer_residual_ownership_assigned=0,
 source_scaler_a8_from_lcd_flag_difference_reviewed=True,all_residual_root_causes_proved=False,
 reviewed_chromium_source_version='147.0.7727.24',measured_chromium_binary_version='147.0.7727.50',runtime_typeface_factory_trace_observed=False,
 first_trial=data['first-audit']['totals'],final_trial=data['audit']['totals'],per_scale=data['first-audit']['per_scale'],
 hosted_umbrella_observation=({k:hosted[k] for k in ['source','successful_jobs','skipped_jobs','failed_jobs','all_seven_native_guards_executed_and_passed_in_hosted_parity']} if hosted else None),
 previous_font_choice_index=dict(path='docs/renderer/generated/native-font-choice-v2.json',sha256=sha(ROOT/'docs/renderer/generated/native-font-choice-v2.json')),
 receipts_sha256={k:sha(p) for k,p in paths.items()},archived_members=len(members),artifacts=[dict(path=str(p.relative_to(ROOT)),bytes=p.stat().st_size,sha256=sha(p)) for p in [archive,manifest,patch]],preserver_sha256=sha(Path(__file__)))
INDEX.write_text(json.dumps(index,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(index=str(INDEX),sha256=sha(INDEX),members=len(members),archive_bytes=archive.stat().st_size,private_native_exact=162,exact_gains=100,exact_losses=0)),flush=True)
