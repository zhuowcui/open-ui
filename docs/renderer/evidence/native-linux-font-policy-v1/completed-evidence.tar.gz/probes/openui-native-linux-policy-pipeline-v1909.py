"""Exclusive owner for actual baseline failure, candidate tests, native pixel trial."""
import fcntl,hashlib,json,os,subprocess,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1'
NAME='native-linux-policy-pipeline-v1909'
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for program in ['cargo','rustc','pixel_compare']:
 assert subprocess.run(['pgrep','-x',program],capture_output=True).returncode==1
sources=json.loads(Path('/tmp/openui-native-linux-policy-sources-v1907.json').read_text())['sources']
sys.path.insert(0,str(MAIN/'tools/qualification'))
from renderer_source_identity import repository_source_identity
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
identities={k:repository_source_identity(Path(v['root'])) for k,v in sources.items()}
for label,identity in identities.items():
 assert identity['clean'] and identity['commit']==sources[label]['commit']
 checks=json.loads((RAW/('native-linux-policy-'+label+'-checks-v1908/receipt.json')).read_text())
 assert checks['all_commands_terminal'] and checks['source']==checks['source_after']==identity
 assert len(checks['checks'])==15 and all(row['observed_exit_code']==0 for row in checks['checks'])
OUT=RAW/NAME;STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/NAME
assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
steps=[('baseline-build',Path('/tmp/openui-native-linux-policy-baseline-build-v1909.py')),('candidate-build',Path('/tmp/openui-native-linux-policy-candidate-build-v1909.py')),('candidate-native',Path('/tmp/openui-native-linux-policy-consumer-v1909.py'))]
report=dict(schema_version=1,sources=identities,owner_pid=os.getpid(),all_commands_terminal=False,release_qualification=False,promotion_allowed=False,zero_tolerance=True,javascript_executed_by_openui=False,inherited_rejected_descriptor_change=True,full_renderer_matrices_not_attempted=True,whole_pipeline_lock_covers_all_stages_and_gaps=True,steps=[],probe_sha256=sha(Path(__file__)),worker_sha256={str(p):sha(p) for _,p in steps})
save=lambda:(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
save()
try:
 for name,script in steps:
  for label,identity in identities.items():assert repository_source_identity(Path(sources[label]['root']))==identity
  assert all(sha(p)==report['worker_sha256'][str(p)] for _,p in steps)
  log=OUT/(name+'.log')
  with log.open('xb') as stream:
   process=subprocess.Popen([sys.executable,str(script)],cwd=MAIN,env=dict(os.environ,OPENUI_NATIVE_WHOLE_OWNER=NAME,PYTHONDONTWRITEBYTECODE='1'),stdout=stream,stderr=subprocess.STDOUT)
   report['current_process']=dict(pid=process.pid,stage=name);save();process.wait()
  report.pop('current_process');report['steps'].append(dict(name=name,observed_exit_code=process.returncode,log_sha256=sha(log)));save()
  print(json.dumps(dict(stage=name,actual_exit=process.returncode)),flush=True)
  if name.endswith('build'):assert process.returncode==0,'build or independent metric guard failed'
  else:
   native=json.loads((RAW/'native-linux-policy-consumer-v1909/receipt.json').read_text())
   assert native['all_commands_terminal'] and not native.get('failure') and native['totals']['images']==200
 report['observed_exit_code']=int(any(s['observed_exit_code'] for s in report['steps']))
except BaseException as error:
 report.update(observed_exit_code=1,failure=str(error));raise
finally:
 report['all_commands_terminal']=True;report['sources_after']={k:repository_source_identity(Path(v['root'])) for k,v in sources.items()};save()
raise SystemExit(report['observed_exit_code'])
