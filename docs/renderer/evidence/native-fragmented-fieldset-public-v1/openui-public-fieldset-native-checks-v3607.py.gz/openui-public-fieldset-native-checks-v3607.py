import fcntl
import hashlib
import json
import os
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path('/home/nero/code/open-ui')
BASE = Path('/mnt/d/openui-v02-qualification-d174ea0b')
OUT = BASE / 'public-fieldset-native-checks-v3607'
TARGET = Path('/mnt/e/openui-v02-cargo-c73754e2/target')
sys.path[:0] = [str(ROOT), '/tmp']
from openui_parallel_source_identity_v3060 import identity
from tools.qualification.residuals import analyze_image_difference

def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(2**20), b''):
            digest.update(block)
    return digest.hexdigest()

load = lambda p: json.loads(Path(p).read_bytes())
lock = open('/tmp/openui-native-cargo-raster-owner.lock', 'a+')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
for name in ['cargo', 'rustc', 'rustfmt', 'pixel_compare']:
    assert subprocess.run(['pgrep', '-x', name], capture_output=True).returncode == 1
source = identity(ROOT)
assert source['clean'] and source['commit'].startswith('dc8a540e')
terminal = load('/tmp/openui-private-fragmented-fieldset-renderer-terminal-v3604.json')
assert terminal['all_local_commands_terminal'] and terminal['candidate_nonregression']
assert not OUT.exists()
OUT.mkdir()
env = dict(os.environ, CARGO_TARGET_DIR=str(TARGET), CARGO_PROFILE_DEV_DEBUG='0',
           CARGO_PROFILE_TEST_DEBUG='0', CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='4',
           RUST_MIN_STACK='4194304', PYTHONDONTWRITEBYTECODE='1')
env.pop('LD_PRELOAD', None)
env.pop('LD_LIBRARY_PATH', None)
r = dict(schema_version=1, owner_pid=os.getpid(), source=source, steps=[], cases=[],
         driver_sha256=sha(__file__), source_identity_reader_sha256=sha('/tmp/openui_parallel_source_identity_v3060.py'),
         previous_private_terminal_sha256=sha('/tmp/openui-private-fragmented-fieldset-renderer-terminal-v3604.json'),
         all_commands_terminal=False, javascript_executed_by_openui=False,
         pixel_target='pinned Chromium', pixel_tolerance=0,
         historical_openui_archive_is_a_pixel_target=False, diagnostic_only=True,
         full_renderer_contract_qualified=False, all_native_apis_qualified=False, release_qualified=False)

def save():
    temporary = OUT / 'receipt.tmp'
    temporary.write_text(json.dumps(r, sort_keys=True, indent=2) + '\n')
    os.replace(temporary, OUT / 'receipt.json')

def run(name, command, timeout=None):
    log = OUT / (name + '.log')
    print('Starting ' + name, flush=True)
    with log.open('xb') as stream:
        child = subprocess.Popen(command, cwd=ROOT / 'bindings/rust', env=env,
                                 stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        r['current_process'] = dict(name=name, pid=child.pid)
        save()
        start = time.monotonic()
        try:
            while child.poll() is None:
                if (shutil.disk_usage(ROOT).free < 128 * 2**20
                        or shutil.disk_usage(OUT).free < 10 * 2**30
                        or shutil.disk_usage(TARGET).free < 10 * 2**30
                        or shutil.disk_usage('/dev/shm').free < 256 * 2**20):
                    raise RuntimeError('disk guard')
                if timeout and time.monotonic() - start > timeout:
                    raise TimeoutError(name)
                time.sleep(1)
            code = child.wait()
        finally:
            if child.poll() is None:
                os.killpg(child.pid, signal.SIGTERM)
                try:
                    child.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait()
            r.pop('current_process', None)
            r['steps'].append(dict(name=name, command=command, actual_exit_code=child.returncode,
                                   log_sha256=sha(log)))
            save()
    assert code == 0, name
    print(json.dumps(dict(stage=name, actual_exit_code=code)), flush=True)
    return log

save()
try:
    metadata_log = run('metadata', ['cargo', 'metadata', '--locked', '--offline', '--format-version', '1'])
    metadata = load(metadata_log)
    packages = {p['id'] for p in metadata['packages'] if Path(p['manifest_path']).resolve().is_relative_to(ROOT)}
    assert packages
    run('clean-local-packages', ['cargo', 'clean', *[arg for p in sorted(packages) for arg in ['-p', p]]])
    build_log = run('native-build', ['cargo', 'build', '--locked', '--offline', '-p', 'openui',
                                  '--example', 'native_fragmented_fieldset', '--message-format=json-render-diagnostics'])
    records = []
    for line in build_log.read_text().splitlines():
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        if row.get('reason') == 'compiler-artifact' and row['package_id'] in packages:
            assert row['fresh'] is False
            assert Path(row['manifest_path']).resolve().is_relative_to(ROOT)
            assert Path(row['target']['src_path']).resolve().is_relative_to(ROOT)
            row['sha256'] = {p: sha(p) for p in row['filenames']}
            records.append(row)
    assert any(row['target']['name'] == 'native_fragmented_fieldset' for row in records)
    binary = OUT / 'native_fragmented_fieldset'
    shutil.copy2(TARGET / 'debug/examples/native_fragmented_fieldset', binary)
    r['local_artifacts'] = records
    r['native_binary_sha256'] = sha(binary)
    save()
    previous = load(BASE / 'native-fragmented-fieldset-candidate-compare-v3595/receipt.json')
    for index, old in enumerate(previous['cases']):
        row = dict(scale=old['scale'], phase=old['phase'], alpha=old['alpha'], mode=old['mode'], runs=[])
        directory = OUT / f'case-{index}'
        directory.mkdir()
        for repeat in [1, 2]:
            destination = directory / f'native-{repeat}'
            name = f'case-{index}-native-{repeat}'
            run(name, [str(binary), str(destination), str(row['scale']), str(row['phase']),
                       str(row['alpha']), row['mode']], timeout=120)
            row['runs'].append(dict(directory=str(destination), png_sha256=sha(destination / 'openui.png'),
                                    geometry_sha256=sha(destination / 'geometry.json')))
        first, second = [load(directory / f'native-{n}/geometry.json') for n in [1, 2]]
        assert first == second and first['callbacks'] == 4
        assert first['nodes'] == old['chromium_geometry']['nodes'] and first['rects'] == old['chromium_geometry']['rects']
        assert row['runs'][0]['png_sha256'] == row['runs'][1]['png_sha256'] == old['native_png_sha256']
        assert sha(old['reference_png']) == old['chromium_png_sha256']
        row.update(geometry=first, geometry_exact=True, fragment_rects_exact=True,
                   independent_native_repeats_identical=True, reference_png=old['reference_png'],
                   chromium_png_sha256=old['chromium_png_sha256'],
                   analysis=analyze_image_difference(old['reference_png'], directory / 'native-1/openui.png'))
        assert row['analysis']['mismatched_pixels'] == old['analysis']['mismatched_pixels']
        r['cases'].append(row)
        save()
        print(json.dumps(dict(case=index, wrong_pixels=row['analysis']['mismatched_pixels'])), flush=True)
    run('paint-tests', ['cargo', 'test', '--locked', '--offline', '-p', 'openui-paint', '--lib'])
    r['observed_exit_code'] = 0
except BaseException as error:
    r.update(observed_exit_code=1, failure=repr(error))
    raise
finally:
    r['source_after'] = identity(ROOT)
    r['source_unchanged'] = r['source_after'] == source
    r['all_commands_terminal'] = True
    save()
assert r['source_unchanged'] and len(r['cases']) == 11
print(json.dumps(dict(complete=True, cases=11, source_unchanged=True,
                      full_renderer_contract_qualified=False)), flush=True)
