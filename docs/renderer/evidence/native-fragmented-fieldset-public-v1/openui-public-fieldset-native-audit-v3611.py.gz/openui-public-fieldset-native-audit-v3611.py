import fcntl
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path('/home/nero/code/open-ui')
OUT = Path('/mnt/d/openui-v02-qualification-d174ea0b/public-fieldset-native-checks-v3610')
PROOF = Path('/tmp/openui-public-fieldset-native-terminal-v3611.json')
sys.path.insert(0, '/tmp')
from openui_parallel_source_identity_v3060 import identity

def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(2**20), b''):
            digest.update(block)
    return digest.hexdigest()

lock = open('/tmp/openui-native-cargo-raster-owner.lock', 'a+')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
r = json.loads((OUT / 'receipt.json').read_bytes())
assert r['all_commands_terminal'] and r['observed_exit_code'] == 0 and 'failure' not in r
assert identity(ROOT) == r['source'] == r['source_after'] and r['source_unchanged']
assert subprocess.run(['ps', '-p', str(r['owner_pid'])], capture_output=True).returncode == 1
for name in ['cargo', 'rustc', 'rustfmt', 'pixel_compare', 'native_fragmente']:
    assert subprocess.run(['pgrep', '-x', name], capture_output=True).returncode == 1
assert sha('/tmp/openui-public-fieldset-native-checks-v3610.py') == r['driver_sha256']
assert sha('/tmp/openui_parallel_source_identity_v3060.py') == r['source_identity_reader_sha256']
assert sha('/tmp/openui-public-fieldset-native-failure-terminal-v3609.json') == r['failed_public_attempt_terminal_sha256']
assert sha('/tmp/openui-private-fragmented-fieldset-renderer-terminal-v3604.json') == r['previous_private_terminal_sha256']
for step in r['steps']:
    assert step['actual_exit_code'] == 0
    assert sha(OUT / (step['name'] + '.log')) == step['log_sha256']
records = r['local_artifacts']
paths = {}
for record in records:
    assert record['fresh'] is False and record['reason'] == 'compiler-artifact'
    assert Path(record['manifest_path']).resolve().is_relative_to(ROOT)
    assert Path(record['target']['src_path']).resolve().is_relative_to(ROOT)
    for path, digest in record['sha256'].items():
        assert sha(path) == digest
        paths[path] = digest
assert sha(OUT / 'native_fragmented_fieldset') == r['native_binary_sha256']
assert len(r['cases']) == 11
bounds = rectangles = exact = different = 0
for case in r['cases']:
    assert case['geometry_exact'] and case['fragment_rects_exact'] and case['independent_native_repeats_identical']
    assert case['geometry']['callbacks'] == 4
    assert sha(case['reference_png']) == case['chromium_png_sha256']
    for run in case['runs']:
        directory = Path(run['directory'])
        assert sha(directory / 'openui.png') == run['png_sha256']
        assert sha(directory / 'geometry.json') == run['geometry_sha256']
    bounds += len(case['geometry']['nodes'])
    rectangles += len(case['geometry']['rects'])
    exact += case['analysis']['mismatched_pixels'] == 0
    different += case['analysis']['mismatched_pixels'] != 0
assert (bounds, rectangles, exact, different) == (143, 143, 7, 4)
test_log = (OUT / 'paint-tests.log').read_text()
matches = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', test_log)
assert len(matches) == 1 and matches[0][1:] == ('0', '0')
proof = dict(schema_version=1, all_local_commands_terminal=True, owner_absent=True,
             owner_pid=r['owner_pid'], actual_owner_exit_code=0, source=r['source'],
             receipt_sha256=sha(OUT / 'receipt.json'), compiler_artifact_records=len(records),
             compiled_paths_verified=len(paths), local_libraries_fresh=True,
             native_cases=11, native_bounds_exact=bounds, native_client_rect_sets_exact=rectangles,
             native_images_exact=exact, native_images_different=different,
             native_callbacks_repeats_and_teardown_pass=True, paint_tests_passed=int(matches[0][0]),
             all_native_outputs_unchanged_from_measured_private_candidate=True,
             pixel_target='pinned Chromium', pixel_tolerance=0, javascript_executed_by_openui=False,
             all_native_apis_qualified=False, full_renderer_contract_qualified=False, release_qualified=False,
             retired_for_reexecution_after_source_or_target_mutation=True,
             audit_driver_sha256=sha(__file__))
assert not PROOF.exists()
PROOF.write_text(json.dumps(proof, sort_keys=True, indent=2) + '\n')
print(json.dumps(proof), flush=True)
