"""Preserve an unused historical runner byte-identically while making room for qualification."""
import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');ORIGINAL=MAIN/'out/renderer-evidence/native-image-clean-9b158cda-rerun-v2/pixel_compare-9b158cda-rerun-v2';DEST=Path('/mnt/e/openui-v02-qualification-d174ea0b/terminal-evidence-relocated-v2236');RECEIPT=Path('/tmp/openui-terminal-evidence-relocation-v2236.json')
sys.path.insert(0,str(MAIN/'tools/qualification'));from renderer_source_identity import repository_source_identity
source=repository_source_identity(MAIN);assert source['clean'] and not DEST.exists() and not RECEIPT.exists();assert ORIGINAL.is_file() and not ORIGINAL.is_symlink() and ORIGINAL.stat().st_nlink==1
for name in ['cargo','rustc','ninja','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode!=0
for entry in Path('/proc').iterdir():
 if not entry.name.isdecimal():continue
 try:
  assert (entry/'exe').resolve(strict=True)!=ORIGINAL
  command=(entry/'cmdline').read_bytes().replace(b'\0',b' ')
  assert not (b'python' in command and b'/tmp/openui-' in command and b'-pipeline-' in command),command
 except (OSError,RuntimeError):pass
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(2**20),b''):h.update(b)
 return h.hexdigest()
DEST.mkdir();target=DEST/ORIGINAL.name;digest=sha(ORIGINAL);size=ORIGINAL.stat().st_size;before=shutil.disk_usage(MAIN).free;shutil.copy2(ORIGINAL,target);assert sha(target)==digest==sha(ORIGINAL)
backup=ORIGINAL.with_name(ORIGINAL.name+'.verified-relocation-v2236');assert not backup.exists();ORIGINAL.rename(backup);ORIGINAL.symlink_to(target);assert sha(ORIGINAL)==digest==sha(backup);backup.unlink();assert repository_source_identity(MAIN)==source
r=dict(source_before=source,source_after=source,source_unchanged=True,all_commands_terminal=True,original_path=str(ORIGINAL),target=str(target),bytes=size,original_sha256=digest,copied_sha256=sha(target),final_path_sha256=sha(ORIGINAL),no_local_pipeline_owner_or_running_original=True,home_free_before=before,home_free_after=shutil.disk_usage(MAIN).free,reference_bytes_changed=0,release_qualification=False,probe_sha256=sha(Path(__file__)))
RECEIPT.write_text(json.dumps(r,sort_keys=True,indent=2)+'\n');print(json.dumps(r))
