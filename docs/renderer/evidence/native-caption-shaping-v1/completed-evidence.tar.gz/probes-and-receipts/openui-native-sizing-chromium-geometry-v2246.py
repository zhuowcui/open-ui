"""Preserve repeated Chromium geometry for the unchanged rejected sizing input."""
import ast,fcntl,hashlib,json,os,shutil,subprocess,sys,signal,time
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');SDK=MAIN/'out/private-native-caption-metrics-v2234'
RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';OUT=RAW/'native-sizing-chromium-geometry-v2246'
STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/OUT.name
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
sys.path.insert(0,str(SDK/'tools/qualification'))
from renderer_source_identity import repository_source_identity
sys.path.insert(0,str(SDK/'tools/accountability'))
import run_all_pixel_comparisons as capture
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=repository_source_identity(SDK);public=repository_source_identity(MAIN)
assert source['clean'] and public['clean']
chrome=MAIN/'chrome/linux-147.0.7727.50/chrome-linux64/chrome'
assert sha(chrome)=='0ba87684df0afc11faaea40ac57bd2f1d68b67191443b38215a36b90e6f08848'
original_ws=capture._CdpWebSocket
helper=Path('/tmp/openui-native-vertical-ch-pipeline-v2215.py')
tree=ast.parse(helper.read_text());function=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='observe')
code=ast.unparse(function).replace('logical_width=800, logical_height=600','logical_width=WIDTH, logical_height=HEIGHT')
# The old wrapper stops only Chromium's parent. Stop its complete owned
# process group before deleting the profile, including after parent exit.
code=code.replace("kwargs['stderr'] = stream", "kwargs['stderr'] = stream\n            kwargs['start_new_session'] = True")
code=code.replace("process.terminate()", "os.killpg(process.pid, signal.SIGTERM)")
code=code.replace("process.kill()", "os.killpg(process.pid, signal.SIGKILL)")
marker="cleanup_events.append(dict(pid=process.pid, actual_exit=process.poll(), stopped_before_profile_removal=True))"
assert code.count(marker)==1
replacement='''try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            # Wait for group members to stop; zombies cannot write profiles.
            deadline=time.monotonic()+10
            while True:
                alive=[]
                for entry in Path('/proc').iterdir():
                    if not entry.name.isdecimal(): continue
                    try:
                        fields=(entry/'stat').read_text().rsplit(')',1)[1].split()
                        if int(fields[2])==process.pid and fields[0]!='Z': alive.append(int(entry.name))
                    except (OSError,ValueError): pass
                if not alive: break
                assert time.monotonic()<deadline, alive
                time.sleep(.01)
            cleanup_events.append(dict(pid=process.pid, actual_exit=process.poll(), stopped_before_profile_removal=True, process_group_stopped=True))'''
code=code.replace(marker,replacement)
used=OUT/'used-observe.py';used.write_text(code+'\n')
exec(compile(code,str(used), 'exec'))
summary_path=RAW/'native-caption-metric-pipeline-v2237/sizing-caption-neighbors-matrix/full-summary.json'
summary=json.loads(summary_path.read_bytes())
report=dict(schema_version=1,all_commands_terminal=False,owner_pid=os.getpid(),source=source,public_source=public,
            release_qualification=False,diagnostic_only=True,pixel_tolerance=0,javascript_executed_by_openui=False,
            offline_javascript_executed_only_in_chromium=True,unchanged_matrix_input=True,profiles=[],
            process_group_cleanup=True,failed_previous_capture_receipt_sha256=sha(RAW/'native-sizing-chromium-geometry-v2245/receipt.json'),used_helper_sha256=sha(used),helper_sha256=sha(helper),probe_sha256=sha(Path(__file__)),chromium_binary_sha256=sha(chrome),
            harness_sha256=sha(Path(capture.__file__)))
def save():(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
expression=r'''(() => [...document.querySelectorAll('body>div, body>div div')].map(n=>{const b=n.getBoundingClientRect(),s=getComputedStyle(n);return {class:n.className,text:n.textContent,bounds:{x:b.x,y:b.y,width:b.width,height:b.height},style:{width:s.width,height:s.height,borderTopWidth:s.borderTopWidth,borderRightWidth:s.borderRightWidth,borderBottomWidth:s.borderBottomWidth,borderLeftWidth:s.borderLeftWidth,writingMode:s.writingMode,fontSize:s.fontSize}}}))()'''
save()
try:
    for p in summary['profiles']:
        WIDTH,HEIGHT=p['logical_size_css_px'];directory=OUT/p['profile'];directory.mkdir()
        test_id='wpt/css_sizing/block-size-with-min-or-max-content-1-ref'
        page=summary_path.parent/p['profile']/test_id/'test.html';input_sha=sha(page)
        row=next(r for r in p['tests'] if r['id']==test_id);queries=[]
        for repeat in [1,2]:
            picture=directory/(str(repeat)+'.png')
            query=observe(page,picture,expression,p['device_scale'])
            (directory/(str(repeat)+'-geometry.json')).write_text(json.dumps(query,sort_keys=True,indent=2)+'\n')
            queries.append(query)
        assert queries[0]==queries[1] and sha(directory/'1.png')==sha(directory/'2.png')
        assert input_sha==sha(page)
        report['profiles'].append(dict(profile=p['profile'],scale=p['device_scale'],viewport=[WIDTH,HEIGHT],
            observations=queries[0],input_sha256=input_sha,png_sha256=sha(directory/'1.png'),
            repeated_geometry_and_images_equal=True,immutable_oracle_png_sha256=row['chromium_png_sha256'],
            png_matches_immutable_oracle=sha(directory/'1.png')==row['chromium_png_sha256']))
        save()
    report['observed_exit_code']=0
except BaseException as error:
    report.update(observed_exit_code=1,failure=str(error));raise
finally:
    report.update(all_commands_terminal=True,source_after=repository_source_identity(SDK),public_source_after=repository_source_identity(MAIN))
    report['source_unchanged']=report['source_after']==source;report['public_source_unchanged']=report['public_source_after']==public;save()
print(json.dumps([dict(profile=p['profile'],png_matches_oracle=p['png_matches_immutable_oracle'],observations=p['observations']) for p in report['profiles']]))
