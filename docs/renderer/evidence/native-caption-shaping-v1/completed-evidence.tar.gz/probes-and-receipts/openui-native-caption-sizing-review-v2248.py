"""Review rejected caption/shaping evidence without changing renderer bytes."""
import hashlib,json,re,subprocess
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1'
OUT=RAW/'native-caption-sizing-review-v2248.json';assert not OUT.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_bytes())
whole=load(RAW/'native-caption-metric-pipeline-v2237/receipt.json')
fragments=load(RAW/'native-shaped-sizing-fragments-v2244/receipt.json')
chrome=load(RAW/'native-sizing-chromium-geometry-v2247/receipt.json')
assert whole['all_commands_terminal'] and whole['observed_exit_code']==1 and whole['source_unchanged']
assert chrome['all_commands_terminal'] and chrome['observed_exit_code']==0 and chrome['source_unchanged']
assert subprocess.run(['ps','-p',str(whole['owner_pid'])],capture_output=True).returncode!=0
matrix_path=RAW/'native-caption-metric-pipeline-v2237/sizing-caption-neighbors-matrix/full-summary.json'
matrix=load(matrix_path)
nodes=[2,3,8,12,13,17];geometry=[]
pattern=re.compile(r'^(\s*)frag:.*?left: LayoutUnit\(.*?raw=(-?\d+)\]\), top: LayoutUnit\(.*?raw=(-?\d+)\]\).*?width: LayoutUnit\(.*?raw=(-?\d+)\]\), height: LayoutUnit\(.*?raw=(-?\d+)\]\).*?kind=(\w+) node=NodeId\((\d+)\)')
for row in fragments['rows']:
    if 'css_sizing' not in row['test_id']:continue
    oracle=next(p for p in chrome['profiles'] if p['profile']==row['profile'])
    assert oracle['repeated_geometry_and_images_equal'] and oracle['png_matches_immutable_oracle']
    assert len(oracle['observations'])==len(nodes)
    native={}
    for label in row['dumps']:
        path=RAW/'native-shaped-sizing-fragments-v2244'/(row['test_id'].rsplit('/',1)[-1]+'-'+row['profile']+'-'+label+'.log')
        assert sha(path)==row['dumps'][label]['sha256']
        stack=[];rects={}
        for line in path.read_text().splitlines():
            match=pattern.match(line)
            if not match:continue
            indent=len(match[1]);x,y,w,h=map(int,match.groups()[1:5])
            while stack and stack[-1][0]>=indent:stack.pop()
            if stack:x+=stack[-1][1];y+=stack[-1][2]
            stack.append((indent,x,y));node=int(match[7])
            if node in nodes and match[6]=='Box':rects[node]=dict(zip(['x','y','width','height'],[v/64 for v in [x,y,w,h]]))
        assert len(rects)==len(nodes);native[label]=rects
    for node,expected in zip(nodes,oracle['observations']):
        geometry.append(dict(profile=row['profile'],node=node,chromium=expected['bounds'],
            parent=native['parent'][node],candidate=native['candidate'][node],
            parent_exact=native['parent'][node]==expected['bounds'],candidate_exact=native['candidate'][node]==expected['bounds']))
assert len(geometry)==24 and all(r['candidate_exact'] for r in geometry) and not any(r['parent_exact'] for r in geometry)
residuals=[];caption=[]
parent_full=load(RAW/'native-relative-percent-pipeline-v2204/full-matrix/full-summary.json')
before={(p['profile'],r['id']):r for p in parent_full['profiles'] for r in p['tests']}
for profile in matrix['profiles']:
    for row in profile['tests']:
        if 'css_multicol' in row['id']:
            old=before[(profile['profile'],row['id'])]
            caption.append(dict(profile=profile['profile'],id=row['id'],prior_status=old['status'],status=row['status'],
                prior_mismatched_pixels=old['mismatched_pixels'],mismatched_pixels=row['mismatched_pixels'],
                exact_gain=old['status']!='exact' and row['status']=='exact'))
        if 'css_sizing' in row['id'] and row['status']!='exact':
            residuals.append(dict(profile=profile['profile'],id=row['id'],logical_size_css_px=profile['logical_size_css_px'],
                device_scale=profile['device_scale'],mismatched_pixels=row['mismatched_pixels'],diff_signature=row['diff_signature'],
                owner='text/paint',root_cause='glyph-strike-origin',reviewed_scope='Exact box geometry now agrees with repeated Chromium; extra black glyph cells remain at fractional scales.',
                precise_glyph_mask_or_origin_cause_resolved=False,reduced_native_glyph_reproducer_still_required=True))
assert len(residuals)==6 and sum(r['exact_gain'] for r in caption)==2
report=dict(schema_version=1,all_commands_terminal=True,observed_exit_code=0,source=whole['source'],
    candidate_applied_to_umbrella=False,promotion_allowed=False,release_qualification=False,
    whole_pipeline_observed_exit_code=1,full_expanded_focused_primitive_not_run_on_this_source=True,
    source_unchanged=True,pixel_tolerance=0,javascript_executed_by_openui=False,
    geometry=dict(states=24,parent_exact=0,candidate_exact=24,rows=geometry),caption_comparisons=caption,
    caption_regressions_from_parent_repaired=2,accepted_renderer_exact_gains=0,accepted_renderer_exact_losses=0,
    worsened_comparisons=len(residuals),residuals=residuals,
    layout_precision_must_not_be_added_back_to_hide_raster_differences=True,
    formal_accepted_ownership_ledger_unchanged=True,native_vertical_ch_fix_not_implemented=True,
    primary_missing_glyph_ch_feature_is_stable_in_pinned_chromium=True,
    runtime_missing_glyph_parity_not_qualified=True,
    evidence_receipt_sha256={name:sha(RAW/name/'receipt.json') for name in [
      'native-caption-metric-pipeline-v2237','native-shaped-sizing-fragments-v2244','native-sizing-chromium-geometry-v2245',
      'native-sizing-chromium-geometry-v2246','native-sizing-chromium-geometry-v2247','native-vertical-fallback-primary-v2240',
      'native-vertical-metric-primary-v2242','native-vertical-metric-primary-v2243']},
    probe_sha256=sha(Path(__file__)))
OUT.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(review_sha256=sha(OUT),geometry=24,caption_regressions_repaired=2,worsened_comparisons=6)))
