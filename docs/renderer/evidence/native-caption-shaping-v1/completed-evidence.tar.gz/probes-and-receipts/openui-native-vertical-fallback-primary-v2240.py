"""Preserve pinned Chromium source for vertical metric/fallback review."""
import base64
import concurrent.futures
import hashlib
import json
import subprocess
import urllib.request
from pathlib import Path

MAIN = Path('/home/nero/code/open-ui')
OUT = MAIN / 'out/renderer-evidence/native-viewport-scroll-v1/native-vertical-fallback-primary-v2240'
assert not OUT.exists()
OUT.mkdir()
before = subprocess.check_output(['git', 'status', '--porcelain'], cwd=MAIN)
assert not before
files = {
    'runtime_enabled_features.json5': 'third_party/blink/renderer/platform/runtime_enabled_features.json5',
    'harfbuzz_face.cc': 'third_party/blink/renderer/platform/fonts/shaping/harfbuzz_face.cc',
    'font_orientation.h': 'third_party/blink/renderer/platform/fonts/font_orientation.h',
}

def fetch(item):
    name, path = item
    url = 'https://chromium.googlesource.com/chromium/src/+/147.0.7727.50/' + path + '?format=TEXT'
    with urllib.request.urlopen(url, timeout=30) as response:
        content = base64.b64decode(response.read(), validate=True)
    (OUT / name).write_bytes(content)
    return dict(name=name, url=url, bytes=len(content), sha256=hashlib.sha256(content).hexdigest())

with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    rows = list(pool.map(fetch, files.items()))
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=MAIN) == before
report = dict(schema_version=1, files=rows, all_commands_terminal=True,
              source_changed=False, native_commands_run=0, chromium_commands_run=0,
              web_tool_could_not_open_primary_pages=True,
              release_qualification=False, primary_review_only=True,
              probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(OUT / 'receipt.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
print(json.dumps(report))
