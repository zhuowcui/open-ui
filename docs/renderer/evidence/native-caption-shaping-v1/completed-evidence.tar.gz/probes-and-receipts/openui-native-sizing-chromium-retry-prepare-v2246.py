"""Preserve a failed capture and prepare explicit process-group cleanup."""
import hashlib,json
from pathlib import Path
old=Path('/tmp/openui-native-sizing-chromium-geometry-v2245.py')
new=Path('/tmp/openui-native-sizing-chromium-geometry-v2246.py')
assert not new.exists()
s=old.read_text().replace('native-sizing-chromium-geometry-v2245','native-sizing-chromium-geometry-v2246')
s=s.replace('import ast,fcntl,hashlib,json,os,shutil,subprocess,sys','import ast,fcntl,hashlib,json,os,shutil,subprocess,sys,signal,time')
before="exec(compile(code,str(helper), 'exec'))"
after="""# The old wrapper stops only Chromium's parent. Stop its complete owned
# process group before deleting the profile, including after parent exit.
code=code.replace(\"kwargs['stderr'] = stream\", \"kwargs['stderr'] = stream\\n            kwargs['start_new_session'] = True\")
code=code.replace(\"process.terminate()\", \"os.killpg(process.pid, signal.SIGTERM)\")
code=code.replace(\"process.kill()\", \"os.killpg(process.pid, signal.SIGKILL)\")
marker=\"cleanup_events.append(dict(pid=process.pid, actual_exit=process.poll(), stopped_before_profile_removal=True))\"
assert code.count(marker)==1
replacement='''try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            # Wait for group members to stop; zombies cannot write profiles.
            deadline=time.monotonic()+10
            while True:
                alive=[]
                for entry in Path('/proc').iterdir():
                    if not entry.name.isdecimal(): continue
                    try:
                        fields=(entry/'stat').read_text().rsplit(')',1)[1].split()
                        if int(fields[2])==process.pid and fields[0]!='Z': alive.append(int(entry.name))
                    except (OSError,ValueError): pass
                if not alive: break
                assert time.monotonic()<deadline, alive
                time.sleep(.01)
            cleanup_events.append(dict(pid=process.pid, actual_exit=process.poll(), stopped_before_profile_removal=True, process_group_stopped=True))'''
code=code.replace(marker,replacement)
used=OUT/'used-observe.py';used.write_text(code+'\\n')
exec(compile(code,str(used), 'exec'))"""
assert s.count(before)==1;s=s.replace(before,after)
s=s.replace("helper_sha256=sha(helper),probe_sha256", "process_group_cleanup=True,failed_previous_capture_receipt_sha256=sha(RAW/'native-sizing-chromium-geometry-v2245/receipt.json'),used_helper_sha256=sha(used),helper_sha256=sha(helper),probe_sha256")
new.write_text(s)
compile(s,str(new),'exec')
print(json.dumps(dict(new_probe=str(new),sha256=hashlib.sha256(new.read_bytes()).hexdigest(),source_changed=False,commands_started=0)))
