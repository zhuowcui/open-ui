"""Compare complete source-identified sizing/caption fragments after rejection."""
import fcntl,hashlib,json,os,re,subprocess,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1'
OUT=RAW/'native-shaped-sizing-fragments-v2244'
STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/OUT.name
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
previous=json.loads((RAW/'native-caption-metric-pipeline-v2237/receipt.json').read_bytes())
assert previous['all_commands_terminal'] and previous['observed_exit_code']==1
assert subprocess.run(['ps','-p',str(previous['owner_pid'])],capture_output=True).returncode!=0
assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
sys.path.insert(0,str(MAIN/'tools/qualification'))
from renderer_source_identity import repository_source_identity
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
roots={'parent':MAIN/'out/private-native-relative-api-v2202','candidate':MAIN/'out/private-native-caption-metrics-v2234'}
binaries={'parent':MAIN/'out/renderer-evidence/native-pixel-binary-stage-v2205/pixel_compare','candidate':MAIN/'out/renderer-evidence/native-pixel-binary-stage-v2238/pixel_compare'}
sources={k:repository_source_identity(p) for k,p in roots.items()}
assert all(s['clean'] for s in sources.values())
public=repository_source_identity(MAIN)
for k,binary in binaries.items():
    identity=json.loads(subprocess.check_output([str(binary),'build-source-identity'],cwd=roots[k]))
    assert identity['source']==sources[k]
hashes={k:sha(p) for k,p in binaries.items()}
summary=json.loads((RAW/'native-caption-metric-pipeline-v2237/sizing-caption-neighbors-matrix/full-summary.json').read_bytes())
records=[]
test_ids=['wpt/css_sizing/block-size-with-min-or-max-content-1-ref','wpt/css_multicol/multicol-span-all-004']
pattern=re.compile(r'frag:.*?left: LayoutUnit\(.*?raw=(-?\d+)\]\), top: LayoutUnit\(.*?raw=(-?\d+)\]\).*?width: LayoutUnit\(.*?raw=(-?\d+)\]\), height: LayoutUnit\(.*?raw=(-?\d+)\]\).*?kind=(\w+) node=NodeId\((\d+)\) baseline=([^ ]+)')
for test_id in test_ids:
    for profile in summary['profiles']:
        dumps={}
        for label,binary in binaries.items():
            path=OUT/(test_id.rsplit('/',1)[-1]+'-'+profile['profile']+'-'+label+'.log')
            command=[str(binary),'debug',test_id,'--viewport','x'.join(map(str,profile['logical_size_css_px'])),
                     '--scale',str(profile['device_scale']),'--raster-config','deterministic-alias','--backend','cpu-skia']
            with path.open('xb') as stream:
                process=subprocess.run(command,cwd=roots[label],stdout=stream,stderr=subprocess.STDOUT)
            assert process.returncode==0
            rows=[]
            for match in pattern.finditer(path.read_text()):
                rows.append(dict(rect_raw=list(map(int,match.groups()[:4])),kind=match[5],node=int(match[6]),baseline=float(match[7])))
            assert rows
            dumps[label]=dict(command=command,observed_exit_code=process.returncode,sha256=sha(path),fragments=rows)
        before=dumps['parent']['fragments'];after=dumps['candidate']['fragments'];assert len(before)==len(after)
        changes=[dict(index=i,before=a,after=b) for i,(a,b) in enumerate(zip(before,after)) if a!=b]
        records.append(dict(test_id=test_id,profile=profile['profile'],device_scale=profile['device_scale'],
                            viewport=profile['logical_size_css_px'],dumps=dumps,changed_fragments=changes))
assert sources=={k:repository_source_identity(p) for k,p in roots.items()}
assert hashes=={k:sha(p) for k,p in binaries.items()}
assert repository_source_identity(MAIN)==public
report=dict(schema_version=1,all_commands_terminal=True,observed_exit_code=0,source_unchanged=True,
            public_source=public,sources=sources,binary_sha256=hashes,rows=records,release_qualification=False,
            diagnostic_only=True,complete_matrices_not_rerun=True,native_or_chromium_pixels_captured=False,
            no_javascript_executed_by_openui=True,probe_sha256=sha(Path(__file__)))
(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps([dict(test_id=r['test_id'],profile=r['profile'],changed_fragments=r['changed_fragments']) for r in records]))
