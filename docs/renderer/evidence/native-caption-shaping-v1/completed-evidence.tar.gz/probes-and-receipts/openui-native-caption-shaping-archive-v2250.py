"""Archive the rejected shared caption/shaping correction and completed diagnosis."""
import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1'
INDEX=MAIN/'docs/renderer/generated/native-caption-shaping-v1.json'
ARCHIVE=MAIN/'docs/renderer/evidence/native-caption-shaping-v1/completed-evidence.tar.gz'
assert not INDEX.exists() and not ARCHIVE.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_bytes())
whole=load(RAW/'native-caption-metric-pipeline-v2237/receipt.json')
review=load(RAW/'native-caption-sizing-review-v2248.json')
checks=load(RAW/'native-caption-metric-checks-v2239/receipt.json')
repro=load(RAW/'native-caption-source-repro-v2249/receipt.json')
chrome=load(RAW/'native-sizing-chromium-geometry-v2247/receipt.json')
assert whole['all_commands_terminal'] and whole['observed_exit_code']==1 and whole['source_unchanged'] and whole['public_source_unchanged']
assert whole['native_app_source_unchanged'] and whole['tracked_diagnostic_png_unchanged']
assert subprocess.run(['ps','-p',str(whole['owner_pid'])],capture_output=True).returncode!=0
assert checks['source']==whole['source'] and checks['all_commands_terminal'] and len(checks['checks'])==18
assert all(c['observed_exit_code']==0 for c in checks['checks'])
assert repro['entire_tracked_tree_exact'] and repro['source_unchanged'] and repro['public_source_unchanged']
assert chrome['all_commands_terminal'] and chrome['observed_exit_code']==0 and len(chrome['profiles'])==4
assert all(p['png_matches_immutable_oracle'] and p['repeated_geometry_and_images_equal'] for p in chrome['profiles'])
inputs={}
def add(path,name):
    assert path.is_file() and name not in inputs;inputs[name]=path
def direct(directory,prefix):
    for path in sorted(directory.iterdir()):
        if path.is_file() and path.suffix in ['.json','.log','.patch','.rs','.cc','.h','.py','.json5']:
            add(path,prefix+'/'+path.name)
for name in ['native-caption-metric-pipeline-v2237','native-caption-metric-checks-v2239',
             'native-shaped-sizing-fragments-v2244','native-caption-source-repro-v2249']:
    direct(RAW/name,'records/'+name)
for name in ['native-sizing-chromium-geometry-v2245','native-sizing-chromium-geometry-v2246','native-sizing-chromium-geometry-v2247']:
    for path in sorted((RAW/name).rglob('*')):
        if path.is_file() and path.suffix in ['.json','.log','.html','.png','.py']:
            add(path,'chromium-geometry/'+name+'/'+str(path.relative_to(RAW/name)))
for name in ['native-vertical-fallback-primary-v2240','native-vertical-metric-primary-v2242','native-vertical-metric-primary-v2243']:
    direct(RAW/name,'primary-source/'+name)
matrix=RAW/'native-caption-metric-pipeline-v2237/sizing-caption-neighbors-matrix'
for path in sorted(matrix.rglob('*')):
    if path.is_file() and path.suffix in ['.json','.png','.html']:
        add(path,'sizing-caption-neighbors/'+str(path.relative_to(matrix)))
add(RAW/'native-caption-sizing-review-v2248.json','review/native-caption-sizing-review-v2248.json')
for relative in ['Cargo.toml','Cargo.lock','src/main.rs']:
    add(MAIN/'out/private-native-apps/native-relative-caption-v2235'/relative,'native-app/'+relative)
root=MAIN/'out/private-native-caption-metrics-v2234'
for relative in repro['production_changes']:
    add(root/relative,'source/'+relative)
for pattern in ['openui-native-caption-metrics-prepare-v2234.*','openui-native-caption-metrics-v2234.patch',
    'openui-native-caption-metric-pipeline-v2237.py','openui-native-caption-metric-checks-v2239.py',
    'openui-terminal-evidence-relocation-v2236.*','openui-terminal-evidence-relocation-v2241.*',
    'openui-native-vertical-fallback-primary-v2240.py','openui-native-vertical-metric-primary-v2242.py',
    'openui-native-vertical-metric-primary-v2243.py','openui-native-shaped-sizing-fragments-v2244.py',
    'openui-native-sizing-chromium-geometry-v2245.py','openui-native-sizing-chromium-retry-prepare-v2246.py',
    'openui-native-sizing-chromium-geometry-v2246.py','openui-native-sizing-chromium-geometry-v2247.py',
    'openui-native-sizing-chromium-helper-v2247.py','openui-native-caption-sizing-review-v2248.py',
    'openui-native-caption-source-repro-v2249.py']:
    matches=list(Path('/tmp').glob(pattern));assert matches,pattern
    for path in matches:add(path,'probes-and-receipts/'+path.name)
add(Path(__file__),'probes-and-receipts/'+Path(__file__).name)
add(RAW/'native-relative-units-pipeline-v2189/receipt.json','baseline/unchanged-horizontal-chromium-geometry-receipt.json')
ARCHIVE.parent.mkdir(parents=True);members=[]
with ARCHIVE.open('xb') as output:
    with gzip.GzipFile(filename='',mode='wb',fileobj=output,mtime=0,compresslevel=6) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as tar:
            for name,path in sorted(inputs.items()):
                content=path.read_bytes();info=tarfile.TarInfo(name);info.size=len(content);info.mode=0o644;info.mtime=0
                tar.addfile(info,io.BytesIO(content));members.append(dict(name=name,source_path=str(path),bytes=len(content),sha256=hashlib.sha256(content).hexdigest()))
with tarfile.open(ARCHIVE,'r:gz') as tar:
    assert [m.name for m in tar.getmembers()]==[m['name'] for m in members]
    for row in members:
        content=tar.extractfile(row['name']).read()
        assert len(content)==row['bytes'] and hashlib.sha256(content).hexdigest()==row['sha256']==sha(inputs[row['name']])
report=dict(schema_version=1,source=whole['source'],source_after=whole['source_after'],source_unchanged=True,
    public_source_at_trial=whole['public_source'],all_commands_terminal=True,candidate_applied_to_umbrella=False,
    whole_owner_actual_exit=1,stages=whole['steps'],matrices=whole['matrices'],native_geometry=whole['native_geometry'],
    native_callbacks_per_run=whole['native_callbacks_per_run'],native_outputs_repeat_byte_identically=True,
    native_pixels_captured=False,native_guards_actually_executed_and_passed=True,
    native_and_strict_rgba_guards_actually_executed_in_workspace=True,read_only_checks=checks['checks'],read_only_checks_passed=18,
    complete_pixel_matrices_executed=False,pixel_no_regression_gate_passed=False,
    caption_regressions_from_parent_repaired=2,worsened_sizing_comparisons=6,
    repeated_sizing_geometry=dict(states=24,parent_exact=0,candidate_exact=24),
    fresh_chromium_images_match_immutable_oracle_all_four_profiles=True,review=review,
    entire_tracked_tree_reconstructs_exactly=True,source_patch_sha256=repro['patch_sha256'],
    production_patch_sha256=repro['production_patch_sha256'],private_fontations_or_positioned_intrinsic_changes_included=False,
    failed_capture_and_preparation_attempts_preserved=True,layout_precision_must_not_be_added_back_to_hide_raster_differences=True,
    no_javascript_executed_by_openui=True,pixel_tolerance=0,new_release_states_admitted=0,
    manual_helper_does_not_complete_reactive_native_unit_declarations=True,native_vertical_ch_fix_not_implemented=True,
    formal_accepted_ownership_ledger_unchanged=True,release_qualification=False,promotion_allowed=False,
    archive=dict(path=str(ARCHIVE.relative_to(MAIN)),bytes=ARCHIVE.stat().st_size,sha256=sha(ARCHIVE),all_members_hash_verified=True,members=members),
    probe_sha256=sha(Path(__file__)))
INDEX.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(index=str(INDEX),index_sha256=sha(INDEX),archive_bytes=ARCHIVE.stat().st_size,archive_members=len(members))))
