"""Relocate an unused historical binary; leave the live qualifier untouched."""
import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui')
ORIGINAL=MAIN/'out/renderer-evidence/real-font-hinting-investigation/pixel_compare-baseline-15f9f12d'
DEST=Path('/mnt/e/openui-v02-qualification-d174ea0b/terminal-evidence-relocated-v2241')
RECEIPT=Path('/tmp/openui-terminal-evidence-relocation-v2241.json')
OWNER=Path('/proc/570723')
sys.path.insert(0,str(MAIN/'tools/qualification'))
from renderer_source_identity import repository_source_identity
source=repository_source_identity(MAIN)
assert source['clean'] and not DEST.exists() and not RECEIPT.exists()
assert ORIGINAL.is_file() and not ORIGINAL.is_symlink() and ORIGINAL.stat().st_nlink==1
owner_cmd=(OWNER/'cmdline').read_bytes()
assert b'openui-native-caption-metric-pipeline-v2237.py' in owner_cmd

def unused():
    checked=0
    for entry in Path('/proc').iterdir():
        if not entry.name.isdecimal():continue
        try:
            assert (entry/'exe').resolve(strict=True)!=ORIGINAL
            assert str(ORIGINAL).encode() not in (entry/'cmdline').read_bytes()
            for descriptor in (entry/'fd').iterdir():
                try:assert descriptor.resolve(strict=True)!=ORIGINAL
                except (OSError,RuntimeError):pass
            checked+=1
        except (OSError,RuntimeError):pass
    return checked

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(2**20),b''):h.update(block)
    return h.hexdigest()

checked=unused()
DEST.mkdir();target=DEST/ORIGINAL.name
digest=sha(ORIGINAL);size=ORIGINAL.stat().st_size;before=shutil.disk_usage(MAIN).free
shutil.copy2(ORIGINAL,target)
assert sha(target)==digest==sha(ORIGINAL)
unused()
backup=ORIGINAL.with_name(ORIGINAL.name+'.verified-relocation-v2241')
assert not backup.exists()
ORIGINAL.rename(backup);ORIGINAL.symlink_to(target)
assert sha(ORIGINAL)==digest==sha(backup)
backup.unlink()
assert repository_source_identity(MAIN)==source
assert (OWNER/'cmdline').read_bytes()==owner_cmd
r=dict(source_before=source,source_after=source,source_unchanged=True,
       all_commands_terminal=True,original_path=str(ORIGINAL),target=str(target),
       bytes=size,original_sha256=digest,copied_sha256=sha(target),final_path_sha256=sha(ORIGINAL),
       unused_original_processes_checked=checked,live_pipeline_pid=570723,
       live_pipeline_command_unchanged=True,live_pipeline_binary_not_relocated=True,
       home_free_before=before,home_free_after=shutil.disk_usage(MAIN).free,
       reference_bytes_changed=0,release_qualification=False,probe_sha256=sha(Path(__file__)))
RECEIPT.write_text(json.dumps(r,sort_keys=True,indent=2)+'\n');print(json.dumps(r))
