"""Prepare shared intrinsic shaping and caption wrapper correction without fixture changes."""
import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');BASE=MAIN/'out/private-native-relative-api-v2202';ROOT=MAIN/'out/private-native-caption-metrics-v2234';APP=MAIN/'out/private-native-apps/native-relative-caption-v2235';OLDAPP=MAIN/'out/private-native-apps/native-relative-units-v2203'
OUT=Path('/tmp/openui-native-caption-metrics-prepare-v2234.json');assert not ROOT.exists() and not APP.exists() and not OUT.exists()
sys.path.insert(0,str(MAIN/'tools/qualification'));from renderer_source_identity import repository_source_identity
before=repository_source_identity(BASE);public=repository_source_identity(MAIN);assert before['clean'] and before['commit']=='4046d366eab0a9fc6aa161dc63d8e646104eab84' and public['clean']
subprocess.run(['git','clone','--shared','--no-checkout',str(BASE),str(ROOT)],check=True,capture_output=True)
for key in ['user.name','user.email']:
 value=subprocess.check_output(['git','config','--get',key],cwd=MAIN,text=True).strip();subprocess.run(['git','config',key,value],cwd=ROOT,check=True)
subprocess.run(['git','read-tree',before['commit']],cwd=ROOT,check=True)
for name in filter(None,subprocess.check_output(['git','ls-files','-z'],cwd=BASE).decode().split('\0')):
 src=BASE/name;dst=ROOT/name;dst.parent.mkdir(parents=True,exist_ok=True)
 if src.is_symlink():dst.symlink_to(os.readlink(src))
 else:os.link(src,dst)
assert repository_source_identity(ROOT)==before
for name in ['bindings/rust/openui-layout/src/intrinsic_sizing.rs','bindings/rust/openui-layout/src/table.rs']:
 p=ROOT/name;t=p.with_name(p.name+'.owned-v2234');shutil.copy2(p,t);os.replace(t,p)
subprocess.run(['git','update-index','--refresh'],cwd=ROOT,check=True)
subprocess.run(['git','apply','--index','/tmp/openui-native-intrinsic-shaped-change-v2170.patch'],cwd=ROOT,check=True)
p=ROOT/'bindings/rust/openui-layout/src/table.rs';s=p.read_text()
old='''        // A caption-only table uses CAPMIN plus the table grid's structural
        // edge spacing. Populated auto tables keep their grid preferred width,
        // with CAPMIN acting only as a floor; the caption's max-content width
        // does not stretch the table to the available column measure.
        let caption_floor = if column_count == 0 {
            caption_min_outer_width + grid_border_box_width
        } else {
            caption_min_outer_width
        };
        grid_border_box_width.max_of(caption_floor)'''
new='''        // The caption and grid constrain the same wrapper width. CAPMIN
        // is a floor alongside the grid border box; adding grid spacing to
        // the caption double-counts that contribution when no cells exist.
        // Caption max-content does not stretch an auto table to its column.
        grid_border_box_width.max_of(caption_min_outer_width)'''
assert s.count(old)==1;p.write_text(s.replace(old,new))
p=ROOT/'bindings/rust/openui/tests/native_table_caption.rs';assert not p.exists();shutil.copy2(Path('/dev/shm/openui-native-caption-v2034/bindings/rust/openui/tests/native_table_caption.rs'),p)
subprocess.run(['bash','-c','ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true bindings/rust/openui-layout/src/intrinsic_sizing.rs bindings/rust/openui-layout/src/table.rs bindings/rust/openui/tests/native_table_caption.rs'],cwd=ROOT,check=True)
subprocess.run(['git','add','bindings/rust/openui-layout/src/intrinsic_sizing.rs','bindings/rust/openui-layout/src/table.rs','bindings/rust/openui/tests/native_table_caption.rs'],cwd=ROOT,check=True)
patch=Path('/tmp/openui-native-caption-metrics-v2234.patch');assert not patch.exists();patch.write_bytes(subprocess.check_output(['git','diff','--cached','--binary','--full-index'],cwd=ROOT))
subprocess.run(['git','commit','-m','Measure shared intrinsic text through shaping and separate caption wrapper floors'],cwd=ROOT,check=True,capture_output=True)
source=repository_source_identity(ROOT);assert source['clean'] and repository_source_identity(BASE)==before and repository_source_identity(MAIN)==public
APP.mkdir()
for name in ['Cargo.toml','Cargo.lock','src/main.rs']:
 p=APP/name;p.parent.mkdir(parents=True,exist_ok=True);content=(OLDAPP/name).read_bytes()
 if name=='Cargo.toml':content=content.replace(str(BASE).encode(),str(ROOT).encode())
 p.write_bytes(content)
subprocess.run(['git','init','-q'],cwd=APP,check=True)
for key in ['user.name','user.email']:
 value=subprocess.check_output(['git','config','--get',key],cwd=MAIN,text=True).strip();subprocess.run(['git','config',key,value],cwd=APP,check=True)
subprocess.run(['git','add','.'],cwd=APP,check=True);subprocess.run(['git','commit','-q','-m','Prepare identical native font-unit consumer against shared intrinsic correction'],cwd=APP,check=True)
report=dict(source=source,parent_source=before,public_source=public,root=str(ROOT),app_root=str(APP),all_commands_terminal=True,source_only_preparation=True,cargo_commands_run=0,native_commands_run=0,chromium_commands_run=0,source_patch=str(patch),source_patch_sha256=hashlib.sha256(patch.read_bytes()).hexdigest(),private_fontations_factory_and_positioned_intrinsic_changes_included=False,shared_intrinsic_shaping_and_caption_floors_changed=True,near_grid_normalizer_removed=True,release_qualification=False,promotion_allowed=False,javascript_executed_by_openui=False,probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
OUT.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(report))
