use openui::prelude::*;
use openui_geometry::{LayoutUnit, TextEdging, TextHinting, TextRasterConfiguration};
use openui_text::{Font, FontDescription, TextDirection, TextShaper};
use serde_json::json;
use std::error::Error;

fn main() -> Result<(), Box<dyn Error>> {
    let collection = FontCollection::deterministic_test();
    let shaper = TextShaper::new();
    for family in ["Ahem", "DejaVu Sans", "DejaVu Serif", "DejaVu Sans Mono"] {
        for size in [10.0, 12.0, 16.0, 20.0, 24.0] {
            for scale in [1.0, 1.25, 1.5, 2.0, 3.0] {
                let mut ft_auto_alias = RasterConfiguration::deterministic_aliased(false);
                ft_auto_alias.author_text = TextRasterConfiguration::chromium_linux_platform();
                ft_auto_alias.author_text.edging = TextEdging::Alias;
                let mut fnta_auto_alias = RasterConfiguration::chromium_linux_fontations_lcd();
                fnta_auto_alias.author_text.edging = TextEdging::Alias;
                let mut ft_fixed_full = RasterConfiguration::deterministic_aliased(false);
                ft_fixed_full.author_text.hinting = TextHinting::Full;
                for (policy, raster) in [
                    (
                        "fontations-lcd",
                        RasterConfiguration::chromium_linux_fontations_lcd(),
                    ),
                    ("freetype-lcd", RasterConfiguration::chromium_linux_lcd()),
                    (
                        "freetype-alias",
                        RasterConfiguration::deterministic_aliased(false),
                    ),
                    (
                        "freetype-alias-subpixel",
                        RasterConfiguration::deterministic_aliased(true),
                    ),
                    ("freetype-auto-alias", ft_auto_alias),
                    ("fontations-auto-alias", fnta_auto_alias),
                    ("freetype-full-alias", ft_fixed_full),
                ] {
                    let document = Document::with_font_collection_and_options(
                        ViewportMetrics::from_logical_size(800.0, 600.0, scale)?,
                        collection.clone(),
                        EngineOptions {
                            raster_configuration: raster,
                        },
                    )?;
                    let root = document.body();
                    let element = Element::create(&document, "div")?;
                    element.set_position(Position::Absolute)?;
                    element.set_left(Length::px(20.0))?;
                    element.set_top(Length::px(20.0))?;
                    element.set_font_family(FontFamilyList::single(family.to_string()))?;
                    element.set_font_size(LengthValue::px(size))?;
                    element.set_line_height(LineHeight::Number(1.0))?;
                    root.append_child(&element)?;
                    let mut desc = FontDescription::new();
                    desc.family = FontFamilyList::single(family.to_string());
                    desc.size = size;
                    desc.specified_size = size;
                    desc.device_scale_factor = scale;
                    desc.raster_configuration = raster;
                    let font = Font::new_in_collection(desc, collection.clone());
                    let data = font.primary_font().ok_or("resolved font required")?;
                    let sk_font = data.sk_font();
                    for text in ["X", "XX", "XXXXXXXXXXXXX"] {
                        element.set_text(text)?;
                        let bounds = element.bounding_rect()?.ok_or("natural bounds required")?;
                        let shape = shaper.shape(text, &font, TextDirection::Ltr);
                        let raw = font.width(text);
                        println!(
                            "{}",
                            json!({
                                "policy":policy, "family":family, "size":size, "scale":scale, "text":text,
                                "raw_width":raw, "raw_width_bits":raw.to_bits(),
                                "shaped_width":shape.width, "shaped_width_bits":shape.width.to_bits(),
                                "ceil_shaped_width":LayoutUnit::from_f32_ceil(shape.width).to_f32(),
                                "nearest_shaped_width":LayoutUnit::from_f32_round(shape.width).to_f32(),
                                "native_bounds":{"x":bounds.x,"y":bounds.y,"width":bounds.width,"height":bounds.height},
                                "hinting":format!("{:?}",sk_font.hinting()), "edging":format!("{:?}",sk_font.edging()),
                                "subpixel":sk_font.is_subpixel(), "linear_metrics":sk_font.is_linear_metrics(),
                            })
                        );
                    }
                }
            }
        }
    }
    Ok(())
}
