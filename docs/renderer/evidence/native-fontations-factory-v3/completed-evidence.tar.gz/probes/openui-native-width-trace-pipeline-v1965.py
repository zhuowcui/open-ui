import fcntl,hashlib,json,os,shutil,signal,subprocess,sys,time
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');SDK=Path('/dev/shm/openui-native-fontations-current-retry-v1946');ROOT=Path('/dev/shm/openui-native-width-trace-resolved-v1964');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';NAME='native-width-trace-pipeline-v1965'
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','ninja','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
OUT=RAW/NAME;STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/NAME;assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
TMP=STORE/'compiler-tmp';TMP.mkdir();env=dict(os.environ,CARGO_TARGET_DIR='/mnt/e/openui-v02-cargo-c73754e2/target',CARGO_INCREMENTAL='0',RUST_MIN_STACK='4194304',CARGO_BUILD_JOBS='4',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(TMP),CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
base=['cargo','--config',str(SDK/'bindings/rust/.cargo/config.chromium.toml')]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(2**20),b''):h.update(chunk)
 return h.hexdigest()
sys.path.insert(0,str(SDK/'tools/qualification'));from renderer_source_identity import repository_source_identity
sdk_source=repository_source_identity(SDK);assert sdk_source['clean'] and sdk_source['commit']=='9e4baa08e784b33365e03b807849dcb4804177a9'
report=dict(schema_version=1,sdk_source=sdk_source,all_commands_terminal=False,whole_pipeline_lock_covers_all_stages_and_gaps=True,owner_pid=os.getpid(),release_qualification=False,promotion_allowed=False,javascript_executed_by_openui=False,pixel_oracle_commands_run=0,steps=[],probe_sha256=sha(Path(__file__)))
save=lambda:(OUT/'receipt.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');save()
def identity():
 return dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=ROOT,text=True).strip(),clean=not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT))
def run(name,command):
 log=OUT/(name+'.log')
 with log.open('xb') as stream:
  child=subprocess.Popen(command,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True);report['current_process']=dict(pid=child.pid,stage=name);save();guard=False
  while child.poll() is None:
   if shutil.disk_usage(MAIN).free<512*2**20 or shutil.disk_usage(STORE).free<10*2**30:
    guard=True;os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=20);break
   time.sleep(1)
  child.wait()
 report.pop('current_process');row=dict(name=name,observed_exit_code=child.returncode,disk_guard_triggered=guard,log_sha256=sha(log));report['steps'].append(row);save();print(json.dumps(row),flush=True)
 assert not guard and child.returncode==0, name+' failed'
 if 'source' in report:assert identity()==report['source'],'diagnostic source changed'
try:
 run('format',['bash','-c','ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true src/main.rs'])
 shutil.copy2(SDK/'bindings/rust/Cargo.lock',ROOT/'Cargo.lock')
 run('resolve-lockfile',base+['metadata','--format-version','1'])
 subprocess.run(['git','add','.'],cwd=ROOT,check=True,capture_output=True);subprocess.run(['git','commit','-m','Trace native glyph advances and public natural element widths'],cwd=ROOT,check=True,capture_output=True)
 report['source']=identity();assert report['source']['clean'];report['lockfile_sha256']=sha(ROOT/'Cargo.lock');save()
 run('diagnostic-build',base+['build','--offline','--locked'])
 binary=OUT/'openui-native-width-trace';shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/openui-native-width-trace',binary);report['binary_sha256']=sha(binary);save()
 run('native-first',[str(binary)]);run('native-second',[str(binary)])
 first=OUT/'native-first.log';second=OUT/'native-second.log';assert first.read_bytes()==second.read_bytes()
 rows=[json.loads(line) for line in first.read_text().splitlines()];assert len(rows)==2100
 native=json.loads((RAW/'native-fontations-current-consumer-v1948/receipt.json').read_bytes());assert native['all_commands_terminal'] and native['source']==sdk_source
 refs={(r['family'],r['size'],r['scale'],i['state']):i['independent_reference_runs'][0]['query']['bounds'][0]['width'] for r in native['cases'] for i in r['images']}
 chosen=[r for r in rows if r['policy']=='fontations-lcd' and r['text'] in ['X','XX']]
 assert len(chosen)==200
 for r in chosen:
  r['chromium_width']=refs[(r['family'],r['size'],r['scale'],'before' if r['text']=='X' else 'after')]
  r['actual_width_exact']=r['native_bounds']['width']==r['chromium_width'];r['ceil_shaped_width_exact']=r['ceil_shaped_width']==r['chromium_width']
 report['observations']=chosen
 report['totals']=dict(native_rows=len(rows),repeated_native_output_identical=True,current_fontations_widths_exact=sum(r['actual_width_exact'] for r in chosen),ceil_shaped_fontations_widths_exact=sum(r['ceil_shaped_width_exact'] for r in chosen),chromium_widths=len(chosen))
 report['observed_exit_code']=0;save();print(json.dumps(report['totals']),flush=True)
except BaseException as error:
 report.update(observed_exit_code=1,failure=str(error));raise
finally:
 report['all_commands_terminal']=True;report['sdk_source_after']=repository_source_identity(SDK);report['sdk_source_unchanged']=report['sdk_source_after']==sdk_source
 if 'source' in report:report['source_after']=identity();report['source_unchanged']=report['source_after']==report['source']
 if not report['sdk_source_unchanged'] or report.get('source_unchanged') is False:report.update(observed_exit_code=1,failure='source changed during pipeline')
 save()
raise SystemExit(report['observed_exit_code'])
