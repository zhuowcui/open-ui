import fcntl,gzip,hashlib,json,os,re,shutil,signal,subprocess,sys,time
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');ROOT=Path('/dev/shm/openui-native-shaped-intrinsic-v1966');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';NAME='native-shaped-intrinsic-pipeline-v1968'
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for program in ['cargo','rustc','pixel_compare','ninja']:assert subprocess.run(['pgrep','-x',program],capture_output=True).returncode==1
OUT=RAW/NAME;STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/NAME;assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
TMP=STORE/'compiler-tmp';TMP.mkdir();env=dict(os.environ,OPENUI_NATIVE_WHOLE_OWNER=NAME,CARGO_TARGET_DIR='/mnt/e/openui-v02-cargo-c73754e2/target',CARGO_INCREMENTAL='0',RUST_MIN_STACK='4194304',CARGO_BUILD_JOBS='4',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(TMP),CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
base=['cargo','--config','.cargo/config.chromium.toml']
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(2**20),b''):h.update(chunk)
 return h.hexdigest()
report=dict(schema_version=1,all_commands_terminal=False,whole_pipeline_lock_covers_all_stages_and_gaps=True,owner_pid=os.getpid(),release_qualification=False,promotion_allowed=False,javascript_executed_by_openui=False,new_release_states_admitted=0,full_renderer_matrices_not_attempted=True,preserves_current_variable_font_instance_correction=True,steps=[],probe_sha256=sha(Path(__file__)))
save=lambda:(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');save()
sys.path.insert(0,str(ROOT/'tools/qualification'));from renderer_source_identity import repository_source_identity
source=None
def run(name,command,cwd=ROOT/'bindings/rust',require_zero=True):
 log=OUT/(name+'.log')
 with log.open('xb') as stream:
  child=subprocess.Popen(command,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True);report['current_process']=dict(pid=child.pid,stage=name);save();guard=False
  while child.poll() is None:
   if shutil.disk_usage(MAIN).free<512*2**20 or shutil.disk_usage(STORE).free<10*2**30:
    guard=True;os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=20);break
   time.sleep(1)
  child.wait()
 report.pop('current_process');totals=[tuple(map(int,m)) for m in re.findall(rb'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',log.read_bytes())]
 row=dict(name=name,observed_exit_code=child.returncode,disk_guard_triggered=guard,log_sha256=sha(log),passed=sum(x[0] for x in totals),failed=sum(x[1] for x in totals),ignored=sum(x[2] for x in totals));report['steps'].append(row);save();print(json.dumps(row),flush=True)
 assert not guard
 if source is not None:assert repository_source_identity(ROOT)==source,'source changed during a committed stage'
 if require_zero:assert child.returncode==0,name+' failed'
 return row
try:
 run('format',['bash','-c','ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true bindings/rust/openui-layout/src/intrinsic_sizing.rs'],cwd=ROOT)
 run('locked-metadata',base+['metadata','--offline','--locked','--no-deps','--format-version','1'])
 run('dependency-policy',[sys.executable,'tools/release/generate_v02_contract.py','--check'],cwd=ROOT)
 subprocess.run(['git','add','bindings/rust/openui-layout/src/intrinsic_sizing.rs'],cwd=ROOT,check=True,capture_output=True);subprocess.run(['git','commit','-m','Measure intrinsic text through shaping and retain positive grid fractions'],cwd=ROOT,check=True,capture_output=True)
 source=repository_source_identity(ROOT);assert source['clean'];report['source']=source;save()
 metadata=json.loads(subprocess.check_output(base+['metadata','--offline','--locked','--no-deps','--format-version','1'],cwd=ROOT/'bindings/rust',env=env));members=set(metadata['workspace_members']);packages=[p['name'] for p in metadata['packages'] if p['id'] in members];assert len(packages)==19
 run('clean-workspace',base+['clean','--locked']+[a for package in packages for a in ['-p',package]])
 run('text-and-layout-tests',base+['test','--offline','--locked','-p','openui-text','-p','openui-layout','--lib'])
 run('glyph-build',base+['build','--offline','--locked','-p','openui','--example','native_glyph_coverage'])
 binary=OUT/'native_glyph_coverage';shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/examples/native_glyph_coverage',binary);report['native_binary_sha256']=sha(binary);report['build_complete']=True;save()
 run('candidate-native',[sys.executable,'/tmp/openui-native-shaped-intrinsic-consumer-v1968.py'],cwd=MAIN)
 run('pixel-build',base+['build','--offline','--locked','-p','pixel-compare','--bin','pixel_compare'])
 pixel=OUT/'pixel_compare';shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/pixel_compare',pixel);report['pixel_binary_sha256']=sha(pixel);ident=json.loads(subprocess.check_output([str(pixel),'build-source-identity'],cwd=ROOT,env=env));assert ident['source']==source;report['build_identity']=ident;save()
 regions=json.loads(gzip.decompress((MAIN/'docs/renderer/evidence/native-intrinsic-snap-v8/regions-and-four-profile-sweeps.json.gz').read_bytes()));ids=sorted(set(r['id'] for r in regions['rows']));assert len(ids)==20
 selection=OUT/'affected-20-ids.json';selection.write_text(json.dumps(ids,indent=2)+'\n');report['selection_sha256']=sha(selection);save()
 for suite in ['affected','focused','primitive']:
  result=OUT/(suite+'-matrix');result.mkdir()
  command=[sys.executable,str(ROOT/'tools/qualification/run_renderer_matrix.py'),'--suite','full' if suite=='affected' else suite,'--results-dir',str(result),'--cache-dir','/mnt/e/openui-v02-qualification-d174ea0b/renderer-cache','--oracle-cache-dir','/home/nero/code/open-ui/out/renderer-qualification-cache/chromium-oracle','--pixel-compare',str(pixel),'--chrome',str(MAIN/'chrome/linux-147.0.7727.50/chrome-linux64/chrome'),'--raster-backend','cpu-skia','--jobs','2']
  if suite=='affected':command.extend([a for test_id in ids for a in ['--test-id',test_id]])
  stage=run(suite+'-matrix',command,cwd=ROOT,require_zero=suite!='affected')
  summary=result/(('full' if suite=='affected' else suite)+'-summary.json');s=json.loads(summary.read_bytes());assert s['source']==source;report[suite+'_matrix']=dict(summary_sha256=sha(summary),totals=s.get('totals'),observed_exit_code=stage['observed_exit_code']);save()
 report['observed_exit_code']=0
except BaseException as error:
 report.update(observed_exit_code=1,failure=str(error));raise
finally:
 report['all_commands_terminal']=True
 if source is not None:
  report['source_after']=repository_source_identity(ROOT);report['source_unchanged']=report['source_after']==source
  if not report['source_unchanged']:report.update(observed_exit_code=1,failure='source identity changed during pipeline')
 save()
raise SystemExit(report['observed_exit_code'])
