import fcntl,json,os,shutil,subprocess
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');OLD=Path('/dev/shm/openui-native-fontations-current-retry-v1946');ROOT=Path('/dev/shm/openui-native-shaped-intrinsic-v1966');HEAD='9e4baa08e784b33365e03b807849dcb4804177a9'
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','ninja','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
assert not ROOT.exists() and not subprocess.check_output(['git','status','--porcelain'],cwd=OLD)
subprocess.run(['git','worktree','add','--no-checkout','--detach',str(ROOT),HEAD],cwd=MAIN,check=True,capture_output=True)
for encoded in subprocess.check_output(['git','ls-tree','-r','--name-only','-z',HEAD],cwd=MAIN).split(b'\0'):
 if not encoded:continue
 name=encoded.decode();p=ROOT/name;old=OLD/name;p.parent.mkdir(parents=True,exist_ok=True)
 if old.is_symlink():p.symlink_to(os.readlink(old))
 else:os.link(old,p)
subprocess.run(['git','read-tree',HEAD],cwd=ROOT,check=True,capture_output=True)
p=ROOT/'bindings/rust/openui-layout/src/intrinsic_sizing.rs';tmp=p.with_name(p.name+'.isolated-v1966');shutil.copy2(p,tmp);tmp.replace(p)
s=p.read_text();start=s.index('/// Convert a shaped advance to Blink\'s 1/64px intrinsic-size grid.');end=s.index('\n}',start)+2
s=s[:start]+'''/// Convert a shaped advance to Blink's 1/64px intrinsic-size grid.
///
/// Blink's ShapeResult::SnappedWidth preserves every positive fraction before
/// ceil conversion. Intrinsic measurement must obtain the shaped advance;
/// raw SkFont metrics can retain fractions that the shaping policy removes.
fn intrinsic_text_width(width: f32) -> LayoutUnit {
    LayoutUnit::from_f32_ceil(width)
}'''+s[end:]
old='''    let font = doc.resolve_font(style_to_font_description(style));
    let measure = |run: &str| intrinsic_text_width(font.width(run));'''
new='''    let font = doc.resolve_font(style_to_font_description(style));
    let shaper = openui_text::TextShaper::new();
    let direction = if style.direction == openui_style::Direction::Rtl {
        openui_text::TextDirection::Rtl
    } else {
        openui_text::TextDirection::Ltr
    };
    let measure = |run: &str| intrinsic_text_width(shaper.shape(run, &font, direction).width);'''
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('fn intrinsic_text_width_normalizes_backend_roundoff_at_layout_unit_boundaries()', 'fn intrinsic_text_width_keeps_positive_shaped_fractions()').replace('''intrinsic_text_width(208.000_396_729),
            LayoutUnit::from_i32(208)''','''intrinsic_text_width(208.000_396_729),
            LayoutUnit::from_raw(208 * 64 + 1)''')
p.write_text(s)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=OLD)
Path('/tmp/openui-native-shaped-intrinsic-prepare-v1966.json').write_text(json.dumps(dict(root=str(ROOT),base=HEAD,previous_source_preserved=True,all_mutable_paths_isolated=True,release_qualification=False),indent=2)+'\n')
print('prepared shaped intrinsic trial')
