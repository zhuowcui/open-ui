import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';ROOT=Path('/dev/shm/openui-native-shaped-intrinsic-v1966');NAME='native-fontations-factory-v3'
OUT=MAIN/'docs/renderer/evidence'/NAME;INDEX=MAIN/'docs/renderer/generated'/(NAME+'.json');assert not OUT.exists() and not INDEX.exists()
sha=lambda data:hashlib.sha256(data).hexdigest()
owner=json.loads((RAW/'native-shaped-intrinsic-pipeline-v1968/receipt.json').read_bytes());assert owner['all_commands_terminal'] and owner['source_unchanged'] and owner['observed_exit_code']==0
checks=json.loads((RAW/'native-shaped-intrinsic-checks-v1969/receipt.json').read_bytes());assert checks['source']==owner['source'] and all(r['observed_exit_code']==0 for r in checks['checks'])
audit=json.loads((RAW/'native-shaped-intrinsic-audit-v1970.json').read_bytes());assert audit['source']==owner['source'] and audit['native_totals']['geometry_exact']==12800
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
OUT.mkdir(parents=True);members={}
def add(name,data,source):
 assert name not in members;members[name]=dict(data=data,source=source)
for dirname in ['native-width-trace-pipeline-v1960','native-width-trace-pipeline-v1963','native-width-trace-pipeline-v1965','native-shaped-intrinsic-pipeline-v1968','native-shaped-intrinsic-consumer-v1968','native-shaped-intrinsic-checks-v1969','native-fontations-umbrella-hosted-v1961','native-shaped-intrinsic-source-repro-v1972']:
 root=RAW/dirname
 for p in sorted(root.rglob('*')):
  if p.is_file() and 'compiler-tmp' not in p.parts and p.name not in ['openui-native-width-trace','native_glyph_coverage','pixel_compare','reproduction-index']:
   add(str(Path(dirname)/p.relative_to(root)),p.read_bytes(),str(p))
for number,rootname in [(1959,'openui-native-width-trace-v1959'),(1962,'openui-native-width-trace-retry-v1962'),(1964,'openui-native-width-trace-resolved-v1964')]:
 root=Path('/dev/shm')/rootname
 for f in ['Cargo.toml','Cargo.lock','README.md','src/main.rs']:
  p=root/f
  if p.exists():add(str(Path('diagnostic-source')/rootname/f),p.read_bytes(),str(p))
for filename in ['openui-verified-terminal-binary-relocation-v1958.py','openui-verified-terminal-binary-relocation-v1958.json','openui-native-width-trace-pipeline-v1960.py','openui-native-width-trace-pipeline-v1963.py','openui-native-width-trace-pipeline-v1965.py','openui-native-fontations-umbrella-hosted-collect-v1961.py','openui-native-shaped-intrinsic-prepare-v1966.py','openui-native-shaped-intrinsic-prepare-v1966.json','openui-native-shaped-intrinsic-pipeline-v1968.py','openui-native-shaped-intrinsic-consumer-v1968.py','openui-native-shaped-intrinsic-checks-v1969.py','openui-native-shaped-intrinsic-audit-v1970.py','openui-native-shaped-intrinsic-preserve-v1971.py','openui-native-shaped-intrinsic-source-repro-v1972.py']:
 p=Path('/tmp')/filename;add('probes/'+filename,p.read_bytes(),str(p))
p=RAW/'native-shaped-intrinsic-audit-v1970.json';add('paired-audit.json',p.read_bytes(),str(p))
p=ROOT/'bindings/rust/openui-layout/src/intrinsic_sizing.rs';add('source/intrinsic_sizing.rs',p.read_bytes(),str(p))
patch=subprocess.check_output(['git','diff','--binary','9f0d22112136bc8b5325d0b0619031bdd8b9adcf','HEAD'],cwd=ROOT);compressed=gzip.compress(patch,mtime=0);(OUT/'reproduction-from-9f0d2211.patch.gz').write_bytes(compressed);add('reproduction-from-9f0d2211.patch',patch,'git diff --binary 9f0d2211 HEAD')
archive=OUT/'completed-evidence.tar.gz';records=[]
with archive.open('wb') as file:
 with gzip.GzipFile(fileobj=file,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,row in sorted(members.items()):
    info=tarfile.TarInfo(name);info.size=len(row['data']);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(row['data']));records.append(dict(name=name,sha256=sha(row['data']),bytes=len(row['data']),source_path=row['source']))
with tarfile.open(archive,'r:gz') as tar:
 entries=tar.getmembers();assert len(entries)==len(records)
 for entry,record in zip(entries,records):assert entry.name==record['name'] and sha(tar.extractfile(entry).read())==record['sha256']
record=dict(schema_version=1,source=owner['source'],source_after=owner['source_after'],all_commands_terminal=True,release_qualification=False,candidate_applied_to_umbrella=False,promotion_allowed=False,new_release_states_admitted=0,javascript_executed_by_openui=False,pixel_tolerance=0,full_original_and_expanded_censuses_not_run=True,formal_original_residual_ownership_unchanged=True,native_totals=audit['native_totals'],native_png_bytes_changed=audit['native_png_bytes_changed'],native_geometry_changes=audit['native_geometry_changes'],source_checks_passed=len(checks['checks']),text_and_layout_tests_passed=next(s['passed'] for s in owner['steps'] if s['name']=='text-and-layout-tests'),suites={name:{k:v for k,v in row.items() if k!='changed_comparisons'} for name,row in audit['suites'].items()},archive=dict(path=str(archive.relative_to(MAIN)),sha256=sha(archive.read_bytes()),bytes=archive.stat().st_size,all_members_hash_verified=True,members=records),reproduction_patch=dict(path=str((OUT/'reproduction-from-9f0d2211.patch.gz').relative_to(MAIN)),sha256=sha(compressed),bytes=len(compressed),decompressed_sha256=sha(patch),decompressed_bytes=len(patch),base_commit='9f0d22112136bc8b5325d0b0619031bdd8b9adcf',target_commit=owner['source']['commit']),entire_tracked_tree_reproduction=json.loads((RAW/'native-shaped-intrinsic-source-repro-v1972/receipt.json').read_bytes()),probe_sha256=sha(Path(__file__).read_bytes()))
INDEX.write_text(json.dumps(record,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(index=str(INDEX),index_sha256=sha(INDEX.read_bytes()),archive_bytes=archive.stat().st_size,archive_members=len(records),source=owner['source']['commit'])),flush=True)
