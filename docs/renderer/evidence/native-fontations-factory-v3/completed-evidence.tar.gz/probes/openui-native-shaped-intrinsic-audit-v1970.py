import collections,hashlib,json,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';OUT=RAW/'native-shaped-intrinsic-audit-v1970.json';assert not OUT.exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_bytes())
sys.path.insert(0,str(MAIN/'tools/qualification'));from residuals import canonical_sha256
owner_path=RAW/'native-shaped-intrinsic-pipeline-v1968/receipt.json';owner=load(owner_path);assert owner['all_commands_terminal'] and owner['observed_exit_code']==0 and owner['source']==owner['source_after']
current_path=RAW/'native-shaped-intrinsic-consumer-v1968/receipt.json';prior_path=RAW/'native-fontations-current-consumer-v1948/receipt.json';current,prior=load(current_path),load(prior_path)
assert current['all_commands_terminal'] and current['observed_exit_code']==0 and current['source']==owner['source'];assert prior['all_commands_terminal']
key=lambda r:(r['family'],r['size'],r['scale'])
a={key(r):r for r in prior['cases']};b={key(r):r for r in current['cases']};assert a.keys()==b.keys() and len(b)==100
geometry=collections.Counter();image_gains=image_losses=changed_native_png=0
for k,row in b.items():
 for i,old in zip(row['images'],a[k]['images']):
  assert i['state']==old['state'] and i['chromium_png_sha256']==old['chromium_png_sha256'] and i['independent_reference_runs']==old['independent_reference_runs']
  image_gains+=i['analysis']['mismatched_pixels']==0 and old['analysis']['mismatched_pixels']!=0
  image_losses+=old['analysis']['mismatched_pixels']==0 and i['analysis']['mismatched_pixels']!=0
  changed_native_png+=i['native_png_sha256']!=old['native_png_sha256']
  for p,previous in zip(i['phases'],old['phases']):
   assert p['logical_phase_64ths']==previous['logical_phase_64ths'] and p['chromium_bounds']==previous['chromium_bounds']
   for field in ['x','y','width','height']:
    delta=p['native_bounds'][field]-previous['native_bounds'][field]
    if delta:geometry[(field,delta)]+=1
report=dict(schema_version=1,source=owner['source'],all_commands_terminal=True,observed_exit_code=0,release_qualification=False,promotion_allowed=False,javascript_executed_by_openui=False,new_release_states_admitted=0,pixel_tolerance=0,native_gate_actual_exit=current['observed_exit_code'],native_totals=current['totals'],native_image_gains=image_gains,native_image_losses=image_losses,native_png_bytes_changed=changed_native_png,native_geometry_changes=[dict(field=k[0],delta=k[1],states=v) for k,v in sorted(geometry.items())],native_reference_records_unchanged=True,whole_owner_receipt_sha256=sha(owner_path),prior_native_receipt_sha256=sha(prior_path),native_receipt_sha256=sha(current_path),suites={},formal_original_residual_ownership_unchanged=True,probe_sha256=sha(Path(__file__)))
invariants=['openui_png_sha256','openui_rgba_sha256','chromium_png_sha256','chromium_rgba_sha256','chromium_oracle_identity_sha256','chromium_oracle_rgba_sha256','status','mismatched_pixels','diff_signature'];oracle=invariants[2:6]
for suite in ['affected','focused','primitive']:
 matrix_suite='full' if suite=='affected' else suite
 p=owner_path.parent/(suite+'-matrix')/(matrix_suite+'-summary.json');s=load(p)
 oldp=RAW/('native-event-targets-clean-'+matrix_suite+'-v1456')/(matrix_suite+'-summary.json');old=load(oldp)
 assert s['source']==s['source_after']==owner['source'];assert s['results']['profile_result_sha256']==canonical_sha256([r['result_sha256'] for r in s['profiles']])
 for profile in s['profiles']:assert profile['result_sha256']==canonical_sha256(profile['tests'])
 flatten=lambda d:{(p['profile'],r['id']):r for p in d['profiles'] for r in p['tests']}
 before,after=flatten(old),flatten(s);assert all(k in before for k in after)
 changes=[]
 for k,r in after.items():
  previous=before[k];assert all(r[n]==previous[n] for n in oracle)
  if any(r[n]!=previous[n] for n in invariants):changes.append(dict(profile=k[0],id=k[1],prior_status=previous['status'],status=r['status'],prior_mismatched_pixels=previous['mismatched_pixels'],mismatched_pixels=r['mismatched_pixels'],exact_loss=previous['status']=='exact' and r['status']!='exact',exact_gain=previous['status']!='exact' and r['status']=='exact',reviewed_root_cause=False))
 report['suites'][suite]=dict(results=s['results'],actual_exit=owner[suite+'_matrix']['observed_exit_code'],summary_sha256=sha(p),prior_summary_sha256=sha(oldp),comparisons=len(after),immutable_chromium_rows=len(after),changed_comparisons=changes,exact_losses=sum(r['exact_loss'] for r in changes),exact_gains=sum(r['exact_gain'] for r in changes),complete_matrix=suite!='affected')
assert changed_native_png==image_gains==image_losses==0 and current['totals']['pixel_exact']==200 and current['totals']['geometry_exact']==12800
assert geometry==collections.Counter({('width',1/64):1280})
assert report['suites']['affected']['comparisons']==80
OUT.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(receipt_sha256=sha(OUT),native_totals=report['native_totals'],native_png_bytes_changed=0,suites={name:{k:v[k] for k in ['comparisons','results','exact_losses','exact_gains']} for name,v in report['suites'].items()})),flush=True)
