#pragma once
#include "include/core/SkTypeface.h"
#include "include/core/SkFontArguments.h"
#include "rust/cxx.h"
namespace openui_fontations {
SkTypeface* make_typeface(rust::Slice<const uint8_t> data, const SkFontArguments* arguments);
SkTypeface* remake_typeface(const SkTypeface&, const SkFontArguments*);
uint32_t factory_id(const SkTypeface&);
}
