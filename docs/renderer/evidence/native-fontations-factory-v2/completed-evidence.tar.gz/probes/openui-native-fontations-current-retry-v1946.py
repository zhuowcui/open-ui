"""Prepare a fresh retry only after all previous build children are terminal."""
import json,os,shutil,subprocess
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');OLD=Path('/dev/shm/openui-native-fontations-current-main-v1941');ROOT=Path('/dev/shm/openui-native-fontations-current-retry-v1946');HEAD='93062a65e76b40e083ea5ab4d8ae85261acdf522'
for program in ['cargo','rustc','ninja','native_glyph_coverage']:assert subprocess.run(['pgrep','-x',program],capture_output=True).returncode==1
assert not ROOT.exists();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=OLD,text=True).strip()==HEAD
subprocess.run(['git','worktree','add','--no-checkout','--detach',str(ROOT),HEAD],cwd=MAIN,check=True,capture_output=True)
for encoded in subprocess.check_output(['git','ls-tree','-r','--name-only','-z',HEAD],cwd=MAIN).split(b'\0'):
 if not encoded:continue
 name=encoded.decode();old=OLD/name;p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True)
 if old.is_symlink():p.symlink_to(os.readlink(old))
 else:os.link(old,p)
subprocess.run(['git','read-tree',HEAD],cwd=ROOT,check=True,capture_output=True)
# Preserve the complete lockfile Cargo produced in the failed attempt. Isolate
# all formatter and generator output paths before any retry mutation.
mutable=['bindings/rust/Cargo.lock','bindings/rust/openui-fontations/build.rs','bindings/rust/openui-fontations/src/ports/fontations/src/factory.rs','bindings/rust/openui-geometry/src/raster.rs','bindings/rust/openui-text/src/font/collection.rs','bindings/rust/openui-text/src/font/platform.rs','bindings/rust/openui-paint/src/emphasis_painter.rs','bindings/rust/openui-paint/src/text_painter.rs','bindings/rust/openui-paint/src/painter.rs','bindings/rust/openui-text/src/shaping/shape_result.rs','bindings/rust/openui/examples/native_glyph_coverage.rs']+[str(p.relative_to(ROOT)) for p in (ROOT/'docs/v02/generated').iterdir() if p.is_file()]
for name in mutable:
 p=ROOT/name;tmp=p.with_name(p.name+'.isolated-v1946');shutil.copy2(p,tmp);tmp.replace(p)
meta=dict(root=str(ROOT),previous_failed_root=str(OLD),source_base=HEAD,retry_uses_complete_cargo_lockfile=True,previous_source_and_probe_preserved=True,all_mutable_paths_isolated=True,release_qualification=False)
Path('/tmp/openui-native-fontations-current-retry-v1946.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta),flush=True)
