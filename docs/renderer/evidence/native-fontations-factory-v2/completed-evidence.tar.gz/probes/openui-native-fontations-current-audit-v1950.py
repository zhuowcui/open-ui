"""Pair all native observations without changing source, inputs or PNG bytes."""
import hashlib,json
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1'
newpath=RAW/'native-fontations-current-consumer-v1948/receipt.json';oldpath=RAW/'native-linux-policy-consumer-v1909/receipt.json';out=RAW/'native-fontations-current-audit-v1950.json';assert not out.exists()
new=json.loads(newpath.read_text());old=json.loads(oldpath.read_text());assert new['all_commands_terminal'] and old['all_commands_terminal'];assert new['totals']['images']==old['totals']['images']==200
key=lambda row:(row['family'],row['size'],row['scale']);oldrows={key(r):r for r in old['cases']};assert len(oldrows)==100
rows=[];gains=losses=unchanged_geometry=0;per_scale={};residuals=[]
for row in new['cases']:
 before=oldrows[key(row)]
 for image in row['images']:
  previous=next(i for i in before['images'] if i['state']==image['state']);assert image['chromium_png_sha256']==previous['chromium_png_sha256'];assert image['independent_reference_runs']==previous['independent_reference_runs']
  assert len(image['phases'])==len(previous['phases'])==64
  gain=previous['analysis']['mismatched_pixels']!=0 and image['analysis']['mismatched_pixels']==0;loss=previous['analysis']['mismatched_pixels']==0 and image['analysis']['mismatched_pixels']!=0;gains+=gain;losses+=loss
  geometry=[]
  for a,b in zip(image['phases'],previous['phases']):
   assert a['logical_phase_64ths']==b['logical_phase_64ths'] and a['chromium_bounds']==b['chromium_bounds'];same=a['native_bounds']==b['native_bounds'];unchanged_geometry+=same
   if not a['geometry_exact']:
    delta={name:a['native_bounds'][name]-a['chromium_bounds'][name] for name in a['native_bounds']};assert {n for n,v in delta.items() if v}=={'width'} and delta['width']==-1/64
    residuals.append(dict(family=row['family'],size=row['size'],scale=row['scale'],state=image['state'],logical_phase_64ths=a['logical_phase_64ths'],native_bounds=a['native_bounds'],chromium_bounds=a['chromium_bounds'],owner='text/layout measurement; reviewed shared allocation fix required'))
   geometry.append(dict(native_bounds_unchanged=same,chromium_bounds_unchanged=True))
  scale=per_scale.setdefault(str(row['scale']),dict(images=0,exact=0,gains=0,losses=0));scale['images']+=1;scale['exact']+=image['analysis']['mismatched_pixels']==0;scale['gains']+=gain;scale['losses']+=loss
  rows.append(dict(family=row['family'],size=row['size'],scale=row['scale'],state=image['state'],reference_png_unchanged=True,reference_queries_unchanged=True,prior_mismatched_pixels=previous['analysis']['mismatched_pixels'],mismatched_pixels=image['analysis']['mismatched_pixels'],exact_gain=gain,exact_loss=loss,native_png_sha256=image['native_png_sha256'],geometry=geometry))
assert gains==38 and losses==0 and len(residuals)==1280 and unchanged_geometry==12800
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=dict(schema_version=1,all_commands_terminal=True,release_qualification=False,promotion_allowed=False,javascript_executed_by_openui=False,chromium_is_only_pixel_target=True,pixel_tolerance=0,source=new['source'],source_after=new['source_after'],prior_source=old['source'],new_receipt_sha256=sha(newpath),prior_receipt_sha256=sha(oldpath),new_states_admitted=0,formal_original_renderer_residual_ownership_assigned=0,
 totals=dict(images=200,exact=200,prior_exact=162,exact_gains=gains,exact_losses=losses,phase_states=12800,phase_exact=12800,geometry_exact=11520,geometry_total=12800,unchanged_geometry_states=unchanged_geometry,remaining_geometry_differences=len(residuals),repeated_native_processes=200,all_reference_bytes_and_queries_unchanged=True,actual_native_gate_exit=1),per_scale=per_scale,rows=rows,geometry_residuals=residuals,probe_sha256=sha(Path(__file__)))
assert new['source']==new['source_after'] and new['source']['clean'];out.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(path=str(out),sha256=sha(out),totals=report['totals'])),flush=True)
