"""Preserve exact native app pixels and every unqualified attempt separately."""
import hashlib,json,os,subprocess,tarfile
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';ROOT=Path('/dev/shm/openui-native-fontations-current-retry-v1946')
DEST=MAIN/'docs/renderer/evidence/native-fontations-factory-v2';INDEX=MAIN/'docs/renderer/generated/native-fontations-factory-v2.json'
assert not DEST.exists() and not INDEX.exists()
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
owner=read(RAW/'native-fontations-current-pipeline-v1948/receipt.json');native=read(RAW/'native-fontations-current-consumer-v1948/receipt.json');checks=read(RAW/'native-fontations-current-checks-v1949/receipt.json');audit=read(RAW/'native-fontations-current-audit-v1950.json');terminal=read(RAW/'native-fontations-current-terminal-v1947.json')
assert all(r['all_commands_terminal'] for r in [owner,native,checks,audit,terminal]);assert owner['observed_exit_code']==native['observed_exit_code']==1 and not owner.get('failure') and not native.get('failure')
assert owner['source']==owner['source_after']==native['source']==native['source_after']==checks['source']==checks['source_after']==audit['source']==audit['source_after'] and owner['source']['clean']
assert len(checks['checks'])==16 and all(r['observed_exit_code']==0 for r in checks['checks']);assert next(s for s in owner['steps'] if s['name']=='all-text-tests')['passed']==344
assert native['totals']['pixel_exact']==200 and native['totals']['geometry_exact']==11520 and native['totals']['phase_exact']==12800
assert audit['totals']['exact_gains']==38 and audit['totals']['exact_losses']==0 and audit['totals']['unchanged_geometry_states']==12800
DEST.mkdir();patch=DEST/'reproduction-from-9f0d2211.patch';patch.write_bytes(subprocess.check_output(['git','diff','--binary','9f0d22112136bc8b5325d0b0619031bdd8b9adcf',owner['source']['commit'],'--'],cwd=MAIN))
cache=Path('/tmp/openui-native-fontations-source-index-v1952');assert not cache.exists();env=dict(os.environ,GIT_INDEX_FILE=str(cache))
subprocess.run(['git','read-tree','9f0d22112136bc8b5325d0b0619031bdd8b9adcf'],cwd=MAIN,env=env,check=True,capture_output=True)
subprocess.run(['git','apply','--cached','--whitespace=nowarn',str(patch)],cwd=MAIN,env=env,check=True,capture_output=True)
reconstructed=subprocess.check_output(['git','write-tree'],cwd=MAIN,env=env,text=True).strip();expected_tree=subprocess.check_output(['git','rev-parse',owner['source']['commit']+'^{tree}'],cwd=MAIN,text=True).strip();assert reconstructed==expected_tree
sources={}
for name in ['native-fontations-current-pipeline-v1944','native-fontations-current-pipeline-v1948','native-fontations-current-consumer-v1948','native-fontations-current-checks-v1949','native-fontations-umbrella-checks-v1938']:
 for p in sorted((RAW/name).rglob('*')):
  if p.is_file() and p.suffix in ['.json','.log','.png','.html']:sources[str(p.relative_to(RAW))]=p
for name in ['native-fontations-current-audit-v1950.json','native-fontations-current-terminal-v1947.json']:
 sources[name]=RAW/name
for pattern in ['openui-native-fontations-current-*.py','openui-native-fontations-current-*.json','openui-native-fontations-umbrella-checks-v1938.py']:
 for p in sorted(Path('/tmp').glob(pattern)):sources['probes/'+p.name]=p
sources['probes/'+Path(__file__).name]=Path(__file__)
# Exact source files changed by this integration, including the vendored include closure.
changed=subprocess.check_output(['git','diff','--name-only','-z','9f0d22112136bc8b5325d0b0619031bdd8b9adcf',owner['source']['commit']],cwd=MAIN).decode().split('\0')
for name in changed:
 if name and (ROOT/name).is_file():sources['current-source/'+name]=ROOT/name
failed=Path('/dev/shm/openui-native-fontations-current-main-v1941')
for name in changed:
 if name and (failed/name).is_file():sources['dirty-attempt-source/'+name]=failed/name
for name in ['bindings/rust/Cargo.lock','docs/v02/generated/dependency-policy.json']:
 p=DEST/('failed-committed-'+Path(name).name);p.write_bytes(subprocess.check_output(['git','show','93062a65e76b40e083ea5ab4d8ae85261acdf522:'+name],cwd=MAIN));sources['failed-committed-source/'+name]=p
# Preserve the partial preparation and its preflight failure without relabelling it.
partial=Path('/dev/shm/openui-native-fontations-current-main-v1939/bindings/rust/openui-fontations')
for p in sorted(partial.rglob('*')):
 if p.is_file():sources['partial-header-preflight-source/'+str(p.relative_to(partial))]=p
sources['source/reproduction-from-9f0d2211.patch']=patch
hosted_path=RAW/'native-fontations-umbrella-hosted-v1951/receipt.json';hosted=read(hosted_path) if hosted_path.exists() else None
if hosted:
 assert hosted['all_commands_terminal'] and hosted['source']=='412e804c6ae2d6f5756054d0f78edfde8be4508d' and hosted['failed_jobs']==0
 for p in hosted_path.parent.iterdir():
  if p.is_file():sources[str(p.relative_to(RAW))]=p
 sources['probes/openui-native-fontations-umbrella-hosted-collect-v1951.py']=Path('/tmp/openui-native-fontations-umbrella-hosted-collect-v1951.py')
archive=DEST/'completed-evidence.tar.gz';members=[];first={}
with tarfile.open(archive,'w:gz',compresslevel=6,format=tarfile.PAX_FORMAT) as tar:
 for name,p in sorted(sources.items()):
  digest=sha(p);members.append(dict(path=name,bytes=p.stat().st_size,sha256=digest));info=tar.gettarinfo(str(p),arcname=name)
  if digest in first:info.type=tarfile.LNKTYPE;info.linkname=first[digest];info.size=0;tar.addfile(info)
  else:
   first[digest]=name
   with p.open('rb') as stream:tar.addfile(info,stream)
with tarfile.open(archive,'r:gz') as tar:
 assert len(tar.getmembers())==len(members)
 for info,row in zip(tar.getmembers(),members):
  content=tar.extractfile(info).read();assert info.name==row['path'] and len(content)==row['bytes'] and hashlib.sha256(content).hexdigest()==row['sha256']
manifest=DEST/'archive-members.json';manifest.write_text(json.dumps(members,sort_keys=True,indent=2)+'\n')
index=dict(schema_version=2,all_commands_terminal=True,release_qualification=False,promotion_allowed=False,source=owner['source'],source_after=owner['source_after'],private_unintegrated_candidate=True,source_base='9f0d22112136bc8b5325d0b0619031bdd8b9adcf',source_tree=expected_tree,source_reconstructed_tree=reconstructed,complete_public_source_reproduction_verified=True,
 javascript_executed_by_openui=False,chromium_is_only_pixel_target=True,pixel_tolerance=0,new_release_states_admitted=0,formal_original_renderer_residual_ownership_assigned=0,
 skia_pin_unchanged='a31b86ba3b767344d39af3b8c30043003d8fc991',full_real_fontations_typeface_and_scaler_used=True,matching_stays_with_system_and_application_registry=True,shaping_and_advances_use_fontations_typeface=True,custom_outline_adapter_not_used_for_new_backend=True,legacy_glyph_origin_compensation_not_used_for_new_backend=True,global_typeface_registry_not_mutated=True,unsupported_factory_data_does_not_silently_switch_to_freetype=True,
 existing_default_and_freetype_paths_have_not_been_globally_requalified=True,inherits_rejected_descriptor_correction=False,preserves_current_variable_font_instance_correction=True,inherited_twenty_nine_losses_not_ported=True,
 explicit_fixed_hinting_guard_passed=True,all_thirty_independent_chromium_metrics_matched=True,real_factory_fnta_verified_in_metrics_guard=True,text_tests_passed=344,readonly_source_checks_passed=16,vendored_exact_pinned_header_files=113,
 original_expanded_focused_and_primitive_matrices_not_run=True,workspace_msrv_miri_c_abi_and_packaging_not_run=True,variation_ttc_palette_woff_and_every_configuration_field_still_need_behavior_qualification=True,
 native_totals=native['totals'],paired_audit_totals=audit['totals'],per_scale=audit['per_scale'],native_pixel_images_exact=200,native_geometry_exact=11520,native_geometry_total=12800,native_qualification_actual_exit=1,remaining_native_width_differences=1280,width_differences_only_and_all_minus_one_sixty_fourth=True,shared_intrinsic_width_helper_still_discards_small_positive_fractions=True,shared_measurement_runtime_data_flow_review_still_required=True,
 failed_dirty_lockfile_attempt_preserved=True,failed_consumer_owner_environment_preflight_preserved=True,original_incomplete_terminal_flag_preserved_with_external_terminal_observation=True,failed_windows_filemode_and_header_preflights_preserved=True,
 archived_members=len(members),all_members_hash_verified=True,artifacts=[dict(path=str(p.relative_to(MAIN)),bytes=p.stat().st_size,sha256=sha(p)) for p in [archive,manifest,patch]],
 previous_outline_trial_index=dict(path='docs/renderer/generated/native-linux-font-policy-v1.json',sha256=sha(MAIN/'docs/renderer/generated/native-linux-font-policy-v1.json')),
 prototype_index=dict(path='docs/renderer/generated/native-fontations-factory-v1.json',sha256=sha(MAIN/'docs/renderer/generated/native-fontations-factory-v1.json')),
 hosted_umbrella_observation=({k:hosted[k] for k in ['source','successful_jobs','skipped_jobs','failed_jobs','all_seven_native_guards_executed_and_passed_in_hosted_parity']} if hosted else None),full_hardening_not_run_on_412e804c=True,receipt_sha256={name:sha(RAW/name) for name in ['native-fontations-current-pipeline-v1948/receipt.json','native-fontations-current-consumer-v1948/receipt.json','native-fontations-current-checks-v1949/receipt.json','native-fontations-current-audit-v1950.json','native-fontations-current-terminal-v1947.json']},preserver_sha256=sha(Path(__file__)))
INDEX.write_text(json.dumps(index,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(index=str(INDEX),sha256=sha(INDEX),members=len(members),archive_bytes=archive.stat().st_size,patch_bytes=patch.stat().st_size,native_images_exact=200,native_bounds_open=1280)),flush=True)
