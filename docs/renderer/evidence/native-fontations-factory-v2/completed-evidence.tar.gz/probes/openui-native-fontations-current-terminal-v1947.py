"""Observe terminal processes while preserving the incomplete old receipt."""
import fcntl,hashlib,json,subprocess,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');ROOT=Path('/dev/shm/openui-native-fontations-current-main-v1941');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';OUT=RAW/'native-fontations-current-terminal-v1947.json'
assert not OUT.exists();lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
prior=RAW/'native-fontations-current-pipeline-v1944/receipt.json';j=json.loads(prior.read_text());assert subprocess.run(['ps','-p',str(j['owner_pid']),'-o','pid='],capture_output=True).returncode!=0
for program in ['cargo','rustc','ninja','native_glyph_coverage']:assert subprocess.run(['pgrep','-x',program],capture_output=True).returncode==1
sys.path.insert(0,str(MAIN/'tools/qualification'));from renderer_source_identity import repository_source_identity
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=dict(schema_version=1,all_commands_terminal=True,observed_pipeline_exit_code=1,release_qualification=False,promotion_allowed=False,original_receipt_preserved_unmodified=True,original_receipt_terminal_flag_was_not_saved=True,original_receipt_sha256=sha(prior),source_before=j['source'],source_after=repository_source_identity(ROOT),lockfile_changed_after_source_commit=True,unlocked_clean_resolved_additional_dependencies=True,source_checks_stopped_before_running=True,all_text_tests_passed_on_dirty_source=344,app_build_passed_on_dirty_source=True,consumer_failed_before_any_app_process=True,consumer_failure_log_sha256=sha(prior.parent/'candidate-native.log'),consumer_owner_environment_was_missing=True,chromium_pixel_comparisons_run=0,javascript_executed_by_openui=False,probe_sha256=sha(Path(__file__)))
assert not report['source_after']['clean'] and report['source_before']!=report['source_after'];OUT.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(path=str(OUT),sha256=sha(OUT),all_commands_terminal=True,pixel_comparisons=0)),flush=True)
