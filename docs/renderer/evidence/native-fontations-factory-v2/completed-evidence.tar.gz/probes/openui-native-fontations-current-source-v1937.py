"""Prepare a private current-main integration, preserving all old raster choices."""
import hashlib,json,re,shutil,subprocess
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');ROOT=Path('/mnt/e/openui-v02-qualification-d174ea0b/native-fontations-current-main-v1935');RUST=ROOT/'bindings/rust'
PROTOTYPE=Path('/dev/shm/openui-fontations-factory-prototype-v1933');POLICY=Path('/dev/shm/openui-native-linux-policy-candidate-retry-v1907')
SKIA=Path('/home/nero/.cargo/git/checkouts/rust-skia-b4d79b6a888cdb4c/a31b86b/skia-bindings/skia')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='9f0d22112136bc8b5325d0b0619031bdd8b9adcf'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
assert json.loads((MAIN/'out/renderer-evidence/native-viewport-scroll-v1/native-fontations-factory-prototype-v1934/receipt.json').read_text())['all_commands_terminal']
def replace(p,a,b):
 s=p.read_text();assert s.count(a)==1,(str(p),a[:80],s.count(a));p.write_text(s.replace(a,b))
crate=RUST/'openui-fontations';assert not crate.exists();crate.mkdir()
for rel in ['SkTypeface_fontations.cpp','factory.cpp','factory.h','build.rs','LICENSE-skia']:
 shutil.copy2(PROTOTYPE/rel,crate/rel)
shutil.copytree(PROTOTYPE/'src',crate/'src')
(crate/'Cargo.toml').write_text('''[package]
name = "openui-fontations"
version.workspace = true
edition.workspace = true
rust-version.workspace = true
license = "Apache-2.0 AND BSD-3-Clause"
repository.workspace = true
description = "Owned typefaces using the Fontations scaler from Open UI's pinned Skia"

[lib]
path = "src/ports/fontations/src/ffi.rs"

[dependencies]
read-fonts = "=0.34.0"
font-types = "=0.9.0"
skrifa = "=0.36.0"
bytemuck = "1.23.2"
cxx = "=1.0.168"
skia-safe = { version = "0.94", features = ["textlayout", "freetype-woff2"] }

[build-dependencies]
cxx-build = "=1.0.168"
''')
replace(crate/'build.rs','let skia = PathBuf::from(env::var("OPENUI_PINNED_SKIA_INCLUDE").expect("pinned Skia source"));','let skia = PathBuf::from("vendor/skia");')
replace(crate/'build.rs','openui-fontations-factory-prototype/src/ports/fontations/src/ffi.rs.h','openui-fontations/src/ports/fontations/src/ffi.rs.h')
replace(crate/'build.rs','    println!("cargo:rerun-if-env-changed=OPENUI_PINNED_SKIA_INCLUDE");','    println!("cargo:rerun-if-changed=vendor/skia");')
replace(crate/'factory.h','uint32_t factory_id(const SkTypeface&);','SkTypeface* remake_typeface(const SkTypeface&, const SkFontArguments*);\nuint32_t factory_id(const SkTypeface&);')
replace(crate/'factory.cpp','uint32_t factory_id(const SkTypeface& face) {','''SkTypeface* remake_typeface(const SkTypeface& face, const SkFontArguments* arguments) {
    if (!arguments) return nullptr;
    int collection_index = 0;
    auto stream = face.openStream(&collection_index);
    if (!stream) return nullptr;
    auto data = SkData::MakeFromStream(stream.get(), stream->getLength());
    if (!data) return nullptr;
    // Preserve the selected collection member and the complete instance arguments.
    auto instance = *arguments;
    instance.setCollectionIndex(collection_index);
    return SkTypeface_Make_Fontations(std::move(data), instance).release();
}
uint32_t factory_id(const SkTypeface& face) {''')
replace(crate/'src/ports/fontations/src/factory.rs','        fn factory_id(face: &SkTypeface) -> u32;','''        unsafe fn remake_typeface(face: &SkTypeface, arguments: *const SkFontArguments) -> *mut SkTypeface;
        fn factory_id(face: &SkTypeface) -> u32;''')
p=crate/'src/ports/fontations/src/factory.rs';s=p.read_text();s+='''
/// Recreate a selected font through the pinned Fontations factory.
///
/// Font matching stays with the system or application registry. The original
/// bytes and TTC member are retained; shaping and painting use this typeface.
/// Unsupported data returns `None`, never a silent FreeType substitution.
pub fn from_typeface(
    face: &skia_safe::Typeface,
    arguments: &skia_safe::FontArguments<'_, '_>,
) -> Option<skia_safe::Typeface> {
    use skia_safe::wrapper::{NativeTransmutableWrapper, PointerWrapper};
    let args = arguments.inner() as *const _ as *const bridge::SkFontArguments;
    let face = face.inner() as *const _ as *const bridge::SkTypeface;
    // SAFETY: both opaque references use the same pinned Skia ABI. The
    // factory reads them only during this call, owns the font bytes, and
    // transfers exactly one reference to skia-safe's documented wrapper.
    let pointer = unsafe { bridge::remake_typeface(&*face, args) };
    skia_safe::Typeface::wrap(pointer.cast())
}
''';p.write_text(s)
# Copy the exact pinned include closure. Generated CXX headers stay generated.
queue=[SKIA/'src/ports/SkTypeface_fontations.cpp',crate/'factory.h',crate/'factory.cpp'];seen=set();headers={}
while queue:
 p=queue.pop()
 if p in seen:continue
 seen.add(p)
 for name in re.findall(r'^\s*#\s*include\s*"([^"]+)"',p.read_text(errors='replace'),re.M):
  if name in ['src/ports/fontations/src/ffi.rs.h','rust/cxx.h','factory.h']:continue
  choices=[p.parent/name,SKIA/name]
  resolved=next((q.resolve() for q in choices if q.is_file()),None)
  if resolved is None:continue # CXX-generated headers and inactive platform branches.
  try:rel=resolved.relative_to(SKIA)
  except ValueError:continue
  if str(rel) not in headers:headers[str(rel)]=hashlib.sha256(resolved.read_bytes()).hexdigest();queue.append(resolved)
for rel in headers:
 dest=crate/'vendor/skia'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(SKIA/rel,dest)
(crate/'vendor-skia-files.json').write_text(json.dumps(dict(skia_pin='a31b86ba3b767344d39af3b8c30043003d8fc991',files=headers),sort_keys=True,indent=2)+'\n')
replace(RUST/'Cargo.toml','    "openui-text",','    "openui-text",\n    "openui-fontations",')
p=RUST/'openui-text/Cargo.toml';p.write_text(p.read_text()+'openui-fontations = { version = "=0.2.0", path = "../openui-fontations" }\n')
# Only the additive policy API comes from the old private source. Descriptor
# corrections from that source are not copied into layout, paint or shaping.
p=RUST/'openui-geometry/src/raster.rs';shutil.copy2(POLICY/'bindings/rust/openui-geometry/src/raster.rs',p);replace(p,"CPU Skia replay of Chromium's Fontations glyph outlines.","CPU Skia replay using the pinned Fontations typeface and scaler.")
p=RUST/'openui-text/src/font/collection.rs'
replace(p,'    Font as SkFont, FontArguments, FontMgr, Typeface,','    Font as SkFont, FontArguments, FontMgr, Typeface,')
replace(p,'use super::description::FontDescription;','use openui_geometry::RasterBackend;\nuse super::description::FontDescription;')
# Both resolutions already return Option; failed explicit factory selection
# returns None and never inserts the wrong backend in the cache.
s=p.read_text();assert s.count('            description,\n        );\n        insert_instance')==2;s=s.replace('            description,\n        );\n        insert_instance','            description,\n        )?;\n        insert_instance');p.write_text(s)
replace(p,') -> Arc<FontPlatformData> {\n    let typeface = instantiate_typeface(typeface, palette, description);',') -> Option<Arc<FontPlatformData>> {\n    let typeface = instantiate_typeface(typeface, palette, description)?;')
replace(p,'    Arc::new(FontPlatformData::with_resolved_configuration(','    Some(Arc::new(FontPlatformData::with_resolved_configuration(')
replace(p,'        configuration,\n    ))\n}','        configuration,\n    )))\n}')
replace(p,') -> Typeface {\n    let mut axes',') -> Option<Typeface> {\n    let fontations = description.raster_configuration.backend == RasterBackend::ChromiumLinuxFontations;\n    let mut axes')
replace(p,'        return typeface;\n    }\n\n    let coordinates','        return if fontations {\n            openui_fontations::factory::from_typeface(&typeface, &FontArguments::new())\n        } else {\n            Some(typeface)\n        };\n    }\n\n    let coordinates')
replace(p,'    typeface\n        .clone_with_arguments(&arguments)\n        .unwrap_or(typeface)','    if fontations {\n        openui_fontations::factory::from_typeface(&typeface, &arguments)\n    } else {\n        Some(typeface.clone_with_arguments(&arguments).unwrap_or(typeface))\n    }')
p=RUST/'openui-text/src/font/platform.rs'
replace(p,'    physical_font_size, RasterConfiguration, TextEdging, TextHinting, TextRasterConfiguration,','    physical_font_size, RasterBackend, RasterConfiguration, TextEdging, TextHinting, TextRasterConfiguration,')
replace(p,'    sk_font: SkFont,','    sk_font: SkFont,\n    raster_configuration: RasterConfiguration,')
replace(p,'        TextHinting::Full => FontHinting::Full,','        TextHinting::Full => FontHinting::Full,\n        TextHinting::ChromiumLinux => unreachable!("resolve platform hinting first"),')
replace(p,'            && raster_configuration.author_text.edging == TextEdging::Alias','            && raster_configuration.backend != RasterBackend::ChromiumLinuxFontations\n            && raster_configuration.author_text.edging == TextEdging::Alias')
policy_platform=(POLICY/'bindings/rust/openui-text/src/font/platform.rs').read_text()
a=policy_platform.index("        // Linux's platform subpixel positioning");b=policy_platform.index('        sk_font.set_embedded_bitmaps(true);',a)
s=p.read_text();a0=s.index('        let subpixel = settings.subpixel_positioning && !native_button_text_metrics;');b0=s.index('        sk_font.set_embedded_bitmaps(true);',a0);s=s[:a0]+policy_platform[a:b]+s[b0:];p.write_text(s)
a=policy_platform.index('        if fontations_linux && metrics.ascent');b=policy_platform.index('        metrics.line_spacing =',a)
replace(p,'        metrics.line_spacing = metrics.ascent + metrics.descent + metrics.line_gap;',policy_platform[a:b]+'        metrics.line_spacing = metrics.ascent + metrics.descent + metrics.line_gap;')
replace(p,'            sk_font,\n            size,','            sk_font,\n            raster_configuration,\n            size,')
replace(p,'    /// The resolved font size in CSS pixels.','    /// Immutable rendering choice for this resolved font.\n    pub fn raster_configuration(&self) -> RasterConfiguration {\n        self.raster_configuration\n    }\n\n    /// The resolved font size in CSS pixels.')
# Retain meaningful independent metrics and fixed-request guards from the
# previous source, but use the real factory for the new scale metrics guard.
a=policy_platform.index('    #[test]\n    fn fontations_linux_metrics_match_repeated_chromium_scale_queries');
# New tests were appended to the test module. Copy only that tail of functions.
old_tail=policy_platform[a:];assert old_tail.endswith('}\n');p.write_text(p.read_text().rstrip()[:-1]+'\n'+old_tail)
# The metrics tests construct direct platform data; direct setup must use a
# real Fontations face rather than the old outline trial's FreeType face.
s=p.read_text();start=s.index('    fn fontations_linux_metrics_match_repeated_chromium_scale_queries');before=s[:start];tail=s[start:];tail=tail.replace('let face = collection', 'let face = collection');p.write_text(before+tail)
p=RUST/'openui-paint/src/emphasis_painter.rs';replace(p,'font.set_hinting(match settings.hinting {','font.set_hinting(match settings.resolved_hinting(style.device_scale_factor) {');replace(p,'        TextHinting::Full => skia_safe::FontHinting::Full,','        TextHinting::Full => skia_safe::FontHinting::Full,\n        TextHinting::ChromiumLinux => unreachable!("resolved platform hinting"),')
p=RUST/'openui-paint/src/text_painter.rs'
replace(p,') {\n    let text_raster = if style.native_control_text {',') {\n    let fontations = style.raster_configuration.backend == RasterBackend::ChromiumLinuxFontations;\n    // True typefaces own their scaler behavior. Do not replace them with\n    // custom paths or apply legacy FreeType strike/phase compensation.\n    let raster_policy = if fontations { TextRasterPolicy::Skia } else { raster_policy };\n    let text_raster = if style.native_control_text {')
replace(p,'    let lcd_origin = (style.native_control_text','    let lcd_origin = (!fontations && (style.native_control_text')
replace(p,'        || text_raster.edging == TextEdging::SubpixelAntiAlias)\n        .then','        || text_raster.edging == TextEdging::SubpixelAntiAlias))\n        .then')
s=p.read_text();s=s.replace('style.raster_configuration.backend == RasterBackend::ChromiumLinux','style.raster_configuration.backend.is_chromium_cpu()');# Restore new-backend equality changed by substring replacement.
s=s.replace('style.raster_configuration.backend.is_chromium_cpu()Fontations','style.raster_configuration.backend == RasterBackend::ChromiumLinuxFontations');p.write_text(s)
p=RUST/'openui-text/src/shaping/shape_result.rs';replace(p,'            let source_font = run.font_data.sk_font();','            let source_font = run.font_data.sk_font();\n            let fontations = run.font_data.raster_configuration().backend == openui_geometry::RasterBackend::ChromiumLinuxFontations;\n            let raster_policy = if fontations { TextRasterPolicy::Skia } else { raster_policy };')
replace(p,'                        - chromium_lcd_strike_y_offset(','                        - if fontations { 0.0 } else { chromium_lcd_strike_y_offset(')
replace(p,'                            &source_font.typeface().family_name(),\n                        ))','                            &source_font.typeface().family_name(),\n                        ) })')
shutil.copy2(POLICY/'bindings/rust/openui/examples/native_glyph_coverage.rs',RUST/'openui/examples/native_glyph_coverage.rs')
# This source inherits the accepted current-main variable-instance correction,
# never the rejected descriptor source. It is prepared, not yet compiled.
meta=dict(base='9f0d22112136bc8b5325d0b0619031bdd8b9adcf',root=str(ROOT),skia_pin_unchanged='a31b86ba3b767344d39af3b8c30043003d8fc991',prototype='947fc0d84f8c20d8dde16aebc9f8dc3f79100ee4',vendored_header_files=len(headers),javascript_executed_by_openui=False,release_qualification=False,compiled=False,inherits_rejected_descriptor_correction=False,preserves_current_variable_font_instance_correction=True)
Path('/tmp/openui-native-fontations-current-source-v1937.json').write_text(json.dumps(meta,sort_keys=True,indent=2)+'\n');print(json.dumps(meta),flush=True)
