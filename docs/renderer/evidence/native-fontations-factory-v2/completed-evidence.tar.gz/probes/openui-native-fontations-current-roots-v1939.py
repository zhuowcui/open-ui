"""Create a current-main source from verified immutable cache files."""
import hashlib,json,os,shutil,subprocess
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');BASE=Path('/dev/shm/openui-native-linux-policy-candidate-retry-v1907');ROOT=Path('/dev/shm/openui-native-fontations-current-main-v1939');HEAD='9f0d22112136bc8b5325d0b0619031bdd8b9adcf'
assert not ROOT.exists();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=BASE,text=True).strip()=='b1f73e798ee953da685d6d25948b4fe759b28eae';assert not subprocess.check_output(['git','status','--porcelain'],cwd=BASE)
changed=set(subprocess.check_output(['git','diff','--name-only','-z','b1f73e798ee953da685d6d25948b4fe759b28eae',HEAD],cwd=MAIN).decode().split('\0'))
subprocess.run(['git','worktree','add','--no-checkout','--detach',str(ROOT),HEAD],cwd=MAIN,check=True,capture_output=True)
tree=subprocess.check_output(['git','ls-tree','-r','-z',HEAD],cwd=MAIN).split(b'\0');copied=linked=copy_bytes=0
for item in tree:
 if not item:continue
 info,name=item.split(b'\t',1);mode,kind,digest=info.decode().split();name=name.decode();dest=ROOT/name;dest.parent.mkdir(parents=True,exist_ok=True)
 if name not in changed:
  old=BASE/name;assert old.exists() or old.is_symlink()
  if old.is_symlink():dest.symlink_to(os.readlink(old))
  else:os.link(old,dest)
  linked+=1
 else:
  p=MAIN/name;content=p.read_bytes() if p.is_file() else b''
  if hashlib.sha1(b'blob '+str(len(content)).encode()+b'\0'+content).hexdigest()!=digest:
   content=subprocess.check_output(['git','cat-file','blob',digest],cwd=MAIN)
  if mode=='120000':dest.symlink_to(content.decode())
  else:dest.write_bytes(content);dest.chmod(0o755 if mode=='100755' else 0o644)
  copied+=1;copy_bytes+=len(content)
subprocess.run(['git','read-tree',HEAD],cwd=ROOT,check=True,capture_output=True);assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
# Isolate every path the preparation script may rewrite.
for name in ['bindings/rust/Cargo.toml','bindings/rust/openui-text/Cargo.toml','bindings/rust/openui-geometry/src/raster.rs','bindings/rust/openui-text/src/font/collection.rs','bindings/rust/openui-text/src/font/platform.rs','bindings/rust/openui-paint/src/emphasis_painter.rs','bindings/rust/openui-paint/src/text_painter.rs','bindings/rust/openui-text/src/shaping/shape_result.rs','bindings/rust/openui/examples/native_glyph_coverage.rs']:
 p=ROOT/name
 if p.exists():tmp=p.with_name(p.name+'.isolated-v1939');shutil.copy2(p,tmp);tmp.replace(p)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=BASE)
p=Path('/tmp/openui-native-fontations-current-source-v1940.py');assert not p.exists();p.write_text(Path('/tmp/openui-native-fontations-current-source-v1937.py').read_text().replace('/mnt/e/openui-v02-qualification-d174ea0b/native-fontations-current-main-v1935',str(ROOT)).replace('source-v1937.json','source-v1940.json'))
meta=dict(base=HEAD,root=str(ROOT),verified_dead_cache=str(BASE),cache_commit='b1f73e798ee953da685d6d25948b4fe759b28eae',cache_clean_after=True,files_hardlinked=linked,files_copied=copied,bytes_copied=copy_bytes,mutable_paths_isolated=True,previous_preflight_failure_root='/mnt/e/openui-v02-qualification-d174ea0b/native-fontations-current-main-v1935',previous_preflight_failed_before_code_edits=True,release_qualification=False)
Path('/tmp/openui-native-fontations-current-roots-v1939.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta),flush=True)
