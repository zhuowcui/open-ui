"""Own the current-main native Fontations build and repeated app sweep."""
import fcntl,hashlib,json,os,re,shutil,signal,subprocess,sys,time
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');ROOT=Path('/dev/shm/openui-native-fontations-current-retry-v1946');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';NAME='native-fontations-current-pipeline-v1948'
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for program in ['cargo','rustc','pixel_compare','ninja']:assert subprocess.run(['pgrep','-x',program],capture_output=True).returncode==1
OUT=RAW/NAME;STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/NAME;assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
TMP=STORE/'compiler-tmp';TMP.mkdir();env=dict(os.environ,OPENUI_NATIVE_WHOLE_OWNER=NAME,CARGO_TARGET_DIR='/mnt/e/openui-v02-cargo-c73754e2/target',CARGO_INCREMENTAL='0',RUST_MIN_STACK='4194304',CARGO_BUILD_JOBS='4',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(TMP),CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
base=['cargo','--config','.cargo/config.chromium.toml'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=dict(schema_version=1,all_commands_terminal=False,whole_pipeline_lock_covers_all_stages_and_gaps=True,owner_pid=os.getpid(),release_qualification=False,promotion_allowed=False,javascript_executed_by_openui=False,inherits_rejected_descriptor_correction=False,preserves_current_variable_font_instance_correction=True,full_renderer_matrices_not_attempted=True,steps=[],probe_sha256=sha(Path(__file__)))
save=lambda:(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');save()
def run(name,command,cwd=ROOT/'bindings/rust',require_zero=True):
 log=OUT/(name+'.log')
 with log.open('xb') as stream:
  child=subprocess.Popen(command,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True);report['current_process']=dict(pid=child.pid,stage=name);save();guard=False
  while child.poll() is None:
   if shutil.disk_usage(MAIN).free<512*2**20 or shutil.disk_usage(STORE).free<10*2**30:
    guard=True;os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=20);break
   time.sleep(1)
  child.wait()
 report.pop('current_process');totals=[tuple(map(int,m)) for m in re.findall(rb'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',log.read_bytes())]
 row=dict(name=name,observed_exit_code=child.returncode,disk_guard_triggered=guard,log_sha256=sha(log),passed=sum(x[0] for x in totals),failed=sum(x[1] for x in totals),ignored=sum(x[2] for x in totals));report['steps'].append(row);save();print(json.dumps(row),flush=True)
 assert not guard
 if 'source' in report:assert repository_source_identity(ROOT)==report['source'], 'source changed during a committed stage'
 if require_zero:assert child.returncode==0,'native factory integration stage failed'
 return row
try:
 run('format',['bash','-c','ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true bindings/rust/openui-fontations/build.rs bindings/rust/openui-fontations/src/ports/fontations/src/factory.rs bindings/rust/openui-geometry/src/raster.rs bindings/rust/openui-text/src/font/collection.rs bindings/rust/openui-text/src/font/platform.rs bindings/rust/openui-paint/src/emphasis_painter.rs bindings/rust/openui-paint/src/text_painter.rs bindings/rust/openui-paint/src/painter.rs bindings/rust/openui-text/src/shaping/shape_result.rs bindings/rust/openui/examples/native_glyph_coverage.rs'],cwd=ROOT)
 run('resolve-lockfile',base+['metadata','--offline','--locked','--no-deps','--format-version','1'])
 run('generate-dependency-policy',[sys.executable,'tools/release/generate_v02_contract.py'],cwd=ROOT)
 subprocess.run(['git','add','.'],cwd=ROOT,check=True,capture_output=True);subprocess.run(['git','commit','-m','Use owned pinned Fontations typefaces for the explicit native CPU policy'],cwd=ROOT,check=True,capture_output=True);assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
 sys.path.insert(0,str(ROOT/'tools/qualification'));from renderer_source_identity import repository_source_identity
 report['source']=repository_source_identity(ROOT);report['lockfile_sha256']=sha(ROOT/'bindings/rust/Cargo.lock');save()
 metadata=json.loads(subprocess.check_output(base+['metadata','--offline','--locked','--no-deps','--format-version','1'],cwd=ROOT/'bindings/rust',env=env));members=set(metadata['workspace_members']);packages=[p['name'] for p in metadata['packages'] if p['id'] in members];assert len(packages)==19
 run('clean-workspace',base+['clean','--locked']+[a for package in packages for a in ['-p',package]])
 run('all-text-tests',base+['test','--locked','-p','openui-text','--lib'])
 run('glyph-build',base+['build','--locked','-p','openui','--example','native_glyph_coverage'])
 binary=OUT/'native_glyph_coverage';shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/examples/native_glyph_coverage',binary);report['native_binary_sha256']=sha(binary);report['build_complete']=True;save()
 run('candidate-native',[sys.executable,'/tmp/openui-native-fontations-current-consumer-v1948.py'],cwd=MAIN,require_zero=False)
 native=json.loads((RAW/'native-fontations-current-consumer-v1948/receipt.json').read_text());assert native['all_commands_terminal'] and not native.get('failure') and native['totals']['images']==200
 report['observed_exit_code']=int(any(r['observed_exit_code'] for r in report['steps']))
except BaseException as error:
 report.update(observed_exit_code=1,failure=str(error));raise
finally:
 report['all_commands_terminal']=True
 if 'source' in report:
  report['source_after']=repository_source_identity(ROOT);report['source_unchanged']=report['source']==report['source_after']
  if not report['source_unchanged']:report.update(observed_exit_code=1,failure='source identity changed during the pipeline')
 save()
raise SystemExit(report['observed_exit_code'])
