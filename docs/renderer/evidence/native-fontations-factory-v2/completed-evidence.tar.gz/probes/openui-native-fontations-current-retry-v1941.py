import json,os,shutil,subprocess
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');OLD=Path('/dev/shm/openui-native-fontations-current-main-v1939');ROOT=Path('/dev/shm/openui-native-fontations-current-main-v1941');HEAD='9f0d22112136bc8b5325d0b0619031bdd8b9adcf'
assert not ROOT.exists();assert not subprocess.check_output(['git','diff','--name-only','HEAD','--'],cwd=OLD)
subprocess.run(['git','worktree','add','--no-checkout','--detach',str(ROOT),HEAD],cwd=MAIN,check=True,capture_output=True)
for encoded in subprocess.check_output(['git','ls-tree','-r','--name-only','-z',HEAD],cwd=MAIN).split(b'\0'):
 if not encoded:continue
 name=encoded.decode();old=OLD/name;p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True)
 if old.is_symlink():p.symlink_to(os.readlink(old))
 else:os.link(old,p)
subprocess.run(['git','read-tree',HEAD],cwd=ROOT,check=True,capture_output=True)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
mutable=['bindings/rust/Cargo.toml','bindings/rust/Cargo.lock','bindings/rust/openui-text/Cargo.toml','bindings/rust/openui-geometry/src/raster.rs','bindings/rust/openui-text/src/font/collection.rs','bindings/rust/openui-text/src/font/platform.rs','bindings/rust/openui-paint/src/emphasis_painter.rs','bindings/rust/openui-paint/src/text_painter.rs','bindings/rust/openui-text/src/shaping/shape_result.rs','bindings/rust/openui/examples/native_glyph_coverage.rs']+[str(p.relative_to(ROOT)) for p in (ROOT/'docs/v02/generated').iterdir() if p.is_file()]
for name in mutable:
 p=ROOT/name
 if p.exists():tmp=p.with_name(p.name+'.isolated-v1941');shutil.copy2(p,tmp);tmp.replace(p)
p=Path('/tmp/openui-native-fontations-current-source-v1942.py');assert not p.exists();s=Path('/tmp/openui-native-fontations-current-source-v1940.py').read_text().replace(str(OLD),str(ROOT)).replace('source-v1940.json','source-v1942.json')
s=s.replace("'uint32_t factory_id(const SkTypeface&);'","'uint32_t factory_id(const SkTypeface& face);'")
s=s.replace('uint32_t factory_id(const SkTypeface&);\\n','uint32_t factory_id(const SkTypeface& face);\\n')
a=s.index("a=policy_platform.index('    #[test]\\n    fn fontations_linux_metrics_match_repeated_chromium_scale_queries');")
b=s.index("p=RUST/'openui-paint/src/emphasis_painter.rs'",a)
s=s[:a]+'''a=policy_platform.index('    #[test]\\n    fn fontations_explicit_hinting_remains_fixed_across_scales')
b=policy_platform.index('    #[test]\\n    fn aliased_ahem_hinting_tracks_computed_font_size',a)
new_guards=policy_platform[a:b]
p.write_text(p.read_text().rstrip()[:-1]+'\\n'+new_guards+'}\\n')
'''+s[b:]
p.write_text(s)
meta=dict(root=str(ROOT),prior_partial_root=str(OLD),prior_failed_at='factory-header exact declaration preflight',prior_compilation_not_run=True,prior_source_and_probe_preserved=True,all_mutable_paths_isolated=True,windows_preflight_failure_was_file_modes=True,windows_bytes_clean_with_filemode_false=True,release_qualification=False)
Path('/tmp/openui-native-fontations-current-retry-v1941.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta),flush=True)
