use openui::prelude::*;
use openui_geometry::LayoutUnit;
use openui_text::{Font, FontDescription, TextDirection, TextShaper};
use serde_json::json;
use std::error::Error;

fn main() -> Result<(), Box<dyn Error>> {
    let collection = FontCollection::deterministic_test();
    let shaper = TextShaper::new();
    for scale in [1.0, 1.25, 1.5, 2.0, 3.0] {
        for (policy, raster) in [
            ("default", RasterConfiguration::default()),
            (
                "deterministic-alias",
                RasterConfiguration::deterministic_aliased(false),
            ),
            (
                "deterministic-alias-subpixel",
                RasterConfiguration::deterministic_aliased(true),
            ),
            (
                "fontations-lcd",
                RasterConfiguration::chromium_linux_fontations_lcd(),
            ),
        ] {
            for family in ["deterministic", "DejaVu Sans"] {
                let families = if family == "deterministic" {
                    FontFamilyList {
                        families: [
                            "Ahem",
                            "Droid Sans Fallback",
                            "Noto Sans Devanagari",
                            "Noto Color Emoji",
                            "DejaVu Sans",
                        ]
                        .into_iter()
                        .map(|name| FontFamily::Named(name.into()))
                        .collect(),
                    }
                } else {
                    FontFamilyList::single(family)
                };
                for size in [15.0, 16.0, 18.72] {
                    let document = Document::with_font_collection_and_options(
                        ViewportMetrics::from_logical_size(800.0, 600.0, scale)?,
                        collection.clone(),
                        EngineOptions {
                            raster_configuration: raster,
                        },
                    )?;
                    let element = Element::create(&document, "div")?;
                    element.set_position(Position::Absolute)?;
                    element.set_font_family(families.clone())?;
                    element.set_font_size(LengthValue::px(size))?;
                    element.set_font_kerning(FontKerning::None)?;
                    element.set_font_variant_ligatures(FontVariantLigatures::none())?;
                    element.set_line_height(LineHeight::Number(1.0))?;
                    document.body().append_child(&element)?;
                    for writing in [WritingMode::HorizontalTb, WritingMode::VerticalLr] {
                        element.set_writing_mode(writing)?;
                        for text in [
                            "X",
                            "XX",
                            "XXXXXXXXXXXXX",
                            "non-spanner",
                            "in",
                            "caption",
                            "non-spanner in caption",
                            "in the box",
                            "min",
                        ] {
                            element.set_text(text)?;
                            element.set_width(Length::auto().into())?;
                            element.set_height(Length::auto().into())?;
                            let natural =
                                element.bounding_rect()?.ok_or("natural bounds required")?;
                            let desc =
                                FontDescription::from_computed_style(&element.computed_style()?);
                            let font = Font::new_in_collection(desc, collection.clone());
                            let shape = shaper.shape(text, &font, TextDirection::Ltr);
                            let raw = font.width(text);
                            if writing == WritingMode::HorizontalTb {
                                element.set_width(Length::min_content().into())?;
                            } else {
                                element.set_height(Length::min_content().into())?;
                            }
                            let minimum =
                                element.bounding_rect()?.ok_or("minimum bounds required")?;
                            let data = font.primary_font().ok_or("resolved font required")?;
                            let sk_font = data.sk_font();
                            println!(
                                "{}",
                                json!({
                                    "policy":policy, "family":family, "size":size, "scale":scale, "writing":format!("{:?}",writing), "text":text,
                                    "raw_width":raw,"raw_width_bits":raw.to_bits(),"shaped_width":shape.width,"shaped_width_bits":shape.width.to_bits(),
                                    "raw_ceil":LayoutUnit::from_f32_ceil(raw).to_f32(),"shaped_ceil":LayoutUnit::from_f32_ceil(shape.width).to_f32(),
                                    "natural":{"x":natural.x,"y":natural.y,"width":natural.width,"height":natural.height},
                                    "minimum":{"x":minimum.x,"y":minimum.y,"width":minimum.width,"height":minimum.height},
                                    "hinting":format!("{:?}",sk_font.hinting()),"edging":format!("{:?}",sk_font.edging()),
                                    "subpixel":sk_font.is_subpixel(),"linear_metrics":sk_font.is_linear_metrics(),
                                })
                            );
                        }
                    }
                }
            }
        }
    }
    Ok(())
}
