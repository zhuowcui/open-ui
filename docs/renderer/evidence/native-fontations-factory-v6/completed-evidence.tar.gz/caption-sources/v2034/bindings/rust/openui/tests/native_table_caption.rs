use openui::prelude::*;
use std::cell::Cell;
use std::rc::Rc;

#[test]
fn native_caption_minimum_is_a_wrapper_floor_across_spacing_and_callbacks() {
    // Independent Chromium captures give the longest unbroken caption word
    // a 133px advance in this explicit aliased policy at all five scales.
    // Empty-grid spacing must not be added to that caption contribution.
    for scale in [1.0, 1.25, 1.5, 2.0, 3.0] {
        for spacing in [0.0, 2.0, 8.0] {
            let document = Document::with_font_collection_and_options(
                ViewportMetrics::from_logical_size(800.0, 600.0, scale).unwrap(),
                FontCollection::deterministic_test(),
                EngineOptions {
                    raster_configuration: RasterConfiguration::deterministic_aliased(false),
                },
            )
            .unwrap();
            let table = Element::create(&document, "table").unwrap();
            let container = Element::create(&document, "div").unwrap();
            container.set_width(LengthValue::px(156.0)).unwrap();
            document.body().append_child(&container).unwrap();
            table.set_display(Display::Table).unwrap();
            table
                .set_border_spacing((Length::px(spacing), Length::px(spacing)))
                .unwrap();
            table
                .set_font_family(FontFamilyList {
                    families: [
                        "Ahem",
                        "Droid Sans Fallback",
                        "Noto Sans Devanagari",
                        "Noto Color Emoji",
                        "DejaVu Sans",
                    ]
                    .into_iter()
                    .map(|name| FontFamily::Named(name.into()))
                    .collect(),
                })
                .unwrap();
            table.set_font_kerning(FontKerning::None).unwrap();
            table
                .set_font_variant_ligatures(FontVariantLigatures::none())
                .unwrap();
            container.append_child(&table).unwrap();
            let caption = Element::create(&document, "caption").unwrap();
            caption.set_display(Display::TableCaption).unwrap();
            table.append_child(&caption).unwrap();
            let heading = Element::create(&document, "div").unwrap();
            heading.set_font_size(LengthValue::px(18.72)).unwrap();
            heading.set_text("non-spanner in caption").unwrap();
            caption.append_child(&heading).unwrap();
            let before = table.bounding_rect().unwrap().unwrap();
            assert_eq!(before.width, 133.0, "scale={scale}, spacing={spacing}");
            let owned_caption = caption.bounding_rect().unwrap().unwrap();
            assert_eq!(owned_caption.width, 133.0);
            let calls = Rc::new(Cell::new(0));
            let observed = Rc::clone(&calls);
            let weak = heading.downgrade();
            let target = weak.clone();
            heading
                .on("click", move |_| {
                    target.upgrade().unwrap().set_text("caption").unwrap();
                    observed.set(observed.get() + 1);
                })
                .unwrap();
            heading.click().unwrap();
            assert_eq!(calls.get(), 1);
            assert_eq!(heading.text_content().unwrap(), "caption");
            assert_eq!(table.bounding_rect().unwrap().unwrap().width, 133.0);
            assert_eq!(owned_caption.width, 133.0);
            drop(heading);
            drop(caption);
            drop(table);
            drop(container);
            drop(document);
            assert!(weak.upgrade().is_none());
        }
    }
}
