"""Observe reduced geometry with the unchanged offline Chromium capture harness."""
import fcntl, hashlib, html, json, subprocess, sys
from pathlib import Path
from PIL import Image

MAIN=Path('/home/nero/code/open-ui'); SDK=Path('/dev/shm/openui-native-rgba-font-v1989'); RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1'
NAME='native-intrinsic-chromium-v2027'; OUT=RAW/NAME; STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/NAME
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','ninja','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
sys.path.insert(0,str(SDK/'tools/qualification'));from renderer_source_identity import repository_source_identity
sys.path.insert(0,str(SDK/'tools/accountability'));import run_all_pixel_comparisons as capture
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
chrome=MAIN/'chrome/linux-147.0.7727.50/chrome-linux64/chrome';assert sha(chrome)=='0ba87684df0afc11faaea40ac57bd2f1d68b67191443b38215a36b90e6f08848'
source=repository_source_identity(SDK);assert source['clean'] and source['commit'].startswith('02401648')
native_receipt=RAW/'native-intrinsic-trace-pipeline-v2022/receipt.json';native=json.loads(native_receipt.read_bytes());assert native['all_commands_terminal'] and native['observed_exit_code']==0 and native['sdk_source']==source
rows=[json.loads(l) for l in (native_receipt.parent/'native-first.log').read_text().splitlines()]
report=dict(schema_version=1,source=source,owner_pid=__import__('os').getpid(),all_commands_terminal=False,release_qualification=False,promotion_allowed=False,javascript_executed_by_openui=False,offline_javascript_executed_only_in_chromium=True,chromium_binary_sha256=sha(chrome),capture_harness_sha256=sha(SDK/'tools/accountability/run_all_pixel_comparisons.py'),native_receipt_sha256=sha(native_receipt),probe_sha256=sha(Path(__file__)),reduced=[],original=[],capture_process_wrapped_in_strace=True,crash_profiles_preserved=True)
save=lambda:(OUT/'receipt.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');save()
original_ws=capture._CdpWebSocket
original_temporary_directory=capture.tempfile.TemporaryDirectory
class KeptTemporaryDirectory(original_temporary_directory):
 def cleanup(self):self._finalizer.detach()
capture.tempfile.TemporaryDirectory=KeptTemporaryDirectory
def observe(path,output,expression,width,height,scale):
 observations=[]
 class QueryWebSocket(original_ws):
  def command(self,method,params=None):
   result=super().command(method,params)
   if method=='Page.captureScreenshot' and not observations:
    q=super().command('Runtime.evaluate',{'expression':expression,'awaitPromise':True,'returnByValue':True})
    assert 'exceptionDetails' not in q, q.get('exceptionDetails')
    observations.append(q['result']['value'])
   return result
 capture._CdpWebSocket=QueryWebSocket
 processes=[]; exceptions=[]; stderr_path=output.with_suffix('.stderr.log'); stderr_stream=stderr_path.open('xb'); original_popen=capture.subprocess.Popen
 def launch(command,*args,**kwargs):
  if command and command[0]==str(chrome):
   command=['strace','-ff','-o',str(output.with_suffix('.syscalls')),'-e','trace=file,process,memory',*command];kwargs['stderr']=stderr_stream
  process=original_popen(command,*args,**kwargs);processes.append(process);return process
 def trace(frame,event,arg):
  if event=='exception' and frame.f_code.co_filename==str(SDK/'tools/accountability/run_all_pixel_comparisons.py'):
   exceptions.append(dict(function=frame.f_code.co_name,type=arg[0].__name__,message=str(arg[1])))
  return trace
 capture.subprocess.Popen=launch;sys.settrace(trace)
 try:
  ok=capture.render_chrome(str(path),str(output),str(chrome),str(chrome.parent),use_ahem_noaa=True,logical_width=width,logical_height=height,device_scale=scale)
 finally:
  sys.settrace(None);capture._CdpWebSocket=original_ws;capture.subprocess.Popen=original_popen;stderr_stream.close()
  attempt=dict(output=str(output),query_count=len(observations),exceptions=exceptions,process_actual_exits=[p.poll() for p in processes],stderr_sha256=sha(stderr_path));(output.with_suffix('.attempt.json')).write_text(json.dumps(attempt,sort_keys=True,indent=2)+'\n')
  if not observations:print(json.dumps(attempt),flush=True)
 assert ok and len(observations)==1, f'Chromium capture/query failed: capture_ok={ok}, query_count={len(observations)}'
 return observations[0]
def rgba(path):
 with Image.open(path) as image:return image.size,image.convert('RGBA').tobytes()
try:
 for scale in [1.0,1.25,1.5,2.0,3.0]:
  chosen=[r for r in rows if r['scale']==scale and r['policy']=='deterministic-alias'];assert len(chosen)==108
  directory=OUT/('reduced-'+str(scale));directory.mkdir();path=directory/'test.html'
  parts=['<!doctype html><style>*{margin:0;padding:0;box-sizing:content-box}body{font-size:16px}div{position:absolute;left:0;top:0;font-kerning:none;font-variant-ligatures:none;font-synthesis:none;line-height:1}</style>']
  for i,r in enumerate(chosen):
   family='Ahem, "Droid Sans Fallback", "Noto Sans Devanagari", "Noto Color Emoji", "DejaVu Sans"' if r['family']=='deterministic' else '"DejaVu Sans"'
   size='18.72' if abs(r['size']-18.72)<.001 else str(r['size'])
   writing='horizontal-tb' if r['writing']=='HorizontalTb' else 'vertical-lr'
   parts.append(f'<div id="r{i}" data-writing="{writing}" style="font-family:{html.escape(family,quote=True)};font-size:{size}px;writing-mode:{writing}">{html.escape(r["text"])}</div>')
  path.write_text(''.join(parts))
  expression=r'''(() => { const nodes=[...document.querySelectorAll('body>div')]; const rect=n=>{const b=n.getBoundingClientRect();return {x:b.x,y:b.y,width:b.width,height:b.height}}; const natural=nodes.map(rect); const style=nodes.map(n=>({fontSize:getComputedStyle(n).fontSize,fontFamily:getComputedStyle(n).fontFamily,writingMode:getComputedStyle(n).writingMode})); nodes.forEach(n=>{if(n.dataset.writing==='horizontal-tb') n.style.width='min-content';else n.style.height='min-content'}); const result=nodes.map((n,i)=>({id:n.id,natural:natural[i],minimum:rect(n),style:style[i]})); nodes.forEach(n=>{n.style.width='auto';n.style.height='auto'}); return result;})()'''
  queries=[]
  for repeat in [1,2]:
   image=directory/(str(repeat)+'.png');q=observe(path,image,expression,800,600,scale);queries.append(q)
   (directory/(str(repeat)+'-geometry.json')).write_text(json.dumps(q,sort_keys=True,indent=2)+'\n')
  assert queries[0]==queries[1] and (directory/'1.png').read_bytes()==(directory/'2.png').read_bytes()
  observations=[]
  for i,(r,c) in enumerate(zip(chosen,queries[0])):
   assert c['id']=='r'+str(i)
   axis='width' if r['writing']=='HorizontalTb' else 'height'
   observations.append(dict(family=r['family'],size=r['size'],writing=r['writing'],text=r['text'],native_natural=r['natural'][axis],chromium_natural=c['natural'][axis],native_minimum=r['minimum'][axis],chromium_minimum=c['minimum'][axis],raw_width=r['raw_width'],shaped_width=r['shaped_width'],natural_inline_exact=r['natural'][axis]==c['natural'][axis],minimum_inline_exact=r['minimum'][axis]==c['minimum'][axis]))
  row=dict(scale=scale,html_sha256=sha(path),first_png_sha256=sha(directory/'1.png'),second_png_sha256=sha(directory/'2.png'),repeated_png_and_queries_identical=True,observations=observations)
  report['reduced'].append(row);save();print(json.dumps(dict(scale=scale,reduced_rows=len(observations),natural_inline_exact=sum(r['natural_inline_exact'] for r in observations),minimum_inline_exact=sum(r['minimum_inline_exact'] for r in observations))),flush=True)
 regression=json.loads((RAW/'native-rgba-font-regression-evidence-v2006.json').read_bytes())
 originals=[r for r in regression['comparisons'] if r['id'] in ['wpt/css_multicol/multicol-span-all-004','wpt/css_sizing/block-size-with-min-or-max-content-1-ref']]
 assert len(originals)==6
 expression=r'''(() => [...document.querySelectorAll('body,body *')].filter(n=>n.tagName!=='STYLE').map((n,i)=>{const b=n.getBoundingClientRect(),s=getComputedStyle(n),ranges=[];for(const child of n.childNodes){if(child.nodeType===Node.TEXT_NODE&&child.textContent.trim()){const r=document.createRange();r.selectNodeContents(child);ranges.push(...[...r.getClientRects()].map(b=>({x:b.x,y:b.y,width:b.width,height:b.height})))}}return {index:i,tag:n.tagName,id:n.id,text:n.textContent.trim(),bounds:{x:b.x,y:b.y,width:b.width,height:b.height},fontSize:s.fontSize,writingMode:s.writingMode,textAlign:s.textAlign,ranges}}))()'''
 for number,r in enumerate(originals):
  directory=OUT/('original-'+str(number));directory.mkdir();path=directory/'test.html';path.write_bytes(Path(r['html_path']).read_bytes());assert sha(path)==r['html_sha256']
  profile=r['profile'];width,height,scale={'legacy-800x600@1':(800,600,1.0),'desktop-1280x720@1.25':(1280,720,1.25),'desktop-1920x1080@1.5':(1920,1080,1.5),'mobile-375x667@2':(375,667,2.0)}[profile]
  queries=[]
  for repeat in [1,2]:
   image=directory/(str(repeat)+'.png');q=observe(path,image,expression,width,height,scale);queries.append(q);(directory/(str(repeat)+'-geometry.json')).write_text(json.dumps(q,sort_keys=True,indent=2)+'\n')
   assert rgba(image)==rgba(Path(r['chromium_path'])),'original Chromium pixels changed'
  assert queries[0]==queries[1] and (directory/'1.png').read_bytes()==(directory/'2.png').read_bytes()
  report['original'].append(dict(id=r['id'],profile=profile,html_sha256=sha(path),original_chromium_path=r['chromium_path'],original_chromium_sha256=r['chromium_sha256'],first_png_sha256=sha(directory/'1.png'),second_png_sha256=sha(directory/'2.png'),repeated_png_and_queries_identical=True,original_chromium_rgba_unchanged=True,geometry_path=str(directory/'1-geometry.json'),geometry_sha256=sha(directory/'1-geometry.json')));save()
  print(json.dumps(dict(original=r['id'],profile=profile,repeated_original_chromium_rgba_unchanged=True)),flush=True)
 report.update(observed_exit_code=0,totals=dict(reduced_geometry_rows=540,repeated_reduced_capture_pairs=5,repeated_original_capture_pairs=len(originals),all_original_chromium_rgba_unchanged=True))
except BaseException as error:
 report.update(observed_exit_code=1,failure=str(error));raise
finally:
 report.update(all_commands_terminal=True,source_after=repository_source_identity(SDK));report['source_unchanged']=report['source_after']==source
 assert report['source_unchanged'] and sha(chrome)==report['chromium_binary_sha256'] and sha(native_receipt)==report['native_receipt_sha256'];save()
raise SystemExit(report['observed_exit_code'])
