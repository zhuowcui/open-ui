"""Own the entire diagnostic build/query sequence and record actual exits."""
import fcntl, hashlib, json, os, shutil, signal, subprocess, sys, time
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui'); SDK=Path('/dev/shm/openui-native-rgba-font-v1989'); ROOT=Path('/dev/shm/openui-native-intrinsic-trace-v2021')
RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1'; NAME='native-intrinsic-trace-pipeline-v2022'
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','ninja','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
OUT=RAW/NAME; STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/NAME
assert not OUT.exists() and not STORE.exists(); STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
TMP=STORE/'compiler-tmp';TMP.mkdir()
env=dict(os.environ,CARGO_TARGET_DIR='/mnt/e/openui-v02-cargo-c73754e2/target',CARGO_INCREMENTAL='0',RUST_MIN_STACK='4194304',CARGO_BUILD_JOBS='4',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(TMP),CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
base=['cargo','--config',str(SDK/'bindings/rust/.cargo/config.chromium.toml')]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(2**20),b''):h.update(chunk)
 return h.hexdigest()
sys.path.insert(0,str(SDK/'tools/qualification'));from renderer_source_identity import repository_source_identity
source=repository_source_identity(SDK);assert source['clean'] and source['commit']=='02401648d6fecfb0d36c330635b1000b8ce2df39'
report=dict(schema_version=1,sdk_source=source,owner_pid=os.getpid(),all_commands_terminal=False,whole_pipeline_lock_covers_all_stages_and_gaps=True,release_qualification=False,promotion_allowed=False,javascript_executed_by_openui=False,steps=[],probe_sha256=sha(Path(__file__)))
save=lambda:(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');save()
def identity():
 return dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=ROOT,text=True).strip(),clean=not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT))
def run(name,cmd):
 log=OUT/(name+'.log')
 with log.open('xb') as stream:
  child=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True);report['current_process']=dict(pid=child.pid,stage=name);save();guard=False
  while child.poll() is None:
   if shutil.disk_usage(MAIN).free<512*2**20 or shutil.disk_usage(STORE).free<10*2**30:
    guard=True;os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=20);break
   time.sleep(1)
  child.wait()
 report.pop('current_process');row=dict(name=name,observed_exit_code=child.returncode,disk_guard_triggered=guard,log_sha256=sha(log));report['steps'].append(row);save();print(json.dumps(row),flush=True)
 assert not guard and child.returncode==0, name+' failed'
 assert repository_source_identity(SDK)==source,'measured SDK changed'
 if 'source' in report:assert identity()==report['source'],'diagnostic source changed'
try:
 run('format',['bash','-c','ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true src/main.rs'])
 run('locked-metadata',base+['metadata','--offline','--format-version','1'])
 subprocess.run(['git','add','.'],cwd=ROOT,check=True,capture_output=True);subprocess.run(['git','commit','-m','Reduce caption and vertical intrinsic widths through public Rust APIs'],cwd=ROOT,check=True,capture_output=True)
 report['source']=identity();assert report['source']['clean'];report['lockfile_sha256']=sha(ROOT/'Cargo.lock');save()
 run('diagnostic-build',base+['build','--offline','--locked'])
 binary=OUT/'openui-native-intrinsic-trace';shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/openui-native-intrinsic-trace',binary);report['binary_sha256']=sha(binary);save()
 run('native-first',[str(binary)]);run('native-second',[str(binary)])
 assert (OUT/'native-first.log').read_bytes()==(OUT/'native-second.log').read_bytes()
 rows=[json.loads(line) for line in (OUT/'native-first.log').read_text().splitlines()];assert len(rows)==2160
 report.update(observed_exit_code=0,totals=dict(native_rows=len(rows),repeated_native_output_identical=True,raw_shaped_width_differences=sum(r['raw_width_bits']!=r['shaped_width_bits'] for r in rows)))
 print(json.dumps(report['totals']),flush=True)
except BaseException as error:
 report.update(observed_exit_code=1,failure=str(error));raise
finally:
 report['all_commands_terminal']=True;report['sdk_source_after']=repository_source_identity(SDK);report['sdk_source_unchanged']=report['sdk_source_after']==source
 if 'source' in report:report['source_after']=identity();report['source_unchanged']=report['source_after']==report['source']
 if not report['sdk_source_unchanged'] or report.get('source_unchanged') is False:report.update(observed_exit_code=1,failure='source changed during pipeline')
 save()
raise SystemExit(report['observed_exit_code'])
