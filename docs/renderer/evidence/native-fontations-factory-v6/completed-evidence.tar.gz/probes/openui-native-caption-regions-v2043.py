"""Preserve exact image diagnostics for the complete caption follow-up."""
import hashlib
import json
import shutil
import sys
from pathlib import Path

MAIN = Path('/home/nero/code/open-ui')
RAW = MAIN / 'out/renderer-evidence/native-viewport-scroll-v1'
NAME = 'native-caption-regions-v2043'
OUT = RAW / NAME
STORE = Path('/mnt/e/openui-v02-qualification-d174ea0b') / NAME
assert not OUT.exists() and not STORE.exists()
load = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
owner = load(RAW / 'native-caption-pipeline-v2035/receipt.json')
assert owner['all_commands_terminal'] and owner['source_unchanged']
audit = load(RAW / 'native-caption-audit-v2039.json')
assert audit['source'] == owner['source']
sys.path.insert(0, str(MAIN / 'tools/qualification'))
from residuals import analyze_image_difference

STORE.mkdir()
OUT.symlink_to(STORE, target_is_directory=True)
prior = load(RAW / 'native-rgba-font-regression-evidence-v2006.json')
keys = {(r['profile'], r['id']) for r in prior['comparisons']}
keys.update((r['profile'], r['id']) for r in audit['suites']['full']['changed_comparisons'])
summary = load(RAW / 'native-caption-pipeline-v2035/full-matrix/full-summary.json')
current = {(p['profile'], r['id']): r for p in summary['profiles'] for r in p['tests']}
rows = []
for profile, test_id in sorted(keys):
    source = RAW / 'native-caption-pipeline-v2035/full-matrix' / profile / test_id
    accepted = RAW / 'native-event-targets-clean-full-v1456' / profile / test_id
    earlier = RAW / 'native-rgba-font-pipeline-v1990/full-matrix' / profile / test_id
    target = OUT / profile / test_id
    target.mkdir(parents=True)
    paths = {'test.html': source / 'test.html', 'chromium.png': source / 'chromium.png',
             'candidate.png': source / 'openui.png', 'accepted.png': accepted / 'openui.png',
             'prior-trial.png': earlier / 'openui.png'}
    for name, path in paths.items():
        shutil.copyfile(path, target / name)
        assert sha(target / name) == sha(path)
    row = current[profile, test_id]
    assert sha(paths['chromium.png']) == row['chromium_png_sha256']
    assert sha(paths['candidate.png']) == row['openui_png_sha256']
    assert sha(paths['chromium.png']) == sha(accepted / 'chromium.png') == sha(earlier / 'chromium.png')
    diagnostics = {name: analyze_image_difference(paths['chromium.png'], paths[name])
                   for name in ['candidate.png', 'accepted.png', 'prior-trial.png']}
    assert diagnostics['candidate.png']['mismatched_pixels'] == row['mismatched_pixels']
    caption = 'multicol-span-all-004' in test_id
    rows.append(dict(profile=profile, id=test_id, status=row['status'],
                     files={name: dict(path=str((target / name).relative_to(OUT)), sha256=sha(path))
                            for name, path in paths.items()},
                     native_versus_chromium=diagnostics,
                     source_paths={name: str(path) for name, path in paths.items()},
                     owner='shared table caption sizing' if caption else 'shared intrinsic text and positioned sizing',
                     reviewed_caption_root_cause=caption,
                     reviewed_caption_cause_applies_to_prior_width_regression=caption,
                     current_residual_root_cause_review_complete=row['status'] == 'exact',
                     remaining_sizing_root_cause_review_complete=False if not caption else None))
report = dict(schema_version=1, source=owner['source'], all_commands_terminal=True,
              release_qualification=False, promotion_allowed=False, pixel_tolerance=0,
              reference_bytes_changed=False, comparisons=rows,
              formal_original_residual_ownership_unchanged=True,
              new_release_states_admitted=0, javascript_executed_by_openui=False,
              probe_sha256=sha(Path(__file__)))
receipt = OUT / 'receipt.json'
receipt.write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
print(json.dumps(dict(comparisons=len(rows), exact=sum(r['status'] == 'exact' for r in rows),
                     receipt_sha256=sha(receipt))), flush=True)
