"""Correct caption/grid floors in an isolated, immutable follow-up source."""
import fcntl,json,os,shutil,subprocess
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');OLD=Path('/dev/shm/openui-native-font-format-v1996');ROOT=Path('/dev/shm/openui-native-caption-v2030')
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','ninja','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=OLD,text=True).strip();assert HEAD=='24155c19ede6e72e5049b96007d4ade4cb2f3938'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=OLD) and not ROOT.exists()
subprocess.run(['git','worktree','add','--no-checkout','--detach',str(ROOT),HEAD],cwd=MAIN,check=True,capture_output=True)
for encoded in subprocess.check_output(['git','ls-tree','-r','--name-only','-z',HEAD],cwd=MAIN).split(b'\0'):
 if not encoded:continue
 name=encoded.decode();a,b=OLD/name,ROOT/name;b.parent.mkdir(parents=True,exist_ok=True)
 if a.is_symlink():b.symlink_to(os.readlink(a))
 else:os.link(a,b)
subprocess.run(['git','read-tree',HEAD],cwd=ROOT,check=True,capture_output=True)
p=ROOT/'bindings/rust/openui-layout/src/table.rs';t=p.with_name(p.name+'.isolated-v2030');shutil.copy2(p,t);t.replace(p)
old='''        // A caption-only table uses CAPMIN plus the table grid's structural
        // edge spacing. Populated auto tables keep their grid preferred width,
        // with CAPMIN acting only as a floor; the caption's max-content width
        // does not stretch the table to the available column measure.
        let caption_floor = if column_count == 0 {
            caption_min_outer_width + grid_border_box_width
        } else {
            caption_min_outer_width
        };
        grid_border_box_width.max_of(caption_floor)'''
new='''        // The caption and table grid constrain the same wrapper width.
        // CAPMIN is a floor alongside the grid's border-box contribution;
        // it does not acquire the grid's border spacing or edges, including
        // when no cells exist. The caption's max-content width does not
        // stretch an auto table to the available column measure.
        grid_border_box_width.max_of(caption_min_outer_width)'''
s=p.read_text();assert s.count(old)==1;p.write_text(s.replace(old,new))
p=ROOT/'bindings/rust/openui/tests/native_table_caption.rs';assert not p.exists()
p.write_text(r'''use openui::prelude::*;
use std::cell::Cell;
use std::rc::Rc;

#[test]
fn native_caption_minimum_is_a_wrapper_floor_across_spacing_and_callbacks() {
    // Independent Chromium captures give the longest unbroken caption word
    // a 133px advance in this explicit aliased policy at all five scales.
    // Empty-grid spacing must not be added to that caption contribution.
    for scale in [1.0, 1.25, 1.5, 2.0, 3.0] {
        for spacing in [0.0, 2.0, 8.0] {
            let document = Document::with_font_collection_and_options(
                ViewportMetrics::from_logical_size(800.0, 600.0, scale).unwrap(),
                FontCollection::deterministic_test(),
                EngineOptions {
                    raster_configuration: RasterConfiguration::deterministic_aliased(false),
                },
            ).unwrap();
            let table = Element::create(&document, "table").unwrap();
            table.set_position(Position::Absolute).unwrap();
            table.set_display(Display::Table).unwrap();
            table.set_border_spacing((Length::px(spacing), Length::px(spacing))).unwrap();
            table.set_font_family(FontFamilyList {
                families: ["Ahem", "Droid Sans Fallback", "Noto Sans Devanagari", "Noto Color Emoji", "DejaVu Sans"].into_iter().map(|name| FontFamily::Named(name.into())).collect(),
            }).unwrap();
            table.set_font_kerning(FontKerning::None).unwrap();
            table.set_font_variant_ligatures(FontVariantLigatures::none()).unwrap();
            document.body().append_child(&table).unwrap();
            let caption = Element::create(&document, "caption").unwrap();
            caption.set_display(Display::TableCaption).unwrap();
            table.append_child(&caption).unwrap();
            let heading = Element::create(&document, "div").unwrap();
            heading.set_font_size(LengthValue::px(18.72)).unwrap();
            heading.set_text("non-spanner in caption").unwrap();
            caption.append_child(&heading).unwrap();
            let before = table.bounding_rect().unwrap().unwrap();
            assert_eq!(before.width, 133.0, "scale={scale}, spacing={spacing}");
            let owned_caption = caption.bounding_rect().unwrap().unwrap();
            assert_eq!(owned_caption.width, 133.0);
            let calls=Rc::new(Cell::new(0));let observed=Rc::clone(&calls);
            let weak=heading.downgrade();let target=weak.clone();
            heading.on("click", move |_| {
                target.upgrade().unwrap().set_text("caption").unwrap();
                observed.set(observed.get()+1);
            }).unwrap();
            heading.click().unwrap();
            assert_eq!(calls.get(),1);
            assert_eq!(heading.text_content().unwrap(), "caption");
            assert_eq!(table.bounding_rect().unwrap().unwrap().width,133.0);
            assert_eq!(owned_caption.width,133.0);
            drop(heading);drop(caption);drop(table);drop(document);
            assert!(weak.upgrade().is_none());
        }
    }
}
''')
subprocess.run(['bash','-c','ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true bindings/rust/openui-layout/src/table.rs bindings/rust/openui/tests/native_table_caption.rs'],cwd=ROOT,check=True)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=OLD)
subprocess.run(['git','add','bindings/rust/openui-layout/src/table.rs','bindings/rust/openui/tests/native_table_caption.rs'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','Treat caption minimum and table grid edges as separate wrapper floors'],cwd=ROOT,check=True,capture_output=True)
print(json.dumps({'root':str(ROOT),'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'base_source_unchanged':True,'release_qualification':False,'applied':False}))
