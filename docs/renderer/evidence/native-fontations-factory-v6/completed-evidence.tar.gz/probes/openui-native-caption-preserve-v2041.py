"""Preserve the complete caption trial and the measurements that led to it."""
import gzip,hashlib,json,subprocess,tarfile
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';ROOT=Path('/dev/shm/openui-native-caption-v2034')
NAME='native-fontations-factory-v6';OUT=MAIN/'docs/renderer/evidence'/NAME;INDEX=MAIN/'docs/renderer/generated'/(NAME+'.json')
assert not OUT.exists() and not INDEX.exists()
load=lambda p:json.loads(p.read_bytes())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(2**20),b''):h.update(chunk)
 return h.hexdigest()
owner_path=RAW/'native-caption-pipeline-v2035/receipt.json';owner=load(owner_path)
assert owner['all_commands_terminal'] and owner['source_unchanged'] and owner['native_caption_guard_actually_executed']
audit_path=RAW/'native-caption-audit-v2039.json';audit=load(audit_path);assert audit['source']==owner['source']
checks=load(RAW/'native-caption-checks-v2037/receipt.json');assert checks['source']==owner['source'] and all(r['observed_exit_code']==0 for r in checks['checks'])
chromium=load(RAW/'native-intrinsic-chromium-v2029/receipt.json');assert chromium['all_commands_terminal'] and chromium['observed_exit_code']==0 and chromium['totals']['all_original_chromium_rgba_unchanged']
geometry_rows=[r for profile in chromium['reduced'] for r in profile['observations']]
assert len(geometry_rows)==540
geometry_counts=dict(comparisons=len(geometry_rows),natural_inline_exact=sum(r['natural_inline_exact'] for r in geometry_rows),minimum_inline_exact=sum(r['minimum_inline_exact'] for r in geometry_rows))
trace=load(RAW/'native-intrinsic-trace-pipeline-v2022/receipt.json');assert trace['all_commands_terminal'] and trace['observed_exit_code']==0
hosted=load(RAW/'native-font-complete-umbrella-hosted-v2020/receipt.json');assert hosted['all_commands_terminal'] and hosted['failed_jobs']==0 and hosted['all_nine_native_guards_executed_and_passed_in_hosted_parity']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
OUT.mkdir(parents=True);members={}
def add(name,p):
 assert name not in members and p.is_file();members[name]=p
skip={'pixel_compare','native_glyph_coverage','openui-native-intrinsic-trace','libopenui_ffi.so','libopenui.so.0','reproduction-index'}
directories=['native-intrinsic-trace-pipeline-v2015','native-intrinsic-trace-pipeline-v2017','native-intrinsic-trace-pipeline-v2019','native-intrinsic-trace-pipeline-v2022','native-font-complete-umbrella-hosted-v2020','native-intrinsic-chromium-v2023','native-intrinsic-chromium-v2024','native-intrinsic-chromium-v2025','native-intrinsic-chromium-v2026','native-intrinsic-chromium-v2027','native-intrinsic-chromium-v2028','native-intrinsic-chromium-v2029','native-caption-pipeline-v2032','native-caption-pipeline-v2035','native-caption-consumer-v2036','native-caption-checks-v2037','native-caption-source-repro-v2040','native-caption-regions-v2043']
for name in directories:
 root=RAW/name
 for child in sorted(root.iterdir()):
  if child.name in skip or child.name in ['compiler-tmp','chrome-tmp']:continue
  if child.name in ['full-matrix','expanded-matrix']:
   p=child/(child.name.removesuffix('-matrix')+'-summary.json');add(str(Path(name)/p.relative_to(root)),p);continue
  paths=[child] if child.is_file() else sorted(child.rglob('*'))
  for p in paths:
   if p.is_file() and p.name not in skip:add(str(Path(name)/p.relative_to(root)),p)
probes=['openui-native-intrinsic-trace-prepare-v2014.py','openui-native-intrinsic-trace-pipeline-v2015.py','openui-native-intrinsic-trace-retry-prepare-v2016.py','openui-native-intrinsic-trace-retry-prepare-v2016.json','openui-native-intrinsic-trace-pipeline-v2017.py','openui-native-intrinsic-trace-retry-prepare-v2018.py','openui-native-intrinsic-trace-retry-prepare-v2018.json','openui-native-intrinsic-trace-pipeline-v2019.py','openui-native-font-complete-umbrella-hosted-collect-v2020.py','openui-native-intrinsic-trace-retry-prepare-v2021.py','openui-native-intrinsic-trace-retry-prepare-v2021.json','openui-native-intrinsic-trace-pipeline-v2022.py',*[f'openui-native-intrinsic-chromium-v{i}.py' for i in range(2023,2030)],'openui-native-caption-prepare-v2030.py','openui-native-caption-pipeline-v2032.py','openui-native-caption-consumer-v2033.py','openui-native-caption-guard-prepare-v2034.py','openui-native-caption-pipeline-v2035.py','openui-native-caption-consumer-v2036.py','openui-native-caption-checks-v2037.py','openui-verified-terminal-binary-relocation-v2038.py','openui-verified-terminal-binary-relocation-v2038.json','openui-native-caption-audit-v2039.py','openui-native-caption-source-repro-v2040.py','openui-native-caption-preserve-v2041.py','openui-native-caption-regions-v2043.py']
for name in probes:add('probes/'+name,Path('/tmp')/name)
for n in [2014,2016,2018,2021]:
 root=Path('/dev/shm')/('openui-native-intrinsic-trace-v'+str(n))
 for name in ['Cargo.toml','Cargo.lock','src/main.rs','.gitignore']:add('diagnostic-sources/v'+str(n)+'/'+name,root/name)
for n in [2030,2034]:
 root=Path('/dev/shm')/('openui-native-caption-v'+str(n))
 for name in ['bindings/rust/openui-layout/src/table.rs','bindings/rust/openui/tests/native_table_caption.rs']:add('caption-sources/v'+str(n)+'/'+name,root/name)
add('paired-audit.json',audit_path)
proof=load(RAW/'native-caption-source-repro-v2040/receipt.json');assert proof['entire_tracked_tree_exact'] and proof['source']==owner['source']
p=RAW/'native-caption-source-repro-v2040/source.patch';assert sha(p)==proof['patch_sha256']
compressed=OUT/'measured-from-9f0d2211.patch.gz'
with compressed.open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',mtime=0) as gz:
  with p.open('rb') as s:
   while chunk:=s.read(2**20):gz.write(chunk)
archive=OUT/'completed-evidence.tar.gz';records=[]
with archive.open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,p in sorted(members.items()):
    r=dict(name=name,bytes=p.stat().st_size,sha256=sha(p),source_path=str(p));info=tarfile.TarInfo(name);info.size=r['bytes'];info.mode=0o644;info.mtime=0
    with p.open('rb') as s:tar.addfile(info,s)
    records.append(r)
with tarfile.open(archive,'r:gz') as tar:
 entries=tar.getmembers();assert len(entries)==len(records)
 for entry,r in zip(entries,records):
  assert entry.name==r['name'];h=hashlib.sha256()
  with tar.extractfile(entry) as s:
   for chunk in iter(lambda:s.read(2**20),b''):h.update(chunk)
  assert h.hexdigest()==r['sha256']
record=dict(schema_version=1,source=owner['source'],source_after=owner['source_after'],all_commands_terminal=True,release_qualification=False,candidate_applied_to_umbrella=False,promotion_allowed=False,new_release_states_admitted=0,javascript_executed_by_openui=False,pixel_tolerance=0,
 reviewed_caption_root_cause='The caption minimum and table grid border-box width constrain the same wrapper; adding grid spacing to CAPMIN double-counted an empty grid contribution. Prior unshaped text metrics accidentally canceled that layout error.',
 native_caption_callback_and_owned_geometry_guard_executed=True,remaining_intrinsic_text_and_native_api_gaps_open=True,
 workspace_tests=next(r for r in owner['steps'] if r['name']=='workspace'),read_only_checks_passed=len(checks['checks']),
 suites={name:{k:v for k,v in r.items() if k!='changed_comparisons'} for name,r in audit['suites'].items()},native_totals=audit['native_totals'],
 chromium_geometry=dict(totals=chromium['totals'],inline_geometry_comparison=geometry_counts,capture_process_switches_added=chromium['capture_process_switches_added'],diagnostic_environment=True,original_reference_rgba_unchanged=True,framework_javascript_executed=False),
 native_intrinsic_trace=dict(receipt_sha256=sha(RAW/'native-intrinsic-trace-pipeline-v2022/receipt.json'),sdk_source=trace['sdk_source'],no_pixel_qualification_from_geometry_trace=True),
 hosted_umbrella=dict(source=hosted['source'],successful_jobs=hosted['successful_jobs'],skipped_jobs=hosted['skipped_jobs'],failed_jobs=hosted['failed_jobs'],all_nine_native_guards_executed_and_passed=True,not_attributed_to_private_caption_source=True),
 failed_attempts_preserved=True,prepare_v2018_metadata_correction='Its prior attempt reached a native build and exited 101; the failed_before_build label in that preparation receipt is incorrect. The actual pipeline receipt and build log are authoritative.',
 full_census_summaries_archived=True,full_census_individual_image_caches_not_duplicated=True,formal_original_residual_ownership_unchanged=True,
 archive=dict(path=str(archive.relative_to(MAIN)),sha256=sha(archive),bytes=archive.stat().st_size,all_members_hash_verified=True,members=records),
 reproduction_patch=dict(path=str(compressed.relative_to(MAIN)),sha256=sha(compressed),bytes=compressed.stat().st_size,reproduction=proof),probe_sha256=sha(Path(__file__)))
INDEX.write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(index=str(INDEX),index_sha256=sha(INDEX),archive_bytes=archive.stat().st_size,archive_members=len(records),source=owner['source']['commit'])),flush=True)
