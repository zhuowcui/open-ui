"""Correct caption/grid floors in an isolated, immutable follow-up source."""
import fcntl,json,os,shutil,subprocess
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');OLD=Path('/dev/shm/openui-native-caption-v2030');ROOT=Path('/dev/shm/openui-native-caption-v2034')
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','ninja','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=OLD,text=True).strip();assert HEAD=='5c35b286c3e50132887e7c6118f6e2d7d15a80b0'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=OLD) and not ROOT.exists()
subprocess.run(['git','worktree','add','--no-checkout','--detach',str(ROOT),HEAD],cwd=MAIN,check=True,capture_output=True)
for encoded in subprocess.check_output(['git','ls-tree','-r','--name-only','-z',HEAD],cwd=MAIN).split(b'\0'):
 if not encoded:continue
 name=encoded.decode();a,b=OLD/name,ROOT/name;b.parent.mkdir(parents=True,exist_ok=True)
 if a.is_symlink():b.symlink_to(os.readlink(a))
 else:os.link(a,b)
subprocess.run(['git','read-tree',HEAD],cwd=ROOT,check=True,capture_output=True)
p=ROOT/'bindings/rust/openui/tests/native_table_caption.rs';t=p.with_name(p.name+'.isolated-v2034');shutil.copy2(p,t);t.replace(p)
s=p.read_text();assert s.count('table.set_position(Position::Absolute).unwrap();')==1
s=s.replace('table.set_position(Position::Absolute).unwrap();', 'let container = Element::create(&document, "div").unwrap();\n            container.set_width(LengthValue::px(156.0)).unwrap();\n            document.body().append_child(&container).unwrap();')
s=s.replace('document.body().append_child(&table).unwrap();','container.append_child(&table).unwrap();')
p.write_text(s)
subprocess.run(['bash','-c','ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true bindings/rust/openui/tests/native_table_caption.rs'],cwd=ROOT,check=True)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=OLD)
subprocess.run(['git','add','bindings/rust/openui/tests/native_table_caption.rs'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','Exercise caption minimum in ordinary constrained native table flow'],cwd=ROOT,check=True,capture_output=True)
print(json.dumps({'root':str(ROOT),'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'production_code_unchanged_from_5c35b286':True,'release_qualification':False,'applied':False}))
