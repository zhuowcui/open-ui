import fcntl,hashlib,json,shutil,subprocess
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');OLD=Path('/dev/shm/openui-native-intrinsic-trace-v2018');ROOT=Path('/dev/shm/openui-native-intrinsic-trace-v2021')
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','ninja','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
assert not ROOT.exists();ROOT.mkdir();(ROOT/'src').mkdir()
for name in ['Cargo.toml','Cargo.lock','.gitignore','src/main.rs']:shutil.copy2(OLD/name,ROOT/name)
subprocess.run(['git','init','-q'],cwd=ROOT,check=True)
for key in ['user.name','user.email']:
 value=subprocess.check_output(['git','config','--get',key],cwd=MAIN,text=True).strip();subprocess.run(['git','config','--local',key,value],cwd=ROOT,check=True)
(ROOT/'src/main.rs').write_text((ROOT/'src/main.rs').read_text().replace('FontFamilyList::single(family.into())','FontFamilyList::single(family)'))
record=dict(old_root_preserved=True,old_pipeline_terminal=True,prior_native_build_exit=101,retry_root=str(ROOT),local_git_author_identity_available=True)
Path('/tmp/openui-native-intrinsic-trace-retry-prepare-v2021.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n');print(json.dumps(record))
