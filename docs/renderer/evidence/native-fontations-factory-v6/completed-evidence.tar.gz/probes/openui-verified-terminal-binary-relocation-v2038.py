"""Move only one terminal archived binary; preserve its bytes and original path."""
import fcntl,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1'
owner=json.loads((RAW/'native-caption-pipeline-v2035/receipt.json').read_bytes())
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+')
if not owner['all_commands_terminal']:
 os.kill(owner['owner_pid'],0)
 try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 except BlockingIOError:pass
 else:raise AssertionError('Active pipeline must retain exclusive ownership')
else:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 for name in ['cargo','rustc','ninja','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
ROOT=Path('/dev/shm/openui-native-caption-v2034');sys.path.insert(0,str(ROOT/'tools/qualification'))
from renderer_source_identity import repository_source_identity
before=repository_source_identity(ROOT);assert before==owner['source']
old=RAW/'ninepatch-clean-v13';proof=old/'pixel-tool-identity.json';d=json.loads(proof.read_bytes())
assert d['build_process_exit_code']==0 and d['build_source_identity']['source']==d['source'] and d['source']['clean']
p=old/'pixel_compare';assert not p.is_symlink() and p.stat().st_dev==MAIN.stat().st_dev
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(2**20),b''):h.update(chunk)
 return h.hexdigest()
expected=d['binary_sha256'];assert sha(p)==expected;proof_sha=sha(proof)
for proc in Path('/proc').iterdir():
 if proc.name.isdecimal():
  try:assert (proc/'exe').resolve()!=p.resolve()
  except (FileNotFoundError,PermissionError):pass
store=Path('/mnt/e/openui-v02-qualification-d174ea0b/relocated-terminal-ninepatch-binary-v2038');assert not store.exists();store.mkdir()
destination=store/p.name;shutil.copy2(p,destination);size=p.stat().st_size
assert sha(destination)==expected and destination.stat().st_size==size
p.unlink();p.symlink_to(destination)
assert sha(p)==expected and sha(proof)==proof_sha and repository_source_identity(ROOT)==before
receipt=dict(all_commands_terminal=True,original_path_preserved=True,bytes=size,sha256=expected,original_path=str(p),relocated_path=str(destination),terminal_build_proof_sha256=proof_sha,active_source_unchanged=True,active_pipeline_lock_left_with_owner=not owner['all_commands_terminal'],cargo_or_native_queries_started=0,reference_images_rewritten=0,probe_sha256=sha(Path(__file__)))
Path('/tmp/openui-verified-terminal-binary-relocation-v2038.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(bytes_preserved=size,hash_verified=True,home_free=shutil.disk_usage(MAIN).free)))
