import gzip, hashlib, json, subprocess
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b')
DEST=BASE/'native-monochrome-policy-checkpoint-v4137.json';assert not DEST.exists()
load=lambda path:json.loads(Path(path).read_bytes());sha=lambda raw:hashlib.sha256(raw).hexdigest()
measured=load('/tmp/openui-monochrome-policy-reaped-v4131.json')
checks=load(BASE/'native-monochrome-policy-checks-v4136/receipt.json')
assert measured['all_local_commands_terminal'] and measured['owners_absent']
assert checks['all_commands_terminal'] and checks['all_checks_pass'] and checks['source_unchanged']
assert subprocess.check_output(['git','diff',measured['source']['commit'],'--','bindings/rust'],cwd=ROOT)==b''
indices={};count=0
for name in ['native-font-origin-v1','native-monochrome-font-v1','native-fitted-monochrome-v1','native-fitted-monochrome-checkpoint-v1','native-monochrome-policy-matrices-v1']:
 path=ROOT/'docs/renderer/generated'/ (name+'.json');index=load(path)
 for member in index['archive']['members']:
  data=(ROOT/member['path']).read_bytes();assert sha(data)==member['sha256'] and len(data)==member['bytes']
  raw=gzip.decompress(data) if member['compression']=='gzip' else data
  assert sha(raw)==member['raw_sha256'] and len(raw)==member['raw_bytes']
  count+=1
 indices[name]=dict(sha256=sha(path.read_bytes()),members=len(index['archive']['members']))
for name in ['cargo','rustc','rustfmt','pixel_compare']:
 assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
for path in ['tools/qualification/run_renderer_matrix.py','tools/qualification/test_renderer_matrix.py','tools/qualification/summarize_renderer_census.py','tools/qualification/test_summarize_renderer_census.py']:
 assert (ROOT/path).read_bytes()==subprocess.check_output(['git','show',measured['source']['commit']+':'+path],cwd=ROOT)
report=dict(schema_version=1,all_local_owners_terminal=True,measured_source=measured['source'],
 runtime_and_tooling_equal_measured_commit=True,archive_indices=indices,archive_members_verified=count,
 read_only_checks=len(checks['results']),all_checks_pass=True,
 renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False)
DEST.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(proof=str(DEST),archives=len(indices),members=count,checks=len(checks['results']))),flush=True)
