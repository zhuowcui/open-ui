import fcntl,hashlib,json,os,shutil,signal,subprocess,sys,time
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui')
SDK=MAIN
RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1'
PRIOR=RAW/'private-native-checkable-v3331'
REF=RAW/'native-disabled-appearance-reference-v3318'
NAME='public-native-checkable-appearance-v3369'
OUT=Path('/mnt/e/openui-v02-qualification-d174ea0b')/NAME
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','pixel_compare','rustfmt']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_bytes())
baseline=load(RAW/'private-native-disabled-appearance-v3352/receipt.json');baseline_audit=load('/tmp/openui-private-native-disabled-appearance-completed-audit-v3353.json')
assert baseline['all_commands_terminal'] and baseline_audit['owner_terminal'] and baseline_audit['complete']
assert sha(RAW/'private-native-disabled-appearance-v3352/receipt.json')==baseline_audit['receipt_sha256']
assert subprocess.run(['ps','-p',str(baseline['owner_pid'])],capture_output=True).returncode==1
reference=load(REF/'receipt.json');refaudit=load('/tmp/openui-native-disabled-appearance-reference-completed-audit-v3320.json')
assert reference['all_commands_terminal'] and reference['observed_exit_code']==0 and refaudit['owner_terminal']
assert sha(REF/'receipt.json')==refaudit['receipt_sha256'] and len(reference['rows'])==160
assert not OUT.exists() and not (RAW/NAME).exists()
OUT.mkdir();(RAW/NAME).symlink_to(OUT,target_is_directory=True)
binary=OUT/'native_disabled_appearance'
assert sha(MAIN/'chrome/linux-147.0.7727.50/chrome-linux64/chrome')==reference['chrome_sha256']
sys.path.insert(0,'/tmp');from openui_parallel_source_identity_v3060 import identity
sys.path.insert(0,str(MAIN/'tools/qualification'));from residuals import analyze_image_difference
source=identity(SDK);main_source=identity(MAIN)
assert source['clean'] and main_source['clean']
assert source['commit']==Path('/tmp/openui-native-checkable-public-pin-v3367.txt').read_text().strip()
report=dict(schema_version=1,source=source,main_source=main_source,whole_native_qualification_completed=False,owner_pid=os.getpid(),all_commands_terminal=False,driver_sha256=sha(__file__),reference_receipt_sha256=sha(REF/'receipt.json'),baseline_receipt_sha256=sha(RAW/'private-native-disabled-appearance-v3352/receipt.json'),baseline_completed_audit_sha256=sha('/tmp/openui-private-native-disabled-appearance-completed-audit-v3353.json'),steps=[],rows=[],pixel_tolerance=0,pixel_target='pinned Chromium',javascript_executed_by_openui=False,release_qualified=False,all_native_apis_qualified=False,renderer_qualified=False,native_raster_backend='CPU Skia default',implementation_integrated=False)
env=dict(os.environ,CARGO_TARGET_DIR='/mnt/e/openui-v02-cargo-c73754e2/target',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='4',RUST_MIN_STACK='4194304',PYTHONDONTWRITEBYTECODE='1',TMPDIR='/dev/shm')
env.pop('LD_PRELOAD',None);env.pop('LD_LIBRARY_PATH',None);local={};proof={}
def save():(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
save()
def run(name,command):
 with (OUT/(name+'.log')).open('xb') as log:
  child=subprocess.Popen(command,cwd=SDK/'bindings/rust',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);report['current_process']=dict(pid=child.pid,name=name);save()
  try:
   while child.poll() is None:
    if shutil.disk_usage(MAIN).free<128*2**20 or shutil.disk_usage(OUT).free<10*2**30:
     report['disk_guard_triggered']=True;os.killpg(child.pid,signal.SIGTERM);break
    time.sleep(1)
   code=child.wait()
  except BaseException:
   if child.poll() is None:os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=20)
   raise
  finally:
   report.pop('current_process',None);report['steps'].append(dict(name=name,command=command,actual_exit_code=child.returncode,log_sha256=sha(OUT/(name+'.log'))));save()
 print(json.dumps(report['steps'][-1]),flush=True);assert code==0,name
 data=(OUT/(name+'.log')).read_bytes()
 if local and command[0]=='cargo':
  artifacts=[]
  for line in data.splitlines():
   if not line.startswith(b'{'):continue
   record=json.loads(line)
   if record.get('reason')!='compiler-artifact' or record['target']['kind']==['custom-build'] or record['package_id'] not in local:continue
   assert Path(record['manifest_path']).resolve()==Path(local[record['package_id']]['manifest_path']).resolve()
   assert Path(record['target']['src_path']).resolve().is_relative_to(SDK.resolve())
   hashes={p:sha(p) for p in record['filenames']}
   if record['fresh']:assert all(proof.get(p)==h for p,h in hashes.items()),record
   proof.update(hashes);artifacts.append(dict(record=record,sha256=hashes))
  if artifacts:report.setdefault('local_artifacts',{})[name]=artifacts;save()
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=SDK,text=True).strip()==source['commit'] and not subprocess.check_output(['git','status','--porcelain'],cwd=SDK)
 return data
try:
 prior=load(RAW/'public-native-checkable-workspace-v3397/receipt.json')
 audit=load('/tmp/openui-public-native-checkable-workspace-completed-audit-v3398.json')
 assert prior['all_commands_terminal'] and prior['observed_exit_code']==0 and audit['owner_terminal'] and audit['complete'] and audit['actual_whole_exit_code']==0
 assert sha(RAW/'public-native-checkable-workspace-v3397/receipt.json')==audit['receipt_sha256'] and prior['source']==source==main_source==audit['source']
 assert subprocess.run(['ps','-p',str(prior['owner_pid'])],capture_output=True).returncode==1
 origin=RAW/'public-native-checkable-workspace-v3397/native_disabled_appearance'
 assert sha(origin)==prior['binaries']['native_disabled_appearance']['sha256']
 shutil.copy2(origin,binary);assert sha(binary)==sha(origin);report['binary_sha256']=sha(binary)
 report['copied_from_completed_audited_public_owner']=True
 report['compiled_artifacts_and_source_audited_before_target_retirement']=True
 report['public_native_owner_receipt_sha256']=audit['receipt_sha256']
 report['public_native_completed_audit_sha256']=sha('/tmp/openui-public-native-checkable-workspace-completed-audit-v3398.json')
 report['implementation_integrated']=True;save()
 for row in reference['rows']:
  index=row['index'];params=row['parameters'];folder=REF/str(index)
  assert sha(folder/'reference.html')==row['fixture_sha256']
  observations=[]
  for repeat in [1,2]:
   name='appearance-'+str(index)+'-'+str(repeat);dest=OUT/name;log=OUT/(name+'.log')
   command=[str(binary),str(dest),str(row['scale']),str(params['phase']),'disabled' if params['disabled'] else 'enabled','checked' if params['checked'] else 'unchecked']
   assert sha(binary)==report['binary_sha256']
   assert shutil.disk_usage(MAIN).free>=128*2**20 and shutil.disk_usage(OUT).free>=10*2**30
   with log.open('xb') as stream:
    child=subprocess.Popen(command,cwd=SDK,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True);report['current_process']=dict(pid=child.pid,name=name);save()
    try:
     code=child.wait()
    except BaseException:
     if child.poll() is None:child.terminate();child.wait(timeout=20)
     raise
   report.pop('current_process',None);report['steps'].append(dict(name=name,command=command,actual_exit_code=code,log_sha256=sha(log)));save();assert code==0,name
   metadata=load(dest/'observations.json');assert metadata['callback_count']==1
   reference_observation=row['observations'][repeat-1];assert metadata==reference_observation['after'],(index,metadata,reference_observation['after'])
   differences={}
   for phase in ['before','after']:
    refpng=folder/(phase+'-'+str(repeat)+'.png');assert sha(refpng)==reference_observation['images'][phase]['png_sha256']
    differences[phase]=analyze_image_difference(refpng,dest/(phase+'.png'));assert differences[phase]['comparable']
   observations.append(dict(repeat=repeat,metadata=metadata,metadata_sha256=sha(dest/'observations.json'),png_sha256={phase:sha(dest/(phase+'.png')) for phase in ['before','after']},differences=differences))
  assert observations[0]['png_sha256']==observations[1]['png_sha256'] and observations[0]['metadata_sha256']==observations[1]['metadata_sha256']
  exact=all(observations[0]['differences'][phase]['mismatched_pixels']==0 for phase in ['before','after'])
  report['rows'].append(dict(index=index,scale=row['scale'],parameters=params,exact=exact,repeats_identical=True,observations=observations));save()
  if (index+1)%32==0:print(json.dumps(dict(completed=index+1,exact=sum(x['exact'] for x in report['rows']))),flush=True)
 report['baseline_exact']=baseline['exact'];report['baseline_mismatched_pixels']=sum(o['differences'][p]['mismatched_pixels'] for row in baseline['rows'] for o in row['observations'][:1] for p in ['before','after']);report['mismatched_pixels']=sum(o['differences'][p]['mismatched_pixels'] for row in report['rows'] for o in row['observations'][:1] for p in ['before','after']);report['total']=len(report['rows']);report['exact']=sum(x['exact'] for x in report['rows']);assert report['total']==160
 report['native_appearance_qualified']=report['exact']==160;report['observed_exit_code']=int(report['exact']!=160)
except BaseException as error:report.update(observed_exit_code=1,failure=repr(error));raise
finally:
 report.update(source_after=identity(SDK),main_source_after=identity(MAIN));report['source_unchanged']=report['source_after']==source;report['main_source_unchanged']=report['main_source_after']==main_source
 assert report['source_unchanged'] and report['main_source_unchanged'] and sha(REF/'receipt.json')==report['reference_receipt_sha256'];report['all_commands_terminal']=True;save()
print(json.dumps({k:report.get(k) for k in ['all_commands_terminal','observed_exit_code','total','exact','native_appearance_qualified']}),flush=True)
raise SystemExit(report['observed_exit_code'])
