import hashlib,io,json,subprocess,zipfile
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');OUT=Path('/mnt/e/openui-v02-qualification-d174ea0b/public-native-checkable-hosted-v3399')
assert not OUT.exists();OUT.mkdir()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head=='54cf4b3c658ea3224eba928f4d6f808c271913fd'
def api(path):return json.loads(subprocess.check_output(['gh','api','repos/zhuowcui/open-ui/'+path],cwd=ROOT))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
metadata=api('actions/artifacts/11631610661');assert metadata['name']=='native-c-cpp-window-smokes' and not metadata['expired']
run=api('actions/runs/37961331553');assert run['head_sha']==head and run['conclusion']=='success' and run['run_attempt']==2
blob=subprocess.check_output(['gh','api','repos/zhuowcui/open-ui/actions/artifacts/11631610661/zip'],cwd=ROOT)
assert 'sha256:'+hashlib.sha256(blob).hexdigest()==metadata['digest'];(OUT/'artifact.zip').write_bytes(blob)
reports=[]
with zipfile.ZipFile(io.BytesIO(blob)) as zipped:
 for item in zipped.infolist():
  if item.filename.endswith('.json'):
   data=zipped.read(item);(OUT/Path(item.filename).name).write_bytes(data);reports.append(json.loads(data))
assert len(reports)==3
assert {(r['protocol'],r['backend']) for r in reports}=={('x11','software'),('x11','opengl'),('wayland','software')}
for report in reports:
 assert report['source_commit']==head and report['source_clean'] and report['passed'] and report['header_sha256']==sha(ROOT/'include/openui.h')
 for c in report['consumers']:
  assert c['returncode']==0 and not c['timed_out'] and c['source_sha256']==sha(ROOT/c['source'])
  assert 'focus=4 blur=3' in c['stdout']
 assert len(report['consumers'])==2
(OUT/'artifact-metadata.json').write_text(json.dumps(metadata,sort_keys=True,indent=2)+'\n')
(OUT/'hosted-run.json').write_text(json.dumps(run,sort_keys=True,indent=2)+'\n')
result=dict(schema_version=1,implementation_commit=head,reports=reports,source_header_consumer_bytes_verified=True,window_consumers=6,all_window_consumers_passed=True,hosted_virtual_displays=True,physical_lab_qualified=False,release_qualified=False,renderer_qualified=False,all_native_apis_qualified=False,all_commands_terminal=True,observed_exit_code=0,artifact_sha256=hashlib.sha256(blob).hexdigest(),artifact_id=metadata['id'],driver_sha256=sha(__file__))
(OUT/'receipt.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(hosted_run=run['id'],source=head,reports=len(reports),consumer_runs=6,source_bytes_verified=True)),flush=True)
