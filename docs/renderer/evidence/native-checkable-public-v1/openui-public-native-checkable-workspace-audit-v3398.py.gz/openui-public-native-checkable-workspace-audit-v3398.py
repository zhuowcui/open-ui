"""Audit a terminal public native/workspace owner before a later clean or source edit."""
import fcntl,hashlib,json,re,subprocess,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1/public-native-checkable-workspace-v3397';OUT=Path('/tmp/openui-public-native-checkable-workspace-completed-audit-v3398.json')
assert not OUT.exists()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','rustfmt','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
read=lambda p:json.loads(Path(p).read_bytes())
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(2**20),b''):h.update(b)
 return h.hexdigest()
r=read(RAW/'receipt.json');assert r['all_commands_terminal'] and r['source_unchanged'] and r['main_source_unchanged']
assert r['source']==r['source_after']==r['main_source']==r['main_source_after']
assert subprocess.run(['ps','-p',str(r['owner_pid'])],capture_output=True).returncode==1
assert sha('/tmp/openui-public-native-checkable-workspace-continuation-v3397.py')==r['driver_sha256']
sys.path.insert(0,'/tmp');from openui_parallel_source_identity_v3060 import identity
assert identity(MAIN)==r['source']
prior_path=MAIN/'out/renderer-evidence/native-viewport-scroll-v1/public-native-checkable-workspace-v3380/receipt.json'
prior_audit_path=Path('/tmp/openui-public-native-checkable-workspace-completed-audit-v3387.json')
prior=read(prior_path);prior_audit=read(prior_audit_path);inherited=r['inherited_completed_stages_from_partial_owner']
assert prior_audit['owner_terminal'] and not prior_audit['complete'] and prior_audit['workspace']==r['workspace_tests']
assert sha(prior_path)==inherited['receipt_sha256']==prior_audit['receipt_sha256']
assert sha(prior_audit_path)==inherited['completed_audit_sha256'] and prior['observed_exit_code']==inherited['whole_prior_exit_code']==1
assert prior['source']==r['source'] and subprocess.run(['ps','-p',str(prior['owner_pid'])],capture_output=True).returncode==1
for old,new in zip(prior['steps'][:5],r['steps'][:5]):
 assert old['actual_exit_code']==new['actual_exit_code']==0 and old['name']==new['name'] and old['log_sha256']==new['log_sha256']
 assert new['executed_in_prior_owner'] and new['prior_receipt_sha256']==inherited['receipt_sha256']

for p,h in r['reference_inputs_sha256'].items():assert sha(p)==h
for step in r['steps']:assert sha(RAW/(step['name']+'.log'))==step['log_sha256']
proof={};last_by_inode={};records=0;aliases=[];packages=set()
for step in r['steps']:
 group=step['name']
 artifacts=r.get('local_artifacts',{}).get(group,[])
 for a in artifacts:
  record=a['record'];assert Path(record['manifest_path']).resolve().is_relative_to(MAIN.resolve()) and Path(record['target']['src_path']).resolve().is_relative_to(MAIN.resolve())
  assert group!='locked-workspace-tests' or not record['fresh'];packages.add(record['package_id']);records+=1
  for p,h in a['sha256'].items():
   if record['fresh']:assert proof.get(p)==h,(group,p)
   proof[p]=h;st=Path(p).stat();last_by_inode[st.st_dev,st.st_ino]=dict(path=p,sha256=h,stage=group)
for p,h in proof.items():
 st=Path(p).stat();last=last_by_inode[st.st_dev,st.st_ino];actual=sha(p);assert actual==last['sha256'],p
 if actual!=h:
  assert Path(p).samefile(last['path']) and p!=last['path'];aliases.append(dict(prior_path=p,prior_sha256=h,current_path=last['path'],current_sha256=actual))
for name,b in r.get('binaries',{}).items():assert sha(RAW/name)==b['sha256']
if 'ffi_library_sha256' in r:
 assert sha(RAW/'libopenui_ffi.so')==r['ffi_library_sha256'] and r['ffi_library_sha256'] in proof.values()
workspace_path=RAW/'locked-workspace-tests.log';workspace=None
if workspace_path.exists():
 totals=[tuple(map(int,m)) for m in re.findall(rb'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',workspace_path.read_bytes())]
 workspace=dict(passed=sum(x[0] for x in totals),failed=sum(x[1] for x in totals),ignored=sum(x[2] for x in totals))
 if 'workspace_tests' in r:assert workspace==r['workspace_tests']
rows=exact=repeat_pairs=0
for c in r.get('comparisons',[]):
 assert c['exact']==(c['native']==c['chromium']);rows+=1;exact+=c['exact']
for p in RAW.glob('*-1.json'):
 partner=p.with_name(p.name[:-7]+'-2.json')
 if partner.exists():assert p.read_bytes()==partner.read_bytes();repeat_pairs+=1
for language,c in r.get('scenario_counts',{}).items():
 observed=[x for x in r['comparisons'] if x['language']==language];assert len(observed)==c['total'] and sum(x['exact'] for x in observed)==c['exact']
complete='failure' not in r and 'comparisons' in r and all(x['actual_exit_code']==0 for x in r['steps'])
if complete:
 assert r['observed_exit_code']==0 and r['implementation_integrated'] and r['public_native_behavior_qualified']
 assert workspace['passed']>=8623 and workspace['failed']==0 and rows==exact==924
 assert all(x['unchanged'] for x in r['regression_comparisons']) and r['all_regression_rows_unchanged']
 assert 'C ABI verified: symbols=128 C_examples=25 C++=19 ran=True' in (RAW/'all-c-cpp-consumers.log').read_text()
 assert r['headless_tests'][0][0]>=52 and r['headless_tests'][0][1:]==[0,0]
else:assert r['observed_exit_code']!=0
report=dict(schema_version=1,owner_terminal=True,complete=complete,actual_whole_exit_code=r['observed_exit_code'],source=r['source'],all_source_bytes_unchanged=True,receipt_sha256=sha(RAW/'receipt.json'),logs_verified=len(r['steps']),inherited_successful_stage_count=5,whole_prior_owner_exit_code=1,compiled_records_verified=records,compiled_paths_verified=len(proof),fresh_packages_verified=len(packages),current_inode_aliases_verified=aliases,workspace=workspace,native_behavior_rows_verified=rows,native_behavior_exact=exact,repeated_process_pairs_verified=repeat_pairs,public_native_behavior_qualified=complete,implementation_integrated=True,appearance_qualified=False,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,javascript_executed_by_openui=False)
OUT.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');print(json.dumps(report),flush=True)
