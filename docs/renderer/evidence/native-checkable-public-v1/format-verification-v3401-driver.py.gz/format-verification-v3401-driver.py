import fcntl,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';PRIOR=RAW/'public-native-checkable-workspace-v3397';OUT=Path('/mnt/e/openui-v02-qualification-d174ea0b/native-checkable-c-format-verification-v3401')
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','rustfmt','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
for p in ['/tmp/openui-public-native-checkable-workspace-completed-audit-v3398.json','/tmp/openui-public-native-checkable-appearance-completed-audit-v3370.json']:
 a=read(p);assert a['owner_terminal'] and a['complete'] and a['actual_whole_exit_code']==0
r=read(PRIOR/'receipt.json');assert r['all_commands_terminal'] and subprocess.run(['ps','-p',str(r['owner_pid'])],capture_output=True).returncode==1
prepared=read('/tmp/openui-checkable-clang-format-prepared-v3395.json');source=MAIN/prepared['source'];formatted=Path('/tmp/openui-checkable-clang-format-v3395.c')
assert sha(source)==prepared['before_sha256'] and sha(formatted)==prepared['formatted_sha256'] and subprocess.check_output(['git','rev-parse','HEAD'],cwd=MAIN,text=True).strip()==prepared['source_commit']
assert not OUT.exists();OUT.mkdir()
# Atomic replacement prevents changing an SDK file sharing the original inode.
temporary=source.with_name('.checkable.c-v3401');temporary.write_bytes(formatted.read_bytes());temporary.chmod(source.stat().st_mode&0o777);os.replace(temporary,source)
assert sha(source)==prepared['formatted_sha256']
LIB=PRIOR/'libopenui_ffi.so';assert sha(LIB)==r['ffi_library_sha256']
report=dict(schema_version=1,owner_pid=os.getpid(),all_commands_terminal=False,verification_only=True,clean_source_qualification=False,behavior_oracle='pinned Chromium',library_source=r['source'],library_sha256=sha(LIB),before_source_sha256=prepared['before_sha256'],formatted_source_sha256=sha(source),steps=[],comparison_rows=[],renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,javascript_executed_by_openui=False)
def save():(OUT/'receipt.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
def run(name,cmd):
 result=subprocess.run(cmd,cwd=MAIN,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=dict(os.environ,TMPDIR='/dev/shm'))
 p=OUT/(name+'.log');p.write_bytes(result.stdout);report['steps'].append(dict(name=name,command=cmd,actual_exit_code=result.returncode,log_sha256=sha(p)));save();assert result.returncode==0,(name,result.stdout[-2000:]);return result.stdout
save()
try:
 formatter='/tmp/openui-clang18-ci-v2621/unpacked/clang_format/data/bin/clang-format'
 files=[]
 for token in subprocess.check_output(['git','ls-files','-z','src','include','examples'],cwd=MAIN).split(b'\0'):
  if not token:continue
  p=Path(os.fsdecode(token))
  if p.suffix in ['.c','.cc','.h'] and str(p) not in ['include/openui.h','include/openui_style_properties.h']:files.append(str(p))
 run('clang-format-all-tracked',[formatter,'--dry-run','--Werror',*files])
 sys.path.insert(0,str(MAIN/'tools/ffi'));import verify_abi
 cc,cxx,c_flags,cxx_flags,link_flags=verify_abi.compilers()
 for language,compiler,flags,standard in [('c',cc,c_flags,'c11'),('cpp',cxx,cxx_flags,'c++17')]:
  example=MAIN/'examples/c_v02'/('checkable.c' if language=='c' else 'checkable.cc');obj=OUT/('checkable-'+language+'.o');binary=OUT/('checkable-'+language)
  run('compile-'+language,[compiler,'-std='+standard,'-Wall','-Wextra','-Werror','-pthread',*flags,'-I'+str(MAIN/'include'),str(example),'-c','-o',str(obj)])
  run('link-'+language,[cxx,'-pthread',*cxx_flags,*link_flags,'-fuse-ld=lld',str(obj),str(LIB),'-Wl,-rpath,'+str(PRIOR),'-o',str(binary)])
  report.setdefault('binaries',{})[language]=dict(sha256=sha(binary),source_sha256=sha(example),included_c_source_sha256=sha(source));save()
  for mode in ['accessibility','dispatch']:
   data=[]
   for repeat in [1,2]:
    data.append(run(language+'-'+mode+'-'+str(repeat),[str(binary)]+(['dispatch'] if mode=='dispatch' else [])))
   assert data[0]==data[1]
   expected=(PRIOR/('checkable-'+language+'-'+mode+'-1.json')).read_bytes();a=json.loads(data[0]);e=json.loads(expected);assert a==e
   refs=dict(programmatic='native-radio-programmatic-reference-v3242',default='native-checkable-default-reference-v3249',activation='native-checkable-activation-reference-v3257')
   for suite,rows in a.items():
    assert suite in refs
    if mode=='dispatch':
     refpath=RAW/'native-checkable-dispatch-reference-v3315/observations-1.json';expected_rows=[{k:v for k,v in e.items() if k!='suite'} for e in read(refpath) if e['suite']==suite]
    else:
     refpath=RAW/refs[suite]/'observations-1.json';expected_rows=read(refpath)
    report.setdefault('reference_inputs_sha256',{})[str(refpath)]=sha(refpath)
    assert len(rows)==len(expected_rows)
    for actual,expected in zip(rows,expected_rows):
     assert actual['api_errors']==[]
     assert {k:v for k,v in actual.items() if k!='api_errors'}==expected
   count=sum(len(rows) for rows in a.values());report['comparison_rows'].append(dict(language=language,mode=mode,cases=count,exact=count,chromium_exact=True,previous_output_unchanged=True));save()
 assert sum(c['cases'] for c in report['comparison_rows'])==440
 report['observed_exit_code']=0
except BaseException as e:report.update(observed_exit_code=1,failure=repr(e));raise
finally:
 assert sha(source)==prepared['formatted_sha256'] and sha(LIB)==report['library_sha256']
 for p,h in report.get('reference_inputs_sha256',{}).items():assert sha(p)==h
 report['all_commands_terminal']=True;report['source_format_applied']=True;save()
print(json.dumps(dict(observed_exit_code=report['observed_exit_code'],formatted_c_cpp_cases_verified=440,verification_only=True)),flush=True)
