import fcntl,hashlib,json,subprocess,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';DIR=RAW/'public-native-checkable-appearance-v3369';REF=RAW/'native-disabled-appearance-reference-v3318';OUT=Path('/tmp/openui-public-native-checkable-appearance-completed-audit-v3370.json')
assert not OUT.exists()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','rustfmt','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
read=lambda p:json.loads(Path(p).read_bytes());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=read(DIR/'receipt.json');assert r['all_commands_terminal'] and r['source_unchanged'] and r['main_source_unchanged'] and r['source']==r['source_after']==r['main_source']==r['main_source_after']
assert subprocess.run(['ps','-p',str(r['owner_pid'])],capture_output=True).returncode==1
assert sha('/tmp/openui-public-native-checkable-appearance-prepared-v3369.py')==r['driver_sha256']
ref=read(REF/'receipt.json');assert sha(REF/'receipt.json')==r['reference_receipt_sha256']
auditpath='/tmp/openui-public-native-checkable-workspace-completed-audit-v3398.json';audit=read(auditpath);assert audit['owner_terminal'] and audit['complete'] and audit['source']==r['source'] and sha(auditpath)==r['public_native_completed_audit_sha256']
origin=RAW/'public-native-checkable-workspace-v3397';prior=read(origin/'receipt.json');assert sha(origin/'receipt.json')==audit['receipt_sha256']==r['public_native_owner_receipt_sha256']
assert sha(DIR/'native_disabled_appearance')==sha(origin/'native_disabled_appearance')==r['binary_sha256']==prior['binaries']['native_disabled_appearance']['sha256']
for step in r['steps']:assert sha(DIR/(step['name']+'.log'))==step['log_sha256']
sys.path.insert(0,'/tmp');from openui_parallel_source_identity_v3060 import identity
sys.path.insert(0,str(MAIN/'tools/qualification'));from residuals import analyze_image_difference
assert identity(MAIN)==r['source']
images=metadata_rows=exact=0
for row in r['rows']:
 expected=ref['rows'][row['index']];assert row['scale']==expected['scale'] and row['parameters']==expected['parameters']
 assert sha(REF/str(row['index'])/'reference.html')==expected['fixture_sha256']
 recomputed=[]
 for o in row['observations']:
  repeat=o['repeat'];folder=DIR/('appearance-'+str(row['index'])+'-'+str(repeat));e=expected['observations'][repeat-1]
  assert sha(folder/'observations.json')==o['metadata_sha256'] and read(folder/'observations.json')==o['metadata']==e['after'];metadata_rows+=1
  differences={}
  for phase in ['before','after']:
   expected_png=REF/str(row['index'])/(phase+'-'+str(repeat)+'.png');actual_png=folder/(phase+'.png')
   assert sha(expected_png)==e['images'][phase]['png_sha256'] and sha(actual_png)==o['png_sha256'][phase]
   differences[phase]=analyze_image_difference(expected_png,actual_png);assert differences[phase]==o['differences'][phase];images+=1
  recomputed.append(differences)
 assert row['repeats_identical'] and row['observations'][0]['png_sha256']==row['observations'][1]['png_sha256'] and row['observations'][0]['metadata']==row['observations'][1]['metadata']
 observed_exact=all(d['mismatched_pixels']==0 for o in recomputed for d in o.values());assert observed_exact==row['exact'];exact+=observed_exact
complete='failure' not in r and len(r['rows'])==160
if complete:assert r['total']==160 and r['exact']==exact and r['observed_exit_code']==int(exact!=160) and len(r['steps'])==320
else:assert r['observed_exit_code']!=0
report=dict(schema_version=1,owner_terminal=True,complete=complete,source=r['source'],all_source_bytes_unchanged=True,actual_whole_exit_code=r['observed_exit_code'],receipt_sha256=sha(DIR/'receipt.json'),copied_public_app_source_and_artifact_proven=True,logs_verified=len(r['steps']),cases_verified=len(r['rows']),images_verified=images,metadata_rows_verified=metadata_rows,exact=exact,native_appearance_qualified=complete and exact==160,implementation_integrated=True,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,javascript_executed_by_openui=False,pixel_tolerance=0,pixel_target='pinned Chromium')
OUT.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(report),flush=True)
