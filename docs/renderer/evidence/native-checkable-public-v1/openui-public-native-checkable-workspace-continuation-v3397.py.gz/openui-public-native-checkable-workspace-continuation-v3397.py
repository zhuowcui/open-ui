import fcntl,hashlib,json,os,re,shutil,signal,subprocess,sys,time
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');SDK=MAIN;RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1'
NAME='public-native-checkable-workspace-v3397';OUT=Path('/mnt/e/openui-v02-qualification-d174ea0b')/NAME
renderer=json.loads((RAW/'private-native-checkable-renderer-v3359/receipt.json').read_bytes())
completed=json.loads(Path('/tmp/openui-private-native-checkable-renderer-completed-audit-v3360.json').read_bytes())
integration=json.loads(Path('/tmp/openui-native-checkable-integration-v3363.json').read_bytes())
assert renderer['all_commands_terminal'] and renderer['stage']=='terminal' and completed['owner_terminal'] and completed['complete'] and completed['private_candidate_nonregression']
assert completed['receipt_sha256']==hashlib.sha256((RAW/'private-native-checkable-renderer-v3359/receipt.json').read_bytes()).hexdigest()
assert subprocess.run(['ps','-p',str(renderer['owner_pid'])],capture_output=True).returncode==1
assert integration['public_qualification_pending'] and integration['private_source']==renderer['source']
PRIOR=RAW/'public-native-checkable-workspace-v3380'
inherited_owner=json.loads((PRIOR/'receipt.json').read_bytes())
prior_audit_path=Path('/tmp/openui-public-native-checkable-workspace-completed-audit-v3387.json')
prior_audit=json.loads(prior_audit_path.read_bytes())
cleanup=json.loads(Path('/tmp/openui-unused-skia-build-cache-cleanup-v3388.json').read_bytes())
assert inherited_owner['all_commands_terminal'] and inherited_owner['observed_exit_code']==1 and inherited_owner['disk_guard_triggered']
assert prior_audit['owner_terminal'] and not prior_audit['complete'] and prior_audit['workspace']==dict(passed=8623,failed=0,ignored=13)
assert prior_audit['receipt_sha256']==hashlib.sha256((PRIOR/'receipt.json').read_bytes()).hexdigest()
assert cleanup['all_commands_terminal'] and cleanup['observed_exit_code']==0
assert cleanup['stopped_audit_sha256']==hashlib.sha256(prior_audit_path.read_bytes()).hexdigest()
assert subprocess.run(['ps','-p',str(inherited_owner['owner_pid'])],capture_output=True).returncode==1

lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','pixel_compare','rustfmt']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
assert not OUT.exists() and not (RAW/NAME).exists();OUT.mkdir();(RAW/NAME).symlink_to(OUT,target_is_directory=True)
sys.path.insert(0,'/tmp');from openui_parallel_source_identity_v3060 import identity
source=identity(SDK);assert source['clean'] and source['commit']==Path('/tmp/openui-native-checkable-public-pin-v3367.txt').read_text().strip()
for relative in integration['source_files_integrated']:
 assert (SDK/relative).read_bytes()==subprocess.check_output(['git','show',renderer['source']['commit']+':'+relative],cwd=MAIN)
main_source=identity(MAIN);assert main_source['clean'] and main_source==source
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
references={}
for name in ['native-fieldset-reference-v3192','native-fieldset-neighbors-reference-v3211','native-disabled-state-reference-v3212','native-radio-programmatic-reference-v3242','native-checkable-default-reference-v3249','native-checkable-activation-reference-v3257','native-checkable-dispatch-reference-v3315']:
 directory=RAW/name;r=json.loads((directory/'receipt.json').read_bytes());assert r['all_commands_terminal'] and r['observed_exit_code']==0 and r['source_unchanged'];assert (directory/'observations-1.json').read_bytes()==(directory/'observations-2.json').read_bytes()
 for file in ['receipt.json','observations-1.json','observations-2.json']:references[str(directory/file)]=sha(directory/file)
regression=RAW/'public-native-selection-v3182';prior=json.loads((regression/'receipt.json').read_bytes());assert prior['all_commands_terminal'] and prior['observed_exit_code']==0
reference_modes=dict(focus='native-fieldset-reference-v3192',neighbors='native-fieldset-neighbors-reference-v3211',state='native-disabled-state-reference-v3212')
report=dict(schema_version=1,source=source,main_source=main_source,steps=[],owner_pid=os.getpid(),all_commands_terminal=False,driver_sha256=sha(__file__),reference_inputs_sha256=references,pixel_tolerance=0,javascript_executed_by_openui=False,all_native_apis_qualified=False,release_qualified=False,renderer_qualified=False,implementation_integrated=True)
env=dict(os.environ,CARGO_TARGET_DIR='/mnt/e/openui-v02-cargo-c73754e2/target',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='4',RUST_MIN_STACK='4194304',PYTHONDONTWRITEBYTECODE='1',TMPDIR='/dev/shm')
env.pop('LD_PRELOAD',None);env.pop('LD_LIBRARY_PATH',None);local={};proof={}
def save():(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
def run(name,command,required=True,cwd=None):
 with (OUT/(name+'.log')).open('xb') as log:
  child=subprocess.Popen(command,cwd=cwd or SDK/'bindings/rust',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);report['current_process']=dict(pid=child.pid,name=name);save()
  try:
   while child.poll() is None:
    if shutil.disk_usage(MAIN).free<128*2**20 or shutil.disk_usage(OUT).free<10*2**30:
     report['disk_guard_triggered']=True;os.killpg(child.pid,signal.SIGTERM);break
    time.sleep(1)
   code=child.wait()
  except BaseException:
   if child.poll() is None:os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=20)
   raise
  finally:
   report.pop('current_process',None);report['steps'].append(dict(name=name,command=command,actual_exit_code=child.returncode,log_sha256=sha(OUT/(name+'.log'))));save()
 print(json.dumps(dict(name=name,actual_exit_code=code)),flush=True)
 if required:assert code==0,name
 data=(OUT/(name+'.log')).read_bytes()
 if local and command[0]=='cargo':
  artifacts=[]
  for line in data.splitlines():
   if not line.startswith(b'{'):continue
   record=json.loads(line)
   if record.get('reason')!='compiler-artifact' or record['target']['kind']==['custom-build'] or record['package_id'] not in local:continue
   assert Path(record['manifest_path']).resolve()==Path(local[record['package_id']]['manifest_path']).resolve()
   assert Path(record['target']['src_path']).resolve().is_relative_to(SDK.resolve())
   hashes={p:sha(p) for p in record['filenames']}
   if record['fresh']:assert name!='locked-workspace-tests' and all(proof.get(p)==h for p,h in hashes.items()),record
   proof.update(hashes);artifacts.append(dict(record=record,sha256=hashes))
  if artifacts:report.setdefault('local_artifacts',{})[name]=artifacts;save()
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=SDK,text=True).strip()==source['commit'] and not subprocess.check_output(['git','status','--porcelain'],cwd=SDK)
 return data
save()
try:
 cargo=['cargo','--config',str(SDK/'bindings/rust/.cargo/config.chromium.toml')]
 assert inherited_owner['source']==prior_audit['source']==source
 report['inherited_completed_stages_from_partial_owner']=dict(receipt_sha256=prior_audit['receipt_sha256'],completed_audit_sha256=sha(prior_audit_path),owner_pid=inherited_owner['owner_pid'],source=source,whole_prior_exit_code=1,whole_prior_qualification=False,prior_failed_command='native_range_modes-regression-1')
 # Preserve successful source-proven stages with explicit execution attribution.
 # The interrupted owner remains failed; these five stages are not rerun.
 for prior_step in inherited_owner['steps'][:5]:
  assert prior_step['actual_exit_code']==0
  name=prior_step['name'];origin=PRIOR/(name+'.log');assert sha(origin)==prior_step['log_sha256']
  shutil.copy2(origin,OUT/origin.name)
  inherited=dict(prior_step,executed_in_prior_owner=True,prior_receipt_sha256=prior_audit['receipt_sha256'])
  report['steps'].append(inherited)
  artifacts=inherited_owner.get('local_artifacts',{}).get(name,[])
  if artifacts:report.setdefault('local_artifacts',{})[name]=artifacts
  for artifact in artifacts:proof.update(artifact['sha256'])
 report['workspace_tests']=inherited_owner['workspace_tests'];report['workspace_test_execution']='inherited successful clean-source run; not repeated'
 metadata=json.loads((OUT/'locked-metadata.log').read_bytes())
 local={p['id']:p for p in metadata['packages'] if p['source'] is None}
 assert all(Path(p['manifest_path']).resolve().is_relative_to(SDK.resolve()) for p in local.values())
 # Check the current artifact tree before permitting a fresh Cargo reuse.
 last_by_inode={}
 for step in report['steps']:
  for artifact in report.get('local_artifacts',{}).get(step['name'],[]):
   for path,h in artifact['sha256'].items():
    st=Path(path).stat();last_by_inode[(st.st_dev,st.st_ino)]=(path,h)
 for path,h in proof.items():
  st=Path(path).stat();current_path,current_hash=last_by_inode[(st.st_dev,st.st_ino)]
  assert sha(path)==current_hash,(path,current_path)
  if current_hash!=h:assert Path(path).samefile(current_path) and path!=current_path
 save()
 app_names=['native_fieldset','native_input_metadata','native_selection_phases','native_selection_values','native_range_scalar','native_range_modes','native_disabled_focus']
 report['binaries']={}
 for name in app_names:
  binary=OUT/name;shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/examples'/name,binary);assert sha(binary) in proof.values();report['binaries'][name]=dict(sha256=sha(binary));save()
  for mode in (['focus','neighbors','state'] if name=='native_fieldset' else ['regression']):
   for repeat in [1,2]:
    label=name+'-'+mode+'-'+str(repeat);command=[str(binary)]+([mode] if name=='native_fieldset' else []);data=run(label,command);json.loads(data);(OUT/(label+'.json')).write_bytes(data)
   assert (OUT/(name+'-'+mode+'-1.json')).read_bytes()==(OUT/(name+'-'+mode+'-2.json')).read_bytes()
 binary=OUT/'native_checkable';shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/examples/native_checkable',binary);assert sha(binary) in proof.values();report['binaries']['native_checkable']=dict(sha256=sha(binary));save()
 for mode in ['reference','dispatch']:
  for repeat in [1,2]:
   label='native_checkable-'+mode+'-'+str(repeat);data=run(label,[str(binary)]+(['dispatch'] if mode=='dispatch' else []));json.loads(data);(OUT/(label+'.json')).write_bytes(data)
  assert (OUT/('native_checkable-'+mode+'-1.json')).read_bytes()==(OUT/('native_checkable-'+mode+'-2.json')).read_bytes()
 appearance=OUT/'native_disabled_appearance';shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/examples/native_disabled_appearance',appearance);assert sha(appearance) in proof.values();report['binaries']['native_disabled_appearance']=dict(sha256=sha(appearance));report['appearance_app_built_not_raster_qualified']=True;save()
 run('ffi-library-build',cargo+['build','--locked','--offline','-p','openui-ffi','--features','linux','--message-format=json'])
 library=OUT/'libopenui_ffi.so';shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/libopenui_ffi.so',library);(OUT/'libopenui.so.0').symlink_to(library.name);report['ffi_library_sha256']=sha(library);assert sha(library) in proof.values();save()
 run('all-c-cpp-consumers',[sys.executable,str(SDK/'tools/ffi/verify_abi.py'),'--library',str(library)])
 sys.path.insert(0,str(SDK/'tools/ffi'));import verify_abi
 cc,cxx,c_flags,cxx_flags,link_flags=verify_abi.compilers()
 for language,compiler,flags,standard in [('c',cc,c_flags,'c11'),('cpp',cxx,cxx_flags,'c++17')]:
  for stem in ['fieldset','fieldset_state','selection_tasks','disabled_focus','input_metadata','checkable']:
   example=SDK/'examples/c_v02'/(stem+('.c' if language=='c' else '.cc'));obj=OUT/(stem+'-'+language+'.o');binary=OUT/(stem+'-'+language)
   run('compile-'+stem+'-'+language,[compiler,'-std='+standard,'-Wall','-Wextra','-Werror','-pthread',*flags,'-I'+str(SDK/'include'),str(example),'-c','-o',str(obj)])
   run('link-'+stem+'-'+language,[cxx,'-pthread',*cxx_flags,*link_flags,'-fuse-ld=lld',str(obj),str(library),'-Wl,-rpath,'+str(OUT),'-o',str(binary)])
   report['binaries'][stem+'-'+language]=dict(sha256=sha(binary));save()
   for mode in (['accessibility','dispatch'] if stem=='checkable' else ['focus','neighbors'] if stem=='fieldset' else ['state'] if stem=='fieldset_state' else ['regression']):
    for repeat in [1,2]:
     label=stem+'-'+language+'-'+mode+'-'+str(repeat);data=run(label,[str(binary)]+([mode] if stem=='fieldset' or (stem=='checkable' and mode=='dispatch') else []));json.loads(data);(OUT/(label+'.json')).write_bytes(data)
    assert (OUT/(stem+'-'+language+'-'+mode+'-1.json')).read_bytes()==(OUT/(stem+'-'+language+'-'+mode+'-2.json')).read_bytes()
 comparisons=[]
 for mode,name in reference_modes.items():
  expected=json.loads((RAW/name/'observations-1.json').read_bytes())
  for language,label in [('rust','native_fieldset-'+mode),('c',('fieldset_state-c-state' if mode=='state' else 'fieldset-c-'+mode)),('cpp',('fieldset_state-cpp-state' if mode=='state' else 'fieldset-cpp-'+mode))]:
   actual=json.loads((OUT/(label+'-1.json')).read_bytes());assert len(actual)==len(expected)
   for a,e in zip(actual,expected):
    reference=e
    if mode=='state' and language!='rust':
     reference=json.loads(json.dumps(e))
     for phase in ['initial','synchronous','observed']:
      for state in reference[phase].values():state.pop('kind');state.pop('parent')
    comparisons.append(dict(language=language,mode=mode,scenario=a['scenario'],exact=a==reference,native=a,chromium=reference,projection=('own/property/effective/enabled/connected only; kind and parent Rust-only' if mode=='state' and language!='rust' else 'complete reference row')))
 checkable_comparisons=[]
 checkable_references=dict(programmatic='native-radio-programmatic-reference-v3242',default='native-checkable-default-reference-v3249',activation='native-checkable-activation-reference-v3257')
 consumers=[('rust','native_checkable-reference'),('rust','native_checkable-dispatch')]+[(language,'checkable-'+language+'-'+mode) for language in ['c','cpp'] for mode in ['accessibility','dispatch']]
 for language,label in consumers:
  actual=json.loads((OUT/(label+'-1.json')).read_bytes());assert set(actual)==set(checkable_references)
  for suite,name in checkable_references.items():
   raw_dispatch=label.endswith('dispatch')
   if raw_dispatch:
    raw_rows=json.loads((RAW/'native-checkable-dispatch-reference-v3315/observations-1.json').read_bytes())
    expected=[{k:v for k,v in e.items() if k!='suite'} for e in raw_rows if e['suite']==suite]
   else:
    expected=json.loads((RAW/name/'observations-1.json').read_bytes())
   assert len(actual[suite])==len(expected)
   for original,e in zip(actual[suite],expected):
    assert original['api_errors']==[], original
    a={k:v for k,v in original.items() if k!='api_errors'}
    checkable_comparisons.append(dict(language=language,consumer=label,mode=suite,scenario=a['scenario'],exact=a==e,native=a,chromium=e,projection='complete behavior row; raw-reference suite marker moved to grouping key; native API error list must be empty',reference_operation=('DOM raw click dispatchEvent' if raw_dispatch else 'HTMLElement.click / native property writes')))
 comparisons.extend(checkable_comparisons)
 report.update(checkable_comparisons=checkable_comparisons,new_reference_cases=220,new_comparison_rows=len(checkable_comparisons),native_api_errors_verified_empty=True)
 regression_rows=[]
 for name in app_names[1:]:
  a=json.loads((OUT/(name+'-regression-1.json')).read_bytes());e=json.loads((regression/(name+'-1.json')).read_bytes());regression_rows.append(dict(language='rust',name=name,scenarios=len(a),unchanged=a==e,reference_sha256=sha(regression/(name+'-1.json'))))
 for stem in ['selection_tasks','disabled_focus','input_metadata']:
  for language in ['c','cpp']:
   a=json.loads((OUT/(stem+'-'+language+'-regression-1.json')).read_bytes());e=json.loads((regression/(stem+'-'+language+'-1.json')).read_bytes());regression_rows.append(dict(language=language,name=stem,scenarios=len(a),unchanged=a==e,reference_sha256=sha(regression/(stem+'-'+language+'-1.json'))))
 report.update(comparisons=comparisons,scenario_counts={language:dict(total=sum(x['language']==language for x in comparisons),exact=sum(x['language']==language and x['exact'] for x in comparisons)) for language in ['rust','c','cpp']},regression_comparisons=regression_rows,all_regression_rows_unchanged=all(x['unchanged'] for x in regression_rows),fresh_local_library_provenance_verified=True)
 headless=run('headless-c-abi-tests',cargo+['test','--locked','--offline','-p','openui-ffi','--lib','--message-format=json'])
 report['headless_tests']=[tuple(map(int,m)) for m in re.findall(rb'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',headless)];save()
 for name,command in [
  ('release-source',[sys.executable,'tools/release/build_v02_linux.py','--verify-source']),
  ('conformance',[sys.executable,'tools/conformance/verify_v02.py']),
  ('performance-contract',[sys.executable,'tools/performance/verify_v02.py']),
  ('porter-controls',[sys.executable,'-m','unittest','tools.wpt.test_sp20_closure']),
  ('c-abi-generator',[sys.executable,'tools/ffi/generate_ffi.py','--check']),
  ('renderer-contract',[sys.executable,'tools/qualification/generate_renderer_contract.py','--check']),
  ('accountability',[sys.executable,'tools/accountability/audit.py','--repository-only']),
 ]:run(name,command,required=False,cwd=MAIN)
 run('rust-format',['bash','-c','ulimit -s 262144; cargo fmt --all -- --check'],required=False)
 for generator in ['tools/release/generate_v02_contract.py','tools/style/generate_properties.py','tools/wpt/generate_sp13r_multicol_closure.py','tools/wpt/generate_sp17_closure.py','tools/wpt/generate_sp18_closure.py','tools/wpt/generate_sp20_closure.py']:
  run('generator-'+Path(generator).stem,[sys.executable,generator,'--check'],required=False,cwd=MAIN)
 report['observed_exit_code']=int(any(x['actual_exit_code']!=0 for x in report['steps']) or not all(x['exact'] for x in comparisons) or not report['all_regression_rows_unchanged']);report['implementation_integrated']=True;report['public_native_behavior_qualified']=report['observed_exit_code']==0;save()
except BaseException as error:
 report.update(observed_exit_code=130 if isinstance(error,KeyboardInterrupt) else 1,failure=repr(error));raise
finally:
 report.update(source_after=identity(SDK),main_source_after=identity(MAIN));report['source_unchanged']=report['source_after']==source;report['main_source_unchanged']=report['main_source_after']==main_source
 assert all(sha(p)==h for p,h in references.items());report['all_commands_terminal']=True;save()
print(json.dumps({k:report[k] for k in ['observed_exit_code','scenario_counts','all_regression_rows_unchanged','source_unchanged','main_source_unchanged','new_comparison_rows']}),flush=True)
raise SystemExit(report['observed_exit_code'])
