# Authored outline test preconditions

Read-only source diagnosis while owner4202 is running; no test or renderer change applied.

`Fragment::owns_element_box()` (bindings/rust/openui-layout/src/fragment.rs535-539) requires Box/Viewport, AuthoredElement ownership, and a non-NONE node. `is_formatting_helper()` (bindings/rust/openui-paint/src/painter.rs727-730) therefore treats each test Box with NodeId::NONE as a helper. `paint_outline()` returns before painting at20117-20119. White surfaces follow from this precondition mismatch independently of the opacity repair.

Two guards need authored nodes:

- coincident_zero_block_outlines_close_the_fractional_joint_cell, painter.rs22415: Fragment at22420 uses NONE at22421.
- inside_marker_zero_block_outline_retains_the_collapsed_two_edge_contour, painter.rs22444: spanner NONE at22450 and parent NONE at22469.

Proposed setup-only repair after freeze clears: create `let mut doc = Document::new();`, obtain an actual `doc.create_node(ElementTag::Div)` ID for the coincident test, and distinct document IDs for spanner/parent in the second test. Pass those IDs to Fragment::new_box. Existing test-module imports already expose Document/ElementTag and neighboring tests use this pattern at21821. Optionally assert each fixture `owns_element_box()` to document the precondition. Appending nodes to the document is unnecessary for the direct paint_outline function, which has no Document argument; retaining the Document during the calls gives real valid authored identity.

Preserve every coordinate, surface/scale/style, the spanner paint_zero_block_outline flag, both repeated outline calls, and the exact five pixel assertions. Do not weaken helper ownership, ignore the tests, change expected bytes, or replace them with synthetic NodeId values. Retain the existing metadata guard proving NONE boxes are nonowners (fragment.rs776).

Verification after actual4202 completion/fresh audit/saved reaping: rerun the two existing exact guards and the full paint suite from the setup-corrected clean checkpoint. Save failed4202 full-suite result and corrected-run source identity separately. This causal source diagnosis does not itself prove the expected painted bytes after the setup correction.
