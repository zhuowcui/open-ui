//! CPU opacity operation diagnostic; not an Engine qualification result.
//! Run after frozen owner, fresh audit and saved process reaping. This program
//! compares operations; it is not a renderer change or a qualification result.
use skia_safe::canvas::{SaveLayerFlags, SaveLayerRec};
use skia_safe::{
    surfaces, AlphaType, Color, Color4f, ColorSpace, ColorType, ImageInfo, Paint, PictureRecorder,
    Rect,
};
use std::error::Error;

#[derive(Clone, Copy, Debug)]
enum Intermediate {
    N32,
    F16,
    Folded,
}

fn layer(canvas: &skia_safe::Canvas, mode: Intermediate, alpha: f32) {
    match mode {
        Intermediate::N32 => {
            canvas.save_layer_alpha_f(None, alpha);
        }
        Intermediate::F16 => {
            let mut paint = Paint::default();
            paint.set_alpha_f(alpha);
            canvas.save_layer(
                &SaveLayerRec::default()
                    .paint(&paint)
                    .flags(SaveLayerFlags::F16_COLOR_TYPE),
            );
        }
        Intermediate::Folded => {
            canvas.save();
        }
    }
}

fn fill(canvas: &skia_safe::Canvas, rect: Rect, rgb: [u8; 3], alpha: f32) {
    let mut paint = Paint::default();
    paint.set_color4f(
        Color4f::new(
            rgb[0] as f32 / 255.0,
            rgb[1] as f32 / 255.0,
            rgb[2] as f32 / 255.0,
            alpha,
        ),
        None::<&ColorSpace>,
    );
    paint.set_anti_alias(false);
    canvas.draw_rect(rect, &paint);
}

fn draw(canvas: &skia_safe::Canvas, mode: Intermediate, nested: bool, two_ops: bool, rgb: [u8; 3]) {
    layer(canvas, mode, 0.5);
    if nested {
        layer(canvas, mode, 0.5);
    }
    let alpha = if matches!(mode, Intermediate::Folded) {
        if nested {
            0.25
        } else {
            0.5
        }
    } else {
        1.0
    };
    fill(canvas, Rect::from_xywh(4.0, 4.0, 16.0, 12.0), rgb, alpha);
    if two_ops {
        // Disjoint second draw keeps the first sample unchanged but adds an
        // operation, which prevents Chromium's single-draw SaveLayerAlpha fold.
        fill(
            canvas,
            Rect::from_xywh(24.0, 4.0, 12.0, 12.0),
            [0, 0, 255],
            alpha,
        );
    }
    if nested {
        canvas.restore();
    }
    canvas.restore();
}

fn sample(
    mode: Intermediate,
    nested: bool,
    two_ops: bool,
    recorded: bool,
    rgb: [u8; 3],
    scale: f32,
    srgb: bool,
) -> Result<[u8; 4], Box<dyn Error>> {
    let width = (40.0 * scale).round() as i32;
    let height = (24.0 * scale).round() as i32;
    let space = if srgb {
        Some(ColorSpace::new_srgb())
    } else {
        None
    };
    let raster_info = ImageInfo::new_n32_premul((width, height), space.clone());
    let mut surface = surfaces::raster(&raster_info, None, None).ok_or("surface")?;
    surface.canvas().clear(Color::WHITE);
    surface.canvas().scale((scale, scale));
    let save_count = surface.canvas().save_count();
    if recorded {
        let mut recorder = PictureRecorder::new();
        let canvas = recorder.begin_recording(Rect::from_xywh(0.0, 0.0, 40.0, 24.0), false);
        draw(canvas, mode, nested, two_ops, rgb);
        let picture = recorder
            .finish_recording_as_picture(None)
            .ok_or("picture")?;
        surface.canvas().draw_picture(&picture, None, None);
    } else {
        draw(surface.canvas(), mode, nested, two_ops, rgb);
    }
    assert_eq!(surface.canvas().save_count(), save_count);
    let image = surface.image_snapshot();
    let info = ImageInfo::new(
        (width, height),
        ColorType::RGBA8888,
        AlphaType::Premul,
        space,
    );
    let mut bytes = vec![0_u8; info.min_row_bytes() * height as usize];
    if !image.read_pixels(
        &info,
        &mut bytes,
        info.min_row_bytes(),
        (0, 0),
        skia_safe::image::CachingHint::Disallow,
    ) {
        return Err("read pixels".into());
    }
    let x = (10.0 * scale) as usize;
    let y = (10.0 * scale) as usize;
    let index = y * info.min_row_bytes() + x * 4;
    Ok(bytes[index..index + 4].try_into()?)
}

fn main() -> Result<(), Box<dyn Error>> {
    for srgb in [false, true] {
        for scale in [1.0_f32, 1.25, 1.5, 2.0, 3.0] {
            for rgb in [[0, 0, 255], [0, 128, 0], [255, 0, 0]] {
                for mode in [Intermediate::N32, Intermediate::F16, Intermediate::Folded] {
                    for nested in [false, true] {
                        for two_ops in [false, true] {
                            for recorded in [false, true] {
                                let rgba =
                                    sample(mode, nested, two_ops, recorded, rgb, scale, srgb)?;
                                println!("{{\"srgb\":{},\"scale\":{},\"rgb\":{:?},\"mode\":\"{:?}\",\"nested\":{},\"two_ops\":{},\"recorded\":{},\"rgba\":{:?}}}",
                                srgb, scale, rgb, mode, nested, two_ops, recorded, rgba);
                            }
                        }
                    }
                }
            }
        }
    }
    Ok(())
}
