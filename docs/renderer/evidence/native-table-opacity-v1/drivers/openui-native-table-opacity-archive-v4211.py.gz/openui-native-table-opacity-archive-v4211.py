import fcntl,gzip,hashlib,json,os,subprocess
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b')
OUT=ROOT/'docs/renderer/evidence/native-table-opacity-v1';INDEX=ROOT/'docs/renderer/generated/native-table-opacity-v1.json'
load=lambda p:json.loads(Path(p).read_bytes())
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof=load('/tmp/openui-native-opacity-paint-guards-reaped-v4210.json')
assert proof['freeze_cleared'] and proof['all_local_commands_terminal'] and proof['owners_absent']
assert subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)==b''
assert not OUT.exists() and not INDEX.exists()
previous=ROOT/'docs/renderer/generated/native-table-origin-v1.json'
assert sha(previous)=='ceeb85f910f67aaf330053b1f3daded6e59a4f104912041215567bd87df028d2'
for m in load(previous)['archive']['members']:
 data=(ROOT/m['path']).read_bytes();raw=gzip.decompress(data) if m['compression']=='gzip' else data
 assert hashlib.sha256(data).hexdigest()==m['sha256'] and hashlib.sha256(raw).hexdigest()==m['raw_sha256']
measurements=[];excluded=[]
runs=[('native-table-ownership-v4174','openui-native-table-ownership-audit-v4175','openui-native-table-ownership-reaped-v4176'),('native-table-ownership-v4182','openui-native-table-ownership-audit-v4183','openui-native-table-ownership-reaped-v4184'),('native-opacity-operations-v4191','openui-native-opacity-operations-audit-v4192','openui-native-opacity-operations-reaped-v4193'),('native-opacity-operations-v4195','openui-native-opacity-operations-audit-v4196','openui-native-opacity-operations-reaped-v4197'),('native-opacity-operations-v4199','openui-native-opacity-operations-audit-v4200','openui-native-opacity-operations-reaped-v4201'),('native-table-opacity-v4202','openui-native-table-opacity-audit-v4203','openui-native-table-opacity-reaped-v4204'),('native-opacity-paint-guards-v4208','openui-native-opacity-paint-guards-audit-v4209','openui-native-opacity-paint-guards-reaped-v4210')]
for directory,audit_name,reaping_name in runs:
 receipt=BASE/directory/'receipt.json';audit=Path('/tmp')/(audit_name+'.json');reaping=Path('/tmp')/(reaping_name+'.json')
 r=load(receipt);a=load(audit);p=load(reaping)
 assert r['all_commands_terminal'] and a['audit_complete'] and p['all_local_commands_terminal'] and p['owners_absent']
 assert sha(receipt)==a['receipt_sha256'] and sha(audit)==p['audit_sha256']
 assert r['source']==a['source']==p['source'] and r['source']['clean']
 assert r['observed_exit_code']==p['actual_owner_exit_code']==a['actual_owner_exit_code'] and p['actual_audit_exit_code']==0
 measurements.append(dict(directory=directory,source=r['source'],receipt_sha256=sha(receipt),audit_sha256=sha(audit),reaping_sha256=sha(reaping),actual_owner_exit_code=r['observed_exit_code'],actual_audit_exit_code=0,measurement_complete=a['measurement_complete'],failure=r.get('failure'),renderer_qualified=False))
 for key,hashkey in [('retained_binary','binary_sha256'),('retained_origin_binary','origin_binary_sha256')]:
  if key in r:
   assert sha(r[key])==r[hashkey]
   excluded.append(dict(path=r[key],sha256=r[hashkey],reason='Measured executable retained outside Git; its identity is preserved in the original receipt.'))
exclude_paths={e['path'] for e in excluded};members=[]
def add(source,relative):
 source=Path(source);assert source.is_file() and not source.is_symlink();raw=source.read_bytes()
 compressed=source.suffix not in ['.png','.gz'];data=gzip.compress(raw,compresslevel=9,mtime=0) if compressed else raw
 dest=OUT/(relative+('.gz' if compressed else ''));assert not dest.exists();dest.parent.mkdir(parents=True,exist_ok=True)
 tmp=dest.with_name(dest.name+'.tmp');tmp.write_bytes(data);os.replace(tmp,dest)
 assert (gzip.decompress(data) if compressed else data)==raw
 members.append(dict(path=str(dest.relative_to(ROOT)),compression='gzip' if compressed else 'none',bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),raw_bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest()))
directories=['native-table-ownership-source-v4173','native-table-ownership-v4174','native-table-ownership-source-v4181','native-table-ownership-v4182','native-table-ownership-audit-review-v4188','native-opacity-source-review-v4189','native-opacity-operation-source-v4190','native-opacity-operations-v4191','native-opacity-repair-review-v4194','native-opacity-operations-v4195','native-opacity-operation-source-v4198','native-opacity-operations-v4199','native-table-opacity-v4202','native-opacity-paint-guards-v4208','native-table-opacity-archive-plan-v4206']
for name in directories:
 assert (BASE/name).is_dir(),name
 for path in sorted((BASE/name).rglob('*')):
  if path.is_file() and not path.is_symlink() and str(path) not in exclude_paths:add(path,str(Path(name)/path.relative_to(BASE/name)))
for _,an,pn in runs:
 for n in [an,pn]:add(Path('/tmp')/(n+'.json'),'proofs/'+n+'.json')
for n in ['openui-native-table-ownership-owner-v4174','openui-native-table-ownership-audit-v4175','openui-native-table-ownership-owner-v4182','openui-native-table-ownership-audit-v4183','openui-native-opacity-operations-owner-v4191','openui-native-opacity-operations-audit-v4192','openui-native-opacity-operations-owner-v4195','openui-native-opacity-operations-audit-v4196','openui-native-opacity-operations-owner-v4199','openui-native-opacity-operations-audit-v4200','openui-native-table-opacity-owner-v4202','openui-native-table-opacity-audit-v4203','openui-native-opacity-paint-guards-owner-v4208','openui-native-opacity-paint-guards-audit-v4209','openui_parallel_source_identity_v3060','openui-native-table-opacity-archive-v4211']:
 add(Path('/tmp')/(n+'.py'),'drivers/'+n+'.py')
for commit in ['6fd79a9a','80797e94','c4e8a809','0d178e2c']:
 for rel in ['bindings/rust/openui-paint/src/painter.rs','bindings/rust/openui/examples/native_table_ownership.rs']:
  raw=subprocess.check_output(['git','show',commit+':'+rel],cwd=ROOT)
  scratch=BASE/'native-table-opacity-archive-source-snapshots-v4211'/commit/rel;scratch.parent.mkdir(parents=True,exist_ok=True);assert not scratch.exists();scratch.write_bytes(raw)
  add(scratch,'source-snapshots/'+commit+'/'+rel)
for member in members:
 data=(ROOT/member['path']).read_bytes();raw=gzip.decompress(data) if member['compression']=='gzip' else data
 assert len(data)==member['bytes'] and len(raw)==member['raw_bytes'] and hashlib.sha256(data).hexdigest()==member['sha256'] and hashlib.sha256(raw).hexdigest()==member['raw_sha256']
r=load(BASE/'native-table-opacity-v4202/receipt.json');g=load(BASE/'native-opacity-paint-guards-v4208/receipt.json');ops=load(BASE/'native-opacity-operations-v4199/receipt.json')
checks=[v for c in r['cases'] for v in c['native'].values()]
assert len(checks)==25 and all(v['analysis']['mismatched_pixels']==0 and v['snapshot_exact'] for v in checks)
origins=[v for c in r['origin_cases'] for v in c['native'].values()]
assert len(origins)==20 and all(v['chromium_nonregression'] and v['new_wrong_pixels_against_chromium']==0 for v in origins)
assert g['test_result']==dict(status='ok',passed=170,failed=0,ignored=0,measured=0,filtered=0)
index=dict(schema_version=1,all_measurement_commands_terminal=True,all_archive_hashes_verified=True,pixel_target='pinned Chromium 147.0.7727.50',pixel_tolerance=0,javascript_executed_by_openui=False,historical_openui_archive_is_a_pixel_target=False,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,measurements=measurements,
 archive=dict(files=len(members),bytes=sum(m['bytes'] for m in members),members=members,excluded=excluded),
 table_ownership=dict(public_example='bindings/rust/openui/examples/native_table_ownership.rs',source_sha256=sha(ROOT/'bindings/rust/openui/examples/native_table_ownership.rs'),source=r['source'],images=25,exact_images=25,geometry_records=275,exact_geometry_records=275,hits=250,exact_hits=250,scroll_snapshots_exact=25,fresh_local_packages=16,compiled_paths=29,independent_native_processes=90,independent_chromium_processes=10,callbacks_repeats_weak_teardown_verified=True),
 original_reduced_neighbors=dict(images=20,exact_images=sum(v['analysis']['mismatched_pixels']==0 for v in origins),geometry_records=sum(v['bounds_count'] for v in origins),exact_geometry_records=sum(v['exact_bounds'] for v in origins),new_wrong_pixels=sum(v['new_wrong_pixels_against_chromium'] for v in origins),chromium_nonregression=True),
 opacity_operations=dict(source=ops['source'],cells=720,independent_runs=2,repeats_byte_identical=True,same_skia_package_features_artifacts_as_4182=True,diagnostic_only=True),
 scoped_tests=dict(engine_source=r['source'],results=r['test_results'],corrected_paint_source=g['source'],corrected_paint_result=g['test_result'],production_painter_identical_to_pixel_measured_c4e8a809=True,original_suite_failure_preserved=True),
 last_complete_original_census=dict(exact=21329,total=22924,different=1595,errors=0,comparison_pass_percentage=100*21329/22924,new_census=False),
 previous_immutable_evidence=dict(path=str(previous.relative_to(ROOT)),sha256=sha(previous)),
 pending=['Complete original and expanded censuses on the changed shared renderer.','Focused and primitive 40-profile gates on the changed renderer.','Original table glyph, collapsed used-border and joint-paint repairs.','Every needed native API, compositor, hardware and release qualification.'])
t=INDEX.with_suffix('.tmp');t.write_text(json.dumps(index,sort_keys=True,indent=2)+'\n');os.replace(t,INDEX)
print(json.dumps(dict(index=str(INDEX),members=len(members),bytes=index['archive']['bytes'],sha256=sha(INDEX),all_hashes_verified=True)))
