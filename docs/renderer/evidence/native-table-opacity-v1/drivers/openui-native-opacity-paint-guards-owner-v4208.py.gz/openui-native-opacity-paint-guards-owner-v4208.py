import fcntl, hashlib, json, os, shutil, signal, subprocess, sys, time
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui')
BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b')
PROJECT=BASE/'native-opacity-operation-source-v4198/project'
OUT=BASE/'native-opacity-paint-guards-v4208'
TARGET=Path('/mnt/e/openui-v02-cargo-c73754e2/target')
TEMP=Path('/dev/shm/ou4208')
sys.path.insert(0,'/tmp')
from openui_parallel_source_identity_v3060 import identity

def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(p):return json.loads(Path(p).read_bytes())
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','rustfmt','pixel_compare']:
 assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
prior=load('/tmp/openui-native-table-opacity-reaped-v4204.json')
assert prior['freeze_cleared'] and prior['all_local_commands_terminal'] and prior['owners_absent']
source=identity(ROOT)
assert source['clean'] and source['commit']==sys.argv[1]
assert not OUT.exists() and not TEMP.exists()
OUT.mkdir();TEMP.mkdir()
inputs={str(p):sha(p) for p in PROJECT.parent.rglob('*') if p.is_file()}
for p in [Path('/tmp/openui-native-table-opacity-reaped-v4204.json'),Path('/tmp/openui-native-table-ownership-audit-v4183.json'),BASE/'native-table-ownership-v4182/receipt.json',BASE/'native-table-ownership-v4182/native-build.log',ROOT/'bindings/rust/.cargo/config.chromium.toml',Path('/tmp/openui_parallel_source_identity_v3060.py')]:inputs[str(p)]=sha(p)
for p in (BASE/'native-opacity-source-review-v4189').rglob('*'):
 if p.is_file():inputs[str(p)]=sha(p)
for p in (BASE/'native-table-ownership-v4182/profile-0').glob('*opacity*'):
 if p.is_file():inputs[str(p)]=sha(p)
env=dict(os.environ,CARGO_TARGET_DIR=str(TARGET),CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='4',RUST_MIN_STACK='4194304',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(TEMP))
env.pop('LD_PRELOAD',None);env.pop('LD_LIBRARY_PATH',None)
report=dict(schema_version=1,owner_pid=os.getpid(),source=source,driver_sha256=sha(__file__),input_sha256=inputs,steps=[],diagnostic_only=True,engine_qualification=False,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,all_commands_terminal=False)
def save():
 p=OUT/'receipt.tmp';p.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');os.replace(p,OUT/'receipt.json')
def guard():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()==source['commit']
 assert subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)==b''
 assert sha(__file__)==report['driver_sha256']
 for p,h in inputs.items():assert sha(p)==h,p
 for p,limit in [(ROOT,128*2**20),(OUT,10*2**30),(TARGET,10*2**30),(TEMP,256*2**20)]:assert shutil.disk_usage(p).free>limit,str(p)
def run(name,command,timeout=1200):
 guard();print('Starting '+name,flush=True);log=OUT/(name+'.log');child=None
 try:
  with log.open('xb') as stream:
   child=subprocess.Popen(command,cwd=ROOT/'bindings/rust',env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
   report['current_process']=dict(name=name,pid=child.pid);save();start=time.monotonic()
   while child.poll() is None:
    assert time.monotonic()-start<timeout,name
    guard();time.sleep(1)
   code=child.wait()
 finally:
  if child is not None and child.poll() is None:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=20)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
  report.pop('current_process',None)
  report['steps'].append(dict(name=name,command=command,pid=None if child is None else child.pid,actual_exit_code=None if child is None else child.returncode,log_sha256=sha(log)));save()
 guard();print(json.dumps(dict(stage=name,actual_exit_code=code)),flush=True);return code,log
save();code=1
try:
 cargo=['cargo','--config',str(ROOT/'bindings/rust/.cargo/config.chromium.toml')]
 manifest=['--manifest-path',str(ROOT/'bindings/rust/Cargo.toml')]
 old=subprocess.check_output(['git','show','c4e8a809:bindings/rust/openui-paint/src/painter.rs'],cwd=ROOT).decode()
 current=(ROOT/'bindings/rust/openui-paint/src/painter.rs').read_text()
 assert old.split('#[cfg(test)]',1)[0]==current.split('#[cfg(test)]',1)[0]
 report['production_painter_identical_to_pixel_measured_c4e8a809']=True
 report['production_painter_sha256']=hashlib.sha256(current.split('#[cfg(test)]',1)[0].encode()).hexdigest();save()
 status,_=run('clean-paint-package',cargo+['clean','--locked','--offline']+manifest+['-p','openui-paint']);assert status==0
 status,log=run('full-paint-guards',cargo+['test','--locked','--offline','--message-format=json-render-diagnostics']+manifest+['-p','openui-paint','--lib','--','--test-threads=1']);
 artifacts=[];binary=None
 for line in log.read_text().splitlines():
  try:row=json.loads(line)
  except json.JSONDecodeError:continue
  if row.get('reason')=='compiler-artifact':
   artifacts.append(row)
   if row['target']['name']=='openui_paint' and row['profile']['test']:
    assert not row['fresh'];binary=Path(row['executable'])
 report['compiler_artifacts']=artifacts;report['compiled_artifact_sha256']={p:sha(p) for r in artifacts for p in r['filenames']}
 assert binary is not None
 retained=OUT/'paint-guards';shutil.copyfile(binary,retained);retained.chmod(0o755)
 report['binary']=str(binary);report['binary_sha256']=sha(binary);report['retained_binary']=str(retained);assert sha(retained)==report['binary_sha256']
 import re
 summaries=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',log.read_text())
 assert len(summaries)==1,summaries
 kind,passed,failed,ignored,measured,filtered=summaries[0]
 report['test_result']=dict(status=kind,passed=int(passed),failed=int(failed),ignored=int(ignored),measured=int(measured),filtered=int(filtered))
 report['measurement_complete']=True;save()
 assert status==0 and report['test_result']==dict(status='ok',passed=170,failed=0,ignored=0,measured=0,filtered=0)
 code=0
except BaseException as error:
 report['failure']=repr(error);print(json.dumps(dict(failure=repr(error))),flush=True)
finally:
 report['source_after']=identity(ROOT);report['source_unchanged']=report['source_after']==source
 report['inputs_unchanged']=all(sha(p)==h for p,h in inputs.items())
 report['all_commands_terminal']=True;report['observed_exit_code']=code
 report['output_sha256']={str(p):sha(p) for p in OUT.rglob('*') if p.is_file() and p.name not in ['receipt.json','receipt.tmp']}
 save();shutil.rmtree(TEMP)
 print(json.dumps(dict(owner_complete=True,actual_exit_code=code,test_result=report.get('test_result'))),flush=True);sys.exit(code)
