import hashlib,itertools,json,os,subprocess,sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b')
OUT=BASE/'native-opacity-operations-v4199';RECEIPT=OUT/'receipt.json';DEST=Path('/tmp/openui-native-opacity-operations-audit-v4200.json')
sys.path.insert(0,'/tmp')
from openui_parallel_source_identity_v3060 import identity

def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def absent(pid):
 try:os.kill(pid,0);return False
 except ProcessLookupError:return True
assert not DEST.exists();r=json.loads(RECEIPT.read_bytes())
assert r['all_commands_terminal'] and absent(r['owner_pid'])
assert r['source']==r['source_after']==identity(ROOT) and r['source']['clean']
assert sha('/tmp/openui-native-opacity-operations-owner-v4199.py')==r['driver_sha256']
for p,h in r['input_sha256'].items():assert sha(p)==h,p
for step in r['steps']:
 assert absent(step['pid']) and sha(OUT/(step['name']+'.log'))==step['log_sha256']
expected_artifacts=[]
if (OUT/'diagnostic-build.log').exists():
 for line in (OUT/'diagnostic-build.log').read_text().splitlines():
  try:item=json.loads(line)
  except json.JSONDecodeError:continue
  if item.get('reason')=='compiler-artifact':expected_artifacts.append(item)
if r.get('measurement_complete'):
 assert r['observed_exit_code']==0 and all(s['actual_exit_code']==0 for s in r['steps'])
 assert len(r['steps'])==5
 assert expected_artifacts==r['compiler_artifacts']
 assert set(r['compiled_artifact_sha256'])=={p for a in expected_artifacts for p in a['filenames']}
 for p,h in r['compiled_artifact_sha256'].items():assert sha(p)==h,p
 assert sha(r['binary'])==sha(r['retained_binary'])==r['binary_sha256']
 metadata_rows=[json.loads(line) for line in (OUT/'metadata.log').read_text().splitlines() if line.startswith('{')]
 assert len(metadata_rows)==1
 meta=metadata_rows[0]
 ids={p['id'] for p in meta['packages'] if Path(p['manifest_path']).resolve().is_relative_to(BASE/'native-opacity-operation-source-v4198/project')}
 owned=[a for a in expected_artifacts if a['package_id'] in ids]
 assert len(ids)==len(owned)==1 and owned[0]['fresh'] is False and owned[0]['executable']==r['binary']
 previous=[]
 for line in (BASE/'native-table-ownership-v4182/native-build.log').read_text().splitlines():
  try:item=json.loads(line)
  except json.JSONDecodeError:continue
  if item.get('reason')=='compiler-artifact' and item['target']['name'] in ['skia_safe','skia_bindings']:previous.append(item)
 now=[a for a in expected_artifacts if a['target']['name'] in ['skia_safe','skia_bindings']]
 assert len(previous)==len(now)==2
 for a in now:
  old=next(b for b in previous if b['target']['name']==a['target']['name'])
  for k in ['package_id','features','filenames']:assert a[k]==old[k]
 a=(OUT/'operations-run-1.log').read_bytes();b=(OUT/'operations-run-2.log').read_bytes();assert a==b
 rows=[json.loads(l) for l in a.splitlines()]
 keys=[(q['srgb'],q['scale'],tuple(q['rgb']),q['mode'],q['nested'],q['two_ops'],q['recorded']) for q in rows]
 expected=set(itertools.product([False,True],[1,1.25,1.5,2,3],[(0,0,255),(0,128,0),(255,0,0)],['N32','F16','Folded'],[False,True],[False,True],[False,True]))
 assert len(rows)==len(set(keys))==len(expected)==720 and set(keys)==expected
 for q in rows:
  assert set(q)=={'srgb','scale','rgb','mode','nested','two_ops','recorded','rgba'}
  assert len(q['rgba'])==4 and all(type(c) is int and 0<=c<=255 for c in q['rgba'])
 summary=[]
 for srgb,rgb,mode,nested in itertools.product([False,True],[(0,0,255),(0,128,0),(255,0,0)],['N32','F16','Folded'],[False,True]):
  subset=[q for q in rows if q['srgb']==srgb and tuple(q['rgb'])==rgb and q['mode']==mode and q['nested']==nested]
  colors=sorted({tuple(q['rgba']) for q in subset})
  summary.append(dict(srgb=srgb,rgb=rgb,mode=mode,nested=nested,count=len(subset),rgba_values=colors))
else:summary=[]
outputs={str(p):sha(p) for p in OUT.rglob('*') if p.is_file() and p.name not in ['receipt.json','receipt.tmp']}
assert outputs==r['output_sha256']
result=dict(schema_version=1,audit_complete=True,measurement_complete=bool(r.get('measurement_complete')),actual_owner_exit_code=r['observed_exit_code'],owner_absent=True,all_commands_terminal=True,source=r['source'],receipt_sha256=sha(RECEIPT),audit_driver_sha256=sha(__file__),compiled_artifact_sha256=r.get('compiled_artifact_sha256',{}),output_sha256=outputs,case_count=len(rows) if summary else 0,operation_summary=summary,diagnostic_only=True,engine_qualification=False,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,retired_for_reexecution_after_source_or_target_mutation=True)
t=DEST.with_suffix('.tmp');t.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');os.replace(t,DEST)
print(json.dumps(dict(audit_complete=True,measurement_complete=result['measurement_complete'],cases=result['case_count'],operation_summary=summary)))
