import hashlib,json,os,re,subprocess,sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');OUT=Path('/mnt/d/openui-v02-qualification-d174ea0b/native-opacity-paint-guards-v4208');DEST=Path('/tmp/openui-native-opacity-paint-guards-audit-v4209.json')
sys.path.insert(0,'/tmp')
from openui_parallel_source_identity_v3060 import identity

def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def absent(pid):
 try:os.kill(pid,0);return False
 except ProcessLookupError:return True
assert not DEST.exists();r=json.loads((OUT/'receipt.json').read_bytes())
assert r['all_commands_terminal'] and absent(r['owner_pid'])
assert r['source']==r['source_after']==identity(ROOT) and r['source']['clean']
assert sha('/tmp/openui-native-opacity-paint-guards-owner-v4208.py')==r['driver_sha256']
for p,h in r['input_sha256'].items():assert sha(p)==h,p
for step in r['steps']:assert absent(step['pid']) and sha(OUT/(step['name']+'.log'))==step['log_sha256']
artifacts=[]
log=OUT/'full-paint-guards.log'
if log.exists():
 for line in log.read_text().splitlines():
  try:a=json.loads(line)
  except json.JSONDecodeError:continue
  if a.get('reason')=='compiler-artifact':artifacts.append(a)
if r.get('measurement_complete'):
 assert artifacts==r['compiler_artifacts']
 assert set(r['compiled_artifact_sha256'])=={p for a in artifacts for p in a['filenames']}
 for p,h in r['compiled_artifact_sha256'].items():assert sha(p)==h,p
 assert sha(r['binary'])==sha(r['retained_binary'])==r['binary_sha256']
 owned=[a for a in artifacts if a['target']['name']=='openui_paint' and a['profile']['test']]
 assert len(owned)==1 and owned[0]['fresh'] is False and owned[0]['executable']==r['binary']
 sums=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',log.read_text());assert len(sums)==1
 kind,passed,failed,ignored,measured,filtered=sums[0]
 observed=dict(status=kind,passed=int(passed),failed=int(failed),ignored=int(ignored),measured=int(measured),filtered=int(filtered));assert observed==r['test_result']
 if r['observed_exit_code']==0:assert observed==dict(status='ok',passed=170,failed=0,ignored=0,measured=0,filtered=0)
 old=subprocess.check_output(['git','show','c4e8a809:bindings/rust/openui-paint/src/painter.rs'],cwd=ROOT).decode()
 current=(ROOT/'bindings/rust/openui-paint/src/painter.rs').read_text()
 assert old.split('#[cfg(test)]',1)[0]==current.split('#[cfg(test)]',1)[0]
 assert hashlib.sha256(current.split('#[cfg(test)]',1)[0].encode()).hexdigest()==r['production_painter_sha256']
else:observed=None
outputs={str(p):sha(p) for p in OUT.rglob('*') if p.is_file() and p.name not in ['receipt.json','receipt.tmp']};assert outputs==r['output_sha256']
for name in ['cargo','rustc','rustfmt','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
result=dict(schema_version=1,audit_complete=True,measurement_complete=bool(r.get('measurement_complete')),actual_owner_exit_code=r['observed_exit_code'],owner_absent=True,all_commands_terminal=True,source=r['source'],receipt_sha256=sha(OUT/'receipt.json'),audit_driver_sha256=sha(__file__),compiled_artifact_sha256=r.get('compiled_artifact_sha256',{}),output_sha256=outputs,test_result=observed,production_painter_identical_to_pixel_measured_c4e8a809=r.get('production_painter_identical_to_pixel_measured_c4e8a809',False),renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,retired_for_reexecution_after_source_or_target_mutation=True)
t=DEST.with_suffix('.tmp');t.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');os.replace(t,DEST)
print(json.dumps(dict(audit_complete=True,measurement_complete=result['measurement_complete'],test_result=observed)))
