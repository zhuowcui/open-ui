import fcntl, hashlib, json, os, shutil, signal, subprocess, sys, time
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui')
BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b')
PROJECT=BASE/'native-opacity-operation-source-v4198/project'
OUT=BASE/'native-opacity-operations-v4199'
TARGET=Path('/mnt/e/openui-v02-cargo-c73754e2/target')
TEMP=Path('/dev/shm/ou4199')
sys.path.insert(0,'/tmp')
from openui_parallel_source_identity_v3060 import identity

def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(p):return json.loads(Path(p).read_bytes())
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','rustfmt','pixel_compare']:
 assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
prior=load('/tmp/openui-native-opacity-operations-reaped-v4197.json')
assert prior['freeze_cleared'] and prior['all_local_commands_terminal'] and prior['owners_absent']
source=identity(ROOT)
assert source['clean'] and source['commit']==sys.argv[1]
assert not OUT.exists() and not TEMP.exists()
OUT.mkdir();TEMP.mkdir()
inputs={str(p):sha(p) for p in PROJECT.parent.rglob('*') if p.is_file()}
for p in [Path('/tmp/openui-native-opacity-operations-reaped-v4197.json'),Path('/tmp/openui-native-table-ownership-audit-v4183.json'),BASE/'native-table-ownership-v4182/receipt.json',BASE/'native-table-ownership-v4182/native-build.log',ROOT/'bindings/rust/.cargo/config.chromium.toml',Path('/tmp/openui_parallel_source_identity_v3060.py')]:inputs[str(p)]=sha(p)
for p in (BASE/'native-opacity-source-review-v4189').rglob('*'):
 if p.is_file():inputs[str(p)]=sha(p)
for p in (BASE/'native-table-ownership-v4182/profile-0').glob('*opacity*'):
 if p.is_file():inputs[str(p)]=sha(p)
env=dict(os.environ,CARGO_TARGET_DIR=str(TARGET),CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='4',RUST_MIN_STACK='4194304',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(TEMP))
env.pop('LD_PRELOAD',None);env.pop('LD_LIBRARY_PATH',None)
report=dict(schema_version=1,owner_pid=os.getpid(),source=source,driver_sha256=sha(__file__),input_sha256=inputs,steps=[],diagnostic_only=True,engine_qualification=False,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,all_commands_terminal=False)
def save():
 p=OUT/'receipt.tmp';p.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');os.replace(p,OUT/'receipt.json')
def guard():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()==source['commit']
 assert subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)==b''
 assert sha(__file__)==report['driver_sha256']
 for p,h in inputs.items():assert sha(p)==h,p
 for p,limit in [(ROOT,128*2**20),(OUT,10*2**30),(TARGET,10*2**30),(TEMP,256*2**20)]:assert shutil.disk_usage(p).free>limit,str(p)
def run(name,command,timeout=1200):
 guard();print('Starting '+name,flush=True);log=OUT/(name+'.log');child=None
 try:
  with log.open('xb') as stream:
   child=subprocess.Popen(command,cwd=ROOT/'bindings/rust',env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
   report['current_process']=dict(name=name,pid=child.pid);save();start=time.monotonic()
   while child.poll() is None:
    assert time.monotonic()-start<timeout,name
    guard();time.sleep(1)
   code=child.wait()
 finally:
  if child is not None and child.poll() is None:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=20)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
  report.pop('current_process',None)
  report['steps'].append(dict(name=name,command=command,pid=None if child is None else child.pid,actual_exit_code=None if child is None else child.returncode,log_sha256=sha(log)));save()
 guard();print(json.dumps(dict(stage=name,actual_exit_code=code)),flush=True);return code,log
save();code=1
try:
 cargo=['cargo','--config',str(ROOT/'bindings/rust/.cargo/config.chromium.toml')]
 manifest=['--manifest-path',str(PROJECT/'Cargo.toml')]
 status,log=run('metadata',cargo+['metadata','--locked','--offline','--format-version','1']+manifest);assert status==0
 metadata_rows=[json.loads(line) for line in log.read_text().splitlines() if line.startswith('{')]
 assert len(metadata_rows)==1
 metadata=metadata_rows[0]
 package_ids={p['id'] for p in metadata['packages'] if Path(p['manifest_path']).resolve().is_relative_to(PROJECT)}
 assert len(package_ids)==1
 status,_=run('clean-diagnostic-package',cargo+['clean','--locked','--offline']+manifest+[a for p in sorted(package_ids) for a in ['-p',p]]);assert status==0
 status,log=run('diagnostic-build',cargo+['build','--locked','--offline','--message-format=json-render-diagnostics']+manifest);assert status==0
 artifacts=[];binary=None
 for line in log.read_text().splitlines():
  try:row=json.loads(line)
  except json.JSONDecodeError:continue
  if row.get('reason')=='compiler-artifact':
   artifacts.append(row)
   if row['package_id'] in package_ids:
    assert not row['fresh'] and row['executable'];binary=Path(row['executable'])
 assert binary is not None
 report['compiler_artifacts']=artifacts
 report['compiled_artifact_sha256']={p:sha(p) for r in artifacts for p in r['filenames']}
 previous=[]
 for line in (BASE/'native-table-ownership-v4182/native-build.log').read_text().splitlines():
  try:row=json.loads(line)
  except json.JSONDecodeError:continue
  if row.get('reason')=='compiler-artifact' and row['target']['name'] in ['skia_safe','skia_bindings']:previous.append(row)
 current=[r for r in artifacts if r['target']['name'] in ['skia_safe','skia_bindings']]
 assert len(current)==len(previous)==2
 for row in current:
  old=next(r for r in previous if r['target']['name']==row['target']['name'])
  assert row['package_id']==old['package_id'] and row['features']==old['features'] and row['filenames']==old['filenames']
 report['same_skia_package_features_artifacts_as_4182']=True
 retained=OUT/'opacity-operations';shutil.copyfile(binary,retained);retained.chmod(0o755)
 report['binary']=str(binary);report['binary_sha256']=sha(binary);report['retained_binary']=str(retained);assert sha(retained)==report['binary_sha256'];save()
 runs=[]
 for n in [1,2]:
  status,log=run('operations-run-'+str(n),[str(retained)],timeout=180);assert status==0
  rows=[json.loads(l) for l in log.read_text().splitlines()];assert len(rows)==720
  keys=[(r['srgb'],r['scale'],tuple(r['rgb']),r['mode'],r['nested'],r['two_ops'],r['recorded']) for r in rows]
  assert len(set(keys))==720
  runs.append(log)
 assert runs[0].read_bytes()==runs[1].read_bytes()
 report['case_count']=720;report['independent_runs']=2;report['repeats_byte_identical']=True;report['measurement_complete']=True
 code=0
except BaseException as error:
 report['failure']=repr(error);print(json.dumps(dict(failure=repr(error))),flush=True)
finally:
 report['source_after']=identity(ROOT);report['source_unchanged']=report['source_after']==source
 report['inputs_unchanged']=all(sha(p)==h for p,h in inputs.items())
 report['all_commands_terminal']=True;report['observed_exit_code']=code
 report['output_sha256']={str(p):sha(p) for p in OUT.rglob('*') if p.is_file() and p.name not in ['receipt.json','receipt.tmp']}
 save()
 shutil.rmtree(TEMP)
 print(json.dumps(dict(owner_complete=True,actual_exit_code=code,measurement_complete=report.get('measurement_complete',False))),flush=True)
 sys.exit(code)
