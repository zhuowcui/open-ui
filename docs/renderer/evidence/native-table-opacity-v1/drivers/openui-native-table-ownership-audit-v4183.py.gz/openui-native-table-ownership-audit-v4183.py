import hashlib
import json
import subprocess
import sys
from pathlib import Path
from PIL import Image
import numpy as np

ROOT = Path('/home/nero/code/open-ui')
OUT = Path('/mnt/d/openui-v02-qualification-d174ea0b/native-table-ownership-v4182')
PROOF = Path('/tmp/openui-native-table-ownership-audit-v4183.json')
assert not PROOF.exists()
sys.path[:0] = [str(ROOT / 'tools/qualification'), '/tmp']
from openui_parallel_source_identity_v3060 import identity
from residuals import analyze_image_difference
load = lambda path: json.loads(Path(path).read_bytes())
def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

r = load(OUT / 'receipt.json')
assert r['all_commands_terminal'] and r['source_unchanged'] and r['inputs_unchanged']
assert r['source'] == r['source_after'] == identity(ROOT)
assert subprocess.run(['ps', '-p', str(r['owner_pid'])], capture_output=True).returncode == 1
assert sha('/tmp/openui-native-table-ownership-owner-v4182.py') == r['driver_sha256']
for path, expected in r['input_sha256'].items():
    assert sha(path) == expected, path
for step in r['steps']:
    if step.get('pid'):
        assert subprocess.run(['ps', '-p', str(step['pid'])], capture_output=True).returncode == 1
    if 'log_sha256' in step:
        assert sha(OUT / (step['name'] + '.log')) == step['log_sha256']
assert sha(ROOT / 'chrome/linux-147.0.7727.50/chrome-linux64/chrome') == r['chromium_binary_sha256']
compiled = 0
compiled_hashes = {}
metadata = load(OUT/'metadata.log')
project = Path('/mnt/d/openui-v02-qualification-d174ea0b/native-table-ownership-source-v4181/project')
local_ids = {p['id'] for p in metadata['packages'] if Path(p['manifest_path']).resolve().is_relative_to(ROOT) or Path(p['manifest_path']).resolve().is_relative_to(project)}
for path, expected in r.get('compiled_artifact_sha256', {}).items():
    assert sha(path) == expected, path
    compiled_hashes[path] = expected
    compiled += 1
parsed_artifacts = []
if (OUT/'native-build.log').exists():
    for line in (OUT/'native-build.log').read_text().splitlines():
        try: row = json.loads(line)
        except json.JSONDecodeError: continue
        if row.get('reason') == 'compiler-artifact' and row['package_id'] in local_ids:
            parsed_artifacts.append(row)
if 'compiler_artifacts' in r:
    artifacts = r['compiler_artifacts']
    assert artifacts == parsed_artifacts
else:
    assert r.get('failure')
    artifacts = parsed_artifacts
    for row in artifacts:
        for path in row['filenames']:
            assert Path(path).is_file()
            compiled_hashes[path] = sha(path)
    compiled = len(compiled_hashes)
expected_compiled_paths = {path for row in artifacts for path in row['filenames']}
assert set(compiled_hashes) == expected_compiled_paths
assert all(row['fresh'] is False for row in artifacts)
compiled_ids = {row['package_id'] for row in artifacts}
assert compiled_ids <= local_ids
if 'failure' not in r:
    assert compiled_ids == local_ids and len(local_ids) == 16
    assert compiled_hashes == r['compiled_artifact_sha256']
if artifacts:
    metadata = load(OUT / 'metadata.log')
    packages = {row['id']:row for row in metadata['packages']}
    for row in artifacts:
        manifest = Path(packages[row['package_id']]['manifest_path']).resolve()
        assert manifest.is_relative_to(ROOT) or manifest.is_relative_to(Path('/mnt/d/openui-v02-qualification-d174ea0b/native-table-ownership-source-v4181/project'))
    if 'binary' in r:
        assert sha(r['binary']) == sha(r['retained_binary']) == r['binary_sha256']
images = {}; comparisons = 0; observations = []
def picture(path, profile):
    path = Path(path)
    if str(path) not in images:
        with Image.open(path) as image:
            assert image.size == tuple(round(profile[key]*profile['scale']) for key in ['width', 'height'])
            images[str(path)] = dict(sha256=sha(path), rgba_sha256=hashlib.sha256(image.convert('RGBA').tobytes()).hexdigest())
    return images[str(path)]
states=['base','translated','opacity','clipped','scrolled']
plan = load(project.parent/'plan.json')
profiles = [dict(width=400,height=240,scale=scale) for scale in [1,1.25,1.5,2,3]]
def snapshot_shape(snapshot):
    names = [node['name'] for node in snapshot['nodes']]
    assert names == plan['node_ids'] and len(set(names)) == 11
    assert [(hit['x'],hit['y']) for hit in snapshot['hits']] == [tuple(point) for point in plan['hit_points_css_px']]
if 'failure' not in r:
    assert [row['profile'] for row in r['cases']] == profiles
    assert [row['profile'] for row in r['origin_cases']] == profiles
    assert [test['name'] for test in r['test_results']] == ['layout-unit-guards','paint-ownership-guards','native-conformance']
    for test in r['test_results']:
        matching = [step for step in r['steps'] if step['name'] == test['name']]
        assert len(matching) == 1 and matching[0]['actual_exit_code'] == test['actual_exit_code']
for index,row in enumerate(r['cases']):
    directory=OUT/f'profile-{index}';profile=row['profile']
    assert profile == profiles[index]
    if 'failure' not in r:
        assert set(row['native']) == set(states) and set(row['chromium_snapshots']) == set(states)
    for state in states:
        first=load(directory/f'chromium-1-{state}-bounds.json')
        assert first==load(directory/f'chromium-2-{state}-bounds.json')==row['chromium_snapshots'][state]
        snapshot_shape(first); assert first['state'] == state
        expected={node['name']:node for node in first['nodes']};assert len(expected)==11 and len(first['hits'])==10
        browser=[picture(directory/f'chromium-{repeat}-{state}-{number}.png',profile) for repeat in [1,2] for number in [1,2]]
        assert all(blob==browser[0] for blob in browser)
        if state not in row.get('native',{}):continue
        result=row['native'][state];runs=result['runs'];assert len(runs)==2 and runs[0]['files']==runs[1]['files']
        for run in runs:
            native=Path(run['directory'])
            for name,expected_sha in run['files'].items():assert sha(native/name)==expected_sha
            lifecycle=load(native/'lifecycle.json');snapshot=load(native/'bounds.json');snapshot_shape(snapshot)
            assert lifecycle['native_click_callbacks']==1 and lifecycle['unchanged_frame_byte_repeat'] and lifecycle['count_only_callback_preserved_pixels']
            assert lifecycle['weak_teardown_passed'] and not lifecycle['javascript_executed_by_openui']
            assert lifecycle['all_single_owned_box']==all(len(node['client_rects'])==1 for node in snapshot['nodes'])
            picture(native/'frame.png',profile)
        native=Path(runs[0]['directory']);snapshot=load(native/'bounds.json');observed={node['name']:node for node in snapshot['nodes']}
        assert snapshot['state']==state and expected.keys()==observed.keys()
        assert result['native_snapshot']==snapshot and result['nodes_count']==11 and result['hits_count']==10
        assert result['exact_nodes']==sum(expected[name]==observed[name] for name in expected)
        assert result['exact_hits']==sum(a==b for a,b in zip(snapshot['hits'],first['hits']))
        assert result['scroll_exact']==((snapshot['scroll_left'],snapshot['scroll_top'])==(first['scroll_left'],first['scroll_top']))
        assert result['snapshot_exact']==(snapshot==first)
        assert result['analysis']==analyze_image_difference(directory/f'chromium-1-{state}-1.png',native/'frame.png')
        comparisons+=1
    observations.append(dict(profile=profile,native={state:{key:result[key] for key in ['exact_nodes','nodes_count','exact_hits','hits_count','scroll_exact','snapshot_exact']}|{'different_pixels':result['analysis']['mismatched_pixels']} for state,result in row.get('native',{}).items()}))
if 'failure' not in r:
    assert len(r['cases'])==5 and comparisons==25
    expected_code=int(any(test['actual_exit_code'] for test in r['test_results']) or any(result['analysis']['mismatched_pixels'] or not result['snapshot_exact'] for row in r['cases'] for result in row['native'].values()) or any(not result['chromium_nonregression'] for row in r.get('origin_cases',[]) for result in row['native'].values()))
    assert r['observed_exit_code']==expected_code
origin_observations=[];origin_comparisons=0
origin_base=Path('/mnt/d/openui-v02-qualification-d174ea0b/native-table-origin-v4156')
reference=load(origin_base/'receipt.json')
if 'origin_binary' in r:
    assert sha(r['origin_binary'])==sha(r['retained_origin_binary'])==r['origin_binary_sha256']
    origin_fresh=[a for a in r['origin_compiler_artifacts'] if not a['fresh']];assert len(origin_fresh)==1
    assert Path(origin_fresh[0]['target']['src_path']).resolve().is_relative_to(Path('/mnt/d/openui-v02-qualification-d174ea0b/native-table-ownership-source-v4181/origin-project'))
for index,row in enumerate(r.get('origin_cases',[])):
    profile=row['profile'];prior=reference['cases'][index];assert prior['profile']==profile==profiles[index]
    if 'failure' not in r: assert set(row['native']) == {policy+'-'+markers for policy in ['auto','fitted'] for markers in ['no','yes']}
    for key,result in row['native'].items():
        policy,markers=key.split('-');runs=result['runs'];assert len(runs)==2 and runs[0]['files']==runs[1]['files']
        for run in runs:
            native=Path(run['directory'])
            for name,expected_sha in run['files'].items():assert sha(native/name)==expected_sha
            lifecycle=load(native/'lifecycle.json');assert lifecycle['native_click_callbacks']==1 and lifecycle['unchanged_frame_byte_repeat'] and lifecycle['count_only_callback_preserved_pixels'] and lifecycle['weak_teardown_passed'] and not lifecycle['javascript_executed_by_openui'];picture(native/'frame.png',profile)
        native=Path(runs[0]['directory']);expected={node['name']:node for node in prior['chromium_bounds'][markers]};snapshot=load(native/'bounds.json');assert snapshot['policy']==policy and snapshot['markers']==markers;observed={node['name']:node for node in snapshot['nodes']};assert expected.keys()==observed.keys()
        assert result['native_bounds']==snapshot['nodes'] and result['bounds_count']==len(observed) and result['exact_bounds']==sum(observed[name]==expected[name] for name in observed)
        oracle=origin_base/f'profile-{index}'/f'chromium-1-{markers}-1.png';picture(oracle,profile)
        analysis=analyze_image_difference(oracle,native/'frame.png');assert analysis==result['analysis'];previous=prior['native'][policy]['comparisons'][markers]['analysis'];assert previous==result['previous_chromium_analysis']
        unchanged=sha(native/'frame.png')==prior['native'][policy]['runs'][markers][0]['files']['frame.png'];assert result['pixels_unchanged_from_previous_native']==unchanged
        old_frame=Path(prior['native'][policy]['runs'][markers][0]['directory'])/'frame.png'
        expected_pixels=np.asarray(Image.open(oracle).convert('RGBA'));old_pixels=np.asarray(Image.open(old_frame).convert('RGBA'));new_pixels=np.asarray(Image.open(native/'frame.png').convert('RGBA'));assert expected_pixels.shape==old_pixels.shape==new_pixels.shape
        new_wrong=int(np.count_nonzero(np.any(new_pixels!=expected_pixels,axis=2)&np.all(old_pixels==expected_pixels,axis=2)));assert result['new_wrong_pixels_against_chromium']==new_wrong
        nonregression=new_wrong==0 and analysis['mismatched_pixels']<=previous['mismatched_pixels'] and all(analysis['channel_deltas'][channel]['changed_pixels']<=previous['channel_deltas'][channel]['changed_pixels'] and analysis['channel_deltas'][channel]['maximum_absolute_delta']<=previous['channel_deltas'][channel]['maximum_absolute_delta'] for channel in analysis['channel_deltas']);assert result['chromium_nonregression']==nonregression;origin_comparisons+=1
    origin_observations.append(dict(profile=profile,native={name:{k:result[k] for k in ['exact_bounds','bounds_count','pixels_unchanged_from_previous_native','chromium_nonregression','new_wrong_pixels_against_chromium']} for name,result in row['native'].items()}))
if 'failure' not in r:
    assert origin_comparisons==20
    expected_code=int(any(test['actual_exit_code'] for test in r['test_results']) or any(result['analysis']['mismatched_pixels'] or not result['snapshot_exact'] for row in r['cases'] for result in row['native'].values()) or any(not result['chromium_nonregression'] for row in r['origin_cases'] for result in row['native'].values()) or any(not result['chromium_nonregression'] for row in r.get('origin_cases',[]) for result in row['native'].values()))
    assert r['observed_exit_code']==expected_code
for name in ['cargo', 'rustc', 'rustfmt', 'pixel_compare']:
    assert subprocess.run(['pgrep', '-x', name], capture_output=True).returncode == 1
output_files = {str(p):sha(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name != 'native-consumer' and p.name != 'native-origin-consumer'}
measurement_complete = 'failure' not in r and comparisons == 25 and origin_comparisons == 20
proof = dict(schema_version=2, audit_complete=True, measurement_complete=measurement_complete, complete=measurement_complete, source=r['source'], owner_terminal=True, owner_absent=True,
             receipt_sha256=sha(OUT/'receipt.json'), audit_driver_sha256=sha(__file__),
             actual_owner_exit_code=r['observed_exit_code'], measurement_failure=r.get('failure'),
             fresh_compiler_records=len(artifacts), compiled_paths_verified=compiled, compiled_artifact_sha256=compiled_hashes, expected_local_packages=len(local_ids), compiled_local_packages=len(compiled_ids), missing_local_package_ids=sorted(local_ids-compiled_ids), output_file_sha256=output_files, partial_outputs_unqualified=not measurement_complete,
             comparisons_verified=comparisons, image_hashes=images, observations=observations, origin_comparisons_verified=origin_comparisons, origin_observations=origin_observations,
             renderer_qualified=False, all_native_apis_qualified=False, release_qualified=False,
             retired_for_reexecution_after_source_or_target_mutation=True)
PROOF.write_text(json.dumps(proof, sort_keys=True, indent=2)+'\n')
print(json.dumps(dict(proof=str(PROOF), cases=len(observations), comparisons=comparisons, images=len(images), observations=observations)), flush=True)
