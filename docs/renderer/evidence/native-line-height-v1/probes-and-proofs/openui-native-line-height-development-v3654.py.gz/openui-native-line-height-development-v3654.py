import fcntl, hashlib, json, os, re, shutil, signal, subprocess, sys, time
from pathlib import Path

ROOT=Path('/home/nero/code/open-ui')
OUT=Path('/mnt/d/openui-v02-qualification-d174ea0b/native-line-height-development-v3654')
TARGET=Path('/mnt/e/openui-v02-cargo-c73754e2/target')
sys.path.insert(0,'/tmp')
from openui_parallel_source_identity_v3060 import identity

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','rustfmt','pixel_compare']:
    assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
source=identity(ROOT)
assert not source['clean'] and not OUT.exists()
OUT.mkdir()
env=dict(os.environ,CARGO_TARGET_DIR=str(TARGET),CARGO_PROFILE_DEV_DEBUG='0',
         CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='4',
         RUST_MIN_STACK='4194304',PYTHONDONTWRITEBYTECODE='1',TMPDIR='/dev/shm')
env.pop('LD_PRELOAD',None);env.pop('LD_LIBRARY_PATH',None)
env['OPENUI_CLANG_FORMAT']='/mnt/d/openui-v02-qualification-d174ea0b/clang-format-tool-v3625/clang_format/data/bin/clang-format'
cargo=['cargo','--config',str(ROOT/'bindings/rust/.cargo/config.chromium.toml')]
r=dict(schema_version=1,owner_pid=os.getpid(),source=source,driver_sha256=sha(__file__),
       steps=[],all_commands_terminal=False,development_only=True,
       release_qualified=False,full_renderer_contract_qualified=False,
       all_native_apis_qualified=False,javascript_executed_by_openui=False)

def save():
    p=OUT/'receipt.tmp';p.write_text(json.dumps(r,sort_keys=True,indent=2)+'\n');os.replace(p,OUT/'receipt.json')

def run(name,command,cwd=ROOT):
    assert identity(ROOT)==source
    print('Starting '+name,flush=True)
    with (OUT/(name+'.log')).open('xb') as f:
        child=subprocess.Popen(command,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
        r['current_process']=dict(name=name,pid=child.pid);save()
        try:
            while child.poll() is None:
                for p,free in [(ROOT,128*2**20),(OUT,10*2**30),(TARGET,10*2**30),(Path('/dev/shm'),256*2**20)]:
                    if shutil.disk_usage(p).free<free:raise RuntimeError('disk guard '+str(p))
                time.sleep(1)
            child.wait()
        finally:
            if child.poll() is None:
                os.killpg(child.pid,signal.SIGTERM)
                try:child.wait(timeout=20)
                except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
            r.pop('current_process',None)
            log=OUT/(name+'.log');summaries=re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored;',log.read_text())
            r['steps'].append(dict(name=name,command=command,actual_exit_code=child.returncode,
                                  log_sha256=sha(log),test_groups=len(summaries),
                                  totals=[sum(int(x[i]) for x in summaries) for i in range(3)]))
            save()
    assert identity(ROOT)==source
    print(json.dumps(r['steps'][-1]),flush=True)
    return child.returncode

save();status=1
try:
    run('native-tests',cargo+['test','--locked','--offline','-p','openui','--test','native_line_height','--test','native_font_units','--message-format=json-render-diagnostics'],ROOT/'bindings/rust')
    run('style-tests',cargo+['test','--locked','--offline','-p','openui-style','--lib'],ROOT/'bindings/rust')
    run('engine-native-tests',cargo+['test','--locked','--offline','-p','openui-engine','--lib','native_'],ROOT/'bindings/rust')
    if all(s['actual_exit_code']==0 for s in r['steps']):
        run('native-build',cargo+['build','--locked','--offline','-p','openui','--example','native_line_height','--message-format=json-render-diagnostics'],ROOT/'bindings/rust')
        if r['steps'][-1]['actual_exit_code']==0:
            binary=OUT/'native_line_height';shutil.copy2(TARGET/'debug/examples/native_line_height',binary)
            r['native_binary_sha256']=sha(binary);save()
        run('ffi-build',cargo+['build','--locked','--offline','-p','openui-ffi'],ROOT/'bindings/rust')
        if r['steps'][-1]['actual_exit_code']==0:
            library=TARGET/'debug/libopenui_ffi.so';r['ffi_library_sha256']=sha(library);save()
            run('abi-consumers',['python3','-B','tools/ffi/verify_abi.py','--library',str(library)])
    status=int(any(s['actual_exit_code']!=0 for s in r['steps']))
except BaseException as e:r['failure']=repr(e)
finally:
    r['source_after']=identity(ROOT);r['source_unchanged']=r['source_after']==source
    r['all_commands_terminal']=True;r['observed_exit_code']=status;save()
print(json.dumps(dict(complete=True,actual_exit_code=status,source_unchanged=r['source_unchanged'])),flush=True)
raise SystemExit(status)
