import json, os, re
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui')
proof=json.loads(Path('/tmp/openui-public-native-line-height-renderer-completed-audit-v3665.json').read_bytes())
terminal=json.loads(Path('/tmp/openui-public-native-line-height-renderer-terminal-v3667.json').read_bytes())
index=json.loads((ROOT/'docs/renderer/generated/native-line-height-v1.json').read_bytes())
assert terminal['all_local_commands_terminal'] and terminal['actual_audit_exit_code']==0
assert proof['source']==index['source']==terminal['source']
assert index['native_exact_images']==10 and index['native_exact_bounds']==60
assert index['workspace_all_targets_passed']==8640 and index['workspace_docs_passed']==8642
assert proof['matrix_rows_verified']==48252 and proof['candidate_nonregression']
assert all(r['changed_rows']==0 for r in proof['results'].values())
f=proof['results']['full'];e=proof['results']['expanded']
assert (f['exact'],f['different'],e['exact'],e['different'])==(21342,1582,22145,1583)
common='''Fresh complete CPU verification at clean `883ea716` is exact on focused
**640/640** and primitive **960/960** comparisons. Original **21,342/22,924**
and expanded **22,145/23,728** are exact, with zero render errors. Both full
pixel gates still exit 1 for 1,582 and 1,583 differences. All 48,252 comparison
rows retain the preceding native pixels and every Chromium reference field,
with no gains, losses or worsened differences.

The new public `Element::set_line_height_length(LengthValue)` and
`Style::line_height_length` retain relative declarations through the shared
Engine. A native Rust callback changes only the parent font. All **10/10
images and 60/60 bounds** match independently repeated pinned Chromium captures
at the four required profiles and a 3× scale neighbor. The six measured units
are `ch`, `ex`, `lh`, `em`, `rem` and percentage; these rectangle cases do not
qualify all text line boxes, glyphs or font contexts.

All **8,640 locked all-targets tests** and **8,642 workspace and documentation
tests** pass with every feature enabled; 13 existing workspace tests remain
ignored. All 30 C and 24 C++ consumers pass, preserving 131 exports and 34
layouts. Seven explicit hosted hardening jobs pass at the same code checkpoint.
Mixed-unit animation, broader native APIs, residual ownership, compositor,
physical lab and release qualification remain open. Open UI executes no
JavaScript; consuming apps use native Rust methods and Rust callbacks.
[Completed native API and renderer evidence]({link}).'''
files={
 'README.md':'docs/renderer/generated/native-line-height-v1.json',
 'docs/renderer/contract.md':'generated/native-line-height-v1.json',
 'docs/renderer/native-font-relative-lengths.md':'generated/native-line-height-v1.json',
 'docs/progress/current-status.md':'../renderer/generated/native-line-height-v1.json',
 'docs/v02/release.md':'../renderer/generated/native-line-height-v1.json'}
changes={}
pattern=r'Fresh complete CPU qualification at clean `e98a5a17`.*?\[Completed combined evidence\]\([^\n]+\)\.'
for relative,link in files.items():
 p=ROOT/relative;s=p.read_text()
 s,count=re.subn(pattern,common.format(link=link),s,count=1,flags=re.S)
 assert count==1,relative
 changes[relative]=s
s=changes['README.md']
s=s.replace('retained font-relative line-height declarations and broader font contexts remain open. Open UI executes no JavaScript.',
 'broader font contexts and text line-box qualification remain open. The new\nrelative line-height API is measured above. Open UI executes no JavaScript.')
changes['README.md']=s
s=changes['docs/progress/current-status.md']
s=s.replace('mixed-unit animations, font-relative line-height declarations and broader\nfont/root/orientation contexts remain open.',
 'mixed-unit animations and broader font/root/orientation contexts remain open.\nRelative line-height declarations now have the measured public API above;\ncomplete text line-box and glyph qualification remains open.')
changes['docs/progress/current-status.md']=s
relative='docs/v02/supported-platforms.md';s=(ROOT/relative).read_text()
s=s.replace('Mixed-unit animation, retained font-relative line-height declarations and\nbroader font contexts remain native API work.',
 '''Apps can now retain a relative line height with
`Element::set_line_height_length(LengthValue)` or
`Style::line_height_length`. The shared Engine uses the final selected font;
`lh` within line-height uses the parent's line height. A native Rust callback
app matches 10/10 images and 60/60 bounds against repeated Chromium captures at
five scales. C passes the same retained lengths through the existing
`OUI_STYLE_PROPERTY_LINE_HEIGHT` property with a length value; exports and layouts are
unchanged. [Measured scope](../renderer/generated/native-line-height-v1.json).
Mixed-unit animation, broader font contexts and full text line-box/glyph
qualification remain native API work.''')
changes[relative]=s
relative='docs/v02/unsupported-features.md';s=(ROOT/relative).read_text()
s=s.replace('  cases, but mixed-unit animation, font-relative line-height declarations and\n  complete adjusted-font/root/orientation contexts remain native API work;',
 '''  cases; relative line-height now has a public native API with 10/10 images
  and 60/60 bounds exact in the measured rectangle cases. Mixed-unit animation,
  complete adjusted-font/root/orientation contexts and text line-box/glyph
  qualification remain native API work;''')
changes[relative]=s
s=changes['docs/renderer/native-font-relative-lengths.md']
needle='## Current measured checkpoint\n'
section='''## Retained relative line-height

A consuming app assigns the declaration directly:

```rust
element.set_line_height_length(LengthValue::Ch(2.0))?;
element.set_width(LengthValue::Lh(2.5))?;
```

The Engine retains both units and recomputes them after native font changes.
`ch` and `ex` use the element's final selected font; `lh` inside line-height
uses the parent's line height, avoiding a cycle. Other `lh` dimensions use the
element's resulting line height. Inherited values remain computed lengths.
`Style::line_height_length` provides the same declaration for native style and
pseudo builders. Existing `set_line_height(LineHeight)` remains available.
C sends a length-tagged value to the existing line-height property over the
same Engine; no export or struct layout changes are needed.

The [consuming Rust example](../../bindings/rust/openui/examples/native_line_height.rs)
changes only the parent's font from a Rust click callback. Its six bars retain
`ch`, `ex`, `lh`, `em`, `rem` and percentage declarations. Two native processes
and two Chromium processes repeat their captures; all ten images and sixty
bounds agree at five scales. The native app also checks callback count,
unchanged repeated rendering and weak-handle teardown. Three public native
API guards cover declaration ordering, shorthand, inheritance, pseudo styles,
same-unit animation, cloning and invalid relative values. The existing C and
C++ consumers exercise the same units and callback mutations.

These measurements cover six empty rectangle cases. Calculated line heights,
mixed-unit animation, true text line boxes and glyphs, adjusted fonts, root,
orientation and missing-glyph contexts remain open. Existing number/length/
percentage line-height transports also need a complete invalid-input audit.
They are required native API and rendering work.

'''
assert s.count(needle)==1;s=s.replace(needle,section+needle,1)
s=s.replace('No native app runs in that probe; it qualifies no native API or pixels.',
 'No native app runs in that probe; it qualifies no native API or pixels. The\nrelative line-height subset has subsequent native app evidence above;\nmixed-unit animation remains open.')
s=s.replace('animation, retained font-relative line-height declarations, and complete\nroot, font-size-adjust, orientation,',
 'animation and complete root, font-size-adjust, orientation,')
changes['docs/renderer/native-font-relative-lengths.md']=s
# Atomic replacement preserves any older hardlinked source snapshot.
for relative,s in changes.items():
 p=ROOT/relative;tmp=p.with_name(p.name+'.native-line-height.tmp')
 assert not tmp.exists();tmp.write_text(s);os.replace(tmp,p)
print(json.dumps({'updated':list(changes),'measured_source':index['source']['commit']}))
