from pathlib import Path
import os
import tempfile

ROOT = Path('/home/nero/code/open-ui')
changes = {}


def replace(path, old, new, count=1):
    p = ROOT / path
    text = changes.get(p, p.read_text())
    assert text.count(old) == count, (path, text.count(old), old[:100])
    changes[p] = text.replace(old, new)


replace('bindings/rust/openui-style/src/property.rs',
'''                _ => return None,
            }
        }),
        P::TextAlign =>''',
'''                value if !matches!(value, LengthValue::Computed(_)) => {
                    let resolved = value.resolve((0.0, 0.0), 16.0, 16.0);
                    if !resolved.value().is_finite() || resolved.value() < 0.0 {
                        return None;
                    }
                    return Some(StyleValue::Length(value));
                }
                _ => return None,
            }
        }),
        P::TextAlign =>''')
replace('bindings/rust/openui-style/src/property.rs',
'''        (P::FontSize, StyleValue::Length(v)) =>''',
'''        (P::LineHeight, StyleValue::Length(v)) => {
            let length = resolve(*v);
            let pixels = match length.length_type() {
                LengthType::Fixed => length.value(),
                LengthType::Percent => {
                    style.fields.font_size * (length.value() as i32) as f32 / 100.0
                }
                LengthType::Calculated => {
                    let font = openui_geometry::LayoutUnit::from_f32(style.fields.font_size).to_f32();
                    openui_geometry::LayoutUnit::from_f32(
                        font * length.value() / 100.0 + length.calc_offset(),
                    ).to_f32()
                }
                _ => return Err(mismatch()),
            };
            if !length.value().is_finite() || !pixels.is_finite() || pixels < 0.0 {
                return Err(mismatch());
            }
            style.fields.line_height = LineHeight::Length(pixels);
        }
        (P::FontSize, StyleValue::Length(v)) =>''')
replace('bindings/rust/openui/src/element.rs',
'''    /// Return an owned snapshot of this element's resolved style.''',
'''    /// Retain a length-valued line height, including `em`, `rem`, `ch`, `ex`,
    /// `lh`, percentages and viewport units. The Engine resolves it after the
    /// final font context is known and refreshes it after native mutations.
    /// `lh` in line-height uses the parent's line height (the initial style
    /// for the root), avoiding a circular dependency on this element.
    /// Use `set_line_height` for `normal` or a unitless multiplier.
    pub fn set_line_height_length(&self, value: openui_style::LengthValue) -> Result<(), Error> {
        self.set_property(StyleProperty::LineHeight, value.into())
    }

    /// Return an owned snapshot of this element's resolved style.''')
replace('bindings/rust/openui-ffi/src/value.rs',
'''    if value.tag != expected {''',
'''    // Append length-valued line-height support without changing the existing
    // compound representation of normal and unitless line heights.
    let line_height_length = property == StyleProperty::LineHeight && value.tag == 1;
    if value.tag != expected && !line_height_length {''')
replace('bindings/rust/openui-engine/src/lib.rs',
'''            self.native_font_length_metrics(&style)
        });
        let resolved =
            Self::resolve_native_lengths(property, &value, font, root_font, viewport, metrics);''',
'''            let mut metrics = self.native_font_length_metrics(&style);
            if property == StyleProperty::LineHeight {
                let parent_style = if parent.is_none() {
                    ComputedStyle::initial()
                } else {
                    self.document.node(parent).style.clone()
                };
                metrics.lh = self.native_font_length_metrics(&parent_style).lh;
            }
            metrics
        });
        let resolved =
            Self::resolve_native_lengths(property, &value, font, root_font, viewport, metrics);''')
replace('bindings/rust/openui-engine/src/lib.rs',
'''                *property == StyleProperty::FontSize && value.depends_on_font_metrics()
            })''',
'''                matches!(property, StyleProperty::FontSize | StyleProperty::LineHeight)
                    && value.depends_on_font_metrics()
            })''')
replace('bindings/rust/openui-engine/src/lib.rs',
'''            Some(self.native_font_length_metrics(&metric_style))''',
'''            // A font shorthand can override a preceding line-height. Resolve
            // only the winning metric-dependent line-height after all font
            // longhands, then capture the lh basis for other declarations.
            if let Some((StyleProperty::LineHeight, value)) = declarations.iter().rev().find(
                |(property, _)| matches!(property, StyleProperty::Font | StyleProperty::LineHeight),
            ) {
                if value.depends_on_font_metrics() {
                    let mut line_metrics = self.native_font_length_metrics(&metric_style);
                    line_metrics.lh = parent_metrics.expect("line-height parent metrics").lh;
                    let resolved = Self::resolve_native_lengths(
                        StyleProperty::LineHeight,
                        value,
                        font_size,
                        if is_root { font_size } else { root_font },
                        viewport,
                        Some(line_metrics),
                    );
                    apply_to_computed(
                        &mut metric_style, StyleProperty::LineHeight, &resolved, viewport,
                    ).map_err(|_| EngineError::PropertyType { property: StyleProperty::LineHeight })?;
                }
            }
            Some(self.native_font_length_metrics(&metric_style))''')
replace('bindings/rust/openui-engine/src/lib.rs',
'''                if *property == StyleProperty::FontSize {
                    parent_metrics
                } else {
                    metrics
                },''',
'''                if *property == StyleProperty::FontSize {
                    parent_metrics
                } else if *property == StyleProperty::LineHeight {
                    metrics.map(|mut metrics| {
                        if let Some(parent) = parent_metrics {
                            metrics.lh = parent.lh;
                        }
                        metrics
                    })
                } else {
                    metrics
                },''')
replace('bindings/rust/openui-engine/src/animation.rs',
'''            self.native_font_length_metrics(&style)
        });''',
'''            let mut metrics = self.native_font_length_metrics(&style);
            if property == StyleProperty::LineHeight {
                let parent = self.document.node(node).parent;
                let parent_style = if parent.is_none() {
                    openui_style::ComputedStyle::initial()
                } else {
                    self.document.node(parent).style.clone()
                };
                metrics.lh = self.native_font_length_metrics(&parent_style).lh;
            }
            metrics
        });''')

for p, text in changes.items():
    mode = p.stat().st_mode & 0o777
    fd, temporary = tempfile.mkstemp(prefix=p.name + '.', dir=p.parent)
    with os.fdopen(fd, 'w') as stream:
        stream.write(text)
    os.chmod(temporary, mode)
    os.replace(temporary, p)
print('Atomically updated', len(changes), 'source files')
