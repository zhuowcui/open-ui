import gzip, hashlib, json, subprocess
from pathlib import Path

ROOT=Path('/home/nero/code/open-ui')
BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b')
DEST=ROOT/'docs/renderer/evidence/native-line-height-v1'
INDEX=ROOT/'docs/renderer/generated/native-line-height-v1.json'
load=lambda p:json.loads(Path(p).read_bytes())
sha=lambda data:hashlib.sha256(data).hexdigest()

native=load('/tmp/openui-native-line-height-chromium-terminal-v3662.json')
clean=load('/tmp/openui-native-line-height-clean-terminal-v3660b.json')
matrix=load('/tmp/openui-public-native-line-height-renderer-completed-audit-v3665.json')
terminal=load('/tmp/openui-public-native-line-height-renderer-terminal-v3667.json')
hardening=load('/tmp/openui-native-line-height-hardening-terminal-v3663.json')
assert native['source']==clean['source']==matrix['source']==terminal['source']
assert native['source']['clean'] and native['source']['commit']==hardening['head']
assert terminal['all_local_commands_terminal'] and terminal['actual_audit_exit_code']==0
assert native['exact_images']==10 and native['exact_bounds']==60
assert hardening['all_seven_jobs_passed']
assert not DEST.exists() and not INDEX.exists()
DEST.mkdir(parents=True)
members=[]

def add(data,relative):
    path=DEST/relative
    # Store exact text/proof bytes in gzip; embedded patches, ANSI logs and
    # original writer files keep their original whitespace and raw hashes.
    compressed=not relative.endswith('.png')
    stored=gzip.compress(data,mtime=0) if compressed else data
    if compressed:path=path.with_name(path.name+'.gz')
    path.parent.mkdir(parents=True,exist_ok=True);assert not path.exists();path.write_bytes(stored)
    raw=gzip.decompress(stored) if compressed else stored
    assert raw==data
    members.append(dict(path=str(path.relative_to(ROOT)),bytes=len(stored),sha256=sha(stored),
                        raw_bytes=len(data),raw_sha256=sha(data),compression='gzip' if compressed else 'none'))

for scope,folder in [('development','native-line-height-development-v3654'),
                     ('clean','native-line-height-clean-checks-v3659'),
                     ('native-chromium','native-line-height-chromium-v3661')]:
    for path in sorted((BASE/folder).rglob('*')):
        if path.is_file() and path.name!='native_line_height':
            add(path.read_bytes(),scope+'/'+str(path.relative_to(BASE/folder)))
folder=BASE/'public-native-line-height-renderer-v3664'
for name in ['receipt.json','guarded-build.log','focused.log','primitive.log','full.log','expanded.log']:
    add((folder/name).read_bytes(),'renderer/'+name)
for scope in ['focused','primitive','full','expanded']:
    name=scope+'-summary.json';add((folder/(scope+'-matrix')/name).read_bytes(),'renderer/'+name)
for path in sorted((folder/'guarded-build').iterdir()):
    if path.is_file() and path.name != 'pixel_compare':
        add(path.read_bytes(),'renderer/guarded-build/'+path.name)
proof_names=[
    'openui-native-line-height-edit-v3652.py','openui-native-line-height-consumers-v3653.py',
    'openui-native-line-height-development-v3654.py','openui-native-line-height-development-terminal-v3657.json',
    'openui-native-line-height-clean-checks-v3659.py','openui-native-line-height-clean-audit-v3660.py',
    'openui-native-line-height-clean-audit-failure-v3660.json','openui-native-line-height-clean-audit-v3660b.py',
    'openui-native-line-height-clean-terminal-v3660b.json','openui-native-line-height-clean-reaped-v3660b.json',
    'openui-native-line-height-oracle-template-v3656.py','openui-native-line-height-chromium-audit-v3662.py',
    'openui-native-line-height-chromium-terminal-v3662.json','openui-native-line-height-native-reaped-v3662.json',
    'openui-native-line-height-hardening-observed-4-v3663.json','openui-native-line-height-hardening-terminal-v3663.json',
    'openui-native-line-height-ci-v3666.json','openui-public-native-line-height-renderer-v3664.py',
    'openui-public-native-line-height-renderer-audit-v3665.py',
    'openui-public-native-line-height-renderer-completed-audit-v3665.json',
    'openui-public-native-line-height-renderer-reaped-v3667.py',
    'openui-public-native-line-height-renderer-terminal-v3667.json',
    'openui_parallel_source_identity_v3060.py','openui-native-line-height-next-review-v3669.md',
    'openui-native-line-height-archive-v3668.py','openui-native-line-height-docs-v3670.py','openui-native-line-height-pr-before-v3671.json',
    'openui-native-line-height-pr-body-v3672.py']
for name in proof_names:add((Path('/tmp')/name).read_bytes(),'probes-and-proofs/'+name)
for path in sorted(Path('/tmp/openui-native-line-height-chromium-v3651').iterdir()):
    if path.is_file():add(path.read_bytes(),'pinned-chromium-source/'+path.name)
patch=subprocess.check_output(['git','diff','bf20d10c','883ea716','--'],cwd=ROOT)
add(patch,'source/native-line-height.patch')
result=dict(schema_version=1,source=native['source'],native_images=10,native_exact_images=10,
            native_bounds=60,native_exact_bounds=60,native_profiles=native['profiles'],
            workspace_all_targets_passed=clean['workspace_passed'],workspace_docs_passed=clean['workspace_docs_passed'],
            workspace_docs_ignored=clean['workspace_docs_ignored'],abi_counts=clean['abi_counts'],
            fresh_native_compiler_records=clean['fresh_local_records'],
            compiler_artifact_verification=dict(live_paths=clean['live_artifact_paths_verified'],
                owned_copies=clean['owned_compiler_artifact_copies_verified'],mutable_aliases=clean['mutable_cargo_example_aliases']),
            renderer=matrix['results'],candidate_nonregression=matrix['candidate_nonregression'],
            hosted_hardening=hardening,all_members_hash_verified=True,all_local_commands_terminal=True,
            pixel_target='pinned Chromium',pixel_tolerance=0,javascript_executed_by_openui=False,
            historical_openui_archive_is_a_pixel_target=False,all_native_apis_qualified=False,
            full_renderer_contract_qualified=False,release_qualified=False,
            archive=dict(files=len(members),bytes=sum(m['bytes'] for m in members),members=members))
INDEX.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'files':len(members),'bytes':result['archive']['bytes'],'index':str(INDEX)}))
