# Remaining line-height and font API review

Read-only review at clean 883ea716 during full renderer owner3664. No runtime claim or source change.

- New length-valued line-height has measured native app evidence: 10 exact images and 60 exact bounds at five scales, with repeated native Rust callbacks and independently repeated Chromium processes. The complete renderer run remains live.
- Existing TypographyValue::LineHeight and RendererStyleValue::LineHeight assignment paths appear to accept negative or non-finite Number/Length/Percentage values without checking their range. The new length validation does not qualify those existing forms. Inspect and measure invalid-input behavior through consuming Rust and C apps before closing the whole property API.
- Mixed-unit animation, adjusted-font metric precision, root and orientation contexts, missing-zero fallback, calculated line-height and true text line-box/glyph cases remain required implementation/qualification work. The six rectangle cases are a measured subset.

Never re-run retired source/target audits. Preserve Chromium and historical reference bytes.
