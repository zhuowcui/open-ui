import json
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui')
r=json.loads((ROOT/'docs/renderer/generated/native-line-height-v1.json').read_bytes())
prior=json.loads(Path('/tmp/openui-native-line-height-pr-before-v3671.json').read_bytes())
assert prior['state']=='OPEN' and prior['isDraft'] and prior['headRefOid']==r['source']['commit']
assert r['all_local_commands_terminal'] and r['candidate_nonregression']
assert r['native_exact_images']==10 and r['native_exact_bounds']==60
assert r['workspace_all_targets_passed']==8640 and r['workspace_docs_passed']==8642
assert all(row['changed_rows']==0 for row in r['renderer'].values())
body=f'''## Retained native line-height API and completed verification

Clean code checkpoint `883ea716` adds public Rust `Element::set_line_height_length(LengthValue)` and `Style::line_height_length`. The shared retained Engine resolves the final font and parent line-height context, refreshes declarations after native mutations, and supports inheritance, pseudo styles and same-unit animation. C accepts retained lengths through its existing line-height property; 131 exports and 34 layouts remain unchanged.

Open UI never executes JavaScript, in any version. Consuming apps call public native Rust APIs and supply Rust callbacks. Every needed element operation remains required native implementation work, including when the Chromium reference test uses a script. Pinned Chromium alone provides expected pixels; old Open UI images preserve immutable history.

- A real Rust callback changes only the parent font. All **10/10 images and 60/60 bounds** match independently repeated Chromium captures at the four required profiles and a 3× neighbor, with zero tolerance. The six rectangle cases use ch, ex, lh, em, rem and percentage line heights. Full text line-box/glyph contexts and mixed-unit animation remain open.
- Locked tests with every feature enabled pass **8,640 all-targets tests** and **8,642 workspace/documentation tests**, zero failures; the latter retains **13 existing ignored tests**. All **30 C and 24 C++ consumers** pass.
- Focused **640/640** and primitive **960/960** comparisons are exact, with terminal exits **0**. Original **21,342/22,924** and expanded **22,145/23,728** are exact, with **1,582 / 1,583 differences**, **zero render errors**, and terminal exits **1**. All **48,252** rows preserve preceding native pixels and every Chromium reference field; no gains, losses or worsened differences.
- All **seven explicitly dispatched hosted hardening jobs** pass at the measured code checkpoint: [run 38058920492](https://github.com/zhuowcui/open-ui/actions/runs/38058920492). Six ordinary PR checks pass there; five optional hardening skips are recorded separately. These results are distinct from checks on the later documentation/evidence commit.
- The new evidence archive contains **{r['archive']['files']} files / {r['archive']['bytes']:,} stored bytes**, with raw and stored hashes verified. It preserves all actual stage exits and completed process proofs, including an initial failed mutable Cargo example-alias audit and the corrected audit of the immutable fresh executable actually used by every native app run. Historical proofs are retired after source/target changes.

Complete renderer equality, every needed native API, reviewed residual ownership, compositor, physical lab and release qualification remain open. No merge, tag, signing, publication or final-v0.2 claim follows from this checkpoint.

Details: [complete evidence](docs/renderer/generated/native-line-height-v1.json), [public native API and scope](docs/renderer/native-font-relative-lengths.md#retained-relative-line-height), and [native interaction contract](docs/v02/supported-platforms.md#native-interaction-api).

---

## Earlier checkpoints

The previous PR description is preserved verbatim in the new evidence archive. Checkpoint commits and [current status](docs/progress/current-status.md) retain the implementation and qualification history. Earlier measured results remain unchanged in [combined font-unit evidence](docs/renderer/generated/native-font-units-public-v2.json), [native font-unit evidence](docs/renderer/generated/native-font-units-v1.json), and [native keyboard evidence](docs/renderer/generated/native-keyboard-public-v2.json).

'''
p=Path('/tmp/openui-native-line-height-pr-body-v3672.md')
assert not p.exists();p.write_text(body)
print(p)
