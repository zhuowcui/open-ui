import hashlib,json,os,subprocess,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');SDK=MAIN/'out/private-native-editor-clip-main-v2407';RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1'
OUT=RAW/'native-editor-direct-strike-build-v2410';STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/OUT.name
assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
sys.path.insert(0,str(MAIN/'tools/qualification'));from renderer_source_identity import repository_source_identity
source=repository_source_identity(SDK);public=repository_source_identity(MAIN)
assert source['clean'] and source['commit']=='86bcc8bce392ae931e46942195ed3af081c71243' and public['clean'] and public['commit']=='dbaf8ef083243ff6c4a2db6cf1724515d6304975'
env=dict(os.environ,CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_BUILD_JOBS='4',RUST_MIN_STACK='4194304',CARGO_INCREMENTAL='0',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(STORE))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=dict(schema_version=1,source=source,public_source=public,steps=[],all_commands_terminal=False,owner_pid=os.getpid(),release_qualification=False)
def save():(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
def run(name,command,cwd):
 with (OUT/(name+'.log')).open('xb') as f:
  child=subprocess.Popen(command,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT);report['current_process']=dict(pid=child.pid,stage=name);save();code=child.wait()
 report.pop('current_process');report['steps'].append(dict(name=name,command=command,observed_exit_code=code,log_sha256=sha(OUT/(name+'.log'))));save();print(json.dumps(report['steps'][-1]),flush=True)
 assert repository_source_identity(SDK)==source and repository_source_identity(MAIN)==public
 return code
save()
try:
 command=[sys.executable,str(SDK/'tools/qualification/build_renderer.py'),'--offline','--source-root',str(SDK),'--cargo-config',str(SDK/'bindings/rust/.cargo/config.chromium.toml'),'--target-dir','/mnt/e/openui-v02-cargo-c73754e2/target','--results-dir',str(OUT/'guarded-build')]
 assert run('guarded-renderer-build',command,SDK)==0
 # The app may reuse only cached artifacts whose bytes appear in this build proof.
 s=Path('/tmp/openui-native-editor-fresh-parent-v2406.py').read_text()
 s=s.replace('SDK=MAIN\n',"SDK=MAIN/'out/private-native-editor-clip-main-v2407'\n").replace('native-editor-fresh-parent-v2405','native-glyph-regression-v2408').replace('native-editor-fresh-parent-v2406','native-editor-direct-strike-app-v2410')
 s=s.replace("assert source['clean'] and source['commit']=='dbaf8ef083243ff6c4a2db6cf1724515d6304975'","assert source['clean'] and source['commit']=='86bcc8bce392ae931e46942195ed3af081c71243'")
 s=s.replace("proof_path=RAW/'native-renderer-build-proof-smoke-v2397/guarded-build/receipt.json'","proof_path=RAW/'native-editor-direct-strike-build-v2410/guarded-build/receipt.json'")
 s=s.replace('shared_renderer_patch_applied=False','shared_renderer_patch_applied=True')
 pipeline=Path('/tmp/openui-native-editor-direct-strike-app-v2410.py');assert not pipeline.exists();compile(s,str(pipeline),'exec');pipeline.write_text(s)
 code=run('verified-native-app',[sys.executable,str(pipeline)],MAIN)
 app=json.loads((RAW/'native-editor-direct-strike-app-v2410/receipt.json').read_bytes())
 assert app['all_commands_terminal'] and app['source_unchanged'] and app['public_source_unchanged'] and app['native_library_source_proven']
 assert app['totals']['image_states']==30 and app['totals']['geometry_states']==30
 parent=json.loads((RAW/'native-editor-fresh-parent-v2406/receipt.json').read_bytes());assert parent['native_library_source_proven'] and parent['all_commands_terminal']
 before={(c['label'],c['state']):c for c in parent['cases']};changes=[]
 for c in app['cases']:
  old=before[c['label'],c['state']];assert c['chromium']==old['chromium'] and c['chromium_bounds']==old['chromium_bounds']
  if c['native']!=old['native']:
   changes.append(dict(label=c['label'],state=c['state'],before_wrong_pixels=old['difference']['mismatched_pixels'],wrong_pixels=c['difference']['mismatched_pixels'],exact_gain=not old['exact'] and c['exact'],exact_loss=old['exact'] and not c['exact'],more_wrong_pixels=c['difference']['mismatched_pixels']>old['difference']['mismatched_pixels']))
 report.update(native_receipt_sha256=sha(RAW/'native-editor-direct-strike-app-v2410/receipt.json'),totals=app['totals'],native_observed_exit_code=code,changes=changes,exact_gains=sum(c['exact_gain'] for c in changes),exact_losses=sum(c['exact_loss'] for c in changes),worsened_states=sum(c['more_wrong_pixels'] for c in changes),all_chromium_reference_bytes_preserved=True,observed_exit_code=code)
except BaseException as e:
 report.update(observed_exit_code=1,failure=repr(e));raise
finally:
 report.update(all_commands_terminal=True,source_after=repository_source_identity(SDK),public_source_after=repository_source_identity(MAIN));report['source_unchanged']=report['source_after']==source;report['public_source_unchanged']=report['public_source_after']==public;save()
print(json.dumps({k:report.get(k) for k in ['totals','exact_gains','exact_losses','worsened_states','observed_exit_code','all_commands_terminal']}),flush=True)
raise SystemExit(report['observed_exit_code'])
