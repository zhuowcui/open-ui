import fcntl,hashlib,json,os,re,signal,subprocess,sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');RAW=ROOT/'out/renderer-evidence/native-viewport-scroll-v1';OUT=RAW/'native-edit-command-checks-v2417';STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/OUT.name
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
sys.path.insert(0,str(ROOT/'tools/qualification'));from renderer_source_identity import repository_source_identity
source=repository_source_identity(ROOT);assert source['clean'] and source['commit'].startswith('855a2a49')
env=dict(os.environ,CARGO_TARGET_DIR='/mnt/e/openui-v02-cargo-c73754e2/target',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_BUILD_JOBS='4',RUST_MIN_STACK='4194304',CARGO_INCREMENTAL='0',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(STORE))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=dict(schema_version=1,source=source,steps=[],all_commands_terminal=False,owner_pid=os.getpid(),release_qualification=False,renderer_matrices_not_run=True)
def save():(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
def run(name,command,cwd=ROOT/'bindings/rust'):
 with (OUT/(name+'.log')).open('xb') as stream:
  child=subprocess.Popen(command,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True);report['current_process']=dict(pid=child.pid,stage=name);save()
  try:code=child.wait()
  except BaseException:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=20)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
   raise
 report.pop('current_process');row=dict(name=name,command=command,observed_exit_code=code,log_sha256=sha(OUT/(name+'.log')));report['steps'].append(row);save();print(json.dumps(row),flush=True)
 assert repository_source_identity(ROOT)==source
 assert code==0,name
 return (OUT/(name+'.log')).read_bytes()
base=['cargo','--config',str(ROOT/'bindings/rust/.cargo/config.chromium.toml')]
save()
try:
 meta=json.loads(run('locked-metadata',base+['metadata','--locked','--offline','--format-version','1']))
 local=[p for p in meta['packages'] if p['source'] is None]
 assert all(Path(p['manifest_path']).resolve().is_relative_to(ROOT) for p in local)
 run('clean-local-packages',base+['clean','--locked']+[a for p in local for a in ['-p',p['id']]])
 proof={}
 def verify(log,first):
  artifacts=[]
  for line in log.splitlines():
   if not line.startswith(b'{'):continue
   record=json.loads(line)
   if record.get('reason')!='compiler-artifact' or record['target']['kind']==['custom-build']:continue
   package=next((p for p in local if p['id']==record['package_id']),None)
   if package is None:continue
   assert Path(record['manifest_path']).resolve()==Path(package['manifest_path']).resolve()
   assert Path(record['target']['src_path']).resolve().is_relative_to(ROOT)
   hashes={path:sha(Path(path)) for path in record['filenames']}
   if record['fresh']:assert not first and all(proof.get(p)==h for p,h in hashes.items()),record
   proof.update(hashes);artifacts.append(dict(record=record,sha256=hashes))
  assert any(a['record']['target']['name']=='openui' for a in artifacts)
  return artifacts
 tests=run('rust-public-api-tests',base+['test','--locked','--offline','-p','openui','--lib','--message-format=json'])
 report['test_artifacts']=verify(tests,True)
 matches=re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',tests)
 assert len(matches)==1
 report['tests']=dict(passed=int(matches[0][0]),failed=int(matches[0][1]),ignored=int(matches[0][2]));assert report['tests']['failed']==0;save()
 example=run('build-native-consumer',base+['build','--locked','--offline','-p','openui','--example','native_edit_commands','--message-format=json'])
 report['consumer_artifacts']=verify(example,False);save()
 binary=OUT/'native_edit_commands';import shutil;shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/examples/native_edit_commands',binary);report['consumer_binary_sha256']=sha(binary)
 first=run('native-consumer-first',[str(binary)],ROOT);second=run('native-consumer-second',[str(binary)],ROOT)
 assert first==second and first.count(b'callbacks=3')==2
 report.update(native_consumer_repeated_output_identical=True,native_callbacks_per_run=6,native_library_source_proven=True);save()
 run('rust-format',['bash','-c','ulimit -s 262144; cargo fmt --all -- --check'])
 run('renderer-contract',[sys.executable,'tools/qualification/generate_renderer_contract.py','--check'],ROOT)
 run('c-abi-generator',[sys.executable,'tools/ffi/generate_schema.py','--check'],ROOT)
 report['observed_exit_code']=0
except BaseException as error:
 report.update(observed_exit_code=1,failure=repr(error));raise
finally:
 report.update(all_commands_terminal=True,source_after=repository_source_identity(ROOT));report['source_unchanged']=report['source_after']==source;save();lock.close()
print(json.dumps({k:report.get(k) for k in ['tests','native_callbacks_per_run','source_unchanged','observed_exit_code','all_commands_terminal']}),flush=True)
