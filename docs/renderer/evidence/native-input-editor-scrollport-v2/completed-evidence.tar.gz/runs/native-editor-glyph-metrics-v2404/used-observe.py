def observe(page, picture, expression, scale):
    observations = []
    exceptions = []
    commands = []

    def trace(frame, event, arg):
        if event == 'exception' and frame.f_code.co_filename == str(SDK / 'tools/accountability/run_all_pixel_comparisons.py'):
            exceptions.append(dict(function=frame.f_code.co_name, type=arg[0].__name__, message=str(arg[1])))
        return trace

    class QueryWebSocket(original_ws):

        def command(self, method, params=None):
            result = super().command(method, params)
            commands.append(dict(method=method, screenshot_sha256=hashlib.sha256(result['data'].encode()).hexdigest() if method == 'Page.captureScreenshot' and 'data' in result else None))
            if method == 'Runtime.evaluate' and (not observations):
                response = super().command('Runtime.evaluate', dict(expression=expression, returnByValue=True))
                assert 'exceptionDetails' not in response, response.get('exceptionDetails')
                result_value=response['result']['value']
                tree=super().command('DOM.getDocument',dict(depth=-1,pierce=True))
                editors=[]
                def walk(node,in_shadow=False):
                    in_shadow=in_shadow or node.get('shadowRootType')=='user-agent'
                    if in_shadow and node.get('nodeName')=='DIV':
                        resolved=super(QueryWebSocket,self).command('DOM.resolveNode',dict(nodeId=node['nodeId']))
                        observed=super(QueryWebSocket,self).command('Runtime.callFunctionOn',dict(objectId=resolved['object']['objectId'],returnByValue=True,functionDeclaration="function(){const s=getComputedStyle(this),b=this.getBoundingClientRect();const range=document.createRange();range.selectNodeContents(this);const ranges=Array.from(range.getClientRects(),r=>({x:r.x,y:r.y,width:r.width,height:r.height}));const ctx=document.createElement('canvas').getContext('2d');ctx.font=s.fontStyle+' '+s.fontWeight+' '+s.fontSize+' '+s.fontFamily;const m=ctx.measureText(this.textContent);const metrics={actualBoundingBoxAscent:m.actualBoundingBoxAscent,actualBoundingBoxDescent:m.actualBoundingBoxDescent,fontBoundingBoxAscent:m.fontBoundingBoxAscent,fontBoundingBoxDescent:m.fontBoundingBoxDescent,width:m.width};return {rangeBounds:ranges,metrics:metrics,font:ctx.font,fontFamily:s.fontFamily,text:this.textContent,rect:{x:b.x,y:b.y,width:b.width,height:b.height},clientWidth:this.clientWidth,clientHeight:this.clientHeight,scrollWidth:this.scrollWidth,scrollHeight:this.scrollHeight,lineHeight:s.lineHeight,fontSize:s.fontSize,overflowX:s.overflowX,overflowY:s.overflowY,display:s.display,alignItems:s.alignItems,marginTop:s.marginTop,marginBottom:s.marginBottom};}"))
                        assert 'exceptionDetails' not in observed
                        editors.append(dict(attributes=node.get('attributes',[]),observation=observed['result']['value']))
                    for key in ['children','shadowRoots']:
                        for child in node.get(key,[]):walk(child,in_shadow)
                walk(tree['root'])
                assert editors
                observations.append(dict(frame=result_value,editors=editors))
            return result
    capture._CdpWebSocket = QueryWebSocket
    processes = []
    original_popen = capture.subprocess.Popen
    original_tmpdir = capture.tempfile.TemporaryDirectory
    cleanup_events = []

    class StoppedChromeProfile(original_tmpdir):

        def __exit__(self, exc, value, tb):
            for process in processes:
                if process.poll() is None:
                    os.killpg(process.pid, signal.SIGTERM)
                    try:
                        process.wait(timeout=15)
                    except subprocess.TimeoutExpired:
                        os.killpg(process.pid, signal.SIGKILL)
                        process.wait(timeout=15)
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                # Wait for group members to stop; zombies cannot write profiles.
                deadline=time.monotonic()+10
                while True:
                    alive=[]
                    for entry in Path('/proc').iterdir():
                        if not entry.name.isdecimal(): continue
                        try:
                            fields=(entry/'stat').read_text().rsplit(')',1)[1].split()
                            if int(fields[2])==process.pid and fields[0]!='Z': alive.append(int(entry.name))
                        except (OSError,ValueError): pass
                    if not alive: break
                    assert time.monotonic()<deadline, alive
                    time.sleep(.01)
                cleanup_events.append(dict(pid=process.pid, actual_exit=process.poll(), stopped_before_profile_removal=True, process_group_stopped=True))
            return super().__exit__(exc, value, tb)
    stderr = picture.with_suffix('.stderr.log')
    with stderr.open('xb') as stream:

        def launch(command, *args, **kwargs):
            if command and command[0] == str(chrome):
                command = [command[0], '--disable-dev-shm-usage', *command[1:]]
                kwargs['stderr'] = stream
            kwargs['start_new_session'] = True
            process = original_popen(command, *args, **kwargs)
            processes.append(process)
            return process
        capture.subprocess.Popen = launch
        capture.tempfile.TemporaryDirectory = StoppedChromeProfile
        sys.settrace(trace)
        try:
            ok = capture.render_chrome(str(page), str(picture), str(chrome), str(chrome.parent), use_ahem_noaa=True, logical_width=WIDTH, logical_height=HEIGHT, device_scale=scale)
        finally:
            sys.settrace(None)
            capture._CdpWebSocket = original_ws
            capture.subprocess.Popen = original_popen
            capture.tempfile.TemporaryDirectory = original_tmpdir
    attempt = dict(cleanup_events=cleanup_events, exceptions=exceptions, commands=commands, observations=observations, capture_ok=ok, query_count=len(observations), process_actual_exits=[p.poll() for p in processes], stderr_sha256=sha(stderr))
    picture.with_suffix('.attempt.json').write_text(json.dumps(attempt, sort_keys=True, indent=2) + '\n')
    assert ok and len(observations) == 1
    return observations[0]
