"""Verify the corrected candidate while preserving the completed negative baseline."""
import fcntl
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

MAIN = Path('/home/nero/code/open-ui')
RAW = MAIN / 'out/renderer-evidence/native-viewport-scroll-v1'
NAME = 'native-font-variation-pipeline-v1875'
OUT = RAW / NAME
STORE = Path('/mnt/e/openui-v02-qualification-d174ea0b') / NAME
ROOT = Path('/dev/shm/openui-native-font-variation-candidate-ready-v1873')
lock = open('/tmp/openui-native-cargo-raster-owner.lock', 'a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
previous_path = RAW / 'native-font-variation-pipeline-v1867/receipt.json'
previous = json.loads(previous_path.read_bytes())
assert previous['all_commands_terminal'] and previous['observed_exit_code'] == 1
for program in ['cargo', 'pixel_compare']:
    assert subprocess.run(['pgrep', '-x', program], capture_output=True).returncode == 1
sys.path.insert(0, str(MAIN / 'tools/qualification'))
from renderer_source_identity import repository_source_identity

source = repository_source_identity(ROOT)
assert source['clean'] and source['commit'] == '228a875f0224610b856bfc1a8279d836f32b50b1'
checks_path = RAW / 'native-font-variation-candidate-checks-v1876/receipt.json'
checks = json.loads(checks_path.read_bytes())
assert checks['source'] == checks['source_after'] == source and checks['all_commands_terminal']
assert len(checks['checks']) == 15 and all(c['observed_exit_code'] == 0 for c in checks['checks'])
baseline_build_path = RAW / 'native-font-variation-baseline-build-v1866/build.json'
baseline_native_path = RAW / 'native-font-variation-baseline-consumer-v1866/receipt.json'
baseline_build = json.loads(baseline_build_path.read_bytes())
baseline_native = json.loads(baseline_native_path.read_bytes())
for result in [baseline_build, baseline_native]:
    assert result['all_commands_terminal'] and result['observed_exit_code'] == 0
    assert result['source']['commit'] == '01c10501e2252288588bcc40f35dfebdf44d83ba'
    assert result['source'] == result['source_after']
assert baseline_build['baseline_regression_reproduced']
assert baseline_native['baseline_wrong_instance_reproduced']
assert baseline_native['callback_scales_verified'] == 5 and baseline_native['font_reference_exact_scales'] == 0
assert not OUT.exists() and not STORE.exists()
STORE.mkdir(); OUT.symlink_to(STORE, target_is_directory=True)
scripts = [Path('/tmp/openui-native-font-variation-' + name + '-v1874.py') for name in ['build', 'consumer', 'matrices']]
report = dict(schema_version=1, source=source, source_after=source,
    baseline_source=baseline_build['source'], owner_pid=os.getpid(), all_commands_terminal=False,
    state='prepared-verified', release_qualification=False, promotion_allowed=False,
    new_release_states_admitted=0, javascript_executed_by_openui=False,
    public_native_rust_apis_required=True, pixel_tolerance=0,
    whole_pipeline_lock_covers_all_stages_and_gaps=True, steps=[],
    probe_sha256=sha(Path(__file__)), immutable_probe_hashes={str(p): sha(p) for p in scripts},
    read_only_check_receipt_sha256=sha(checks_path), prior_terminal_pipeline_sha256=sha(previous_path),
    unchanged_baseline_build_receipt_sha256=sha(baseline_build_path),
    unchanged_baseline_native_receipt_sha256=sha(baseline_native_path),
    baseline_rebuilt_by_this_pipeline=False,
    full_original_and_expanded_matrices_not_attempted_by_this_pipeline=True,
    native_consumer_reference_is_independent_font_glyph_not_chromium=True)
save = lambda: (OUT / 'receipt.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
save()
stages = [
    ('candidate-build', [sys.executable, str(scripts[0]), 'candidate'],
     RAW / 'native-font-variation-candidate-build-v1874/build.json', 'build'),
    ('candidate-native-callback', [sys.executable, str(scripts[1]), 'candidate'],
     RAW / 'native-font-variation-candidate-consumer-v1874/receipt.json', 'consumer')]
for suite in ['focused', 'primitive']:
    stages.append((suite, [sys.executable, str(scripts[2]), suite],
        RAW / ('native-font-variation-clean-' + suite + '-v1874') / (suite + '-summary.json'), 'matrix'))
try:
    for name, command, result_path, kind in stages:
        assert repository_source_identity(ROOT) == source
        assert all(sha(p) == report['immutable_probe_hashes'][str(p)] for p in scripts)
        report['state'] = 'running-' + name; save()
        log = OUT / (name + '.log')
        with log.open('xb') as stream:
            process = subprocess.Popen(command, cwd=ROOT,
                env=dict(os.environ, OPENUI_NATIVE_WHOLE_OWNER=NAME,
                    PYTHONDONTWRITEBYTECODE='1', TMPDIR='/dev/shm/oui1871'),
                stdout=stream, stderr=subprocess.STDOUT)
            report['current_process'] = dict(pid=process.pid, program=Path(command[1]).name)
            save(); process.wait()
        report.pop('current_process')
        report['steps'].append(dict(name=name, observed_exit_code=process.returncode, log_sha256=sha(log)))
        report['source_after'] = repository_source_identity(ROOT); save()
        print(json.dumps(dict(stage=name, actual_exit=process.returncode)), flush=True)
        result = json.loads(result_path.read_bytes())
        if kind in ['build', 'consumer']:
            assert process.returncode == 0 and result['all_commands_terminal'] and not result.get('failure')
        else:
            assert process.returncode == 0, 'focused or primitive pixel gate failed'
    report.update(state='complete-full-census-and-independent-chromium-API-comparisons-pending', observed_exit_code=0)
except BaseException as error:
    report.update(state='stopped-on-build-harness-or-pixel-failure', failure=str(error), observed_exit_code=1)
    raise
finally:
    report.update(all_commands_terminal=True, source_after=repository_source_identity(ROOT))
    assert report['source_after'] == source; save()
raise SystemExit(report['observed_exit_code'])
