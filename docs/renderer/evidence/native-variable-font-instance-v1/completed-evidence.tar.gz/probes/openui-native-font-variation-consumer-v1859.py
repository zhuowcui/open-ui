"""Replay a real Rust variable-font callback against the font's independent glyph."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

from PIL import Image

MAIN = Path('/home/nero/code/open-ui')
RAW = MAIN / 'out/renderer-evidence/native-viewport-scroll-v1'
assert os.environ.get('OPENUI_NATIVE_WHOLE_OWNER') == 'native-font-variation-pipeline-v1860'
label = sys.argv[1]
assert label in ['baseline', 'candidate']
ROOT = Path('/dev/shm/openui-native-font-variation-' + label + '-profile-v1858')
OUT = RAW / ('native-font-variation-' + label + '-consumer-v1859')
STORE = Path('/mnt/e/openui-v02-qualification-d174ea0b') / OUT.name
assert not OUT.exists() and not STORE.exists()
STORE.mkdir(); OUT.symlink_to(STORE, target_is_directory=True)
sys.path.insert(0, str(ROOT / 'tools/qualification'))
from renderer_source_identity import repository_source_identity
from residuals import analyze_image_difference

sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source = repository_source_identity(ROOT)
build_path = RAW / ('native-font-variation-' + label + '-build-v1859/build.json')
build = json.loads(build_path.read_bytes())
assert build['all_commands_terminal'] and build['observed_exit_code'] == 0
assert source == build['source'] == build['source_after'] and source['clean']
binary = build_path.parent / 'native_font_variation'
assert sha(binary) == next(s['binary_sha256'] for s in build['steps'] if s['name'] == 'variation-build')
font = ROOT / 'bindings/rust/openui-text/tests/data/variabletest_box.ttf'
assert sha(font) == '9270b7f6b2b8b34215a80c63a9c1348e704a0e3803ee49f2531bd62fdb5139c4'
report = dict(schema_version=1, label=label, source=source, source_after=source,
    all_commands_terminal=False, release_qualification=False, promotion_allowed=False,
    new_release_states_admitted=0, javascript_executed_by_openui=False,
    public_native_rust_application_apis=True, pixel_tolerance=0,
    explicit_raster_configuration='RasterConfiguration::deterministic_aliased(true)',
    default_raster_configuration_not_claimed=True,
    reference_kind='independent fixed U+2580 glyph in the pinned WPT variable font',
    chromium_comparison_not_claimed=True, font_sha256=sha(font),
    build_receipt_sha256=sha(build_path), native_binary_sha256=sha(binary),
    probe_sha256=sha(Path(__file__)), cases=[])
save = lambda: (OUT / 'receipt.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
save()
try:
    for scale in [1.0, 1.25, 1.5, 2.0, 3.0]:
        directory = OUT / str(scale); directory.mkdir()
        row = dict(scale=scale, native_runs=[], images=[])
        report['cases'].append(row)
        for repeat in [1, 2]:
            destination = directory / ('native-' + str(repeat))
            command = [str(binary), str(destination), str(scale)]
            result = subprocess.run(command, cwd=ROOT, capture_output=True)
            log = directory / ('native-' + str(repeat) + '.log')
            log.write_bytes(result.stdout + result.stderr)
            row['native_runs'].append(dict(repeat=repeat, observed_exit_code=result.returncode, log_sha256=sha(log)))
            expected = 1 if label == 'baseline' else 0
            assert result.returncode == expected, 'unexpected native consumer exit'
            if label == 'baseline':
                assert b'the native variable-font callback painted the wrong glyph instance' in log.read_bytes()
        geometries = [json.loads((directory / ('native-' + str(i)) / 'geometry.json').read_bytes()) for i in [1, 2]]
        assert geometries[0] == geometries[1] and geometries[0]['callback_count'] == 1
        row['geometry'] = geometries[0]
        for name in ['before', 'after', 'upper-block-reference']:
            first = directory / 'native-1' / (name + '.png')
            second = directory / 'native-2' / (name + '.png')
            assert first.read_bytes() == second.read_bytes()
            with Image.open(first) as image:
                assert image.size == (round(160 * scale), round(160 * scale))
            row['images'].append(dict(state=name, png_sha256=sha(first), repeated_native_png_identical=True))
        row['reference_difference'] = analyze_image_difference(
            directory / 'native-1/upper-block-reference.png', directory / 'native-1/after.png')
        row['state_change_difference'] = analyze_image_difference(
            directory / 'native-1/before.png', directory / 'native-1/after.png')
        if label == 'candidate':
            assert row['reference_difference']['mismatched_pixels'] == 0
            assert row['state_change_difference']['mismatched_pixels'] > 0
            assert row['geometry']['render_changed'] and row['geometry']['matches_font_reference']
        else:
            assert row['reference_difference']['mismatched_pixels'] > 0
            assert not row['geometry']['matches_font_reference']
        save()
        print(json.dumps(dict(label=label, scale=scale,
            native_actual_exit=row['native_runs'][0]['observed_exit_code'],
            reference_diff=row['reference_difference']['mismatched_pixels'])), flush=True)
    report.update(observed_exit_code=0, baseline_wrong_instance_reproduced=(label == 'baseline'),
        native_processes=10, repeated_native_pngs=30, callback_scales_verified=5,
        font_reference_exact_scales=sum(c['reference_difference']['mismatched_pixels'] == 0 for c in report['cases']))
except BaseException as error:
    report.update(observed_exit_code=1, failure=str(error)); raise
finally:
    report.update(all_commands_terminal=True, source_after=repository_source_identity(ROOT))
    assert report['source_after'] == source and sha(binary) == report['native_binary_sha256']
    save()
raise SystemExit(report['observed_exit_code'])
