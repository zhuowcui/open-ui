"""Exclusive baseline/fix proof for resolved variable-font outlines and native callbacks."""
import fcntl
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

MAIN = Path('/home/nero/code/open-ui')
RAW = MAIN / 'out/renderer-evidence/native-viewport-scroll-v1'
NAME = 'native-font-variation-pipeline-v1864'
OUT = RAW / NAME
STORE = Path('/mnt/e/openui-v02-qualification-d174ea0b') / NAME
lock = open('/tmp/openui-native-cargo-raster-owner.lock', 'a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
previous_path = RAW / 'native-font-choice-pipeline-v1850/receipt.json'
previous = json.loads(previous_path.read_bytes())
assert previous['all_commands_terminal']
for program in ['cargo', 'pixel_compare']:
    assert subprocess.run(['pgrep', '-x', program], capture_output=True).returncode == 1
assert not OUT.exists() and not STORE.exists()
STORE.mkdir(); OUT.symlink_to(STORE, target_is_directory=True)
sys.path.insert(0, str(MAIN / 'tools/qualification'))
from renderer_source_identity import repository_source_identity

sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
roots = {label: Path('/dev/shm/openui-native-font-variation-' + label + '-ink-v1862') for label in ['baseline', 'candidate']}
commits = dict(baseline='6bd72f51d4f37b472d6351cbb0c7d54cc8017b94', candidate='87124f68201cf0687a39b7ec3115d043354366a8')
sources = {label: repository_source_identity(root) for label, root in roots.items()}
checks = {}
for label in roots:
    assert sources[label]['clean'] and sources[label]['commit'] == commits[label]
    p = RAW / ('native-font-variation-' + label + '-checks-v1863/receipt.json')
    d = json.loads(p.read_bytes())
    assert d['source'] == d['source_after'] == sources[label] and d['all_commands_terminal']
    assert len(d['checks']) == 15 and all(c['observed_exit_code'] == 0 for c in d['checks'])
    checks[label] = sha(p)
scripts = [Path('/tmp/openui-native-font-variation-' + name + '-v1863.py') for name in ['build', 'consumer', 'matrices']]
report = dict(schema_version=1, source=sources['candidate'], source_after=sources['candidate'],
    baseline_source=sources['baseline'], owner_pid=os.getpid(), all_commands_terminal=False,
    state='prepared-verified', release_qualification=False, promotion_allowed=False,
    new_release_states_admitted=0, javascript_executed_by_openui=False,
    public_native_rust_apis_required=True, pixel_tolerance=0,
    whole_pipeline_lock_covers_all_stages_and_gaps=True, steps=[],
    probe_sha256=sha(Path(__file__)), immutable_probe_hashes={str(p): sha(p) for p in scripts},
    read_only_check_receipt_sha256=checks, prior_terminal_pipeline_sha256=sha(previous_path),
    full_original_and_expanded_matrices_not_attempted_by_this_pipeline=True,
    native_consumer_reference_is_independent_font_glyph_not_chromium=True)
save = lambda: (OUT / 'receipt.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
save()
stages = []
for label in ['baseline', 'candidate']:
    stages.extend([
        (label + '-build', [sys.executable, str(scripts[0]), label],
         RAW / ('native-font-variation-' + label + '-build-v1863/build.json'), 'build'),
        (label + '-native-callback', [sys.executable, str(scripts[1]), label],
         RAW / ('native-font-variation-' + label + '-consumer-v1863/receipt.json'), 'consumer')])
for suite in ['focused', 'primitive']:
    stages.append((suite, [sys.executable, str(scripts[2]), suite],
        RAW / ('native-font-variation-clean-' + suite + '-v1863') / (suite + '-summary.json'), 'matrix'))
try:
    for name, command, result_path, kind in stages:
        assert all(repository_source_identity(roots[l]) == sources[l] for l in roots)
        assert all(sha(p) == report['immutable_probe_hashes'][str(p)] for p in scripts)
        report['state'] = 'running-' + name; save()
        log = OUT / (name + '.log')
        with log.open('xb') as stream:
            process = subprocess.Popen(command, cwd=roots['candidate'],
                env=dict(os.environ, OPENUI_NATIVE_WHOLE_OWNER=NAME,
                    PYTHONDONTWRITEBYTECODE='1', TMPDIR='/dev/shm/oui1863'),
                stdout=stream, stderr=subprocess.STDOUT)
            report['current_process'] = dict(pid=process.pid, program=Path(command[1]).name)
            save(); process.wait()
        report.pop('current_process')
        report['steps'].append(dict(name=name, observed_exit_code=process.returncode, log_sha256=sha(log)))
        report['source_after'] = repository_source_identity(roots['candidate']); save()
        print(json.dumps(dict(stage=name, actual_exit=process.returncode)), flush=True)
        result = json.loads(result_path.read_bytes())
        if kind in ['build', 'consumer']:
            assert process.returncode == 0 and result['all_commands_terminal'] and not result.get('failure')
        else:
            assert process.returncode == 0, 'focused or primitive pixel gate failed'
    report.update(state='complete-full-census-and-independent-chromium-API-comparisons-pending', observed_exit_code=0)
except BaseException as error:
    report.update(state='stopped-on-build-harness-or-pixel-failure', failure=str(error), observed_exit_code=1)
    raise
finally:
    report.update(all_commands_terminal=True, source_after=repository_source_identity(roots['candidate']))
    assert report['source_after'] == sources['candidate']; save()
raise SystemExit(report['observed_exit_code'])
