"""Preserve the completed native API proof and every earlier failed local attempt."""
import hashlib
import json
import subprocess
import tarfile
from pathlib import Path

ROOT = Path('/home/nero/code/open-ui')
RAW = ROOT / 'out/renderer-evidence/native-viewport-scroll-v1'
DEST = ROOT / 'docs/renderer/evidence/native-variable-font-instance-v1'
INDEX = ROOT / 'docs/renderer/generated/native-variable-font-instance-v1.json'
assert not DEST.exists() and not INDEX.exists()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
owner_path = RAW / 'native-font-variation-pipeline-v1880/receipt.json'
owner = json.loads(owner_path.read_bytes())
assert owner['all_commands_terminal'] and owner['observed_exit_code'] == 0 and not owner.get('failure')
assert len(owner['steps']) == 6 and all(s['observed_exit_code'] == 0 for s in owner['steps'])
assert owner['source'] == owner['source_after'] and owner['source']['clean']
assert owner['source']['commit'] == 'feb7e872bd4b55bbbae40a600e280a1cb5ba2ac4'
sources = {}
checks = {}
builds = {}
native = {}
for label in ['baseline', 'candidate']:
    check_path = RAW / ('native-font-variation-' + label + '-checks-v1878/receipt.json')
    check = json.loads(check_path.read_bytes())
    assert check['all_commands_terminal'] and len(check['checks']) == 15
    assert all(c['observed_exit_code'] == 0 for c in check['checks'])
    checks[label] = dict(receipt_sha256=sha(check_path), passed=15)
    build_path = RAW / ('native-font-variation-' + label + '-build-v1879/build.json')
    build = json.loads(build_path.read_bytes())
    expected_source = owner['baseline_source'] if label == 'baseline' else owner['source']
    assert build['source'] == build['source_after'] == check['source'] == check['source_after'] == expected_source
    assert build['all_commands_terminal'] and build['observed_exit_code'] == 0
    stages = {s['name']: s for s in build['steps']}
    assert stages['variation-instance-guard']['observed_exit_code'] == (101 if label == 'baseline' else 0)
    if label == 'baseline':
        assert build['baseline_regression_reproduced'] and len(stages) == 3
    else:
        assert len(stages) == 8 and all(s['observed_exit_code'] == 0 for s in stages.values())
        assert stages['all-text-tests']['passed'] == 342
        assert stages['workspace']['passed'] == 8559 and stages['workspace']['failed'] == 0
        assert stages['workspace']['ignored'] == 13
    builds[label] = dict(receipt_sha256=sha(build_path), stages=build['steps'])
    consumer_path = RAW / ('native-font-variation-' + label + '-consumer-v1879/receipt.json')
    consumer = json.loads(consumer_path.read_bytes())
    assert consumer['source'] == consumer['source_after'] == expected_source
    assert consumer['all_commands_terminal'] and consumer['observed_exit_code'] == 0
    assert consumer['native_processes'] == 10 and consumer['callback_scales_verified'] == 5
    assert consumer['font_reference_exact_scales'] == (0 if label == 'baseline' else 5)
    assert all(c['geometry']['callback_count'] == 1 for c in consumer['cases'])
    if label == 'baseline':
        assert all(c['state_change_difference']['mismatched_pixels'] == 0 for c in consumer['cases'])
    else:
        assert all(c['state_change_difference']['mismatched_pixels'] > 0 for c in consumer['cases'])
        assert all(c['reference_difference']['mismatched_pixels'] == 0 for c in consumer['cases'])
    native[label] = dict(receipt_sha256=sha(consumer_path), actual_native_exit=1 if label == 'baseline' else 0,
        callback_scales=5, font_reference_exact_scales=consumer['font_reference_exact_scales'],
        native_processes=10, saved_repeated_pngs=30)
    work = Path('/dev/shm/openui-native-font-variation-' + label + '-mutation-v1877')
    for relative in ['bindings/rust/openui-text/src/shaping/shape_result.rs',
        'bindings/rust/openui/examples/native_font_variation.rs',
        'bindings/rust/openui-text/tests/data/variabletest_box.ttf',
        'bindings/rust/openui-text/tests/data/VARIABLE-BOX.md',
        'bindings/rust/openui-text/fonts/LICENSE-OFL-1.1.txt']:
        sources[label + '-source/' + relative] = work / relative

matrices = {}
for suite, total in [('focused', 640), ('primitive', 960)]:
    summary_path = RAW / ('native-font-variation-clean-' + suite + '-v1879') / (suite + '-summary.json')
    summary = json.loads(summary_path.read_bytes())
    assert summary['source'] == summary['source_after'] == owner['source']
    assert summary['results']['total'] == summary['results']['exact'] == total
    assert summary['results']['different'] == summary['results']['errors'] == 0
    exit_path = RAW / ('native-font-variation-' + suite + '-exit-v1879.json')
    actual = json.loads(exit_path.read_bytes()); assert actual['observed_exit_code'] == 0
    matrices[suite] = dict(results=summary['results'], actual_exit=0,
        summary_sha256=sha(summary_path), actual_exit_sha256=sha(exit_path))

for path in sorted(RAW.glob('native-font-variation*')):
    if path.is_dir():
        # Complete matrix receipts preserve every row and its hashes; individual
        # full-corpus PNGs remain in their original result stores and caches.
        candidates = path.glob('*.json') if '-clean-' in path.name else path.rglob('*')
        for p in sorted(candidates):
            if p.is_file() and not p.is_symlink() and p.suffix in ['.json', '.log', '.html', '.png']:
                sources[str(p.relative_to(RAW))] = p
    elif path.is_file() and path.suffix in ['.json', '.log']:
        sources[str(path.relative_to(RAW))] = path
for p in sorted(Path('/tmp').glob('openui-native-font-variation-*.py')):
    sources['probes/' + p.name] = p
for name in ['openui-native-font-variation-roots-v1877.json',
             'openui-native-font-variation-data-preflight-failure-v1881.json']:
    p = Path('/tmp') / name
    if p.exists(): sources['preparation/' + name] = p
DEST.mkdir()
patch = DEST / 'resolved-instance.patch'
patch.write_bytes(subprocess.check_output(['git', 'diff', owner['baseline_source']['commit'], owner['source']['commit'],
    '--', 'bindings/rust/openui-text/src/shaping/shape_result.rs'], cwd=ROOT))
sources['review/resolved-instance.patch'] = patch
archive = DEST / 'completed-evidence.tar.gz'
members = []
first_by_hash = {}
with tarfile.open(archive, 'w:gz', compresslevel=6, format=tarfile.PAX_FORMAT) as tar:
    for name, path in sorted(sources.items()):
        digest = sha(path)
        row = dict(path=name, bytes=path.stat().st_size, sha256=digest)
        info = tar.gettarinfo(str(path), arcname=name)
        if digest in first_by_hash:
            info.type = tarfile.LNKTYPE; info.linkname = first_by_hash[digest]; info.size = 0
            tar.addfile(info)
        else:
            first_by_hash[digest] = name
            with path.open('rb') as stream: tar.addfile(info, stream)
        members.append(row)
with tarfile.open(archive, 'r:gz') as tar:
    actual = tar.getmembers(); assert len(actual) == len(members)
    for member, row in zip(actual, members):
        assert member.name == row['path']
        data = tar.extractfile(member).read()
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
manifest = DEST / 'archive-members.json'
manifest.write_text(json.dumps(members, sort_keys=True, indent=2) + '\n')
index = dict(schema_version=1, source=owner['source'], source_after=owner['source_after'],
    baseline_source=owner['baseline_source'], all_commands_terminal=True,
    release_qualification=False, promotion_allowed=False, new_release_states_admitted=0,
    javascript_executed_by_openui=False, public_native_rust_apis_required=True,
    chromium_is_only_pixel_target=True, pixel_tolerance=0,
    callback_reference_kind='independent fixed U+2580 glyph in the unchanged WPT font',
    native_callback_is_not_a_chromium_comparison=True,
    default_raster_configuration_not_claimed=True,
    explicit_raster_configuration='RasterConfiguration::deterministic_aliased(true)',
    baseline_guard_actual_exit=101, candidate_guard_actual_exit=0,
    candidate_text_tests_passed=342, candidate_workspace_tests_passed=8559,
    candidate_workspace_tests_failed=0, candidate_workspace_tests_ignored=13,
    current_c_exports=113, current_c_layouts=30, actual_c_consumers=13, actual_cpp_consumers=7,
    read_only_checks=checks, builds=builds, native=native, matrices=matrices,
    all_six_owner_stages_terminal=True, whole_owner_lock_covered_all_stages_and_gaps=True,
    full_original_and_expanded_matrices_not_attempted_by_completed_pipeline=True,
    prepared_census_probes_are_not_executed_results=True,
    earlier_compile_preflight_and_unsuitable_reference_failures_preserved=True,
    new_formal_wpt_residual_owners_assigned=0,
    owner_receipt_sha256=sha(owner_path), archive_members=len(members),
    font_sha256='9270b7f6b2b8b34215a80c63a9c1348e704a0e3803ee49f2531bd62fdb5139c4',
    artifacts=[dict(path=str(p.relative_to(ROOT)), bytes=p.stat().st_size, sha256=sha(p))
        for p in [archive, manifest, patch]], preserver_sha256=sha(Path(__file__)))
INDEX.write_text(json.dumps(index, sort_keys=True, indent=2) + '\n')
print(json.dumps(dict(index=str(INDEX), index_sha256=sha(INDEX), members=len(members),
    archive_bytes=archive.stat().st_size, candidate_callback_exact_scales=5,
    native_reference_is_not_chromium=True)), flush=True)
