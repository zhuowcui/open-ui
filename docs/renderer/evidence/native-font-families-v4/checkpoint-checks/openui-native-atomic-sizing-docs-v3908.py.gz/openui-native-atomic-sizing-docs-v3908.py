import hashlib,json,os
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui')
INDEX=ROOT/'docs/renderer/generated/native-font-families-v4.json'
load=lambda p:json.loads(Path(p).read_bytes())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=load(INDEX);terminal=load('/tmp/openui-native-font-metrics-archive-terminal-v3906.json')
assert terminal['actual_archive_writer_exit_code']==0 and terminal['archive_writer_reaped'] and terminal['index_sha256']==sha(INDEX)
assert r['all_local_commands_terminal'] and r['all_members_hash_verified'] and r['focused_and_primitive']['candidate_nonregression']
assert r['focused_and_primitive']['results']['focused']['exact']==640 and r['focused_and_primitive']['results']['primitive']['exact']==960
assert r['clean_native_application']['totals']==dict(images=15,exact_images=0,bounds=210,exact_bounds=165)
assert r['isolated_atomic_sizing']['totals']==dict(images=15,exact_images=0,bounds=210,exact_bounds=180)
assert r['isolated_atomic_sizing']['guards']==dict(actual_exit_code=0,passed=1181,failed=0,ignored=0)
comparison=r['isolated_atomic_sizing']['audit']['comparison'];assert comparison['bounds_gains']==15 and comparison['bounds_losses']==0 and comparison['images_worse']==0 and comparison['images_improved']==9
text="""## Shared atomic sizing (scoped trial; full verification pending)

Atomic elements now use the shared minimum and maximum content calculations
across font families. Consecutive floats retain their measured minimum width.
This removes font-name and zero-minimum branches from atomic shrink-to-fit;
global shaping, hinting and rasterization are unchanged.

A separate Rust app at clean `fd478bef` measures **0/15 whole images and
165/210 bounds exact** against unchanged pinned Chromium. Its two Rust
callbacks, independent process repeats, unchanged-frame repeats and weak
teardown pass. The probe records **1,470 direct shaping samples** from retained
computed styles and the shared font collection. These samples are diagnostics,
not a claim about the Engine's inline segmentation or Chromium's internal
strike settings.

The isolated one-file sizing trial measures **0/15 whole images and
180/210 bounds exact** at five profiles: **15 bounds gained, none lost**,
**nine images improved, none worsened**. Consecutive-float width is now 90px,
matching Chromium, instead of zero. Long-word width precision and fallback
line height still differ. All **1,181 layout/text/paint tests** pass with zero
failures or ignores. Focused **640/640** and primitive **960/960** are exact,
with all **1,600 rows** independently audited and Chromium inputs unchanged.
The trial source was dirty and is explicitly unqualified.

Clean verification of this integrated sizing change, complete original and
expanded census nonregression, workspace/ABI and hosted hardening remain
pending. Prior clean `fd478bef` hosted workflows complete, but five hardening
jobs are skipped; that is not a complete hardening pass. The latest complete
original and expanded pixel counts remain attributed to earlier clean
`98d18982`: **21,350/22,924** and **22,153/23,728**, both failed with zero
errors. No renderer, complete native API or release qualification is claimed.

Open UI never runs JavaScript. Applications use public native Rust APIs and
Rust callbacks; every needed element operation remains framework work.
Chromium alone defines expected pixels.
[Immutable native measurements and sizing trial]({link}).

"""
changes=[]
for name,marker,link in [('README.md','### Resolved font raster selection','docs/renderer/generated/native-font-families-v4.json'),('docs/progress/current-status.md','## Current implementation','../renderer/generated/native-font-families-v4.json'),('docs/renderer/contract.md','## Resolved font raster selection','generated/native-font-families-v4.json'),('docs/v02/release.md','## Resolved font raster selection','../renderer/generated/native-font-families-v4.json')]:
 path=ROOT/name;old=path.read_text();assert marker in old and '## Shared atomic sizing' not in old
 section=text.format(link=link)
 if name=='README.md':section=section.replace('## Shared atomic sizing','### Shared atomic sizing',1)
 pos=old.index(marker);new=old[:pos]+section+old[pos:];temp=path.with_name(path.name+'.tmp');temp.write_text(new);os.replace(temp,path);changes.append(dict(path=name,before_sha256=hashlib.sha256(old.encode()).hexdigest(),after_sha256=sha(path)))
path=ROOT/'docs/v02/unsupported-features.md';old=path.read_text();marker='These are implementation gaps, not accepted final-v0.2 omissions:\n\n';assert marker in old
bullet="""- shared atomic sizing is integrated from a dirty diagnostic trial: 180/210
  bounds and 0/15 whole images are exact, with 15 bounds gained, no losses,
  nine images improved and none worsened. All 1,181 layout/text/paint tests
  pass; focused 640/640 and primitive 960/960 are exact with unchanged Chromium
  inputs. Clean current-source native/full-census/workspace/ABI/hardening
  verification remains pending. Long-word precision and fallback line height
  still differ. The clean `fd478bef` native baseline is 165/210 bounds and
  0/15 images exact. No renderer, complete API or release qualification is
  claimed. [Measured evidence](../renderer/generated/native-font-families-v4.json);
"""
new=old.replace(marker,marker+bullet,1);temp=path.with_name(path.name+'.tmp');temp.write_text(new);os.replace(temp,path);changes.append(dict(path=str(path.relative_to(ROOT)),before_sha256=hashlib.sha256(old.encode()).hexdigest(),after_sha256=sha(path)))
proof=Path('/tmp/openui-native-atomic-sizing-docs-v3908.json');assert not proof.exists();proof.write_text(json.dumps(dict(schema_version=1,changes=changes,all_qualification_claims_false=True),sort_keys=True,indent=2)+'\n');print(json.dumps(dict(edited_documents=len(changes),qualification=False)))
