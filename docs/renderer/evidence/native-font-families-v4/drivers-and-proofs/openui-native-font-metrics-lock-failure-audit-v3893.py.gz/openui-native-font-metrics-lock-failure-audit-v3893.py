import fcntl,hashlib,json,subprocess,tomllib,sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b');OUT=BASE/'native-font-metrics-consumer-v3890';PROJECT=BASE/'native-font-metrics-consumer-source-v3889/project'
sys.path[:0]=[str(ROOT),'/tmp']
from openui_parallel_source_identity_v3060 import identity
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_bytes())
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
r=load(OUT/'receipt.json');assert r['all_commands_terminal'] and r['source_unchanged'] and r['consumer_source_unchanged'] and r['observed_exit_code']==1 and r['failure']=='AssertionError()'
assert identity(ROOT)==r['source']==r['source_after'] and r['source']['clean']
assert len(r['steps'])==1 and r['steps'][0]['name']=='consumer-lock' and r['steps'][0]['actual_exit_code']==0 and not r['local_artifacts'] and not r['cases']
assert sha('/tmp/openui-native-font-metrics-consumer-v3890.py')==r['driver_sha256']
assert sha(OUT/'consumer-lock.log')==r['steps'][0]['log_sha256']
for pid in [r['owner_pid'],r['steps'][0]['pid']]:assert subprocess.run(['ps','-p',str(pid)],capture_output=True).returncode==1
for name in ['cargo','rustc','rustfmt','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
assert sha(PROJECT/'src/main.rs')==r['consumer_source_sha256'] and sha(PROJECT/'Cargo.toml')==r['consumer_manifest_sha256']
key=lambda p:(p['name'],p['version'],p.get('source'),p.get('checksum'))
expected={key(p) for p in tomllib.loads((ROOT/'bindings/rust/Cargo.lock').read_text())['package']}
unexpected=[p for p in tomllib.loads((PROJECT/'Cargo.lock').read_text())['package'] if key(p) not in expected and p['name']!='openui-native-font-metrics-consumer']
assert unexpected
p=dict(schema_version=1,complete=True,source=r['source'],actual_owner_exit_code=1,owner_absent=True,receipt_sha256=sha(OUT/'receipt.json'),audit_driver_sha256=sha(__file__),consumer_lock_sha256=sha(PROJECT/'Cargo.lock'),unexpected_lock_packages=unexpected,target_mutation_started=False,compiled=False,executed=False,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,javascript_executed_by_openui=False,retired_for_reexecution_after_source_or_target_mutation=True)
dest=Path('/tmp/openui-native-font-metrics-lock-failure-audit-v3893.json');assert not dest.exists();dest.write_text(json.dumps(p,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(audit=str(dest),unexpected_lock_packages=len(unexpected),target_mutation_started=False)))
