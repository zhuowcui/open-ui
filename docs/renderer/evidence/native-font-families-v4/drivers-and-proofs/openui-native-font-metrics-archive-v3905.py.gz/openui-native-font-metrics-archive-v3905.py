import fcntl,gzip,hashlib,json,shutil,subprocess,sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b')
DEST=ROOT/'docs/renderer/evidence/native-font-families-v4';INDEX=ROOT/'docs/renderer/generated/native-font-families-v4.json'
sys.path[:0]=[str(ROOT),'/tmp']
from openui_parallel_source_identity_v3060 import identity
load=lambda p:json.loads(Path(p).read_bytes())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
NATIVE=BASE/'native-font-metrics-consumer-v3894';TRIAL=BASE/'native-atomic-sizing-trial-v3898';MATRIX=BASE/'native-atomic-sizing-matrices-v3902'
native=load(NATIVE/'receipt.json');trial=load(TRIAL/'receipt.json');matrix=load(MATRIX/'receipt.json')
na=load('/tmp/openui-native-font-metrics-consumer-audit-v3895.json');ta=load('/tmp/openui-native-atomic-sizing-trial-audit-v3899.json');ma=load('/tmp/openui-native-atomic-sizing-matrices-audit-v3903.json')
for receipt,audit,proofname in [(native,na,'openui-native-font-metrics-consumer-reaped-v3896'),(trial,ta,'openui-native-atomic-sizing-trial-reaped-v3900'),(matrix,ma,'openui-native-atomic-sizing-matrices-reaped-v3904')]:
 proof=load('/tmp/'+proofname+'.json');assert receipt['all_commands_terminal'] and audit['complete'] and proof['all_local_commands_terminal'] and proof['owners_absent']
 assert receipt['source']==audit['source']==proof['source']
 assert subprocess.run(['ps','-p',str(receipt['owner_pid'])],capture_output=True).returncode==1
assert identity(ROOT)==matrix['source']==trial['source'] and native['source']['clean'] and not trial['source']['clean']
for name in ['cargo','rustc','rustfmt','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
assert not DEST.exists() and not INDEX.exists() and shutil.disk_usage(ROOT).free>192*2**20
previous=ROOT/'docs/renderer/generated/native-font-families-v3.json';prior_sha=sha(previous)
assert all(sha(ROOT/member['path'])==member['sha256'] for member in load(previous)['archive']['members'])
DEST.mkdir();members=[];excluded=[]
def add(path,label):
 raw=Path(path).read_bytes();stored=gzip.compress(raw,compresslevel=9,mtime=0);target=DEST/(label+'.gz');assert not target.exists();target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(stored)
 assert gzip.decompress(target.read_bytes())==raw
 members.append(dict(path=str(target.relative_to(ROOT)),compression='gzip',bytes=len(stored),sha256=sha(target),raw_bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest()))
for directory,label in [(NATIVE,'clean-consumer'),(TRIAL,'isolated-sizing-trial')]:
 for path in sorted(directory.rglob('*')):
  if not path.is_file():continue
  if path.name=='native_font_metrics_consumer':excluded.append(dict(path=str(path),sha256=sha(path),reason='Owned native executable retained outside Git; exact binary hash and fresh linked compiler provenance are archived.'));continue
  assert path.suffix in ['.json','.png','.log']
  add(path,label+'/'+str(path.relative_to(directory)))
for path in sorted((BASE/'native-font-metrics-consumer-source-v3889').rglob('*')):
 if path.is_file():add(path,'consumer-source/'+str(path.relative_to(BASE/'native-font-metrics-consumer-source-v3889')))
for path in sorted((BASE/'native-atomic-sizing-source-v3897').iterdir()):
 if path.is_file():add(path,'sizing-source/'+path.name)
for path in sorted((MATRIX/'guarded-build').iterdir()):
 if path.is_file() and path.name!='pixel_compare':add(path,'matrix-build/'+path.name)
for suite in ['focused','primitive']:add(MATRIX/(suite+'-matrix')/(suite+'-summary.json'),suite+'-summary.json');add(MATRIX/(suite+'.log'),suite+'.log')
add(MATRIX/'receipt.json','matrix-receipt.json')
for name in ['openui-native-font-metrics-consumer-v3890.py','openui-native-font-metrics-consumer-v3894.py','openui-native-font-metrics-consumer-audit-v3895.py','openui-native-font-metrics-consumer-audit-v3895.json','openui-native-font-metrics-consumer-reaping-v3896.py','openui-native-font-metrics-consumer-reaped-v3896.json','openui-native-font-metrics-lock-failure-audit-v3893.py','openui-native-font-metrics-lock-failure-audit-v3893.json','openui-native-font-metrics-lock-failure-reaped-v3893.json','openui-native-atomic-sizing-trial-v3898.py','openui-native-atomic-sizing-trial-audit-v3899.py','openui-native-atomic-sizing-trial-audit-v3899.json','openui-native-atomic-sizing-trial-reaping-v3900.py','openui-native-atomic-sizing-trial-reaped-v3900.json','openui-native-atomic-sizing-matrices-v3902.py','openui-native-atomic-sizing-matrices-audit-v3903.py','openui-native-atomic-sizing-matrices-audit-v3903.json','openui-native-atomic-sizing-matrices-reaping-v3904.py','openui-native-atomic-sizing-matrices-reaped-v3904.json']:add('/tmp/'+name,'drivers-and-proofs/'+name)
for path in sorted((BASE/'native-font-metrics-consumer-v3890').iterdir()):
 if path.is_file():add(path,'rejected-lock-resolution/'+path.name)
add(BASE/'native-font-metrics-review-v3901.json','font-metrics-review.json')
for path in sorted((BASE/'native-font-metrics-hosted-v3907').iterdir()):
 if path.is_file():add(path,'prior-clean-hosted/'+path.name)
add(__file__,'drivers-and-proofs/'+Path(__file__).name)
build=load(MATRIX/'guarded-build/receipt.json');excluded.append(dict(path=build['binary'],sha256=build['binary_sha256'],reason='Owned renderer executable retained outside Git; exact binary hash and fresh linked-library provenance are archived.'))
assert sha(previous)==prior_sha
result=dict(schema_version=1,source=trial['source'],clean_native_measurement_source=native['source'],previous_immutable_evidence=dict(path=str(previous.relative_to(ROOT)),sha256=prior_sha,unchanged=True),clean_native_application=dict(totals=native['totals'],actual_exit_code=native['observed_exit_code'],audit=na,metrics_scope=native['metrics_scope'],whole_images_exact=False,qualification=False),isolated_atomic_sizing=dict(totals=trial['totals'],actual_exit_code=trial['observed_exit_code'],audit=ta,guards=trial['guard_results'],scope=load(BASE/'native-atomic-sizing-source-v3897/source.json')['scope'],clean_source=False,qualification=False),focused_and_primitive=dict(results=ma['results'],audited_rows=ma['matrix_rows_verified'],candidate_nonregression=ma['candidate_nonregression'],clean_source=False,qualification=False),font_metrics_review=load(BASE/'native-font-metrics-review-v3901.json'),prior_clean_hosted=load(BASE/'native-font-metrics-hosted-v3907/receipt.json'),all_local_commands_terminal=True,all_members_hash_verified=True,full_original_or_expanded_rerun_complete=False,pixel_target='pinned Chromium',pixel_tolerance=0,historical_openui_archive_is_a_pixel_target=False,javascript_executed_by_openui=False,full_renderer_contract_qualified=False,all_native_apis_qualified=False,release_qualified=False,pending=['Clean native trial and complete original/expanded nonregression after any source integration.','Correct word-width precision, fallback line metrics and every remaining font/raster difference through shared behavior.','All remaining native APIs, reviewed residual owners, compositor/3D, physical lab and release gates.'],archive=dict(files=len(members),bytes=sum(m['bytes'] for m in members),members=members,excluded=excluded))
INDEX.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(index=str(INDEX),files=len(members),bytes=result['archive']['bytes'],native=native['totals'],trial=trial['totals'],matrices=ma['results'])),flush=True)
