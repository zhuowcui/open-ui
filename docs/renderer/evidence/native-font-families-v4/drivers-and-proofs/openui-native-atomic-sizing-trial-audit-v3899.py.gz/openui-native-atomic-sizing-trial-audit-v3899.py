import fcntl,hashlib,json,subprocess,sys,tomllib
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui')
BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b')
OUT=BASE/'native-atomic-sizing-trial-v3898'
PROJECT=BASE/'native-font-metrics-consumer-source-v3889/project'
PREP=BASE/'native-font-metrics-consumer-source-v3889/source.json'
REF=BASE/'native-general-font-chromium-v3824'
DEST=Path('/tmp/openui-native-atomic-sizing-trial-audit-v3899.json')
sys.path[:0]=[str(ROOT),'/tmp']
from openui_parallel_source_identity_v3060 import identity
from tools.qualification.residuals import analyze_image_difference
load=lambda p:json.loads(Path(p).read_bytes())
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(2**20),b''):h.update(b)
 return h.hexdigest()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
r=load(OUT/'receipt.json');reference=load(REF/'receipt.json');prep=load(PREP)
assert r['all_commands_terminal'] and r['source_unchanged'] and r['consumer_source_unchanged'] and r['consumer_lock_unchanged']
assert 'failure' not in r and identity(ROOT)==r['source']==r['source_after'] and not r['source']['clean']
assert r['observed_exit_code']==int(sys.argv[1])
assert r['diagnostic_only'] and not r['clean_native_font_metrics_consumer'] and r['atomic_sizing_trial']
assert sha(BASE/'native-atomic-sizing-source-v3897/source.json')==r['source_patch_sha256']
patch=load(BASE/'native-atomic-sizing-source-v3897/source.json');assert patch['source_after']==r['source'] and sha(ROOT/patch['source_path'])==patch['after_sha256']
assert sha('/tmp/openui-native-font-metrics-consumer-reaped-v3896.json')==r['prior_native_reaping_sha256']
assert not r['javascript_executed_by_openui'] and not r['historical_openui_archive_is_a_pixel_target']
assert r['pixel_tolerance']==0 and r['pixel_target']=='pinned Chromium'
assert not r['full_renderer_contract_qualified'] and not r['all_native_apis_qualified'] and not r['release_qualified']
assert sha('/tmp/openui-native-atomic-sizing-trial-v3898.py')==r['driver_sha256']
assert sha(PREP)==r['preparation_sha256'] and prep['source_commit']==r['source']['commit']
assert sha(PROJECT/'src/main.rs')==r['consumer_source_sha256']==prep['consumer_source_sha256']
assert sha(PROJECT/'Cargo.toml')==r['consumer_manifest_sha256']==prep['consumer_manifest_sha256']
assert sha(PROJECT/'Cargo.lock')==r['consumer_lock_sha256']
assert sha(BASE/'native-font-metrics-consumer-source-v3889/workspace-lock-template.txt')==prep['workspace_lock_template_sha256']==sha(ROOT/'bindings/rust/Cargo.lock')
key=lambda p:(p['name'],p['version'],p.get('source'),p.get('checksum'))
expected={key(p) for p in tomllib.loads((ROOT/'bindings/rust/Cargo.lock').read_text())['package']}
consumer_lock=tomllib.loads((PROJECT/'Cargo.lock').read_text())['package']
assert all(key(p) in expected or key(p)==('openui-native-font-metrics-consumer','0.1.0',None,None) for p in consumer_lock)
assert sum(p['name']=='openui-native-font-metrics-consumer' for p in consumer_lock)==1
assert sha('/tmp/openui-native-resolved-raster-clean-full-reaped-v3867.json')==r['full_reaping_sha256']
assert sha(REF/'receipt.json')==r['reference_receipt_sha256']
assert sha('/tmp/openui-native-general-font-chromium-reaped-v3832.json')==r['reference_reaping_sha256']
assert subprocess.run(['ps','-p',str(r['owner_pid'])],capture_output=True).returncode==1
for name in ['cargo','rustc','rustfmt','pixel_compare']:
 assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
assert len(r['steps'])==15
for step in r['steps']:
 assert step['actual_exit_code']==0 or step['name']=='text-layout-paint-guards'
 assert sha(OUT/(step['name']+'.log'))==step['log_sha256']
 assert subprocess.run(['ps','-p',str(step['pid'])],capture_output=True).returncode==1
 if step['command'][0]=='cargo':
  assert step['command'][1:3]==['--config',str(ROOT/'bindings/rust/.cargo/config.chromium.toml')]
  assert step['name']=='text-layout-paint-guards' or ('--manifest-path' in step['command'] and str(PROJECT/'Cargo.toml') in step['command'])
compiled={}
for row in r['local_artifacts']:
 assert row['reason']=='compiler-artifact' and not row['fresh']
 assert (Path(row['manifest_path']).resolve().is_relative_to(ROOT) and Path(row['target']['src_path']).resolve().is_relative_to(ROOT)) or (Path(row['manifest_path']).resolve().is_relative_to(PROJECT) and Path(row['target']['src_path']).resolve().is_relative_to(PROJECT))
 for path,digest in row['sha256'].items():
  assert sha(path)==digest;compiled[path]=digest
assert {'openui','openui_engine','openui_layout','openui_paint','openui_text','openui-native-font-metrics-consumer'}.issubset({x['target']['name'] for x in r['local_artifacts']})
assert sha(OUT/'native_font_metrics_consumer')==r['native_binary_sha256']
assert len(r['cases'])==5
images=bounds=exact_images=exact_bounds=0;metric_files=metric_nodes=metric_samples=0
for i,case in enumerate(r['cases']):
 assert case['profile']==reference['cases'][i]['profile']
 assert len(case['runs'])==2 and case['runs'][0]['files']==case['runs'][1]['files']
 assert case['native_alias_pixels_equal']==(case['runs'][0]['files']['before.png']==case['runs'][0]['files']['alias.png'])
 assert case['native_alias_bounds_equal']==(load(OUT/f'profile-{i}/native-1/before.json')==load(OUT/f'profile-{i}/native-1/alias.json'))
 for run in case['runs']:
  directory=Path(run['directory'])
  assert {p.name:sha(p) for p in directory.iterdir()}==run['files']
  lifecycle=load(directory/'lifecycle.json');assert lifecycle['callbacks']==2 and lifecycle['weak_teardown_passed'] and not lifecycle['javascript_executed_by_openui']
 assert set(case['stages'])=={'before','alias','after'}
 for stage,row in case['stages'].items():
  native=OUT/f'profile-{i}/native-1/{stage}.png';png=REF/f'profile-{i}/chromium-1-{stage}-capture-1.png'
  assert sha(native)==row['native_png_sha256'] and sha(png)==row['chromium_png_sha256']==reference['cases'][i]['png_sha256'][stage]
  assert load(OUT/f'profile-{i}/native-1/{stage}.json')==row['native_bounds']
  assert reference['cases'][i]['geometry'][stage]==row['chromium_bounds']
  assert row['analysis']==analyze_image_difference(png,native)
  assert row['bounds_count']==14 and row['exact_bounds']==sum(a==b for a,b in zip(row['native_bounds'],row['chromium_bounds']))
  metrics_path=OUT/f'profile-{i}/native-1/{stage}-font-metrics.json'
  assert sha(metrics_path)==row['font_metrics_sha256']
  metrics=load(metrics_path);assert len(metrics)==row['font_metrics_node_count']==14
  assert [x['name'] for x in metrics]==[x['name'] for x in row['native_bounds']]
  for m in metrics:
   assert len(m['samples'])==7
   assert 'device_scale_factor' in m['computed_font_description']
   for sample in m['samples']:
    assert all(len(run['glyphs'])==len(run['advances'])==len(run['offsets'])==len(run['clusters']) for run in sample['runs'])
    assert abs(sum(sum(run['advances']) for run in sample['runs'])-sample['shaped_width'])<0.001
   metric_samples+=len(m['samples'])
  metric_files+=1;metric_nodes+=len(metrics)
  images+=1;bounds+=14;exact_images+=row['analysis']['mismatched_pixels']==0;exact_bounds+=row['exact_bounds']
assert r['totals']==dict(images=images,exact_images=exact_images,bounds=bounds,exact_bounds=exact_bounds)
assert images==15 and bounds==210 and metric_files==15 and metric_nodes==210 and metric_samples==1470
guards_log=OUT/'text-layout-paint-guards.log'
import re
summaries=re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored;',guards_log.read_text());assert len(summaries)==3
step=next(x for x in r['steps'] if x['name']=='text-layout-paint-guards')
assert r['guard_results']==dict(actual_exit_code=step['actual_exit_code'],passed=sum(int(x[0]) for x in summaries),failed=sum(int(x[1]) for x in summaries),ignored=sum(int(x[2]) for x in summaries))
assert r['observed_exit_code']==int(exact_images!=15 or exact_bounds!=210 or r['guard_results']['actual_exit_code']!=0)
previous=load(BASE/'native-font-metrics-consumer-v3894/receipt.json')
comparison=dict(previous_diagnostic_source=previous['source'],previous_receipt_sha256=sha(BASE/'native-font-metrics-consumer-v3894/receipt.json'),native_images_unchanged_from_prior_diagnostic=all(a['stages'][s]['native_png_sha256']==b['stages'][s]['native_png_sha256'] for a,b in zip(r['cases'],previous['cases']) for s in a['stages']),native_bounds_unchanged_from_prior_diagnostic=all(a['stages'][s]['native_bounds']==b['stages'][s]['native_bounds'] for a,b in zip(r['cases'],previous['cases']) for s in a['stages']),chromium_references_unchanged=all(a['profile']==b['profile'] and all(a['stages'][s]['chromium_png_sha256']==b['stages'][s]['chromium_png_sha256'] and a['stages'][s]['chromium_bounds']==b['stages'][s]['chromium_bounds'] for s in a['stages']) for a,b in zip(r['cases'],previous['cases'])))
assert comparison['chromium_references_unchanged']
comparison['bounds_gains']=sum(old!=expected and new==expected for a,b in zip(previous['cases'],r['cases']) for s in a['stages'] for old,new,expected in zip(a['stages'][s]['native_bounds'],b['stages'][s]['native_bounds'],b['stages'][s]['chromium_bounds']))
comparison['bounds_losses']=sum(old==expected and new!=expected for a,b in zip(previous['cases'],r['cases']) for s in a['stages'] for old,new,expected in zip(a['stages'][s]['native_bounds'],b['stages'][s]['native_bounds'],b['stages'][s]['chromium_bounds']))
comparison['images_worse']=sum(b['stages'][s]['analysis']['mismatched_pixels']>a['stages'][s]['analysis']['mismatched_pixels'] for a,b in zip(previous['cases'],r['cases']) for s in a['stages'])
comparison['images_improved']=sum(b['stages'][s]['analysis']['mismatched_pixels']<a['stages'][s]['analysis']['mismatched_pixels'] for a,b in zip(previous['cases'],r['cases']) for s in a['stages'])
assert not DEST.exists()
p=dict(schema_version=1,complete=True,actual_owner_exit_code=r['observed_exit_code'],owner_absent=True,source=r['source'],receipt_sha256=sha(OUT/'receipt.json'),driver_sha256=r['driver_sha256'],audit_driver_sha256=sha(__file__),fresh_local_compiler_records=len(r['local_artifacts']),compiled_paths_verified=len(compiled),native_binary_sha256=r['native_binary_sha256'],consumer_source_sha256=r['consumer_source_sha256'],consumer_manifest_sha256=r['consumer_manifest_sha256'],consumer_lock_sha256=r['consumer_lock_sha256'],process_repeats=True,unchanged_frames=True,rust_callback_count=2,weak_teardown=True,totals=r['totals'],guard_results=r['guard_results'],metrics=dict(files=metric_files,nodes=metric_nodes,samples=metric_samples,scope=r['metrics_scope']),comparison=comparison,diagnostic_only=True,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,javascript_executed_by_openui=False,retired_for_reexecution_after_source_or_target_mutation=True)
DEST.write_text(json.dumps(p,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(audit=str(DEST),totals=p['totals'],metrics=p['metrics'],comparison=comparison)),flush=True)
