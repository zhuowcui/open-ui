import hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');OUT=Path('/mnt/d/openui-v02-qualification-d174ea0b/native-shaping-wrap-baseline-build-v3679')
sys.path.insert(0,'/tmp')
from openui_parallel_source_identity_v3060 import identity

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(2**20),b''):h.update(b)
 return h.hexdigest()

r=json.loads((OUT/'receipt.json').read_bytes())
assert r['observed_exit_code']==int(sys.argv[1])==0
assert r['all_commands_terminal'] and r['source_unchanged'] and r['source']==r['source_after']==identity(ROOT)
assert r['source']['clean'] and subprocess.run(['ps','-p',str(r['owner_pid'])],capture_output=True).returncode==1
assert sha('/tmp/openui-native-shaping-wrap-baseline-build-v3679.py')==r['driver_sha256']
for n in ['cargo','rustc','rustfmt','pixel_compare']:
 assert subprocess.run(['pgrep','-x',n],capture_output=True).returncode==1,n
paths=set()
for a in r['local_artifacts']:
 assert a['reason']=='compiler-artifact' and a['fresh'] is False
 assert Path(a['manifest_path']).resolve().is_relative_to(ROOT)
 assert Path(a['target']['src_path']).resolve().is_relative_to(ROOT)
 for p,d in a['sha256'].items():assert sha(p)==d;paths.add(p)
binary=OUT/'native_shaping_wrap'
assert sha(binary)==r['native_binary_sha256']
example=next(a for a in r['local_artifacts'] if a['target']['name']=='native_shaping_wrap')
assert r['native_binary_sha256'] in example['sha256'].values()
for s in r['steps']:
 assert s['actual_exit_code']==0
 assert sha(OUT/(s['name']+'.log'))==s['log_sha256']
assert len(r['cases'])==5
for c in r['cases']:
 assert len(c['runs'])==2 and c['runs'][0]['files']==c['runs'][1]['files']
 for run in c['runs']:
  d=Path(run['directory'])
  for p,h in run['files'].items():assert sha(d/p)==h
  lifecycle=json.loads((d/'lifecycle.json').read_bytes())
  assert lifecycle=={'callbacks':1,'weak_teardown_passed':True,'javascript_executed_by_openui':False}
p=Path('/tmp/openui-native-shaping-wrap-baseline-terminal-v3680.json');assert not p.exists()
p.write_text(json.dumps({'schema_version':1,'source':r['source'],'all_local_commands_terminal':True,'actual_owner_exit_code':0,'owner_absent':True,'receipt_sha256':sha(OUT/'receipt.json'),'driver_sha256':sha(__file__),'fresh_local_records':len(r['local_artifacts']),'live_artifact_paths_verified':len(paths),'owned_native_binary_sha256':sha(binary),'diagnostic_only':True,'chromium_geometry_qualified':False,'chromium_pixels_qualified':False,'all_native_apis_qualified':False,'renderer_qualified':False,'release_qualified':False,'retired_for_reexecution_after_source_or_target_mutation':True},indent=2)+'\n')
print(p)
