    /// Contiguous shaping items still belong to one logical text node.
    fn logical_text_item_span(&self, index: usize) -> (usize, usize) {
        let same_text = |a: &InlineItem, b: &InlineItem| {
            a.item_type == InlineItemType::Text
                && b.item_type == InlineItemType::Text
                && a.node_id == b.node_id
                && a.style_index == b.style_index
                && a.text_range.end == b.text_range.start
        };
        let mut begin = index;
        while begin > 0
            && same_text(&self.items_data.items[begin - 1], &self.items_data.items[begin])
        {
            begin -= 1;
        }
        let mut end = index;
        while end + 1 < self.items_data.items.len()
            && same_text(&self.items_data.items[end], &self.items_data.items[end + 1])
        {
            end += 1;
        }
        (begin, end)
    }

    /// Compute Unicode opportunities once per logical text group, including
    /// the context on both sides of its independently shaped runs.
    fn logical_text_breaks(&mut self, begin: usize, end: usize) -> &[usize] {
        let data = self.items_data;
        self.logical_break_opportunities.entry(begin).or_insert_with(|| {
            let start = data.items[begin].text_range.start;
            let finish = data.items[end].text_range.end;
            let style = &data.styles[data.items[begin].style_index];
            find_break_opportunities(
                &data.text[start..finish],
                style.word_break,
                style.overflow_wrap,
                style.line_break,
            ).into_iter().map(|offset| start + offset).collect()
        })
    }

    /// A shaping boundary does not create a CSS line-break opportunity.
    /// Rewind to the preceding logical break when a continuation cannot fit.
    /// An oversized first word instead continues through its next real break.
    fn repair_shaping_boundary_wrap(&mut self, line: &mut LineInfo) {
        if line.has_forced_break || line.has_forced_hyphen {
            return;
        }
        let Some(last) = line.items.last() else { return; };
        if last.item_type != InlineItemType::Text {
            return;
        }
        let last_index = last.item_index;
        let first = &self.items_data.items[last_index];
        let Some(next) = self.items_data.items.get(self.current_item) else { return; };
        let resume = self.current_text_offset.max(next.text_range.start);
        if next.item_type != InlineItemType::Text
            || next.node_id != first.node_id
            || next.style_index != first.style_index
            || resume != last.text_range.end
        {
            return;
        }
        let style = &self.items_data.styles[first.style_index];
        if !allows_line_wrap(style.white_space) || !allows_line_wrap(self.container_white_space) {
            return;
        }
        let (begin, end) = self.logical_text_item_span(last_index);
        let logical_start = self.items_data.items[begin].text_range.start;
        let logical_end = self.items_data.items[end].text_range.end;
        let tail_start = line.items.iter().rev().take_while(|result| {
            result.item_type == InlineItemType::Text
                && result.item_index >= begin && result.item_index <= end
        }).last().map_or(resume, |result| result.text_range.start);
        let (legal, previous, following) = {
            let breaks = self.logical_text_breaks(begin, end);
            let insertion = breaks.partition_point(|&cut| cut < resume);
            (
                breaks.get(insertion) == Some(&resume),
                insertion.checked_sub(1).map_or(logical_start, |i| breaks[i]),
                breaks.get(insertion).copied().unwrap_or(logical_end),
            )
        };
        if legal || resume == logical_end {
            return;
        }
        if matches!(style.overflow_wrap, OverflowWrap::BreakWord | OverflowWrap::Anywhere)
            || style.word_break == WordBreak::BreakWord
        {
            // Emergency grapheme breaking is permitted for a logical unit
            // that cannot fit on an otherwise empty line. An item boundary
            // cannot turn a fitting word into an emergency break.
            let unit_end = if matches!(style.white_space, WhiteSpace::Normal | WhiteSpace::PreLine) {
                previous + self.items_data.text[previous..following]
                    .trim_end_matches([' ', '\t']).len()
            } else { following };
            let width = (begin..=end).fold(LayoutUnit::zero(), |width, index| {
                let range = &self.items_data.items[index].text_range;
                let start = range.start.max(previous);
                let end = range.end.min(unit_end);
                width + if start < end {
                    self.measure_text_range(index, start, end)
                } else { LayoutUnit::zero() }
            });
            if width > line.available_width {
                return;
            }
        }
        if previous <= tail_start {
            let width = self.measure_text_range(self.current_item, resume, next.text_range.end);
            self.force_text_through_next_logical_break(self.current_item, resume, width, line, style);
            return;
        }
        let cut = previous;
        while line.items.last().is_some_and(|result| {
            result.item_type == InlineItemType::Text && result.text_range.start >= cut
        }) {
            let removed = line.items.pop().unwrap();
            line.used_width = line.used_width - removed.inline_size;
        }
        if let Some(last) = line.items.last_mut() {
            if last.text_range.end > cut {
                let width = self.measure_text_range(last.item_index, last.text_range.start, cut);
                line.used_width = line.used_width - last.inline_size + width;
                last.inline_size = width;
                last.text_range.end = cut;
            }
        }
        self.current_item = (begin..=end)
            .find(|&index| self.items_data.items[index].text_range.contains(&cut))
            .expect("soft break inside logical text");
        self.current_text_offset = cut;
    }
