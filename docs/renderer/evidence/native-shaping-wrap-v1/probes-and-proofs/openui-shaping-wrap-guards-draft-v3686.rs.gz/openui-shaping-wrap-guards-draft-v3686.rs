    #[test]
    fn shaping_run_boundaries_do_not_split_quoted_words_or_contractions() {
        use openui_dom::NodeId;
        use openui_text::{Font, FontDescription, TextDirection, TextShaper};
        use std::sync::Arc;

        for (text, ranges, first_end, second_start) in [
            ("XX 'XX", vec![0..3, 3..4, 4..6], 2, 3),
            ("can't tail", vec![0..3, 3..4, 4..10], 5, 6),
        ] {
            let shaper = TextShaper::new();
            let font = Font::new(FontDescription::default());
            let shapes: Vec<_> = ranges
                .iter()
                .map(|range| Arc::new(shaper.shape(&text[range.clone()], &font, TextDirection::Ltr)))
                .collect();
            let width = LayoutUnit::from_f32_ceil(shapes[0].width + shapes[1].width);
            let data = InlineItemsData {
                font_collection: openui_text::FontCollection::system(),
                text: text.into(),
                items: ranges
                    .into_iter()
                    .zip(shapes)
                    .map(|(range, shape)| InlineItem {
                        item_type: InlineItemType::Text,
                        text_range: range,
                        node_id: NodeId::NONE,
                        shape_result: Some(shape),
                        style_index: 0,
                        end_collapse_type: CollapseType::NotCollapsible,
                        is_end_collapsible_newline: false,
                        bidi_level: 0,
                        intrinsic_inline_size: None,
                    })
                    .collect(),
                styles: vec![ComputedStyle::default()],
                oof_children: Vec::new(),
                block_in_inline: Vec::new(),
            };
            let mut breaker = LineBreaker::new(&data, width);
            let first = breaker.next_line(width).expect("first logical line");
            assert_eq!(first.items.last().unwrap().text_range.end, first_end, "{text}");
            let second = breaker.next_line(width).expect("second logical line");
            assert_eq!(second.items.first().unwrap().text_range.start, second_start, "{text}");
            assert_eq!(second.items.last().unwrap().text_range.end, text.len(), "{text}");
            assert!(breaker.next_line(width).is_none(), "must make progress: {text}");
        }
    }
