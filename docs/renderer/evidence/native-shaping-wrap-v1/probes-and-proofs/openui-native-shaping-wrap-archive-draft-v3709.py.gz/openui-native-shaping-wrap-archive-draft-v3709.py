import gzip,hashlib,json,subprocess
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b')
DEST=ROOT/'docs/renderer/evidence/native-shaping-wrap-v1';INDEX=ROOT/'docs/renderer/generated/native-shaping-wrap-v1.json'
load=lambda p:json.loads(Path(p).read_bytes())
sha=lambda data:hashlib.sha256(data).hexdigest()
# Required completed proofs will be bound after actual terminal output.
matrix=load('/tmp/openui-native-shaping-wrap-renderer-completed-audit-v3699.json')
terminal=load('/tmp/openui-native-shaping-wrap-renderer-reaped-v3699.json')
clean=load('/tmp/openui-native-shaping-wrap-clean-terminal-v3701.json')
assert matrix['source']==clean['source']==terminal['source']
assert matrix['source']['clean'] and terminal['all_local_commands_terminal']
assert terminal['actual_audit_exit_code']==0
assert not DEST.exists() and not INDEX.exists()
DEST.mkdir(parents=True);members=[];excluded=[]
def add(data,relative):
 p=DEST/relative;compressed=not relative.endswith('.png')
 stored=gzip.compress(data,mtime=0) if compressed else data
 if compressed:p=p.with_name(p.name+'.gz')
 p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(stored)
 assert (gzip.decompress(stored) if compressed else stored)==data
 members.append(dict(path=str(p.relative_to(ROOT)),bytes=len(stored),sha256=sha(stored),raw_bytes=len(data),raw_sha256=sha(data),compression='gzip' if compressed else 'none'))
for scope,folder in [
 ('initial-build-failure','native-shaping-wrap-baseline-build-v3679'),
 ('baseline-build','native-shaping-wrap-baseline-build-v3682'),
 ('baseline-chromium','native-shaping-wrap-baseline-chromium-v3684'),
 ('baseline-guard','shaping-wrap-baseline-guard-v3688'),
 ('first-candidate-guard','shaping-wrap-candidate-layout-v3690'),
 ('candidate-guard','shaping-wrap-candidate-layout-v3691'),
 ('neighbor-compile-failure','shaping-wrap-candidate-layout-v3692'),
 ('neighbors','shaping-wrap-candidate-layout-v3693'),
 ('candidate-build','native-shaping-wrap-candidate-build-v3694'),
 ('candidate-chromium','native-shaping-wrap-candidate-chromium-v3696'),
 ('clean','native-shaping-wrap-clean-checks-v3700')]:
 d=BASE/folder;assert d.is_dir()
 for p in sorted(d.rglob('*')):
  if not p.is_file():continue
  if p.name=='native_shaping_wrap':
   excluded.append(dict(path=str(p),sha256=sha(p.read_bytes()),bytes=p.stat().st_size,reason='owned executable hash and compiler provenance retained; binary excluded from source archive'));continue
  add(p.read_bytes(),scope+'/'+str(p.relative_to(d)))
d=BASE/'native-shaping-wrap-renderer-v3698'
for name in ['receipt.json','guarded-build.log','focused.log','primitive.log','full.log','expanded.log']:
 add((d/name).read_bytes(),'renderer/'+name)
for suite in ['focused','primitive','full','expanded']:
 name=suite+'-summary.json';add((d/(suite+'-matrix')/name).read_bytes(),'renderer/'+name)
for p in sorted((d/'guarded-build').iterdir()):
 if p.is_file() and p.name!='pixel_compare':add(p.read_bytes(),'renderer/guarded-build/'+p.name)
proofs=[p for p in sorted(Path('/tmp').glob('openui*')) if p.is_file() and any(('v'+str(v)) in p.name for v in range(3677,3710)) and p.suffix in ['.py','.json','.cc','.rs','.txt']]
for p in proofs:add(p.read_bytes(),'probes-and-proofs/'+p.name)
add(Path('/tmp/openui_parallel_source_identity_v3060.py').read_bytes(),'probes-and-proofs/source-identity-reader.py')
add(subprocess.check_output(['git','diff','c4314f4f',matrix['source']['commit'],'--'],cwd=ROOT),'source/native-shaping-wrap.patch')
baseline=load('/tmp/openui-native-shaping-wrap-baseline-chromium-terminal-v3687.json')
candidate=load('/tmp/openui-native-shaping-wrap-candidate-chromium-terminal-v3697.json')
result=dict(schema_version=1,source=matrix['source'],baseline_native=baseline,candidate_native=candidate,clean_checks=clean,renderer=matrix['results'],candidate_nonregression=matrix['candidate_nonregression'],all_local_commands_terminal=True,all_members_hash_verified=True,pixel_target='pinned Chromium',pixel_tolerance=0,javascript_executed_by_openui=False,historical_openui_archive_is_a_pixel_target=False,all_native_apis_qualified=False,full_renderer_contract_qualified=False,release_qualified=False,archive=dict(files=len(members),bytes=sum(m['bytes'] for m in members),members=members,excluded=excluded))
INDEX.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(files=len(members),bytes=result['archive']['bytes'],index=str(INDEX))))
