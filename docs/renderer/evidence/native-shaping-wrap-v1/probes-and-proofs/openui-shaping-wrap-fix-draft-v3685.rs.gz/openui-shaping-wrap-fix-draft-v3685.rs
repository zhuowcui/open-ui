    /// A shaping boundary does not create a CSS line-break opportunity.
    /// When a continuation no longer fits, rewind the already accepted runs
    /// to the preceding break in the complete logical text. If this line
    /// contains only the overflowing logical unit, finish that unit instead.
    fn repair_shaping_boundary_wrap(&mut self, line: &mut LineInfo) {
        if line.has_forced_break || line.has_forced_hyphen {
            return;
        }
        let Some(last) = line.items.last() else {
            return;
        };
        if last.item_type != InlineItemType::Text {
            return;
        }
        let last_index = last.item_index;
        let first = &self.items_data.items[last_index];
        let Some(next) = self.items_data.items.get(self.current_item) else {
            return;
        };
        let resume = if self.current_text_offset > next.text_range.start {
            self.current_text_offset
        } else {
            next.text_range.start
        };
        if next.item_type != InlineItemType::Text
            || next.node_id != first.node_id
            || next.style_index != first.style_index
            || resume != last.text_range.end
        {
            return;
        }
        let style = &self.items_data.styles[first.style_index];
        if !allows_line_wrap(style.white_space)
            || !allows_line_wrap(self.container_white_space)
        {
            return;
        }
        let same_text = |a: &InlineItem, b: &InlineItem| {
            a.item_type == InlineItemType::Text
                && b.item_type == InlineItemType::Text
                && a.node_id == b.node_id
                && a.style_index == b.style_index
                && a.text_range.end == b.text_range.start
        };
        let mut begin = last_index;
        while begin > 0
            && same_text(
                &self.items_data.items[begin - 1],
                &self.items_data.items[begin],
            )
        {
            begin -= 1;
        }
        let mut end = self.current_item;
        while end + 1 < self.items_data.items.len()
            && same_text(
                &self.items_data.items[end],
                &self.items_data.items[end + 1],
            )
        {
            end += 1;
        }
        let logical_start = self.items_data.items[begin].text_range.start;
        let logical_end = self.items_data.items[end].text_range.end;
        let breaks: Vec<_> = find_break_opportunities(
            &self.items_data.text[logical_start..logical_end],
            style.word_break,
            style.overflow_wrap,
            style.line_break,
        )
        .into_iter()
        .map(|offset| logical_start + offset)
        .collect();
        if breaks.contains(&resume) || resume == logical_end {
            return;
        }
        let tail_start = line.items.iter().rev().take_while(|result| {
            result.item_type == InlineItemType::Text
                && result.item_index >= begin
                && result.item_index <= end
        }).last().map_or(resume, |result| result.text_range.start);
        let Some(cut) = breaks.iter().rev().copied().find(|&cut| {
            tail_start < cut && cut < resume
        }) else {
            let width = self.measure_text_range(self.current_item, resume, next.text_range.end);
            self.force_text_through_next_logical_break(
                self.current_item,
                resume,
                width,
                line,
                style,
            );
            return;
        };
        while line.items.last().is_some_and(|result| result.text_range.start >= cut) {
            let removed = line.items.pop().unwrap();
            line.used_width = line.used_width - removed.inline_size;
        }
        if let Some(last) = line.items.last_mut() {
            if last.text_range.end > cut {
                let width = self.measure_text_range(last.item_index, last.text_range.start, cut);
                line.used_width = line.used_width - last.inline_size + width;
                last.inline_size = width;
                last.text_range.end = cut;
            }
        }
        let resume_item = (begin..=end)
            .find(|&index| self.items_data.items[index].text_range.contains(&cut))
            .expect("soft break inside logical text");
        self.current_item = resume_item;
        self.current_text_offset = cut;
    }
