import fcntl,hashlib,json,os,subprocess,sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');OUT=Path('/mnt/d/openui-v02-qualification-d174ea0b/shaping-wrap-candidate-layout-v3692')
sys.path.insert(0,'/tmp')
from openui_parallel_source_identity_v3060 import identity
assert not OUT.exists();OUT.mkdir()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
source=identity(ROOT)
command=['cargo','--config',str(ROOT/'bindings/rust/.cargo/config.chromium.toml'),'test','--locked','--offline','-p','openui-layout','--lib']
env=dict(os.environ,CARGO_TARGET_DIR='/mnt/e/openui-v02-cargo-c73754e2/target',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='4',RUST_MIN_STACK='4194304',TMPDIR='/dev/shm',PYTHONDONTWRITEBYTECODE='1')
log=OUT/'guard.log'
with log.open('xb') as f:
 child=subprocess.Popen(command,cwd=ROOT/'bindings/rust',env=env,stdout=f,stderr=subprocess.STDOUT)
 code=child.wait()
text=log.read_text()
passed=code==0 and 'test result: ok.' in text
after=identity(ROOT);assert after==source
(OUT/'receipt.json').write_text(json.dumps({'schema_version':1,'source':source,'source_after':after,'source_unchanged':True,'all_commands_terminal':True,'command':command,'actual_test_exit_code':code,'tests_passed':passed,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'diagnostic_only':True,'renderer_qualified':False,'release_qualified':False},indent=2)+'\n')
print(json.dumps({'candidate_layout_actual_exit_code':code,'tests_passed':passed,'source_unchanged':True}))

sys.exit(0 if passed else 1)
