import hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');OUT=Path('/mnt/d/openui-v02-qualification-d174ea0b/native-shaping-wrap-candidate-chromium-v3696')
sys.path.insert(0,'/tmp')
from openui_parallel_source_identity_v3060 import identity

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(2**20),b''):h.update(b)
 return h.hexdigest()

r=json.loads((OUT/'receipt.json').read_bytes())
actual=int(sys.argv[1]);assert r['observed_exit_code']==actual
assert r['all_commands_terminal'] and r['source_unchanged'] and r['source']==r['source_after']==identity(ROOT)
assert subprocess.run(['ps','-p',str(r['owner_pid'])],capture_output=True).returncode==1
assert sha('/tmp/openui-native-shaping-wrap-candidate-chromium-v3696.py')==r['driver_sha256']
assert sha('/tmp/openui-native-shaping-wrap-candidate-terminal-v3695.json')==r['build_terminal_sha256']
assert sha('/mnt/d/openui-v02-qualification-d174ea0b/native-shaping-wrap-candidate-build-v3694/receipt.json')==r['build_receipt_sha256']
assert sha('/mnt/d/openui-v02-qualification-d174ea0b/native-shaping-wrap-candidate-build-v3694/native_shaping_wrap')==r['native_binary_sha256']
for step in r['steps']:
 assert step['actual_exit_code']==0,step
 assert subprocess.run(['ps','-p',str(step['pid'])],capture_output=True).returncode==1
assert len(r['cases'])==5
bounds=exact_bounds=images=exact_images=0
for i,c in enumerate(r['cases']):
 d=OUT/f'profile-{i}';assert sha(d/'test.html')==c['input_sha256']
 assert len(c['native_runs'])==2 and c['native_runs'][0]['files']==c['native_runs'][1]['files']
 for run in c['native_runs']:
  for p,h in run['files'].items():assert sha(Path(run['directory'])/p)==h
 for stage,s in c['stages'].items():
  native=json.loads((d/'native-1'/f'{stage}.json').read_bytes())
  oracle=json.loads((d/f'chromium-1-{stage}.json').read_bytes())
  assert native==s['native_bounds'] and oracle==s['chromium_bounds']
  assert oracle==json.loads((d/f'chromium-2-{stage}.json').read_bytes())
  assert len(native)==len(oracle)==7
  assert s['bounds_exact']==(native==oracle)
  for a,b in zip(native,oracle):assert a['name']==b['name'];bounds+=1;exact_bounds+=a==b
  assert sha(d/'native-1'/f'{stage}.png')==s['native_png_sha256']
  for repeat in [1,2]:
   for capture in [1,2]:assert sha(d/f'chromium-{repeat}-{stage}-capture-{capture}.png')==s['chromium_png_sha256']
  images+=1;exact_images+=s['analysis']['mismatched_pixels']==0
baseline=json.loads(Path('/mnt/d/openui-v02-qualification-d174ea0b/native-shaping-wrap-baseline-chromium-v3684/receipt.json').read_bytes())
for field in ['chromium_binary_sha256','chromium_version','capture_harness_sha256','fontconfig_sha256','ahem_font_sha256']:
 assert baseline[field]==r[field],field
improved=worsened=0
for old,new in zip(baseline['cases'],r['cases']):
 assert old['profile']==new['profile'] and old['input_sha256']==new['input_sha256']
 for stage in ['before','after']:
  a,b=old['stages'][stage],new['stages'][stage]
  assert a['chromium_png_sha256']==b['chromium_png_sha256'] and a['chromium_bounds']==b['chromium_bounds']
  improved+=b['analysis']['mismatched_pixels']<a['analysis']['mismatched_pixels']
  worsened+=b['analysis']['mismatched_pixels']>a['analysis']['mismatched_pixels']
assert bounds==70 and images==10
assert actual==int(exact_bounds!=bounds or exact_images!=images)
p=Path('/tmp/openui-native-shaping-wrap-candidate-chromium-terminal-v3697.json');assert not p.exists()
p.write_text(json.dumps({'schema_version':1,'source':r['source'],'actual_owner_exit_code':actual,'all_local_commands_terminal':True,'owner_absent':True,'receipt_sha256':sha(OUT/'receipt.json'),'audit_driver_sha256':sha(__file__),'images':images,'exact_images':exact_images,'bounds':bounds,'exact_bounds':exact_bounds,'reference_repeats_stable':True,'chromium_references_changed':0,'images_improved':improved,'images_worsened':worsened,'diagnostic_only':True,'pixel_target':'pinned Chromium','pixel_tolerance':0,'javascript_executed_by_openui':False,'renderer_qualified':False,'all_native_apis_qualified':False,'release_qualified':False,'retired_for_reexecution_after_source_or_target_mutation':True},indent=2)+'\n')
print(p)
