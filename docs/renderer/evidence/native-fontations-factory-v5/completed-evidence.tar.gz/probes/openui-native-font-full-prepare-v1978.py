import fcntl,json,os,shutil,subprocess
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');OLD=Path('/dev/shm/openui-native-shaped-intrinsic-v1966');ROOT=Path('/dev/shm/openui-native-font-full-v1978');HEAD='2fcdc66d6f626c70ee494d776eef9d7c23c41439'
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','ninja','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
assert not ROOT.exists() and not subprocess.check_output(['git','status','--porcelain'],cwd=OLD)
subprocess.run(['git','worktree','add','--no-checkout','--detach',str(ROOT),HEAD],cwd=MAIN,check=True,capture_output=True)
for encoded in subprocess.check_output(['git','ls-tree','-r','--name-only','-z',HEAD],cwd=MAIN).split(b'\0'):
 if not encoded:continue
 name=encoded.decode();p=ROOT/name;old=OLD/name;p.parent.mkdir(parents=True,exist_ok=True)
 if old.is_symlink():p.symlink_to(os.readlink(old))
 else:os.link(old,p)
subprocess.run(['git','read-tree',HEAD],cwd=ROOT,check=True,capture_output=True)
p=ROOT/'bindings/rust/openui-paint/tests/pixel_comparison_tests.rs';tmp=p.with_name(p.name+'.isolated-v1978');shutil.copy2(p,tmp);tmp.replace(p)
s=p.read_text().replace('Saves the output PNG to `tests/pixel_text/openui_renders/`.','Saves generated PNGs to the ignored `out/pixel_text/openui_renders/`.').replace('performs a pixel-by-pixel comparison with tolerance ±2 per channel.','requires an exact comparison of every RGBA channel.').replace('Number of pixels that differ beyond tolerance.','Number of pixels with any differing RGBA channel.').replace('Compare two RGBA images pixel-by-pixel with per-channel tolerance.','Compare every RGBA channel exactly, including alpha.')
s=s.replace('fn pixel_diff(a: &(u32, u32, Vec<u8>), b: &(u32, u32, Vec<u8>), tolerance: u8) -> PixelDiff {','fn pixel_diff(a: &(u32, u32, Vec<u8>), b: &(u32, u32, Vec<u8>)) -> PixelDiff {').replace('if d > tolerance {','if d != 0 {')
s=s.replace('    tolerance: u8,\n','').replace('for c in 0..3 {','for c in 0..4 {')
s=s.replace('.join("tests/pixel_text/openui_renders")','.join("out/pixel_text/openui_renders")').replace('const TOLERANCE: u8 = 2;\n','')
s=s.replace('pixel_diff(&our_pixels, &ref_pixels, TOLERANCE)','pixel_diff(&our_pixels, &ref_pixels)').replace('save_diff_image(&our_pixels, &ref_pixels, TOLERANCE, &dp)','save_diff_image(&our_pixels, &ref_pixels, &dp)')
s=s.replace('d.max_channel_diff <= TOLERANCE','d.max_channel_diff == 0').replace('tolerance {}','required 0').replace('tolerance: {}','required: 0').replace(',\n            TOLERANCE\n','\n')
assert 'TOLERANCE' not in s and 'tolerance' not in s, 'unhandled legacy tolerance wording'
p.write_text(s)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=OLD)
Path('/tmp/openui-native-font-full-prepare-v1978.json').write_text(json.dumps(dict(root=str(ROOT),base=HEAD,previous_source_preserved=True,all_mutable_paths_isolated=True,generated_diagnostics_outside_tracked_source=True,reference_bytes_changed=False,exact_rgba_required=True,release_qualification=False),indent=2)+'\n')
print('prepared strict text diagnostics on the full font candidate')
