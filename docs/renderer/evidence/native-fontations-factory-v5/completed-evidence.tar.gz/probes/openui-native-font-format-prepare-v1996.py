"""Prepare a separate formatter fix while the immutable raster run continues."""
import hashlib, json, os, shutil, subprocess, sys
from pathlib import Path

MAIN = Path('/home/nero/code/open-ui')
OLD = Path('/dev/shm/openui-native-rgba-font-v1989')
ROOT = Path('/dev/shm/openui-native-font-format-v1996')
HEAD = '02401648d6fecfb0d36c330635b1000b8ce2df39'
RAW = MAIN / 'out/renderer-evidence/native-viewport-scroll-v1'
owner = json.loads((RAW / 'native-rgba-font-pipeline-v1990/receipt.json').read_bytes())
assert not owner['all_commands_terminal'] and owner['current_process']['stage'] == 'full-matrix'
assert Path('/proc/' + str(owner['owner_pid'])).exists()
sys.path.insert(0, str(OLD / 'tools/qualification'))
from renderer_source_identity import repository_source_identity
before = repository_source_identity(OLD)
assert before == owner['source'] and before['clean'] and not ROOT.exists()
# No Cargo, build, native query, capture or raster process is started here.
# Only the new worktree's isolated copies are formatted.
subprocess.run(['git', 'worktree', 'add', '--no-checkout', '--detach', str(ROOT), HEAD], cwd=MAIN, check=True, capture_output=True)
for encoded in subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', '-z', HEAD], cwd=MAIN).split(b'\0'):
    if not encoded:
        continue
    name = encoded.decode()
    source, destination = OLD / name, ROOT / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    if source.is_symlink():
        destination.symlink_to(os.readlink(source))
    else:
        os.link(source, destination)
subprocess.run(['git', 'read-tree', HEAD], cwd=ROOT, check=True, capture_output=True)
package = ROOT / 'bindings/rust/openui-fontations'
for name in ['base.rs', 'hinting.rs']:
    path = package / 'src/ports/fontations/src' / name
    temporary = path.with_name(path.name + '.isolated-v1996')
    shutil.copy2(path, temporary)
    temporary.replace(path)
subprocess.run(['bash', '-c', 'ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true bindings/rust/openui-fontations/src/ports/fontations/src/base.rs bindings/rust/openui-fontations/src/ports/fontations/src/hinting.rs'], cwd=ROOT, check=True)
upstream = Path('/home/nero/.cargo/git/checkouts/rust-skia-b4d79b6a888cdb4c/a31b86b/skia-bindings/skia')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
files = {}
for name in ['base.rs', 'bitmap.rs', 'colr.rs', 'ffi.rs', 'hinting.rs', 'names.rs', 'verbs_points_pen.rs']:
    relative = 'src/ports/fontations/src/' + name
    files[relative] = dict(upstream_sha256=sha(upstream / relative), local_sha256=sha(package / relative))
    if name in ['base.rs', 'hinting.rs']:
        files[relative]['local_change'] = 'Rustfmt indentation or line wrapping only; upstream behavior and test assertions retained.'
    elif files[relative]['upstream_sha256'] != files[relative]['local_sha256']:
        files[relative]['local_change'] = 'Open UI factory bridge module registration.'
    else:
        files[relative]['local_change'] = 'None; exact upstream bytes.'
assert (package / 'src/ports/fontations/src/base.rs').read_text().split('#[cfg(test)]', 1)[1] == (upstream / 'src/ports/fontations/src/base.rs').read_text().split('#[cfg(test)]', 1)[1]
manifest = dict(schema_version=1, rust_skia_commit='a31b86ba3b767344d39af3b8c30043003d8fc991', skia_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=upstream, text=True).strip(), license_file='LICENSE-skia', files=files)
(package / 'vendor-fontations-rust-files.json').write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
assert repository_source_identity(OLD) == before
subprocess.run(['git', 'add', 'bindings/rust/openui-fontations/src/ports/fontations/src/base.rs', 'bindings/rust/openui-fontations/src/ports/fontations/src/hinting.rs', 'bindings/rust/openui-fontations/vendor-fontations-rust-files.json'], cwd=ROOT, check=True)
subprocess.run(['git', 'commit', '-m', 'Format pinned Fontations bridge sources and record their derivation'], cwd=ROOT, check=True, capture_output=True)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
report = dict(root=str(ROOT), base=HEAD, commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(), source_before=before, previous_raster_source_unchanged=repository_source_identity(OLD) == before, only_two_rustfmt_changes_and_provenance_added=True, upstream_test_assertions_unchanged=True, reference_bytes_changed=False, cargo_commands_run=0, raster_queries_run=0, release_qualification=False)
Path('/tmp/openui-native-font-format-prepare-v1996.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
print(json.dumps({k: report[k] for k in ['root', 'base', 'commit', 'previous_raster_source_unchanged', 'upstream_test_assertions_unchanged']}))
