import fcntl,hashlib,json,os,pathlib,shutil,subprocess
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','pixel_compare','ninja']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
raw=pathlib.Path('/home/nero/code/open-ui/out/renderer-evidence/native-viewport-scroll-v1/corner-coverage-clean-v100')
j=json.loads((raw/'pixel-build.json').read_text());assert j['source']==j['source_after'];assert j['pixel_build_exit_code']==0
build=json.loads((raw/'build.json').read_text());assert build['source']==build['source_after']==j['source'] and build['clean_exit_code']==build['native_build_exit_code']==0
p=raw/'pixel_compare';assert not p.is_symlink() and p.stat().st_dev==pathlib.Path('/home/nero').stat().st_dev
expected=j['pixel_binary_sha256']
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(2**20),b''): h.update(chunk)
 return h.hexdigest()
assert sha(p)==expected
for proc in pathlib.Path('/proc').iterdir():
 if proc.name.isdecimal():
  try:assert (proc/'exe').resolve()!=p.resolve()
  except (FileNotFoundError,PermissionError):pass
store=pathlib.Path('/mnt/e/openui-v02-qualification-d174ea0b/relocated-terminal-corner-binary-v1986');assert not store.exists();store.mkdir()
dest=store/p.name;shutil.copy2(p,dest);assert sha(dest)==expected and dest.stat().st_size==p.stat().st_size
size=p.stat().st_size;p.unlink();p.symlink_to(dest);assert sha(p)==expected
receipt=dict(all_commands_terminal=True,original_paths_preserved=True,reference_images_rewritten=0,files=[dict(original_path=str(p),relocated_path=str(dest),sha256=expected,bytes=size,unchanged=True)],probe_sha256=sha(pathlib.Path(__file__)))
pathlib.Path('/tmp/openui-verified-terminal-binary-relocation-v1986.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(dict(bytes_preserved=size,hash_verified=True,home_free=shutil.disk_usage('/home/nero').free)))
