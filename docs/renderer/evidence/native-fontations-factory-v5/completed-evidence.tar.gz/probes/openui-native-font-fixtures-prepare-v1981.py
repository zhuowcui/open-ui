import fcntl, hashlib, json, os, shutil, subprocess
from pathlib import Path

MAIN = Path('/home/nero/code/open-ui')
OLD = Path('/dev/shm/openui-native-font-full-v1978')
ROOT = Path('/dev/shm/openui-native-font-fixtures-v1981')
HEAD = '2dad9cd93d6d6f6d4e7b1b414df979ba09ebcec2'
SKIA = Path('/home/nero/.cargo/git/checkouts/rust-skia-b4d79b6a888cdb4c/a31b86b/skia-bindings/skia')
lock = open('/tmp/openui-native-cargo-raster-owner.lock', 'a+')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
for name in ['cargo', 'rustc', 'ninja', 'pixel_compare']:
    assert subprocess.run(['pgrep', '-x', name], capture_output=True).returncode == 1
assert not ROOT.exists() and not subprocess.check_output(['git', 'status', '--porcelain'], cwd=OLD)
subprocess.run(['git', 'worktree', 'add', '--no-checkout', '--detach', str(ROOT), HEAD], cwd=MAIN, check=True, capture_output=True)
for encoded in subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', '-z', HEAD], cwd=MAIN).split(b'\0'):
    if not encoded:
        continue
    name = encoded.decode()
    source, destination = OLD / name, ROOT / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    if source.is_symlink():
        destination.symlink_to(os.readlink(source))
    else:
        os.link(source, destination)
subprocess.run(['git', 'read-tree', HEAD], cwd=ROOT, check=True, capture_output=True)
package = ROOT / 'bindings/rust/openui-fontations'
files = {}
for name in ['test_glyphs-glyf_colr_1_variable.ttf', 'test.ttc', 'cond-bold-italic.ttf', 'Variable.ttf']:
    relative = 'resources/fonts/' + name
    source, destination = SKIA / relative, package / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    assert hashlib.sha256(destination.read_bytes()).hexdigest() == digest
    files[relative] = {'sha256': digest, 'bytes': source.stat().st_size}
manifest = {
    'schema_version': 1,
    'purpose': 'Unmodified upstream Fontations unit-test inputs; Cargo runs tests from this crate root.',
    'rust_skia_commit': 'a31b86ba3b767344d39af3b8c30043003d8fc991',
    'skia_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SKIA, text=True).strip(),
    'source': 'Pinned rust-skia skia-bindings/skia/resources/fonts',
    'license_file': 'LICENSE-skia',
    'files': files,
}
(package / 'test-font-fixtures.json').write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=OLD)
subprocess.run(['git', 'add', 'bindings/rust/openui-fontations/resources/fonts', 'bindings/rust/openui-fontations/test-font-fixtures.json'], cwd=ROOT, check=True)
subprocess.run(['git', 'commit', '-m', 'Include pinned Skia fonts required by Fontations unit tests'], cwd=ROOT, check=True, capture_output=True)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
report = dict(root=str(ROOT), base=HEAD, commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(), previous_source_preserved=True, upstream_tests_unchanged=True, production_sources_unchanged=True, fixture_manifest=manifest, release_qualification=False)
Path('/tmp/openui-native-font-fixtures-prepare-v1981.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
print(json.dumps({k: report[k] for k in ['root', 'base', 'commit', 'upstream_tests_unchanged', 'production_sources_unchanged']}))
