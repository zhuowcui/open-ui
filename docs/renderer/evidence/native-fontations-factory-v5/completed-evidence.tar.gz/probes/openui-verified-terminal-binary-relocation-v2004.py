"""Move one unused archived binary without touching the active raster pipeline."""
import fcntl, hashlib, json, os, shutil, subprocess, sys
from pathlib import Path

MAIN = Path('/home/nero/code/open-ui')
RAW = MAIN / 'out/renderer-evidence/native-viewport-scroll-v1'
owner_path = RAW / 'native-rgba-font-pipeline-v1990/receipt.json'
owner = json.loads(owner_path.read_bytes())
assert not owner['all_commands_terminal'] and owner['current_process']['stage'] == 'full-matrix'
os.kill(owner['owner_pid'], 0)
lock = open('/tmp/openui-native-cargo-raster-owner.lock', 'a+')
try:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
except BlockingIOError:
    pass
else:
    fcntl.flock(lock, fcntl.LOCK_UN)
    raise AssertionError('The active whole pipeline must retain exclusive ownership.')
root = Path('/dev/shm/openui-native-rgba-font-v1989')
sys.path.insert(0, str(root / 'tools/qualification'))
from renderer_source_identity import repository_source_identity
before = repository_source_identity(root)
assert before == owner['source']
old = RAW / 'legacy-context-clean-v95'
pixel = json.loads((old / 'pixel-build.json').read_bytes())
build = json.loads((old / 'build.json').read_bytes())
assert pixel['source'] == pixel['source_after'] == build['source'] == build['source_after']
assert pixel['pixel_build_exit_code'] == build['native_build_exit_code'] == build['clean_exit_code'] == 0
source = old / 'pixel_compare'
assert not source.is_symlink() and source.stat().st_dev == MAIN.stat().st_dev
def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(2**20), b''):
            h.update(chunk)
    return h.hexdigest()
expected = pixel['pixel_binary_sha256']
assert sha(source) == expected
for proc in Path('/proc').iterdir():
    if proc.name.isdecimal():
        try:
            assert (proc / 'exe').resolve() != source.resolve()
        except (FileNotFoundError, PermissionError):
            pass
store = Path('/mnt/e/openui-v02-qualification-d174ea0b/relocated-terminal-legacy-context-binary-v2004')
assert not store.exists()
store.mkdir()
destination = store / source.name
shutil.copy2(source, destination)
assert sha(destination) == expected and destination.stat().st_size == source.stat().st_size
size = source.stat().st_size
source.unlink()
source.symlink_to(destination)
assert sha(source) == expected and repository_source_identity(root) == before
report = dict(all_commands_terminal=True, original_paths_preserved=True,
              active_pipeline_source_unchanged=True, active_pipeline_lock_left_with_owner=True,
              cargo_or_native_queries_started=0, reference_images_rewritten=0,
              files=[dict(original_path=str(source), relocated_path=str(destination), bytes=size, sha256=expected, unchanged=True)],
              probe_sha256=sha(Path(__file__)))
Path('/tmp/openui-verified-terminal-binary-relocation-v2004.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
print(json.dumps(dict(bytes_preserved=size, hash_verified=True, active_source_unchanged=True, home_free=shutil.disk_usage(MAIN).free)))
