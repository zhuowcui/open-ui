import fcntl,gzip,hashlib,json,os,subprocess
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');ROOT=Path('/dev/shm/openui-native-rgba-font-v1989');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';NAME='native-rgba-font-source-repro-v1994'
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for p in ['cargo','rustc','ninja','pixel_compare']:assert subprocess.run(['pgrep','-x',p],capture_output=True).returncode==1
owner=json.loads((RAW/'native-rgba-font-pipeline-v1990/receipt.json').read_bytes());assert owner['all_commands_terminal'] and owner['source_unchanged']
OUT=RAW/NAME;STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/NAME;assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
base='9f0d22112136bc8b5325d0b0619031bdd8b9adcf';patch=subprocess.check_output(['git','diff','--binary',base,'HEAD'],cwd=ROOT);p=OUT/'source.patch';p.write_bytes(patch)
env=dict(os.environ,GIT_INDEX_FILE=str(STORE/'reproduction-index'))
logs=[]
for command in [['git','read-tree',base],['git','apply','--cached',str(p)],['git','write-tree']]:
 r=subprocess.run(command,cwd=ROOT,env=env,capture_output=True);logs.append(dict(command=command,observed_exit_code=r.returncode,stdout=r.stdout.decode(),stderr=r.stderr.decode()));assert r.returncode==0
expected=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=ROOT,text=True).strip();reconstructed=logs[-1]['stdout'].strip();assert reconstructed==expected
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
sha=lambda b:hashlib.sha256(b).hexdigest();receipt=dict(schema_version=1,all_commands_terminal=True,release_qualification=False,source=owner['source'],base_commit=base,target_commit=owner['source']['commit'],expected_tree=expected,reconstructed_tree=reconstructed,entire_tracked_tree_exact=True,patch_sha256=sha(patch),patch_bytes=len(patch),steps=logs,probe_sha256=sha(Path(__file__).read_bytes()))
(OUT/'receipt.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(entire_tracked_tree_exact=True,target_commit=receipt['target_commit'],patch_bytes=len(patch),receipt_sha256=sha((OUT/'receipt.json').read_bytes()))))
