import fcntl,hashlib,importlib.util,json,os,re,shutil,signal,subprocess,sys,time
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');ROOT=Path('/dev/shm/openui-native-font-fixtures-v1981');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';NAME='native-font-fixtures-pipeline-v1982'
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for program in ['cargo','rustc','pixel_compare','ninja']:assert subprocess.run(['pgrep','-x',program],capture_output=True).returncode==1
OUT=RAW/NAME;STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/NAME;assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
TMP=STORE/'compiler-tmp';TMP.mkdir();env=dict(os.environ,OPENUI_NATIVE_WHOLE_OWNER=NAME,CARGO_TARGET_DIR='/mnt/e/openui-v02-cargo-c73754e2/target',CARGO_INCREMENTAL='0',RUST_MIN_STACK='4194304',CARGO_BUILD_JOBS='4',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(TMP),CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
base=['cargo','--config','.cargo/config.chromium.toml']
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(2**20),b''):h.update(chunk)
 return h.hexdigest()
sys.path.insert(0,str(ROOT/'tools/qualification'));from renderer_source_identity import repository_source_identity
source=repository_source_identity(ROOT);assert source['clean'] and source['commit'].startswith('c44ead16')
tracked=ROOT/'tests/pixel_text/openui_renders/basic_text_openui.png';tracked_sha=sha(tracked)
ref_files=sorted(p for p in (ROOT/'tests/pixel_text/chromium_refs').rglob('*') if p.is_file());ref_sha={str(p.relative_to(ROOT)):sha(p) for p in ref_files}
report=dict(schema_version=1,source=source,all_commands_terminal=False,whole_pipeline_lock_covers_all_stages_and_gaps=True,owner_pid=os.getpid(),release_qualification=False,promotion_allowed=False,javascript_executed_by_openui=False,new_release_states_admitted=0,steps=[],matrices={},tracked_diagnostic_png_sha256=tracked_sha,legacy_reference_files=ref_sha,source_rewrites_allowed=False,probe_sha256=sha(Path(__file__)))
save=lambda:(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');save()
def run(name,command,cwd=ROOT/'bindings/rust',require_zero=True):
 log=OUT/(name+'.log')
 with log.open('xb') as stream:
  child=subprocess.Popen(command,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True);report['current_process']=dict(pid=child.pid,stage=name);save();guard=False
  while child.poll() is None:
   if shutil.disk_usage(MAIN).free<512*2**20 or shutil.disk_usage(STORE).free<10*2**30:
    guard=True;os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=20);break
   time.sleep(1)
  child.wait()
 report.pop('current_process');totals=[tuple(map(int,m)) for m in re.findall(rb'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',log.read_bytes())]
 row=dict(name=name,observed_exit_code=child.returncode,disk_guard_triggered=guard,log_sha256=sha(log),passed=sum(x[0] for x in totals),failed=sum(x[1] for x in totals),ignored=sum(x[2] for x in totals));report['steps'].append(row);save();print(json.dumps(row),flush=True)
 assert not guard
 assert repository_source_identity(ROOT)==source,'source changed during a committed stage'
 assert sha(tracked)==tracked_sha and all(sha(ROOT/p)==h for p,h in ref_sha.items()),'legacy source or reference bytes changed'
 if require_zero:assert child.returncode==0,name+' failed'
 return row
try:
 run('locked-metadata',base+['metadata','--offline','--locked','--no-deps','--format-version','1'])
 run('strict-comparison-format',['bash','-c','ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true --check bindings/rust/openui-paint/tests/pixel_comparison_tests.rs'],cwd=ROOT)
 run('dependency-policy',[sys.executable,'tools/release/generate_v02_contract.py','--check'],cwd=ROOT)
 metadata=json.loads(subprocess.check_output(base+['metadata','--offline','--locked','--no-deps','--format-version','1'],cwd=ROOT/'bindings/rust',env=env));members=set(metadata['workspace_members']);packages=[p['name'] for p in metadata['packages'] if p['id'] in members];assert len(packages)==19
 run('clean-workspace',base+['clean','--locked']+[a for package in packages for a in ['-p',package]])
 run('fontations-unit',base+['test','--offline','--locked','-p','openui-fontations','--lib'])
 run('workspace',base+['test','--offline','--locked','--workspace','--features','openui-ffi/linux'])
 content=(OUT/'workspace.log').read_bytes();assert b'test reference_comparison_rejects_single_bit_rgba_changes ... ok' in content
 report['strict_rgba_guard_actually_executed']=True;report['tracked_diagnostic_png_unchanged_through_workspace']=sha(tracked)==tracked_sha;save()
 run('ffi-build',base+['build','--offline','--locked','-p','openui-ffi','--features','linux'])
 lib=OUT/'libopenui_ffi.so';shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/libopenui_ffi.so',lib);soname=OUT/'libopenui.so.0';soname.symlink_to(lib.name);report['ffi_binary_sha256']=sha(lib);save()
 run('ffi-consumers',[sys.executable,str(ROOT/'tools/ffi/verify_abi.py'),'--library',str(lib)],cwd=ROOT)
 run('pixel-build',base+['build','--offline','--locked','-p','pixel-compare','--bin','pixel_compare'])
 pixel=OUT/'pixel_compare';shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/pixel_compare',pixel);report['pixel_binary_sha256']=sha(pixel);ident=json.loads(subprocess.check_output([str(pixel),'build-source-identity'],cwd=ROOT,env=env));assert ident['source']==source;report['build_identity']=ident;save()
 for suite in ['full','expanded']:
  result=OUT/(suite+'-matrix');result.mkdir()
  command=[sys.executable,str(ROOT/'tools/qualification/run_renderer_matrix.py'),'--suite',suite,'--results-dir',str(result),'--cache-dir','/mnt/e/openui-v02-qualification-d174ea0b/renderer-cache','--oracle-cache-dir','/home/nero/code/open-ui/out/renderer-qualification-cache/chromium-oracle','--pixel-compare',str(pixel),'--chrome',str(MAIN/'chrome/linux-147.0.7727.50/chrome-linux64/chrome'),'--raster-backend','cpu-skia','--jobs','8']
  stage=run(suite+'-matrix',command,cwd=ROOT,require_zero=False)
  summary=result/(suite+'-summary.json');s=json.loads(summary.read_bytes());assert s['source']==s['source_after']==source;assert s['results']['total']==(22924 if suite=='full' else 23728) and s['results']['errors']==0
  report['matrices'][suite]=dict(summary_sha256=sha(summary),results=s['results'],observed_exit_code=stage['observed_exit_code']);save();print(json.dumps(dict(suite=suite,results=s['results'],actual_exit=stage['observed_exit_code'])),flush=True)
 run('glyph-build',base+['build','--offline','--locked','-p','openui','--example','native_glyph_coverage'])
 binary=OUT/'native_glyph_coverage';shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/examples/native_glyph_coverage',binary);report['native_binary_sha256']=sha(binary);report['build_complete']=True;save()
 run('native-app',[sys.executable,'/tmp/openui-native-font-fixtures-consumer-v1982.py'],cwd=MAIN)
 for suite in ['focused','primitive']:
  result=OUT/(suite+'-matrix');result.mkdir()
  command=[sys.executable,str(ROOT/'tools/qualification/run_renderer_matrix.py'),'--suite',suite,'--results-dir',str(result),'--cache-dir','/mnt/e/openui-v02-qualification-d174ea0b/renderer-cache','--oracle-cache-dir','/home/nero/code/open-ui/out/renderer-qualification-cache/chromium-oracle','--pixel-compare',str(pixel),'--chrome',str(MAIN/'chrome/linux-147.0.7727.50/chrome-linux64/chrome'),'--raster-backend','cpu-skia','--jobs','4']
  stage=run(suite+'-matrix',command,cwd=ROOT)
  summary=result/(suite+'-summary.json');s=json.loads(summary.read_bytes());assert s['source']==s['source_after']==source
  report['matrices'][suite]=dict(summary_sha256=sha(summary),results=s['results'],observed_exit_code=stage['observed_exit_code']);save();print(json.dumps(dict(suite=suite,results=s['results'])),flush=True)
 report['observed_exit_code']=int(any(m['observed_exit_code'] for m in report['matrices'].values()))
except BaseException as error:
 report.update(observed_exit_code=1,failure=str(error));raise
finally:
 report['all_commands_terminal']=True;report['source_after']=repository_source_identity(ROOT);report['source_unchanged']=report['source_after']==source
 if not report['source_unchanged']:report.update(observed_exit_code=1,failure='source identity changed during pipeline')
 report['tracked_diagnostic_png_unchanged']=sha(tracked)==tracked_sha;save()
raise SystemExit(report['observed_exit_code'])
