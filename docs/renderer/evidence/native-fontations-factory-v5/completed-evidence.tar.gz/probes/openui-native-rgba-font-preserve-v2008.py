"""Preserve completed qualification records, failures and the formatted follow-up."""
import gzip, hashlib, json, subprocess, tarfile
from pathlib import Path

MAIN = Path('/home/nero/code/open-ui')
RAW = MAIN / 'out/renderer-evidence/native-viewport-scroll-v1'
ROOT = Path('/dev/shm/openui-native-rgba-font-v1989')
FOLLOW = Path('/dev/shm/openui-native-font-format-v1996')
NAME = 'native-fontations-factory-v5'
OUT = MAIN / 'docs/renderer/evidence' / NAME
INDEX = MAIN / 'docs/renderer/generated' / (NAME + '.json')
assert not OUT.exists() and not INDEX.exists()
load = lambda p: json.loads(p.read_bytes())
def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(2**20), b''):
            h.update(chunk)
    return h.hexdigest()

owner = load(RAW / 'native-rgba-font-pipeline-v1990/receipt.json')
assert owner['all_commands_terminal'] and owner['source_unchanged']
audit_path = RAW / 'native-rgba-font-audit-v1992.json'
audit = load(audit_path)
assert audit['source'] == owner['source'] and audit['observed_exit_code'] in [0, 1]
checks = load(RAW / 'native-rgba-font-checks-v1991/receipt.json')
follow_checks = load(RAW / 'native-font-format-checks-v1997/receipt.json')
assert checks['source'] == owner['source'] and all(r['observed_exit_code'] == 0 for r in checks['checks'])
assert follow_checks['source'] == follow_checks['source_after'] and all(r['observed_exit_code'] == 0 for r in follow_checks['checks'])
for root in [ROOT, FOLLOW]:
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)
OUT.mkdir(parents=True)
members = {}
def add(name, path):
    assert name not in members and path.is_file()
    members[name] = path

directories = ['native-font-full-pipeline-v1979', 'native-font-full-checks-v1980',
               'native-font-fixtures-pipeline-v1982', 'native-font-fixtures-checks-v1983',
               'native-font-fixtures-umbrella-hosted-v1984', 'native-rgba-font-pipeline-v1990',
               'native-rgba-font-consumer-v1990', 'native-rgba-font-checks-v1991',
               'native-rgba-font-source-repro-v1994', 'native-rgba-font-vendor-format-v1995',
               'native-font-format-checks-v1997', 'native-rgba-font-umbrella-checks-v1999',
               'native-font-format-source-repro-v2000', 'native-rgba-font-umbrella-hosted-v2002', 'native-rgba-font-archive-failed-v2003']
skip_names = {'native_glyph_coverage', 'pixel_compare', 'reproduction-index', 'libopenui_ffi.so', 'libopenui.so.0'}
for directory in directories:
    root = RAW / directory
    for child in sorted(root.iterdir()):
        if child.name == 'compiler-tmp' or child.name in skip_names:
            continue
        if child.name in ['full-matrix', 'expanded-matrix']:
            summary = child / (child.name.removesuffix('-matrix') + '-summary.json')
            add(str(Path(directory) / summary.relative_to(root)), summary)
            continue
        paths = [child] if child.is_file() else sorted(child.rglob('*'))
        for path in paths:
            if path.is_file() and path.name not in skip_names:
                add(str(Path(directory) / path.relative_to(root)), path)
probes = ['openui-native-font-full-prepare-v1978.py', 'openui-native-font-full-prepare-v1978.json',
          'openui-native-font-full-pipeline-v1979.py', 'openui-native-font-full-consumer-v1979.py',
          'openui-native-font-full-checks-v1980.py', 'openui-native-font-fixtures-prepare-v1981.py',
          'openui-native-font-fixtures-prepare-v1981.json', 'openui-native-font-fixtures-pipeline-v1982.py',
          'openui-native-font-fixtures-consumer-v1982.py', 'openui-native-font-fixtures-checks-v1983.py',
          'openui-native-font-fixtures-umbrella-hosted-collect-v1984.py',
          'openui-verified-terminal-binary-relocation-v1986.py', 'openui-verified-terminal-binary-relocation-v1986.json',
          'openui-native-rgba-font-prepare-v1987.py', 'openui-native-rgba-font-prepare-v1987-failed.json',
          'openui-native-rgba-font-prepare-v1989.py', 'openui-native-rgba-font-prepare-v1989.json',
          'openui-native-rgba-font-pipeline-v1990.py', 'openui-native-rgba-font-consumer-v1990.py',
          'openui-native-rgba-font-checks-v1991.py', 'openui-native-rgba-font-audit-v1992.py',
          'openui-native-rgba-font-fixture-proof-v1993.json', 'openui-native-rgba-font-source-repro-v1994.py',
          'openui-native-font-format-prepare-v1996.py', 'openui-native-font-format-prepare-v1996.json',
          'openui-native-font-format-checks-v1997.py', 'openui-native-rgba-font-umbrella-checks-v1999.py',
          'openui-native-font-format-source-repro-v2000.py', 'openui-native-rgba-font-umbrella-ci-current-v2001.json',
          'openui-native-rgba-font-umbrella-hosted-collect-v2002.py', 'openui-native-rgba-font-preserve-v2003.py',
          'openui-verified-terminal-binary-relocation-v2004.py', 'openui-verified-terminal-binary-relocation-v2004.json', 'openui-native-rgba-font-preserve-v2008.py']
for name in probes:
    add('probes/' + name, Path('/tmp') / name)
add('paired-audit.json', audit_path)
add('original-regression-audit.json', RAW / 'native-rgba-font-original-audit-v2005.json')
regression_path = RAW / 'native-rgba-font-regression-evidence-v2006.json'
add('regression-metrics.json', regression_path)
for row in load(regression_path)['comparisons']:
    directory = 'regressions/' + row['profile'] + '/' + row['id']
    for field, name in [('html_path', 'test.html'), ('native_path', 'candidate-openui.png'),
                        ('previous_native_path', 'accepted-openui.png'), ('chromium_path', 'chromium.png')]:
        add(directory + '/' + name, Path(row[field]))

for source_name, root in [('measured-source', ROOT), ('formatted-follow-up', FOLLOW)]:
    for relative in ['bindings/rust/openui-paint/tests/pixel_comparison_tests.rs',
                     'bindings/rust/openui-fontations/test-font-fixtures.json',
                     'bindings/rust/openui-fontations/vendor-fontations-rust-files.json']:
        path = root / relative
        if path.exists():
            add(source_name + '/' + relative, path)
patches = {}
for label, proof_name in [('measured', 'native-rgba-font-source-repro-v1994'), ('formatted', 'native-font-format-source-repro-v2000')]:
    proof = load(RAW / proof_name / 'receipt.json')
    assert proof['entire_tracked_tree_exact']
    path = RAW / proof_name / 'source.patch'
    assert sha(path) == proof['patch_sha256']
    compressed = OUT / (label + '-from-9f0d2211.patch.gz')
    with compressed.open('wb') as stream:
        with gzip.GzipFile(fileobj=stream, mode='wb', mtime=0) as gz:
            with path.open('rb') as source:
                while chunk := source.read(2**20):
                    gz.write(chunk)
    patches[label] = dict(path=str(compressed.relative_to(MAIN)), sha256=sha(compressed),
                          bytes=compressed.stat().st_size, reproduction=proof)
archive = OUT / 'completed-evidence.tar.gz'
records = []
with archive.open('wb') as file:
    with gzip.GzipFile(fileobj=file, mode='wb', mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w') as tar:
            for name, path in sorted(members.items()):
                record = dict(name=name, bytes=path.stat().st_size, sha256=sha(path), source_path=str(path))
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = record['bytes'], 0o644, 0
                with path.open('rb') as source:
                    tar.addfile(info, source)
                records.append(record)
with tarfile.open(archive, 'r:gz') as tar:
    entries = tar.getmembers()
    assert len(entries) == len(records)
    for entry, record in zip(entries, records):
        assert entry.name == record['name']
        h = hashlib.sha256()
        with tar.extractfile(entry) as source:
            for chunk in iter(lambda: source.read(2**20), b''):
                h.update(chunk)
        assert h.hexdigest() == record['sha256']
record = dict(schema_version=1, source=owner['source'], source_after=owner['source_after'],
              all_commands_terminal=True, release_qualification=False,
              candidate_applied_to_umbrella=False, promotion_allowed=False,
              new_release_states_admitted=0, javascript_executed_by_openui=False, pixel_tolerance=0,
              full_census_summaries_archived=True, full_census_individual_image_caches_not_duplicated=True,
              original_and_expanded_actual_exits=[owner['matrices'][s]['observed_exit_code'] for s in ['full', 'expanded']],
              formal_original_residual_ownership_unchanged=True, new_exact_regressions=6, changed_comparisons=14, new_regression_root_cause_review_pending=True,
              workspace_tests=next(s for s in owner['steps'] if s['name'] == 'workspace'),
              measured_source_read_only_checks_passed=len(checks['checks']),
              measured_source_required_vendor_format_check_failed=True,
              formatted_follow_up=dict(source=follow_checks['source'], read_only_checks_passed=len(follow_checks['checks']),
                                       runtime_and_renderer_qualification_not_run=True),
              native_totals=audit['native_totals'], native_rows_unchanged_from_2fcdc66d=True,
              suites={name: {k: v for k, v in row.items() if k != 'changed_comparisons'} for name, row in audit['suites'].items()},
              archive=dict(path=str(archive.relative_to(MAIN)), sha256=sha(archive), bytes=archive.stat().st_size,
                           all_members_hash_verified=True, members=records),
              reproduction_patches=patches, probe_sha256=sha(Path(__file__)))
INDEX.write_text(json.dumps(record, sort_keys=True, indent=2) + '\n')
print(json.dumps(dict(index=str(INDEX), index_sha256=sha(INDEX), archive_bytes=archive.stat().st_size,
                      archive_members=len(records), measured_source=owner['source']['commit'],
                      formatted_source=follow_checks['source']['commit'])), flush=True)
