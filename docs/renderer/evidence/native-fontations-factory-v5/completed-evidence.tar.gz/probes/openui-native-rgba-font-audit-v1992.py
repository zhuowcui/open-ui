"""Compare the complete clean candidate with accepted rows and native references."""
import hashlib, json, sys
from pathlib import Path

MAIN = Path('/home/nero/code/open-ui')
RAW = MAIN / 'out/renderer-evidence/native-viewport-scroll-v1'
OUT = RAW / 'native-rgba-font-audit-v1992.json'
assert not OUT.exists()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_bytes())
sys.path.insert(0, str(MAIN / 'tools/qualification'))
from residuals import canonical_sha256

owner_path = RAW / 'native-rgba-font-pipeline-v1990/receipt.json'
owner = load(owner_path)
assert owner['all_commands_terminal'] and owner['source_unchanged']
assert owner['source'] == owner['source_after'] and owner['source']['clean']
assert owner['strict_rgba_guard_actually_executed']
assert all(s['observed_exit_code'] == 0 for s in owner['steps'] if s['name'] not in ['full-matrix', 'expanded-matrix'])
report = dict(schema_version=1, source=owner['source'], all_commands_terminal=True,
              release_qualification=False, promotion_allowed=False, pixel_tolerance=0,
              javascript_executed_by_openui=False, new_release_states_admitted=0,
              whole_owner_receipt_sha256=sha(owner_path), suites={},
              formal_original_residual_ownership_unchanged=True, probe_sha256=sha(Path(__file__)))
invariants = ['openui_png_sha256', 'openui_rgba_sha256', 'chromium_png_sha256',
              'chromium_rgba_sha256', 'chromium_oracle_identity_sha256',
              'chromium_oracle_rgba_sha256', 'status', 'mismatched_pixels', 'diff_signature']
for suite, total in [('full', 22924), ('expanded', 23728), ('focused', 640), ('primitive', 960)]:
    current_path = owner_path.parent / (suite + '-matrix') / (suite + '-summary.json')
    old_path = RAW / ('native-event-targets-clean-' + suite + '-v1456') / (suite + '-summary.json')
    current, old = load(current_path), load(old_path)
    assert current['source'] == current['source_after'] == owner['source']
    assert current['results']['total'] == total and current['results']['errors'] == 0
    assert current['results']['profile_result_sha256'] == canonical_sha256([r['result_sha256'] for r in current['profiles']])
    for profile in current['profiles']:
        assert profile['result_sha256'] == canonical_sha256(profile['tests'])
    flatten = lambda d: {(p['profile'], r['id']): r for p in d['profiles'] for r in p['tests']}
    before, after = flatten(old), flatten(current)
    assert before.keys() == after.keys() and len(after) == total
    changes = []
    for key, row in after.items():
        previous = before[key]
        assert all(row[n] == previous[n] for n in invariants[2:6]), 'immutable Chromium input changed'
        changed = [n for n in invariants if row[n] != previous[n]]
        if changed:
            changes.append(dict(profile=key[0], id=key[1], changed_fields=changed,
                                prior_status=previous['status'], status=row['status'],
                                prior_mismatched_pixels=previous['mismatched_pixels'],
                                mismatched_pixels=row['mismatched_pixels'],
                                exact_loss=previous['status'] == 'exact' and row['status'] != 'exact',
                                exact_gain=previous['status'] != 'exact' and row['status'] == 'exact'))
    report['suites'][suite] = dict(results=current['results'],
                                  actual_exit=owner['matrices'][suite]['observed_exit_code'],
                                  summary_sha256=sha(current_path), prior_summary_sha256=sha(old_path),
                                  comparisons=total, immutable_chromium_rows=total,
                                  changed_comparisons=changes,
                                  exact_losses=sum(r['exact_loss'] for r in changes),
                                  exact_gains=sum(r['exact_gain'] for r in changes))
    del current, old, before, after

native_path = RAW / 'native-rgba-font-consumer-v1990/receipt.json'
previous_native_path = RAW / 'native-shaped-intrinsic-consumer-v1968/receipt.json'
native, previous_native = load(native_path), load(previous_native_path)
assert native['all_commands_terminal'] and native['observed_exit_code'] == 0
assert native['source'] == native['source_after'] == owner['source']
assert native['totals']['pixel_exact'] == 200 and native['totals']['geometry_exact'] == 12800
key = lambda r: (r['family'], r['size'], r['scale'])
previous = {key(r): r for r in previous_native['cases']}
assert len(previous) == len(native['cases']) == 100
for row in native['cases']:
    for image, old_image in zip(row['images'], previous[key(row)]['images']):
        for field in ['state', 'native_png_sha256', 'chromium_png_sha256', 'independent_reference_runs', 'phases']:
            assert image[field] == old_image[field], 'native pixels, geometry or oracle changed'
report.update(native_gate_actual_exit=0, native_totals=native['totals'],
              native_rows_unchanged_from_2fcdc66d=True,
              native_receipt_sha256=sha(native_path), prior_native_receipt_sha256=sha(previous_native_path),
              observed_exit_code=int(any(s['exact_losses'] for s in report['suites'].values())))
OUT.write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
print(json.dumps(dict(receipt_sha256=sha(OUT), native_totals=report['native_totals'],
                      suites={name: {k: row[k] for k in ['comparisons', 'results', 'exact_losses', 'exact_gains']} for name, row in report['suites'].items()})), flush=True)
raise SystemExit(report['observed_exit_code'])
