import fcntl, json, os, shutil, subprocess
from pathlib import Path

MAIN = Path('/home/nero/code/open-ui')
OLD = Path('/dev/shm/openui-native-font-fixtures-v1981')
ROOT = Path('/dev/shm/openui-native-rgba-font-v1987')
HEAD = 'c44ead16502a141488b6805618f4235ec548b108'
lock = open('/tmp/openui-native-cargo-raster-owner.lock', 'a+')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
for name in ['cargo', 'rustc', 'ninja', 'pixel_compare']:
    assert subprocess.run(['pgrep', '-x', name], capture_output=True).returncode == 1
assert not ROOT.exists() and not subprocess.check_output(['git', 'status', '--porcelain'], cwd=OLD)
subprocess.run(['git', 'worktree', 'add', '--no-checkout', '--detach', str(ROOT), HEAD], cwd=MAIN, check=True, capture_output=True)
for encoded in subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', '-z', HEAD], cwd=MAIN).split(b'\0'):
    if not encoded:
        continue
    name = encoded.decode()
    source, destination = OLD / name, ROOT / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    if source.is_symlink():
        destination.symlink_to(os.readlink(source))
    else:
        os.link(source, destination)
subprocess.run(['git', 'read-tree', HEAD], cwd=ROOT, check=True, capture_output=True)
path = ROOT / 'bindings/rust/openui-paint/tests/pixel_comparison_tests.rs'
temporary = path.with_name(path.name + '.isolated-v1987')
shutil.copy2(path, temporary)
temporary.replace(path)
text = path.read_text()
old = '''    let info = image.image_info();
    let w = info.width() as u32;
    let h = info.height() as u32;
    let row_bytes = (w * 4) as usize;
    let mut pixels = vec![0u8; (h as usize) * row_bytes];
    image.read_pixels(
        &info,
        &mut pixels,
        row_bytes,
        (0, 0),
        skia_safe::image::CachingHint::Allow,
    );'''
new = '''    let w = image.width() as u32;
    let h = image.height() as u32;
    // PNG comparisons require RGBA with straight alpha, regardless of the
    // platform's native N32 channel order or surface premultiplication.
    let info = skia_safe::ImageInfo::new(
        (w as i32, h as i32),
        skia_safe::ColorType::RGBA8888,
        skia_safe::AlphaType::Unpremul,
        None,
    );
    let row_bytes = (w * 4) as usize;
    let mut pixels = vec![0u8; (h as usize) * row_bytes];
    assert!(image.read_pixels(
        &info,
        &mut pixels,
        row_bytes,
        (0, 0),
        skia_safe::image::CachingHint::Allow,
    ));'''
assert text.count(old) == 1
text = text.replace(old, new)
marker = '#[test]\nfn reference_comparison_rejects_single_bit_rgba_changes()'
guard = '''#[test]
fn surface_comparison_preserves_rgba_order_and_straight_alpha() {
    let mut surface = skia_safe::surfaces::raster_n32_premul((1, 1)).unwrap();
    surface.canvas().clear(skia_safe::Color::from_argb(255, 13, 77, 199));
    assert_eq!(surface_to_rgba(&mut surface), (1, 1, vec![13, 77, 199, 255]));
    surface.canvas().clear(skia_safe::Color::from_argb(128, 255, 0, 0));
    assert_eq!(surface_to_rgba(&mut surface), (1, 1, vec![255, 0, 0, 128]));
}

'''
assert text.count(marker) == 1
path.write_text(text.replace(marker, guard + marker))
subprocess.run(['bash', '-c', 'ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true bindings/rust/openui-paint/tests/pixel_comparison_tests.rs'], cwd=ROOT, check=True)
# Test diagnostics use the large disk; this ignored directory is not source.
diagnostics = Path('/mnt/e/openui-v02-qualification-d174ea0b/native-rgba-font-diagnostics-v1987')
assert not diagnostics.exists()
diagnostics.mkdir()
(ROOT / 'out').symlink_to(diagnostics, target_is_directory=True)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=OLD)
subprocess.run(['git', 'add', 'bindings/rust/openui-paint/tests/pixel_comparison_tests.rs'], cwd=ROOT, check=True)
subprocess.run(['git', 'commit', '-m', 'Read exact text comparisons in PNG RGBA channel and alpha format'], cwd=ROOT, check=True, capture_output=True)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
report = dict(root=str(ROOT), base=HEAD, commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(), previous_source_preserved=True, production_sources_unchanged=True, native_n32_comparison_format_corrected=True, reference_bytes_changed=False, generated_diagnostics_on_large_disk=True, release_qualification=False)
Path('/tmp/openui-native-rgba-font-prepare-v1987.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
print(json.dumps(report))
