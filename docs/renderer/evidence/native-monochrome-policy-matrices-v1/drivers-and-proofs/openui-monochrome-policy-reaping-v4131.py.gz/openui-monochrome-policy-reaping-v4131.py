import fcntl, hashlib, json, subprocess, sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui')
OUT=Path('/mnt/d/openui-v02-qualification-d174ea0b/native-monochrome-policy-matrices-v4129')
AUDIT=Path('/tmp/openui-monochrome-policy-audit-v4130.json')
DEST=Path('/tmp/openui-monochrome-policy-reaped-v4131.json')
load=lambda path:json.loads(Path(path).read_bytes())
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
r=load(OUT/'receipt.json');a=load(AUDIT)
assert r['all_commands_terminal'] and a['complete'] and a['owner_absent']
assert r['observed_exit_code']==a['actual_owner_exit_code']==int(sys.argv[1])
assert int(sys.argv[2])==0 and r['source']==r['source_after']==a['source']
assert sha(OUT/'receipt.json')==a['receipt_sha256']
assert subprocess.run(['ps','-p',str(r['owner_pid'])],capture_output=True).returncode==1
for name in ['cargo','rustc','rustfmt','pixel_compare']:
 assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
sys.path.insert(0,'/tmp');from openui_parallel_source_identity_v3060 import identity
assert identity(ROOT)==r['source'] and not DEST.exists()
proof=dict(schema_version=1,source=r['source'],all_local_commands_terminal=True,owners_absent=True,
 actual_owner_exit_code=int(sys.argv[1]),actual_audit_exit_code=int(sys.argv[2]),
 actual_sessions=[dict(session=int(sys.argv[4]),actual_exit_code=int(sys.argv[1]),reaped=True),
                  dict(session=int(sys.argv[3]),actual_exit_code=int(sys.argv[2]),reaped=True)],
 receipt_sha256=sha(OUT/'receipt.json'),completed_audit_sha256=sha(AUDIT),
 results=a['results'],matrix_rows_verified=a['matrix_rows_verified'],comparisons=a['comparisons'],
 renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,
 retired_for_reexecution_after_source_or_target_mutation=True)
DEST.write_text(json.dumps(proof,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(proof=str(DEST),rows=proof['matrix_rows_verified'],results=proof['results'])),flush=True)
