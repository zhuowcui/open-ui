import hashlib, json, subprocess, sys
from pathlib import Path
from PIL import Image

ROOT = Path('/home/nero/code/open-ui')
OUT = Path('/mnt/d/openui-v02-qualification-d174ea0b/native-monochrome-policy-matrices-v4129')
PROOF = Path('/tmp/openui-monochrome-policy-audit-v4130.json')
assert not PROOF.exists()
sys.path.insert(0, str(ROOT / 'tools/qualification'))
from renderer_source_identity import repository_source_identity
from residuals import canonical_sha256, analyze_image_difference
from build_renderer import verify_build_receipt

load = lambda path: json.loads(Path(path).read_bytes())
def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(2**20), b''):
            digest.update(chunk)
    return digest.hexdigest()

r = load(OUT / 'receipt.json')
assert r['all_commands_terminal'] and r['source_unchanged'] and 'failure' not in r
assert r['source'] == r['source_after'] == repository_source_identity(ROOT)
assert r['source']['clean']
assert subprocess.run(['ps', '-p', str(r['owner_pid'])], capture_output=True).returncode == 1
assert sha('/tmp/openui-monochrome-policy-matrices-v4129.py') == r['driver_sha256']
assert sha(OUT / 'selected-ids.json') == r['selected_ids_sha256']
assert load(OUT / 'selected-ids.json') == r['selected_ids']
assert sha('/tmp/openui-fitted-monochrome-guards-reaped-v4110.json') == r['prior_reaping_sha256']
assert sha('/mnt/d/openui-v02-qualification-d174ea0b/native-strict-intrinsic-ceil-clean-full-v4012/receipt.json') == r['previous_full_receipt_sha256']
for step in r['steps']:
    assert sha(OUT / (step['name'] + '.log')) == step['log_sha256']
build_path = OUT / 'guarded-build/receipt.json'
build = load(build_path)
assert sha(build_path) == r['guarded_build_receipt_sha256']
verify_build_receipt(build, Path(build['binary']), r['source'])
assert json.loads(subprocess.check_output([build['binary'], 'build-source-identity']))['source'] == r['source']
for step in build['steps']:
    assert step['observed_exit_code'] == 0
    for channel in ['stdout', 'stderr']:
        assert sha(build_path.parent / (step['name'] + '.' + channel)) == step[channel + '_sha256']
for path, digest in build['compiled_artifact_sha256'].items():
    assert sha(path) == digest
records = sum(len(rows) for rows in build['artifacts'].values())
for rows in build['artifacts'].values():
    for row in rows:
        assert row['fresh'] is False
        assert Path(row['manifest_path']).resolve().is_relative_to(ROOT)
        assert Path(row['target']['src_path']).resolve().is_relative_to(ROOT)
results = {}; total = 0; verified_png = {}; verified_differences = {}
for name, row in r['matrices'].items():
    path = OUT / name / (row['suite'] + '-summary.json')
    summary = load(path)
    assert sha(path) == row['summary_sha256']
    assert summary['source'] == summary['source_after'] == r['source']
    assert summary['selection']['complete_profile_set']
    assert summary['selection']['complete_id_set'] == (not row['selected'])
    assert summary['selection']['monochrome_raster_config'] == ('chromium-linux-monochrome' if row['candidate'] else None)
    assert summary['evidence']['qualification_policy_match'] == (not row['candidate'])
    assert summary['complete_contract_scope'] == (not row['selected'] and not row['candidate'])
    assert not row['candidate'] or not summary['evidence']['qualified']
    exact = different = errors = count = 0
    for profile in summary['profiles']:
        assert profile['result_sha256'] == canonical_sha256(profile['tests'])
        if row['selected']:
            assert [case['id'] for case in profile['tests']] == r['selected_ids']
        for case in profile['tests']:
            count += 1; exact += case['status'] == 'exact'; different += case['status'] == 'different'; errors += case['status'] == 'error'
            assert case['status'] == ('different' if case['mismatched_pixels'] else 'exact')
            assert case['chromium_rgba_sha256'] == case['chromium_oracle_rgba_sha256']
            assert case['diff_signature']['mismatched_pixels'] == case['mismatched_pixels']
            for origin in ['openui', 'chromium']:
                picture = str(OUT.parent / 'native-monochrome-policy-cache-v4129' / case[origin + '_png_cache_path'])
                expected = (case[origin + '_png_sha256'], case[origin + '_rgba_sha256'])
                if picture not in verified_png:
                    with Image.open(picture) as image:
                        rgba = hashlib.sha256(image.convert('RGBA').tobytes()).hexdigest()
                        assert list(image.size) == profile['physical_size_px']
                    verified_png[picture] = (sha(picture), rgba)
                assert verified_png[picture] == expected
            pair = tuple(str(OUT.parent / 'native-monochrome-policy-cache-v4129' / case[origin + '_png_cache_path']) for origin in ['chromium', 'openui'])
            if pair not in verified_differences:
                verified_differences[pair] = analyze_image_difference(Path(pair[0]), Path(pair[1]))
            assert verified_differences[pair] == case['diff_signature']
    assert count == (84 if row['selected'] else {'focused':640,'primitive':960}[row['suite']])
    assert summary['results']['total'] == count
    assert summary['results']['exact'] == exact and summary['results']['different'] == different
    assert summary['results']['errors'] == errors == 0
    assert row['results'] == summary['results']
    step = next(step for step in r['steps'] if step['name'] == name)
    assert step['observed_exit_code'] == row['actual_exit_code']
    results[name] = dict(total=count, exact=exact, different=different, errors=errors,
                         actual_exit_code=row['actual_exit_code'], qualified=summary['evidence']['qualified'])
    total += count
    if row['candidate']:
        baseline = load(OUT / name.replace('-fitted', '-auto') / (row['suite'] + '-summary.json'))
        old = {(profile['profile'],case['id']):case for profile in baseline['profiles'] for case in profile['tests']}
        gains = losses = worsened = changed = compared = 0
        for profile in summary['profiles']:
            for case in profile['tests']:
                before = old.pop((profile['profile'],case['id'])); compared += 1
                for field in ['chromium_png_sha256','chromium_rgba_sha256','chromium_oracle_identity_sha256','chromium_oracle_rgba_sha256','font_profile']:
                    assert before[field] == case[field]
                if case['font_profile'] == 'registered-ahem':
                    assert case['raster_configuration'] == 'cpu-skia:chromium-linux-monochrome'
                else:
                    assert case['raster_configuration'] == before['raster_configuration']
                    assert case['openui_rgba_sha256'] == before['openui_rgba_sha256']
                gains += before['status'] != 'exact' and case['status'] == 'exact'
                losses += before['status'] == 'exact' and case['status'] != 'exact'
                worsened += case['mismatched_pixels'] > before['mismatched_pixels']
                changed += case['openui_rgba_sha256'] != before['openui_rgba_sha256']
        comparison = r['comparisons'][name]
        assert not old and comparison['audited_rows'] == compared
        assert (comparison['exact_gains'],comparison['exact_losses'],comparison['worsened'],len(comparison['changes'])) == (gains,losses,worsened,changed)
assert len(results) == 6 and total == 3368
assert r['observed_exit_code'] == int(any(row['different'] for row in results.values()))
proof = dict(schema_version=1,complete=True,owner_absent=True,owner_terminal=True,
             actual_owner_exit_code=r['observed_exit_code'],source=r['source'],
             receipt_sha256=sha(OUT / 'receipt.json'),audit_driver_sha256=sha(__file__),
             fresh_compiler_records=records,compiled_paths_verified=len(build['compiled_artifact_sha256']),
             matrix_rows_verified=total,png_files_verified=len(verified_png),
             chromium_reference_changes=0,results=results,comparisons=r['comparisons'],
             renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,
             retired_for_reexecution_after_source_or_target_mutation=True)
PROOF.write_text(json.dumps(proof,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(proof=str(PROOF),rows=total,png_files=len(verified_png),results=results)),flush=True)
