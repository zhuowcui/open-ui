import fcntl, hashlib, json, os, shutil, signal, subprocess, sys, time
from pathlib import Path

ROOT = Path('/home/nero/code/open-ui')
BASE = Path('/mnt/d/openui-v02-qualification-d174ea0b')
OUT = BASE / 'native-monochrome-policy-matrices-v4129'
TARGET = Path('/mnt/e/openui-v02-cargo-c73754e2/target')
CACHE = BASE / 'native-monochrome-policy-cache-v4129'
POOL = Path('/mnt/e/openui-v02-qualification-d174ea0b/renderer-cache/png')
TEMP = Path('/dev/shm/ou4129')
PREVIOUS = BASE / 'native-strict-intrinsic-ceil-clean-full-v4012/receipt.json'
sys.path.insert(0, '/tmp')
sys.path.insert(0, str(ROOT / 'tools/qualification'))
from openui_parallel_source_identity_v3060 import identity
from residuals import canonical_sha256

def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(2**20), b''):
            digest.update(chunk)
    return digest.hexdigest()

load = lambda path: json.loads(Path(path).read_bytes())
lock = open('/tmp/openui-native-cargo-raster-owner.lock', 'a+')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
for name in ['cargo', 'rustc', 'rustfmt', 'pixel_compare']:
    assert subprocess.run(['pgrep', '-x', name], capture_output=True).returncode == 1
prior_reaping = Path('/tmp/openui-fitted-monochrome-guards-reaped-v4110.json')
assert load(prior_reaping)['all_local_commands_terminal']
assert load(prior_reaping)['owners_absent']
source = identity(ROOT)
assert source['clean'] and source['commit'] == sys.argv[1]
for path in [OUT, CACHE, TEMP]:
    assert not path.exists(), str(path)
    path.mkdir()
assert POOL.is_dir()
(CACHE / 'png').symlink_to(POOL, target_is_directory=True)
selected_ids = sorted({row['id'] for row in load(PREVIOUS)['comparisons']['full']['changes']})
assert len(selected_ids) == 21
(OUT / 'selected-ids.json').write_text(json.dumps(selected_ids, indent=2) + '\n')
env = dict(os.environ, CARGO_TARGET_DIR=str(TARGET), CARGO_PROFILE_DEV_DEBUG='0',
           CARGO_PROFILE_TEST_DEBUG='0', CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='4',
           RUST_MIN_STACK='4194304', PYTHONDONTWRITEBYTECODE='1', TMPDIR=str(TEMP))
env.pop('LD_PRELOAD', None); env.pop('LD_LIBRARY_PATH', None)
report = dict(schema_version=1, owner_pid=os.getpid(), source=source,
              driver_sha256=sha(__file__), prior_reaping_sha256=sha(prior_reaping),
              selected_ids=selected_ids, selected_ids_sha256=sha(OUT / 'selected-ids.json'),
              selection_reason='all original case IDs changed by the preceding strict-ceil census',
              previous_full_receipt_sha256=sha(PREVIOUS), steps=[], matrices={}, comparisons={},
              all_commands_terminal=False, pixel_target='pinned Chromium', pixel_tolerance=0,
              javascript_executed_by_openui=False, renderer_qualified=False,
              all_native_apis_qualified=False, release_qualified=False)

def save():
    tmp = OUT / 'receipt.tmp'
    tmp.write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
    os.replace(tmp, OUT / 'receipt.json')

def sweep():
    live = []
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():
            continue
        try:
            live.append((proc / 'cmdline').read_bytes())
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
    for path in TEMP.glob('openui-chrome-profile-*'):
        if path.is_dir() and not path.is_symlink() and time.time() - path.stat().st_mtime > 20:
            if not any(str(path).encode() in command for command in live):
                shutil.rmtree(path)
    sockets = [line.split(maxsplit=7)[-1] for line in Path('/proc/net/unix').read_text().splitlines()[1:]
               if len(line.split(maxsplit=7)) == 8]
    for path in TEMP.glob('org.chromium.Chromium.*'):
        if path.is_dir() and not path.is_symlink() and time.time() - path.stat().st_mtime > 30:
            if any(socket.startswith(str(path) + '/') for socket in sockets):
                continue
            children = list(path.iterdir())
            if all(child.is_symlink() or child.is_socket() for child in children):
                for child in children:
                    child.unlink()
                path.rmdir()

def run(name, command, allowed=(0,)):
    assert identity(ROOT) == source
    print('Starting ' + name, flush=True)
    log = OUT / (name + '.log')
    with log.open('xb') as stream:
        child = subprocess.Popen(command, cwd=ROOT, env=env, stdout=stream,
                                 stderr=subprocess.STDOUT, start_new_session=True)
        report['current_process'] = dict(pid=child.pid, stage=name); save()
        try:
            while child.poll() is None:
                sweep()
                if (shutil.disk_usage(ROOT).free < 128 * 2**20
                        or shutil.disk_usage(OUT).free < 10 * 2**30
                        or shutil.disk_usage(TARGET).free < 10 * 2**30
                        or shutil.disk_usage(TEMP).free < 256 * 2**20):
                    report['disk_guard_triggered'] = True
                    os.killpg(child.pid, signal.SIGTERM)
                    break
                time.sleep(1)
            code = child.wait(timeout=20)
        except BaseException:
            if child.poll() is None:
                os.killpg(child.pid, signal.SIGTERM)
                try:
                    child.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL); child.wait()
            raise
        finally:
            report.pop('current_process', None)
            report['steps'].append(dict(name=name, command=command,
                                        observed_exit_code=child.returncode, log_sha256=sha(log)))
            save()
    assert code in allowed, (name, code)
    assert identity(ROOT) == source
    print(json.dumps(dict(stage=name, actual_exit_code=code)), flush=True)
    return code

save()
try:
    fcntl.flock(lock, fcntl.LOCK_UN)
    build_dir = OUT / 'guarded-build'
    run('guarded-build', [sys.executable, str(ROOT / 'tools/qualification/build_renderer.py'),
                         '--source-root', str(ROOT), '--results-dir', str(build_dir),
                         '--target-dir', str(TARGET), '--cargo-config',
                         str(ROOT / 'bindings/rust/.cargo/config.chromium.toml'), '--offline'])
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    build = load(build_dir / 'receipt.json')
    assert build['all_commands_terminal'] and build['observed_exit_code'] == 0
    assert build['renderer_library_provenance_verified']
    assert build['source'] == build['source_after'] == source
    report['guarded_build_receipt_sha256'] = sha(build_dir / 'receipt.json'); save()
    for name, suite, candidate, selected in [
        ('selected-auto', 'full', False, True),
        ('selected-fitted', 'full', True, True),
        ('focused-auto', 'focused', False, False),
        ('focused-fitted', 'focused', True, False),
        ('primitive-auto', 'primitive', False, False),
        ('primitive-fitted', 'primitive', True, False),
    ]:
        path = OUT / name
        command = [sys.executable, str(ROOT / 'tools/qualification/run_renderer_matrix.py'),
                   '--suite', suite, '--results-dir', str(path), '--cache-dir', str(CACHE),
                   '--oracle-cache-dir', str(ROOT / 'out/renderer-qualification-cache/chromium-oracle'),
                   '--pixel-compare', build['binary'], '--build-receipt', str(build_dir / 'receipt.json'),
                   '--chrome', str(ROOT / 'chrome/linux-147.0.7727.50/chrome-linux64/chrome'),
                   '--raster-backend', 'cpu-skia', '--jobs', '4']
        if candidate:
            command.extend(['--monochrome-raster-config', 'chromium-linux-monochrome'])
        if selected:
            for test_id in selected_ids:
                command.extend(['--test-id', test_id])
        code = run(name, command, allowed=(0, 1))
        summary_path = path / (suite + '-summary.json')
        summary = load(summary_path)
        assert summary['source'] == summary['source_after'] == source
        assert summary['results']['errors'] == 0
        assert summary['selection']['complete_profile_set']
        assert summary['selection']['complete_id_set'] == (not selected)
        assert summary['selection']['monochrome_raster_config'] == ('chromium-linux-monochrome' if candidate else None)
        assert summary['evidence']['qualification_policy_match'] == (not candidate)
        assert summary['complete_contract_scope'] == (not selected and not candidate)
        assert not candidate or not summary['evidence']['qualified']
        report['matrices'][name] = dict(suite=suite, candidate=candidate, selected=selected,
             summary_sha256=sha(summary_path), results=summary['results'], actual_exit_code=code,
             complete_contract_scope=summary['complete_contract_scope'], qualified=summary['evidence']['qualified'])
        if candidate:
            baseline = load(OUT / name.replace('-fitted', '-auto') / (suite + '-summary.json'))
            old = {(p['profile'], t['id']):t for p in baseline['profiles'] for t in p['tests']}
            changes = []; gains = losses = worsened = checked = 0
            for profile in summary['profiles']:
                for row in profile['tests']:
                    before = old.pop((profile['profile'], row['id'])); checked += 1
                    for field in ['chromium_png_sha256', 'chromium_rgba_sha256', 'chromium_oracle_identity_sha256', 'chromium_oracle_rgba_sha256', 'font_profile']:
                        assert before[field] == row[field], field
                    gains += before['status'] != 'exact' and row['status'] == 'exact'
                    losses += before['status'] == 'exact' and row['status'] != 'exact'
                    worsened += row['mismatched_pixels'] > before['mismatched_pixels']
                    if before['openui_rgba_sha256'] != row['openui_rgba_sha256']:
                        changes.append(dict(profile=profile['profile'], id=row['id'],
                            before_status=before['status'], after_status=row['status'],
                            before_mismatched_pixels=before['mismatched_pixels'], after_mismatched_pixels=row['mismatched_pixels']))
            assert not old
            report['comparisons'][name] = dict(audited_rows=checked, exact_gains=gains,
                exact_losses=losses, worsened=worsened, changes=changes, chromium_reference_changes=0)
        save()
        print(json.dumps(dict(matrix=name, results=summary['results'], comparison=report['comparisons'].get(name))), flush=True)
    report['observed_exit_code'] = int(any(row['results']['different'] for row in report['matrices'].values()))
except BaseException as error:
    report.update(observed_exit_code=1, failure=repr(error))
    raise
finally:
    report.update(source_after=identity(ROOT), all_commands_terminal=True)
    report['source_unchanged'] = report['source_after'] == source
    save(); lock.close()
print(json.dumps(dict(receipt=str(OUT / 'receipt.json'), actual_exit_code=report['observed_exit_code'])), flush=True)
sys.exit(report['observed_exit_code'])
