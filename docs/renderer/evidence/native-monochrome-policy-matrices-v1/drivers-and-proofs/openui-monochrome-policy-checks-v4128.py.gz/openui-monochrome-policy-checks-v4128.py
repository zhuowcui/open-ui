import fcntl,hashlib,json,os,subprocess,sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');OUT=Path('/mnt/d/openui-v02-qualification-d174ea0b/native-monochrome-policy-checks-v4128')
sys.path.insert(0,'/tmp');from openui_parallel_source_identity_v3060 import identity
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert not OUT.exists();OUT.mkdir();before=identity(ROOT)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
commands=[('matrix-tests',['python3','-B','-m','unittest','tools.qualification.test_renderer_matrix','tools.qualification.test_summarize_renderer_census']),('style',['python3','-B','tools/style/generate_properties.py','--check']),('ffi',['python3','-B','tools/ffi/generate_ffi.py','--check']),('renderer',['python3','-B','tools/qualification/generate_renderer_contract.py','--check']),('release',['python3','-B','tools/release/generate_v02_contract.py','--check']),('accountability',['python3','-B','tools/accountability/audit.py','--repository-only']),('whitespace',['git','diff','--check'])]
for name,path in [('format-paint','bindings/rust/openui-paint/src/painter.rs'),('format-example','bindings/rust/openui/examples/native_monochrome_font.rs')]:commands.append((name,['rustfmt','--edition','2021','--config','skip_children=true','--emit','stdout'],path))

def check(item):
 name,command,*rest=item;input_data=(ROOT/rest[0]).read_bytes() if rest else None
 with (OUT/(name+'.stdout')).open('xb') as out,(OUT/(name+'.stderr')).open('xb') as err:
  child=subprocess.run(command,cwd=ROOT,input=input_data,stdout=out,stderr=err,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),timeout=1200)
 code=child.returncode
 if rest and (OUT/(name+'.stdout')).read_bytes()!=input_data:code=1
 row=dict(name=name,command=command,actual_exit_code=child.returncode,check_exit_code=code,reaped=True,stdout_sha256=sha(OUT/(name+'.stdout')),stderr_sha256=sha(OUT/(name+'.stderr')))
 (OUT/(name+'.json')).write_text(json.dumps(row,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(check=name,actual_exit_code=child.returncode,check_exit_code=code)),flush=True);return row
with ThreadPoolExecutor(max_workers=6) as pool:results=list(pool.map(check,commands))
after=identity(ROOT);assert before==after
report=dict(schema_version=1,source_before=before,source_after=after,source_unchanged=True,all_commands_terminal=True,results=results,all_checks_pass=all(r['check_exit_code']==0 for r in results),renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False)
(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(all_checks_pass=report['all_checks_pass'],all_commands_terminal=True)),flush=True)
raise SystemExit(int(not report['all_checks_pass']))
