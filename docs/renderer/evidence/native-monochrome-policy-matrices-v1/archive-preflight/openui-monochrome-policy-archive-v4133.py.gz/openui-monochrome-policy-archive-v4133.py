import gzip, hashlib, json, shutil, subprocess
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b')
OUT=BASE/'native-monochrome-policy-matrices-v4129'
DEST=ROOT/'docs/renderer/evidence/native-monochrome-policy-matrices-v1'
INDEX=ROOT/'docs/renderer/generated/native-monochrome-policy-matrices-v1.json'
load=lambda path:json.loads(Path(path).read_bytes())
sha=lambda raw:hashlib.sha256(raw).hexdigest()
r=load(OUT/'receipt.json');a=load('/tmp/openui-monochrome-policy-audit-v4130.json');p=load('/tmp/openui-monochrome-policy-reaped-v4131.json')
assert r['all_commands_terminal'] and a['complete'] and p['all_local_commands_terminal'] and p['owners_absent']
assert sha((OUT/'receipt.json').read_bytes())==a['receipt_sha256']==p['receipt_sha256']
assert a['source']==r['source']==p['source'] and not DEST.exists() and not INDEX.exists()
files=[]
def add(source,label):
 source=Path(source);assert source.is_file(),str(source);files.append((source,label))
for source in sorted(OUT.rglob('*')):
 if source.is_file() and source.name!='pixel_compare':add(source,'matrices/'+str(source.relative_to(OUT)))
for directory in ['native-monochrome-policy-checks-v4128','native-fitted-monochrome-hosted-v4125','native-fitted-monochrome-hosted-v4132','native-fitted-monochrome-hosted-v4139']:
 for source in sorted((BASE/directory).rglob('*')):
  if source.is_file():add(source,directory+'/'+str(source.relative_to(BASE/directory)))
for name in ['openui-monochrome-policy-matrices-v4129.py','openui-monochrome-policy-audit-v4130.py','openui-monochrome-policy-audit-v4130.json','openui-monochrome-policy-reaping-v4131.py','openui-monochrome-policy-reaped-v4131.json','openui-monochrome-policy-checks-v4128.py','openui-fitted-monochrome-hosted-v4125.py','openui-fitted-monochrome-hosted-v4132.py','openui-fitted-monochrome-hosted-v4139.py']:
 add('/tmp/'+name,'drivers-and-proofs/'+name)
review=BASE/'native-monochrome-table-review-v4134.json';add(review,'table-review/'+review.name)
for relative in ['tools/qualification/run_renderer_matrix.py','tools/qualification/test_renderer_matrix.py','tools/qualification/summarize_renderer_census.py','tools/qualification/test_summarize_renderer_census.py','docs/renderer/native-monochrome-font-policy.md']:
 assert (ROOT/relative).read_bytes()==subprocess.check_output(['git','show',r['source']['commit']+':'+relative],cwd=ROOT)
 add(ROOT/relative,'measured-source/'+relative)
pngs={}
for name,matrix in r['matrices'].items():
 summary=load(OUT/name/(matrix['suite']+'-summary.json'))
 for profile in summary['profiles']:
  for case in profile['tests']:
   for origin in ['openui','chromium']:
    digest=case[origin+'_png_sha256'];path=BASE/'native-monochrome-policy-cache-v4129'/case[origin+'_png_cache_path']
    assert path.is_file();pngs[digest]=path
for digest,path in sorted(pngs.items()):add(path,'png/'+digest+'.png')
prepared=[];labels=set()
for source,label in files:
 assert label not in labels;labels.add(label)
 raw=source.read_bytes();packed=raw if source.suffix=='.png' else gzip.compress(raw,compresslevel=9,mtime=0)
 label+= '' if source.suffix=='.png' else '.gz'
 prepared.append((label,packed,dict(raw_bytes=len(raw),raw_sha256=sha(raw),bytes=len(packed),sha256=sha(packed),compression='none' if source.suffix=='.png' else 'gzip')))
size=sum(len(packed) for _,packed,_ in prepared)
assert shutil.disk_usage(ROOT).free-size>128*2**20,(size,shutil.disk_usage(ROOT).free)
DEST.mkdir(parents=True)
members=[]
for label,packed,metadata in prepared:
 destination=DEST/label;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(packed)
 metadata['path']=str(destination.relative_to(ROOT));members.append(metadata)
for member in members:
 packed=(ROOT/member['path']).read_bytes();assert sha(packed)==member['sha256']
 raw=gzip.decompress(packed) if member['compression']=='gzip' else packed
 assert sha(raw)==member['raw_sha256'] and len(raw)==member['raw_bytes']
index=dict(schema_version=1,measured_source=r['source'],matrix_results=a['results'],comparisons=a['comparisons'],
 matrix_rows_verified=a['matrix_rows_verified'],png_files_verified=a['png_files_verified'],
 all_archive_hashes_verified=True,all_measurement_commands_terminal=True,
 pixel_target='pinned Chromium',pixel_tolerance=0,javascript_executed_by_openui=False,
 renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,
 default_policy_changed=False,candidate_results_are_diagnostic=True,
 archive=dict(files=len(members),bytes=size,members=members,excluded=[dict(path=load(OUT/'guarded-build/receipt.json')['binary'],reason='Owned measured executable retained outside Git',sha256=load(OUT/'guarded-build/receipt.json')['binary_sha256'])]))
INDEX.write_text(json.dumps(index,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(index=str(INDEX),members=len(members),bytes=size,index_sha256=sha(INDEX.read_bytes()))),flush=True)
