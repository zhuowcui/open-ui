import json
import os
from pathlib import Path

ROOT = Path('/home/nero/code/open-ui')
r = json.loads(Path('/tmp/openui-native-font-units-all-features-reaped-v3643.json').read_bytes())
assert r['all_local_commands_terminal'] and r['actual_audit_exit_code'] == 0
assert (ROOT/'docs/renderer/generated/native-font-units-public-v2.json').exists()
all_targets = r['results']['workspace-all-targets-all-features']
workspace = r['results']['workspace-and-docs-all-features']
assert all_targets['failed'] == workspace['failed'] == 0
current = f'''Fresh complete CPU qualification at clean `e98a5a17` is exact on focused
**640/640** and primitive **960/960** comparisons. Original **21,342/22,924**
and expanded **22,145/23,728** are exact, with zero render errors. Both full
pixel gates still exit 1 for 1,582 and 1,583 differences. All 48,252 comparison
rows retain the preceding native pixels and every Chromium reference field,
with no gains, losses or worsened differences.

All **{all_targets['passed']:,} locked all-targets tests** and **{workspace['passed']:,} workspace
and documentation tests** pass with every feature enabled; {workspace['ignored']} existing
workspace tests remain ignored. Seven explicit hosted hardening jobs pass at
the same checkpoint. Broader native APIs, residual ownership, compositor,
physical lab and release qualification remain open.
'''
updates = {}

def replace(text, old, new):
    assert text.count(old) == 1, old[:100]
    return text.replace(old, new)

def load(relative):
    return (ROOT/relative).read_text()

def insert(relative, marker, link):
    text = load(relative)
    return replace(text, marker, marker+current+link+'\n\n')

updates['README.md'] = insert('README.md', '## Verified status\n\n',
    '[Completed combined evidence](docs/renderer/generated/native-font-units-public-v2.json).')
updates['README.md'] = replace(updates['README.md'],
    'layouts. Complete renderer qualification on this change remains pending, as do\nmixed-unit animation and broader font contexts.',
    'layouts. Both complete pixel gates remain failed. Mixed-unit animation,\nretained font-relative line-height declarations and broader font contexts remain open.')
updates['README.md'] = replace(updates['README.md'],
    'primitive gates pass; both full gates still fail. Fresh combined umbrella\nqualification is pending.',
    'primitive gates pass; both full gates still fail. Fresh combined umbrella\nresults are recorded above.')

updates['docs/progress/current-status.md'] = insert('docs/progress/current-status.md',
    '## Current implementation checkpoint\n\n',
    '[Completed combined evidence](../renderer/generated/native-font-units-public-v2.json).\n\n### Earlier native app verification')
updates['docs/progress/current-status.md'] = replace(updates['docs/progress/current-status.md'],
    'remain open. Fresh combined umbrella qualification is pending.',
    'remain open. Fresh combined umbrella results are recorded above.')

updates['docs/renderer/contract.md'] = insert('docs/renderer/contract.md',
    'Scripts may run only in the separate offline Chromium reference tooling.\n\n',
    '[Completed combined evidence](generated/native-font-units-public-v2.json).')
updates['docs/renderer/contract.md'] = replace(updates['docs/renderer/contract.md'],
    'app results do not qualify the complete renderer matrices or every font context;\nfresh complete qualification remains required.',
    'app results qualify their measured subset. Both complete pixel gates above\nremain failed; broader font contexts still require qualification.')
updates['docs/renderer/contract.md'] = replace(updates['docs/renderer/contract.md'],
    'all Chromium fields are unchanged. Both full gates remain failed and fresh\ncombined umbrella qualification is pending. Four neighboring reduction cases',
    'all Chromium fields are unchanged. Both full gates remain failed in the fresh\ncombined umbrella run above. Four neighboring reduction cases')

updates['docs/v02/release.md'] = insert('docs/v02/release.md',
    'claimed by source code alone.\n\n',
    '[Completed combined evidence](../renderer/generated/native-font-units-public-v2.json).\n\n## Earlier fieldset and keyboard verification')
updates['docs/v02/release.md'] = replace(updates['docs/v02/release.md'],
    'exit 1; fresh combined umbrella qualification and final release remain open.',
    'exit 1 in the fresh combined umbrella run above; final release remains open.')

updates['docs/renderer/native-font-relative-lengths.md'] = insert(
    'docs/renderer/native-font-relative-lengths.md',
    '## Current measured checkpoint\n\n',
    '[Completed combined evidence](generated/native-font-units-public-v2.json).\n\n'
    'A separate reference-only probe records 100 Chromium geometry observations\n'
    'at five scales, with two independent processes agreeing. It covers relative\n'
    'line-height values and mixed-unit animation for remaining native API work.\n'
    'No native app runs in that probe; it qualifies no native API or pixels.\n\n'
    '### Earlier native app verification at `45d21648`')
updates['docs/renderer/native-font-relative-lengths.md'] = replace(
    updates['docs/renderer/native-font-relative-lengths.md'],
    'Complete focused, primitive, original and expanded renderer qualification on\nthis change remains required. Mixed-unit animation, retained font-relative\nline-height declarations, and complete root, font-size-adjust, orientation,',
    'Complete focused, primitive, original and expanded matrices have run at the\n'
    'combined checkpoint above; both full pixel gates still fail. Mixed-unit\n'
    'animation, retained font-relative line-height declarations, and complete\n'
    'root, font-size-adjust, orientation,')

for relative in ['README.md', 'docs/progress/current-status.md', 'docs/renderer/contract.md', 'docs/v02/release.md']:
    updates[relative] = replace(updates[relative],
        'and 168 paint tests. Four neighboring images still differ; complete canonical\nrenderer/workspace qualification remains pending.',
        'and 168 paint tests. Four neighboring images still differ. Complete combined\nrenderer/workspace results are recorded above.')

updates['docs/v02/supported-platforms.md'] = replace(load('docs/v02/supported-platforms.md'),
'''The [native font-relative helper](../renderer/native-font-relative-lengths.md)
resolves `ch`, `ex` and `lh` from an owned computed style and the app's font
collection. Apps currently assign a pixel value and recompute after font changes.
The [private upright correction](../renderer/native-glyph-mask.md) matches all
1,440 measured rectangles, with 160 gains and no losses; it captures no native
pixels and remains unapplied. Its parent glyph correction passes focused and
primitive checks but regresses both complete censuses and is rejected.
Automatic typed declarations, complete contexts and C parity remain native
API work. None of these operations requires JavaScript.
''',
'''The [retained native font-unit declarations](../renderer/native-font-relative-lengths.md)
let apps assign `LengthValue::Ch`, `Ex` and `Lh` directly. The shared Engine
recomputes them after font changes; apps do not need to assign pixel lengths
again. C uses the same Engine through appended length-unit tags. A consuming
Rust callback app matches 8/8 Chromium images and 32/32 bounds at the four
required profiles. The owned metric-query helper remains available for apps
that deliberately want a captured pixel value.
Mixed-unit animation, retained font-relative line-height declarations and
broader font contexts remain native API work. Earlier private upright/glyph
experiments retain their own evidence and promotion status. None of these
operations requires JavaScript.
''')
updates['docs/v02/unsupported-features.md'] = replace(load('docs/v02/unsupported-features.md'),
'''- complete coverage of needed element operations through public native Rust
  APIs still requires review and verification from consuming applications;
''',
'''- complete coverage of needed element operations through public native Rust
  APIs still requires review and verification from consuming applications;
- retained `ch`, `ex` and `lh` declarations work in the measured native app
  cases, but mixed-unit animation, font-relative line-height declarations and
  complete adjusted-font/root/orientation contexts remain native API work;
''')

# Validate every exact replacement before changing any repository file.
for relative, updated in updates.items():
    assert updated != load(relative), relative
for relative, updated in updates.items():
    path = ROOT/relative
    temporary = path.with_name(path.name+'.native-font-units.tmp')
    assert not temporary.exists()
    temporary.write_text(updated)
    os.replace(temporary, path)
print('Updated measured status and native Rust API documentation', flush=True)

