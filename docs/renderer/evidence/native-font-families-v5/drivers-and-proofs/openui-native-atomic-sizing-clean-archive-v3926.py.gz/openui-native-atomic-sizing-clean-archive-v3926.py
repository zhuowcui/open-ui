import fcntl,gzip,hashlib,json,shutil,subprocess
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b');OUT=BASE/'native-atomic-sizing-clean-full-v3918';NATIVE=BASE/'native-atomic-sizing-clean-consumer-v3914'
DEST=ROOT/'docs/renderer/evidence/native-font-families-v5';INDEX=ROOT/'docs/renderer/generated/native-font-families-v5.json'
load=lambda p:json.loads(Path(p).read_bytes());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
r=load(OUT/'receipt.json');a=load('/tmp/openui-native-atomic-sizing-clean-full-audit-v3919.json');proof=load('/tmp/openui-native-atomic-sizing-clean-full-reaped-v3920.json');native=load(NATIVE/'receipt.json');na=load('/tmp/openui-native-atomic-sizing-clean-consumer-audit-v3915.json');nr=load('/tmp/openui-native-atomic-sizing-clean-consumer-reaped-v3916.json');inventory=load('/tmp/openui-native-atomic-sizing-residual-inventory-v3923.json')
assert r['all_commands_terminal'] and a['complete'] and proof['all_local_commands_terminal'] and proof['owners_absent']
assert native['all_commands_terminal'] and na['complete'] and nr['all_local_commands_terminal'] and nr['owners_absent']
assert r['source']==a['source']==proof['source']==native['source']==na['source']==nr['source']==inventory['source'] and r['source']['clean']
assert sha(OUT/'receipt.json')==a['receipt_sha256']==proof['receipt_sha256'] and sha(NATIVE/'receipt.json')==na['receipt_sha256']==nr['receipt_sha256']
for owner in [r['owner_pid'],native['owner_pid']]:assert subprocess.run(['ps','-p',str(owner)],capture_output=True).returncode==1
for name in ['cargo','rustc','rustfmt','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
assert not DEST.exists() and not INDEX.exists() and shutil.disk_usage(ROOT).free>192*2**20
previous=ROOT/'docs/renderer/generated/native-font-families-v4.json';previous_hash=sha(previous)
for member in load(previous)['archive']['members']:assert sha(ROOT/member['path'])==member['sha256']
DEST.mkdir();members=[];excluded=[]
def add(path,label):
 raw=Path(path).read_bytes();stored=gzip.compress(raw,compresslevel=9,mtime=0);target=DEST/(label+'.gz');assert not target.exists();target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(stored)
 assert gzip.decompress(target.read_bytes())==raw
 members.append(dict(path=str(target.relative_to(ROOT)),compression='gzip',bytes=len(stored),sha256=sha(target),raw_bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest()))
for p in sorted(NATIVE.rglob('*')):
 if p.is_file():
  if p.name=='native_font_metrics_consumer':excluded.append(dict(path=str(p),sha256=sha(p),reason='Owned native executable retained outside Git; exact binary hash and fresh linked compiler provenance archived.'));continue
  assert p.suffix in ['.json','.png','.log'];add(p,'clean-native/'+str(p.relative_to(NATIVE)))
for p in sorted((BASE/'native-atomic-sizing-clean-consumer-source-v3913').rglob('*')):
 if p.is_file():add(p,'consumer-source/'+str(p.relative_to(BASE/'native-atomic-sizing-clean-consumer-source-v3913')))
for p in sorted((OUT/'guarded-build').iterdir()):
 if p.is_file() and p.name!='pixel_compare':add(p,'renderer-build/'+p.name)
for suite in ['focused','primitive','full','expanded']:add(OUT/(suite+'-matrix')/(suite+'-summary.json'),suite+'-summary.json');add(OUT/(suite+'.log'),suite+'.log')
add(OUT/'receipt.json','renderer-receipt.json')
for name in ['openui-native-atomic-sizing-clean-consumer-v3914.py','openui-native-atomic-sizing-clean-consumer-audit-v3915.py','openui-native-atomic-sizing-clean-consumer-audit-v3915.json','openui-native-atomic-sizing-clean-consumer-reaping-v3916.py','openui-native-atomic-sizing-clean-consumer-reaped-v3916.json','openui-native-atomic-sizing-clean-full-v3918.py','openui-native-atomic-sizing-clean-full-audit-v3919.py','openui-native-atomic-sizing-clean-full-audit-v3919.json','openui-native-atomic-sizing-clean-full-reaping-v3920.py','openui-native-atomic-sizing-clean-full-reaped-v3920.json','openui-native-atomic-sizing-residual-inventory-v3923.py','openui-native-atomic-sizing-residual-inventory-v3923.json']:add('/tmp/'+name,'drivers-and-proofs/'+name)
for p in sorted((BASE/'native-atomic-sizing-hosted-v3924').iterdir()):
 if p.is_file():add(p,'hosted/'+p.name)
for p in sorted((BASE/'chromium-intrinsic-source-v3921').iterdir()):
 if p.is_file():add(p,'official-chromium-source/'+p.name)
add(BASE/'native-intrinsic-source-review-v3922.json','intrinsic-source-review.json');add(BASE/'native-font-unit-advance-review-v3925.json','font-unit-advance-review.json');add(BASE/'native-text-exception-debt-v3930.json','text-exception-debt.json');add(__file__,'drivers-and-proofs/'+Path(__file__).name)
b=load(OUT/'guarded-build/receipt.json');excluded.append(dict(path=b['binary'],sha256=b['binary_sha256'],reason='Owned renderer executable retained outside Git; exact binary hash and fresh linked-library provenance archived.'))
assert sha(previous)==previous_hash
hosted=load(BASE/'native-atomic-sizing-hosted-v3924/receipt.json');assert hosted['source_commit']==r['source']['commit'] and hosted['jobs']==12 and hosted['skips']==0 and hosted['all_jobs_success']
result=dict(schema_version=1,source=r['source'],previous_immutable_evidence=dict(path=str(previous.relative_to(ROOT)),sha256=previous_hash,unchanged=True),clean_native_application=dict(totals=native['totals'],actual_exit_code=native['observed_exit_code'],audit=na,guard_results=native['guard_results'],metrics_scope=native['metrics_scope'],qualification=False),clean_renderer=dict(results=a['results'],rows_audited=a['matrix_rows_verified'],candidate_nonregression=a['candidate_nonregression'],audit=a,qualification=False),residual_inventory=inventory,hosted=hosted,official_intrinsic_source_review=load(BASE/'native-intrinsic-source-review-v3922.json'),font_unit_advance_review=load(BASE/'native-font-unit-advance-review-v3925.json'),all_local_commands_terminal=True,all_members_hash_verified=True,pixel_target='pinned Chromium',pixel_tolerance=0,historical_openui_archive_is_a_pixel_target=False,javascript_executed_by_openui=False,full_renderer_contract_qualified=False,all_native_apis_qualified=False,release_qualified=False,pending=['All original and expanded pixel comparisons exact with zero errors.','Native word-width precision, fallback line metrics and all font/raster differences.','Existing font-family, size, scale and phase exceptions need shared replacements.','Every residual needs reviewed cause, owner and minimized Engine-backed reproduction.','Current clean local full workspace/ABI and all remaining needed native APIs.','Compositor/3D, physical lab and release qualification.'],archive=dict(files=len(members),bytes=sum(m['bytes'] for m in members),members=members,excluded=excluded))
INDEX.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(index=str(INDEX),files=len(members),stored_bytes=result['archive']['bytes'],results=a['results'],candidate_nonregression=a['candidate_nonregression'])),flush=True)
