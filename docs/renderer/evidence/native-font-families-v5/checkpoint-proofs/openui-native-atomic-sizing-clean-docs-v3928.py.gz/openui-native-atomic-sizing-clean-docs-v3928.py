import hashlib,json,os
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui')
INDEX=ROOT/'docs/renderer/generated/native-font-families-v5.json'
load=lambda p:json.loads(Path(p).read_bytes())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=load(INDEX);terminal=load('/tmp/openui-native-atomic-sizing-clean-archive-terminal-v3927.json')
assert terminal['actual_archive_writer_exit_code']==0 and terminal['archive_writer_reaped'] and terminal['index_sha256']==sha(INDEX)
assert r['all_local_commands_terminal'] and r['all_members_hash_verified']
source=r['source']['commit'];assert source=='b21ece156a391d76cfd6c5c46791a5c13ce6dcc0' and r['source']['clean']
n=r['clean_native_application'];m=r['clean_renderer'];inv=r['residual_inventory'];hosted=r['hosted']
assert n['totals']==dict(images=15,exact_images=0,bounds=210,exact_bounds=180)
assert n['guard_results']==dict(actual_exit_code=0,passed=1181,failed=0,ignored=0)
assert hosted['source_commit']==source and hosted['jobs']==12 and hosted['skips']==0 and hosted['all_jobs_success']
assert m['rows_audited']==48252 and m['results']['focused']['exact']==640 and m['results']['primitive']['exact']==960
f=m['results']['full'];e=m['results']['expanded']
assert f['errors']==e['errors']==0
regression=not m['candidate_nonregression']
assert regression and f['losses']>0
fmt=lambda v:format(v,',')
text=f"""## Shared atomic sizing (clean measurement; regression gate failed)

The integrated sizing change fails the full-census regression gate and requires
repair before acceptance. Atomic elements use the shared minimum and maximum
content calculations across
font families. Consecutive floats retain their measured minimum width. This
removes the font-name and zero-minimum branches from atomic shrink-to-fit.

A separate Rust app at clean `{source[:8]}` measures **0/15 whole images and
180/210 bounds exact** against unchanged pinned Chromium. Its pixels and bounds
reproduce the earlier sizing trial byte for byte. Same-byte font aliases retain
pixels and bounds at all five profiles; different font bytes change pixels.
Both Rust callbacks, independent process repeats, unchanged-frame repeats and
weak teardown pass. All **1,181 layout/text/paint tests** pass, with zero failures
or ignores. The **1,470 direct shaping samples** describe retained styles and
the shared font collection; they do not establish the Engine's inline
segmentation or Chromium's internal strike settings.

Fresh CPU verification at the same clean source measures
**{fmt(f['exact'])}/{fmt(f['total'])} original** and
**{fmt(e['exact'])}/{fmt(e['total'])} expanded** exact comparisons, with
**{fmt(f['different'])} / {fmt(e['different'])} differences**, zero errors and
actual exits **{f['actual_exit_code']} / {e['actual_exit_code']}**.
Focused **640/640** and primitive **960/960** are exact. All **48,252 rows**,
fresh linked artifacts and unchanged Chromium reference fields are audited.
Against earlier clean `98d18982`, the original census gains **{f['gains']}**
exact comparisons, loses **{f['losses']}**, and worsens **{f['worsened']}** differences;
the expanded census gains **{e['gains']}**, loses **{e['losses']}**, and worsens **{e['worsened']}**.

All **12 hosted jobs** pass on measured `{source[:8]}`, with zero skips: format,
ordinary CI and all seven explicitly dispatched hardening jobs, including the
hosted X11/Mesa and pure Wayland native consumers.
[Hardening run 38113517188](https://github.com/zhuowcui/open-ui/actions/runs/38113517188).
These results are attributed to the measured source; a later checkpoint needs
its own hosted results.

There are **{inv['remaining_test_ids']} residual original test IDs**, including
**{len(inv['residual_ids_without_ledger_entry'])} without a reviewed ownership entry**.
Long-word advance precision, fallback line height and broader font/raster
behavior remain open. Existing font-name, size, scale and phase exceptions in
text rendering still require shared fixes; this sizing change does not remove
them. Full local workspace/ABI, complete native API, compositor, physical lab
and release qualification remain open. No renderer or release pass is claimed.

Open UI never runs JavaScript. Applications use public native Rust APIs and
Rust callbacks; every needed element operation remains framework work.
Chromium alone defines expected pixels.
[Immutable clean native and renderer evidence]({{link}}).

"""
changes=[]
for name,marker,link in [('README.md','### Resolved font raster selection','docs/renderer/generated/native-font-families-v5.json'),('docs/progress/current-status.md','## Current implementation','../renderer/generated/native-font-families-v5.json'),('docs/renderer/contract.md','## Resolved font raster selection','generated/native-font-families-v5.json'),('docs/v02/release.md','## Resolved font raster selection','../renderer/generated/native-font-families-v5.json')]:
 p=ROOT/name;old=p.read_text();heading='### Shared atomic sizing' if name=='README.md' else '## Shared atomic sizing';start=old.index(heading);end=old.index(marker,start)
 section=text.format(link=link)
 if name=='README.md':section=section.replace('## Shared atomic sizing','### Shared atomic sizing',1)
 new=old[:start]+section+old[end:];tmp=p.with_name(p.name+'.tmp');tmp.write_text(new);os.replace(tmp,p);changes.append(dict(path=name,before_sha256=hashlib.sha256(old.encode()).hexdigest(),after_sha256=sha(p)))
p=ROOT/'docs/v02/unsupported-features.md';old=p.read_text();start=old.index('- shared atomic sizing is integrated from a dirty diagnostic trial:');end=old.index('\n- ',start+1)
bullet=f"""- shared atomic sizing has a failed clean full-census regression gate at
  `{source[:8]}`: 180/210 bounds and 0/15 images are exact. All 1,181
  layout/text/paint tests pass; focused 640/640 and primitive 960/960 are
  exact. Original {fmt(f['exact'])}/{fmt(f['total'])} and expanded
  {fmt(e['exact'])}/{fmt(e['total'])} still fail with zero errors and no exact
  render errors. The regression gate fails: {f['losses']} original exact
  comparisons are lost and {f['worsened']} differences worsen; all Chromium
  reference fields are unchanged.
  All 12 hosted jobs pass on that measured source, with zero skips. Long-word
  advance precision, fallback line height, existing text-rendering exceptions,
  local full workspace/ABI, complete native APIs, compositor, physical lab and
  release gates remain open. No renderer or release pass is claimed.
  [Measured evidence](../renderer/generated/native-font-families-v5.json);"""
new=old[:start]+bullet+old[end:];tmp=p.with_name(p.name+'.tmp');tmp.write_text(new);os.replace(tmp,p);changes.append(dict(path=str(p.relative_to(ROOT)),before_sha256=hashlib.sha256(old.encode()).hexdigest(),after_sha256=sha(p)))
p=Path('/tmp/openui-native-atomic-sizing-clean-docs-v3928.json');assert not p.exists();p.write_text(json.dumps(dict(schema_version=1,source=r['source'],changes=changes,all_qualification_claims_false=True),sort_keys=True,indent=2)+'\n');print(json.dumps(dict(edited_documents=len(changes),qualification=False)))
