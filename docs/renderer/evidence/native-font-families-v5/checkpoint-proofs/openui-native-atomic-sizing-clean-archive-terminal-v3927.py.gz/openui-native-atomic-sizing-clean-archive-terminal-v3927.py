import hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');INDEX=ROOT/'docs/renderer/generated/native-font-families-v5.json';DEST=Path('/tmp/openui-native-atomic-sizing-clean-archive-terminal-v3927.json')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert int(sys.argv[1])==0 and not DEST.exists()
r=json.loads(INDEX.read_bytes());assert r['all_local_commands_terminal'] and r['all_members_hash_verified']
for name in ['cargo','rustc','rustfmt','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
for member in r['archive']['members']:assert sha(ROOT/member['path'])==member['sha256']
proof=dict(schema_version=1,actual_archive_writer_exit_code=0,archive_writer_reaped=True,actual_archive_writer_session=int(sys.argv[2]),index_sha256=sha(INDEX),member_hashes_verified=len(r['archive']['members']),all_local_commands_terminal=True,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False)
DEST.write_text(json.dumps(proof,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(proof=str(DEST),members=proof['member_hashes_verified'])),flush=True)
