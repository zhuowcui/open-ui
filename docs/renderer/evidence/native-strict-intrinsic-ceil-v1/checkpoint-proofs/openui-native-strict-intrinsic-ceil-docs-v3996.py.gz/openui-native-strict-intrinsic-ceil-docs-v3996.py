import hashlib,json,os
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');INDEX=ROOT/'docs/renderer/generated/native-strict-intrinsic-ceil-v1.json'
r=json.loads(INDEX.read_bytes());m=r['renderer_dirty']['results'];assert r['all_local_commands_terminal'] and r['trial_dirty']['totals']['exact_bounds']==190
assert m['selected']['total']==1368 and m['focused']['total']==640 and m['primitive']['total']==960
kept=r['implementation_retained_in_umbrella'];source=r['measured_source']['commit'][:8]
state='The shared intrinsic-size conversion now preserves small positive font advances when rounding up to the layout grid, following pinned Chromium. A public Rust guard creates an inline block, changes its font alias through a Rust callback and checks neighboring fixed-width floats.' if kept else 'The shared strict-ceil candidate is rejected for application after its regression checks. The production source is restored; the candidate and all measured failures remain preserved.'
text='''## Fractional intrinsic text widths (scoped verification)

{state}

The clean font probe at `{source}` measures **180/210 bounds** exact. The
strict-ceil diagnostic trial measures **190/210**, with **ten gains and no
losses**, at all five scales. All **15 app pictures remain byte-identical**
and none are yet Chromium-exact. Same-byte font aliases, independent process
and unchanged-frame repeats, two Rust callbacks and weak teardown pass.
All **1,181 layout/text/paint tests and three public Rust API tests** pass.
The previous normalization-only assertion is replaced by the measured native
application guard. The 1,470 direct font samples remain diagnostics; they do
not capture Chromium's internal strike settings or Engine inline segmentation.

The affected 342-case sweep measures **{selected_exact}/1,368 exact**, with
**{selected_different} existing differences**, zero errors, {selected_losses}
exact losses and {selected_worse} worsened differences. Focused **{focused_exact}/640**
and primitive **{primitive_exact}/960** are exact. All **2,968 rows**, fresh
compiled libraries and unchanged Chromium reference fields are independently
audited. Every owner and audit is terminal and reaped before later changes.
These are source-attributed diagnostics from a dirty trial. Current clean-source
full original and expanded qualification remains pending. The last complete
clean census remains **21,350/22,924 original** and **22,153/23,728 expanded**
exact, with zero errors; both pixel gates still fail.

Open UI never executes JavaScript. Every needed element operation must be
implemented in the shared Rust Engine and callable through public native Rust
APIs and Rust callbacks. Chromium alone defines expected pixels; old Open UI
screenshots preserve history. Complete font/control behavior, every required
native API, reviewed residual ownership, compositor/3D, hardware and release
qualification remain open. [Immutable evidence]({link}).

'''
params=dict(state=state,source=source,selected_exact=m['selected']['exact'],selected_different=m['selected']['different'],selected_losses=m['selected']['losses'],selected_worse=m['selected']['worsened'],focused_exact=m['focused']['exact'],primitive_exact=m['primitive']['exact'])
changes=[]
for name,link in [('README.md','docs/renderer/generated/native-strict-intrinsic-ceil-v1.json'),('docs/progress/current-status.md','../renderer/generated/native-strict-intrinsic-ceil-v1.json'),('docs/renderer/contract.md','generated/native-strict-intrinsic-ceil-v1.json'),('docs/v02/release.md','../renderer/generated/native-strict-intrinsic-ceil-v1.json')]:
 p=ROOT/name;old=p.read_text();marker='### Cleared empty boxes' if name=='README.md' else '## Cleared empty boxes';at=old.index(marker);section=text.format(link=link,**params)
 if name=='README.md':section=section.replace('## Fractional','### Fractional',1)
 new=old[:at]+section+old[at:];tmp=p.with_name(p.name+'.ou3996.tmp');tmp.write_text(new);os.replace(tmp,p);changes.append(name)
p=ROOT/'docs/v02/unsupported-features.md';old=p.read_text();at=old.index('- clean `81381713` verifies');bullet='''- the shared intrinsic-ceil diagnostic gains ten native bounds (190/210 exact)
  without changing any of 15 app pictures. All 1,181 layout/text/paint tests and
  three public Rust API tests pass. The affected 342-case sweep, focused and
  primitive matrices independently audit 2,968 rows with unchanged Chromium
  references. Current clean-source full qualification and remaining shared
  font/control behavior are open. No complete renderer, native API or release
  pass is claimed. [Evidence](../renderer/generated/native-strict-intrinsic-ceil-v1.json);
''';new=old[:at]+bullet+old[at:];tmp=p.with_name(p.name+'.ou3996.tmp');tmp.write_text(new);os.replace(tmp,p);changes.append(str(p.relative_to(ROOT)))
out=Path('/tmp/openui-native-strict-intrinsic-ceil-docs-v3996.json');assert not out.exists();out.write_text(json.dumps(dict(schema_version=1,edited_documents=changes,implementation_retained=kept,measured_source=r['measured_source'],all_commands_terminal=True,qualified=False),sort_keys=True,indent=2)+'\n');print(json.dumps(dict(edited_documents=len(changes),implementation_retained=kept,qualified=False)))
