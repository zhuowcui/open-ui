import fcntl,gzip,hashlib,json,shutil,subprocess
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b')
DEST=ROOT/'docs/renderer/evidence/native-strict-intrinsic-ceil-v1';INDEX=ROOT/'docs/renderer/generated/native-strict-intrinsic-ceil-v1.json'
load=lambda p:json.loads(Path(p).read_bytes());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
baseline=load(BASE/'native-independent-font-flags-clean-consumer-v3985/receipt.json');bp=load('/tmp/openui-native-independent-font-flags-clean-consumer-reaped-v3987.json')
trial=load(BASE/'native-strict-intrinsic-ceil-trial-v3989/receipt.json');tp=load('/tmp/openui-native-strict-intrinsic-ceil-trial-reaped-v3991.json');ta=load('/tmp/openui-native-strict-intrinsic-ceil-trial-audit-v3990.json')
matrix=load(BASE/'native-strict-intrinsic-ceil-matrices-v3992/receipt.json');mp=load('/tmp/openui-native-strict-intrinsic-ceil-matrices-reaped-v3994.json');ma=load('/tmp/openui-native-strict-intrinsic-ceil-matrices-audit-v3993.json')
for proof,r in [(bp,baseline),(tp,trial),(mp,matrix)]:
 assert proof['all_local_commands_terminal'] and proof['owners_absent'] and r['all_commands_terminal']
 assert subprocess.run(['ps','-p',str(r['owner_pid'])],capture_output=True).returncode==1
for name in ['cargo','rustc','rustfmt','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
assert trial['source']==matrix['source']==tp['source']==mp['source'] and not trial['source']['clean']
assert baseline['source']['clean'] and baseline['source']['commit']==trial['source']['commit']
assert baseline['totals']==dict(images=15,exact_images=0,bounds=210,exact_bounds=180)
assert trial['totals']==dict(images=15,exact_images=0,bounds=210,exact_bounds=190)
assert ta['comparison']['bounds_gains']==10 and ta['comparison']['bounds_losses']==0 and ta['comparison']['native_images_unchanged_from_prior_diagnostic']
assert sha(BASE/'native-strict-intrinsic-ceil-trial-v3989/receipt.json')==tp['receipt_sha256']==ta['receipt_sha256']
assert sha(BASE/'native-strict-intrinsic-ceil-matrices-v3992/receipt.json')==mp['receipt_sha256']==ma['receipt_sha256']
assert ma['matrix_rows_verified']==2968
kept=ma['candidate_nonregression']
patch=load(BASE/'native-strict-intrinsic-ceil-source-v3988/source.json')
for file in patch['source_files']:assert sha(ROOT/file['path'])==file['after_sha256' if kept else 'before_sha256']
prior_path=ROOT/'docs/renderer/generated/native-float-clearance-v2.json';prior=load(prior_path);prior_hash=sha(prior_path)
for member in prior['archive']['members']:assert sha(ROOT/member['path'])==member['sha256']
assert not DEST.exists() and not INDEX.exists() and shutil.disk_usage(ROOT).free>128*2**20
DEST.mkdir();members=[];excluded=[]
def add(path,label):
 path=Path(path);raw=path.read_bytes();data=gzip.compress(raw,compresslevel=9,mtime=0);out=DEST/(label+'.gz');assert not out.exists();out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data);assert gzip.decompress(out.read_bytes())==raw
 members.append(dict(path=str(out.relative_to(ROOT)),compression='gzip',bytes=len(data),sha256=sha(out),raw_bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest()))
for directory,label in [('native-independent-font-flags-clean-source-v3984','baseline-source'),('native-independent-font-flags-clean-consumer-v3985','baseline-native'),('native-strict-intrinsic-ceil-source-v3988','trial-source'),('native-strict-intrinsic-ceil-trial-v3989','trial-native')]:
 for path in sorted((BASE/directory).rglob('*')):
  if path.is_file():
   if path.name in ['native_font_metrics_consumer','pixel_compare']:excluded.append(dict(path=str(path),sha256=sha(path),reason='Owned executable retained outside Git with fresh compiler hashes.'));continue
   add(path,label+'/'+str(path.relative_to(BASE/directory)))
mat=BASE/'native-strict-intrinsic-ceil-matrices-v3992'
for path in sorted((mat/'guarded-build').iterdir()):
 if path.is_file():
  if path.name=='pixel_compare':excluded.append(dict(path=str(path),sha256=sha(path),reason='Owned renderer retained outside Git with fresh compiler hashes.'));continue
  add(path,'renderer-build/'+path.name)
for suite in ['selected','focused','primitive']:
 ms='full' if suite=='selected' else suite
 add(mat/(suite+'-matrix')/(ms+'-summary.json'),suite+'-summary.json');add(mat/(suite+'.log'),suite+'.log')
add(mat/'receipt.json','renderer-receipt.json')
for pattern in ['openui-native-independent-font-flags-clean-consumer-v3985.py','openui-native-independent-font-flags-clean-consumer-audit-v3986.*','openui-native-independent-font-flags-clean-consumer-reap*-v3987.*','openui-native-strict-intrinsic-ceil-trial-v3989.py','openui-native-strict-intrinsic-ceil-trial-audit-v3990.*','openui-native-strict-intrinsic-ceil-trial-reap*-v3991.*','openui-native-strict-intrinsic-ceil-matrices-v3992.py','openui-native-strict-intrinsic-ceil-matrices-audit-v3993.*','openui-native-strict-intrinsic-ceil-matrices-reap*-v3994.*']:
 for path in sorted(Path('/tmp').glob(pattern)):add(path,'drivers-and-proofs/'+path.name)
for directory,label in [('chromium-intrinsic-source-v3921','pinned-chromium-intrinsic-source'),('native-strict-intrinsic-ceil-hosted-v4005','hosted-parent')]:
 for path in sorted((BASE/directory).rglob('*')):
  if path.is_file():add(path,label+'/'+str(path.relative_to(BASE/directory)))
for name in ['native-strict-intrinsic-ceil-selected-ids-v4002.json','native-strict-intrinsic-ceil-selected-ids-v4002.receipt.json']:add(BASE/name,'selected/'+name)
add(__file__,'drivers-and-proofs/'+Path(__file__).name)
assert sha(prior_path)==prior_hash
result=dict(schema_version=1,implementation_retained_in_umbrella=kept,clean_source_qualification_pending=kept,measured_source=trial['source'],previous_immutable_evidence=dict(path=str(prior_path.relative_to(ROOT)),sha256=prior_hash,unchanged=True),baseline_clean=dict(source=baseline['source'],totals=baseline['totals'],guards=baseline['guard_results'],audit=load('/tmp/openui-native-independent-font-flags-clean-consumer-audit-v3986.json')),trial_dirty=dict(totals=trial['totals'],guards=trial['guard_results'],native_api_guards=trial['native_api_guard_results'],audit=ta,comparison=ta['comparison'],qualification=False),renderer_dirty=dict(audit=ma,results=ma['results'],rows_audited=ma['matrix_rows_verified'],candidate_nonregression=ma['candidate_nonregression'],qualification=False),primary_source_findings=['Pinned Blink ShapeResult::SnappedWidth strictly ceil-converts advances to LayoutUnit; LayoutUnit::FromFloatCeil has no near-grid epsilon.','Removing the shared local normalization restores ten measured public native bounds; all 15 native app pictures remain unchanged.','Independent cloned SkFont flag samples measure unshaped widths; they do not capture Chromium internal font strikes or Engine inline segmentation.'],hosted_parent=load(BASE/'native-strict-intrinsic-ceil-hosted-v4005/receipt.json'),all_local_commands_terminal=True,all_members_hash_verified=True,pixel_target='pinned Chromium',pixel_tolerance=0,historical_openui_archive_is_a_pixel_target=False,javascript_executed_by_openui=False,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,pending=['Current clean-source full original and expanded renderer qualification.','Remaining shared font/control differences and every required public native API.','Reviewed residual ownership, clean workspace/ABI, compositor/3D, physical lab and release gates.'],archive=dict(files=len(members),bytes=sum(m['bytes'] for m in members),members=members,excluded=excluded))
INDEX.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(index=str(INDEX),members=len(members),stored_bytes=result['archive']['bytes'],candidate_nonregression=ma['candidate_nonregression'],qualified=False)),flush=True)
