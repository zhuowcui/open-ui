# Measured selection task ordering

Pinned Chromium v3006 completed twelve input/textarea scenarios twice with 28 callback rows, byte-identical observations, actual whole exit 0 and unchanged Main source. Open UI executes no JavaScript; these observations define obligations for native Rust operations and callback delivery.

Setting the current range again emits no events. One changed range emits selectionchange then select. Two changes before the frame barrier emit one selectionchange and two select callbacks, all reading the final retained range. Returning to the original range still emits one selectionchange and two select callbacks. Two range replacements and a replacement followed by restoring the original selection follow the same ordering. Thus the measured selectionchange task is coalesced while each changed-selection select task is retained. Listeners observe delivery-time state rather than captured per-edit selection values.

The previous range reference v2897 also emits selectionchange alone for a value replacement that leaves the selection unchanged. This requires distinguishing value-driven selectionchange notification from changed-selection select notification. Both events are noncancelable and bubble in these element-local reference captures.

Shared native Document scheduling, owning-thread application wakeups, C delegation, headless task barriers, selection direction, cross-control ordering and callback mutation/teardown are still implementation work. The reference does not establish document-level event dispatch or all reentry semantics. No native behavior/API/release qualification is claimed.
