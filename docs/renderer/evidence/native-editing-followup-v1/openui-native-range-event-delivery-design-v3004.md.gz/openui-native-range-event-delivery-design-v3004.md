# Native deferred selection event integration (unimplemented)

The immutable pinned Chromium scalar range reference v2995 records selectionchange then select for all eight cases. Both events bubble and are noncancelable. Their listeners read the retained value, selection and focus at delivery time. Open UI must provide this behavior through native Rust callbacks over the same Document used by input, C and rendering; no JavaScript runtime is involved.

Current EventState::for_type omits select and selectionchange from its noncancelable event set. Current Element::set_selection directly borrows Engine and has no native notifications. App::event/key_input and HeadlessApp render methods provide no public pending selection task barrier. Merely adding a range mutation method would leave these obligations open.

Proposed design: Document owns a separate deferred native task queue, holding generation-checked targets and typed selection task kinds. It must remain separate from composition's synchronous scoped queue. A public owning-thread dispatch_pending_events operation snapshots pending tasks, releases all engine/listener/task borrows, then dispatches. Reentrant scheduling should land in the subsequent task turn instead of being drained in an unbounded loop. Do not silently discard detached live target events: preserve local listeners and resolve the current route at delivery; destroyed targets are generation-checked. Panic/error cleanup and callback mutation need guards.

The Linux shared event-loop adapter must wake/dispatch these tasks after platform/default action borrows end, including native API calls made from callbacks. C must delegate scheduling and provide a coequal task barrier. Headless consumers need an explicit barrier. Selectionchange coalescing, select task multiplicity, ordering across controls, changes back to the original range, selection direction, destroyed/detached targets, and history/preedit require dedicated pinned references before coding a presumed queue policy. The scalar Rust draft v3000 names provisional APIs and is uncompiled; it reads a native direction accessor rather than substituting the reference value.

No production files changed. No compile/runtime/API/release qualification is claimed by this design.

Completed reference v3006 now establishes element-local coalescing: same-range no events, one selectionchange per turn and one select per changed selection, including returning to the original range. All callbacks read final retained state. See measured review v3009; cross-control and reentry remain open.
