# Settled mutation reference result

Corrected pinned Chromium2932 whole0/unchanged cleanMain454c:15scenarios128rows twice byte-identical SHAd0dfa15e6e824b1141a8c06427ba9fe9e0fab1d877a521ca860daa6751bd1553. Firstattempt2928whole1(noobservations due harness nullactiveElement) preserved.

Disable after preview: compositionend observes preview while text is focused; then change/blur/focusout observe no focused text. Later platform commit/cancel has no effect. Detach after preview: retained value stays; change/blur/focusout occur without compositionend, and late platform operations do not affect value. Readonly keeps focus/value, suppressing later commit/cancel events. Display:none may defer focus invalidation until a subsequent platform layout barrier; the immediate observation alone must not be treated as proof that hidden controls remain focusable. Removing body produces activeElement null; native headless body-removal contract has separate root restrictions.

Draft2936 replaces cancellation on detach with retaining preview/closing history/clearing late target, then shared native change/blur/out. It is uncompiled/unapplied. Readonly cancellation and hidden flush remain wrong/open; native command nesting, Cshared adapters and full source-qualified gates still required. All-nativeAPI and release qualification false. OpenUI never executes JavaScript.
