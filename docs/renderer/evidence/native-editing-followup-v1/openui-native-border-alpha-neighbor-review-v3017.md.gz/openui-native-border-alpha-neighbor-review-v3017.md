# Rounded border alpha neighbor evidence

The native public Rust click consumer inherited from clean private framework source2544 now renders the opaque radius40/width10/local/hidden variant at scale1 exactly against the immutable pinned Chromium reference2732: zero differing decoded RGBA pixels, maximum channel delta0, matching logical rectangle120x120at20,20 and one callback. The PNG encodings differ, but decoded pixels are identical. Diagnostic audit3016 records both original PNG hashes; neither image is edited.

The transparent alpha0.5 neighbor with otherwise equal geometry has303differentpixels/max13. Phase0.25 matches the same pair of decoded images at scale1. Radius39 has302differences/max6; width9 has313/max13. Thus the measured opaque neighbor narrows the issue toward transparent paint/composition behavior rather than a blanket geometry failure. It does not prove the reviewed root cause; coverage, draw grouping, clips and alpha/color rounding can still interact. Other scales and local-versus-scroll/overflow-visible neighbors are pending.

Whole owner2858 is live and final source checks have not finished. The first opaque result is diagnostic, not full pixel/API/release qualification. No production source change, reference rewrite, fixture-specific correction, tolerance or JavaScript is introduced.
