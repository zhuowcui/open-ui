# Provisional draft2940 conflicts with first reenable observation

Live independent pinned Chromium2941 has completed its first18-scenario run; second/finalsource verification still pending. The diagnostic first run shows readonly prevents commit/cancel without ending the preedit: after readonly is cleared, commit replaces the preview and cancel restores original. Thus draft2940 clearing the readonly session and finishing history would be wrong. Do not apply2940. Preserve it as an uncompiled failed design assumption; wait for whole repeated evidence before selecting the replacement.

Disable and detach close the session; after reenable/reattach, Input.insertText is ordinary committed text appended to preview with beforeinput/input, while imeSetComposition(empty) outside preedit has no extra events. Document::dispatch_composition_end and dispatch_text_input are separate native APIs; do not equate a late native compositionend with generic platform inserted text. App currently maps committed IME platform events to compositionend, which may need adapter proof/normalization for the no-session case. Mapping must use a retained operation contract and no session value/fixture IDs.

No measured source changed, no native compile/runtime result, no API/release qualification. Current2858 whole owner stilllive; keep Main454c/private d11 immutable through whole.
