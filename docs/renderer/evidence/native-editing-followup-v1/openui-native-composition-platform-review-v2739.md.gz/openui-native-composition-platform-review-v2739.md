# Shared composition integration points

Read-only source review at current454c. App::event routes CompositionStart/Update/End to the retained Document. PlatformEvent::Focused(false) currently calls dispatch_composition_cancel. Linux IME adapters use CompositionEnd("") for explicit cancel/reset. C native dispatch uses the same retained Document route.

Pinned Chromium refs2725/2735 establish native element blur/transfer/modal semantics. They do not yet qualify OS window deactivation, input-method reset, disable/remove or replacement of a preedit range. Capture separate appropriate references and real Linux consumers for those states before changing their meaning. Do not equate an explicit platform cancel with implicit element focus transfer.

The shared fix should keep preedit text/history accounting in Engine and ordering/reentrant event handling in Document, release all borrows before callbacks, and expose immutable input/composition metadata to native app callbacks. Input insertCompositionText may be noncancelable while CompositionEvent remains cancelable in the measured Chromium traces; event_type-only flags are insufficient for beforeinput. Existing generation checks protect native object lifetime but cannot erase required reference behavior such as the update-focus-redirection trace.

Explicit dispatch_composition_cancel currently documents no input. The Chromium cancel reference emits a preview-removal input sequence. Resolve this as a native API behavior gap from a consuming-app comparison; updating documentation alone cannot close it. Preserve stale late-commit rejection and undo grouping. All scope/buffer/Rust callback semantics and full static renderer equality still need verification. No framework JavaScript is introduced.
