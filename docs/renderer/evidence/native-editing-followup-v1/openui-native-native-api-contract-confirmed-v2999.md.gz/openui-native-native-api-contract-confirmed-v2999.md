# Confirmed native application contract

Open UI is a native framework. It never executes JavaScript in this or future versions and provides no eval, script bindings or JavaScript glue. Consuming apps use public Rust Document and Element APIs, signals and Rust callbacks. C uses the same retained engine through the versioned ABI.

Browser reference tests can exercise behavior through JavaScript in a separate Chromium process. Every needed element operation must be implemented in the shared native Rust engine and exposed to the consuming app, including its state changes, events, geometry and rendering. An internal Engine fixture or a test disposition does not complete or waive a missing public API.

Pinned Chromium alone defines expected pixels. Old Open UI screenshots remain historical evidence. The active README, engineering principles, renderer contract, supported-platform contract, roadmap and unsupported-feature document already state these rules; the read-only policy audit v2988 verified them without changing measured sources.

Range replacement references v2897 and v2995 remain behavior obligations. The latter adds eight Unicode cases with scalar-aligned UTF-16 selections that can be converted to native UTF-8/grapheme positions. Both captures repeat byte-identically. This is Chromium evidence only: the native range replacement implementation and asynchronous selection notifications are still uncompiled and unqualified. The former reference also contains an initial split-surrogate selection that the current native selection model cannot represent; it stays explicitly open. No all-API or release completion is claimed.
