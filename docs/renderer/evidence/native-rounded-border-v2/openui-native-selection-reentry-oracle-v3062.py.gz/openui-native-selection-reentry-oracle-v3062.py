import hashlib,json,os,subprocess,sys,tempfile,time
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';NAME='native-selection-reentry-oracle-v3062';OUT=Path('/mnt/e/openui-v02-qualification-d174ea0b')/NAME
assert not OUT.exists() and not (RAW/NAME).exists();OUT.mkdir();(RAW/NAME).symlink_to(OUT,target_is_directory=True)
sys.path.insert(0,str(MAIN/'tools/accountability'));import run_all_pixel_comparisons as capture
sys.path.insert(0,str(MAIN/'tools/qualification'));from renderer_source_identity import repository_source_identity
source=repository_source_identity(MAIN);assert source['clean'] and source['commit']=='187079185c1e701d8995aeb6a72cbdbf49286326'
chrome=MAIN/'chrome/linux-147.0.7727.50/chrome-linux64/chrome';scratch=OUT/'scratch';scratch.mkdir()
variants={
 'cross-a-b':"a.setSelectionRange(2,5,'forward');b.setSelectionRange(0,3,'backward');",
 'cross-b-a':"b.setSelectionRange(0,3,'backward');a.setSelectionRange(2,5,'forward');",
 'reenter-selectionchange-self':"a.addEventListener('selectionchange',()=>a.setSelectionRange(0,3,'forward'),{once:true});a.setSelectionRange(2,5,'forward');",
 'reenter-select-self':"a.addEventListener('select',()=>a.setSelectionRange(0,3,'forward'),{once:true});a.setSelectionRange(2,5,'forward');",
 'reenter-selectionchange-other-pending':"a.addEventListener('selectionchange',()=>b.setSelectionRange(2,5,'forward'),{once:true});a.setSelectionRange(2,5,'forward');b.setSelectionRange(0,3,'backward');",
 'reenter-select-other':"a.addEventListener('select',()=>b.setSelectionRange(0,3,'backward'),{once:true});a.setSelectionRange(2,5,'forward');",
 'detach-on-selectionchange':"a.addEventListener('selectionchange',()=>a.remove(),{once:true});a.setSelectionRange(2,5,'forward');",
 'direction-only':"a.setSelectionRange(1,4,'backward');",
}
cases=[(tag+'-'+name,tag,name,actions) for tag in ['input','textarea'] for name,actions in variants.items()]
report=dict(schema_version=1,source=source,owner_pid=os.getpid(),all_commands_terminal=False,javascript_executed_by_openui=False,script_runs_only_in_offline_chromium=True,release_qualification=False,all_native_apis_qualified=False,native_api_behavior_measured=False,diagnostic_only=True,probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),chrome_sha256=hashlib.sha256(chrome.read_bytes()).hexdigest(),runs=[])
def save():(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
def evaluate(client,expression,await_promise=False):
 r=client.command('Runtime.evaluate',dict(expression=expression,returnByValue=True,awaitPromise=await_promise));assert 'exceptionDetails' not in r,r;return r['result'].get('value')
def barrier(client):return evaluate(client,'new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve(true))))',True)
setup_template=r"""
document.body.innerHTML='<TAG id=a></TAG><TAG id=b></TAG>';
window.a=document.getElementById('a');window.b=document.getElementById('b');window.rows=[];
window.snapshot=()=>({a:{value:a.value,start:a.selectionStart,end:a.selectionEnd,direction:a.selectionDirection,connected:a.isConnected},b:{value:b.value,start:b.selectionStart,end:b.selectionEnd,direction:b.selectionDirection,connected:b.isConnected},active:document.activeElement.id||'body'});
for(const node of [a,b])for(const type of ['select','selectionchange'])node.addEventListener(type,event=>rows.push({type,target:event.target.id,bubbles:event.bubbles,cancelable:event.cancelable,...snapshot()}));
a.value='abcdef';b.value='abcdef';a.focus();a.setSelectionRange(1,4,'forward');b.setSelectionRange(1,4,'forward');true
"""
save()
try:
 for number in [1,2]:
  observations=[]
  for name,tag,variant,actions in cases:
   process=None;client=None
   with tempfile.TemporaryDirectory(prefix='chrome-',dir=scratch) as profile:
    try:
     command=[str(chrome),'--headless','--disable-gpu','--no-sandbox','--no-first-run','--no-default-browser-check','--remote-debugging-port=0','--user-data-dir='+profile,'--window-size=800,687','about:blank'];process=subprocess.Popen(command,env=capture.chrome_environment(str(chrome.parent)),stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True);port=capture._wait_for_devtools_endpoint(profile,process);client=capture._CdpWebSocket(capture._page_websocket_url(port));client.command('Page.enable');client.command('Page.bringToFront');client.command('Emulation.setFocusEmulationEnabled',dict(enabled=True))
     evaluate(client,setup_template.replace('TAG',tag));barrier(client)
     synchronous=evaluate(client,'rows.length=0;'+actions+'({rows:rows.slice(),state:snapshot()})')
     barrier(client)
     observed=evaluate(client,'({rows,state:snapshot()})')
     observations.append(dict(scenario=name,control=tag,variant=variant,synchronous=synchronous,observed=observed))
    finally:capture._close_chromium_client(client);capture._stop_chromium_process(process)
   assert repository_source_identity(MAIN)==source
   report['current_scenario']=name;save()
  report.pop('current_scenario',None)
  path=OUT/('observations-'+str(number)+'.json');path.write_text(json.dumps(observations,sort_keys=True,indent=2)+'\n');report['runs'].append(dict(number=number,scenarios=len(observations),callback_rows=sum(len(x['observed']['rows']) for x in observations),observations_sha256=hashlib.sha256(path.read_bytes()).hexdigest()));save()
 assert (OUT/'observations-1.json').read_bytes()==(OUT/'observations-2.json').read_bytes();report['repeated_observations_identical']=True;report['observed_exit_code']=0
except BaseException as error:report.update(observed_exit_code=1,failure=repr(error));raise
finally:report.update(all_commands_terminal=True,source_after=repository_source_identity(MAIN));report['source_unchanged']=report['source_after']==source;save()
print(json.dumps(dict(all_commands_terminal=True,observed_exit_code=report['observed_exit_code'],scenarios=len(observations),rows=sum(len(r['observed']['rows']) for r in observations))),flush=True)
