# Native selection callback review

Pinned Chromium reference v3062 completes sixteen input/textarea scenarios twice with 58 callback rows, byte-identical observations, actual exit 0 and unchanged Main `18707918`. All synchronous rows are empty. Open UI executes no JavaScript; this separate offline browser reference defines native Rust API and callback obligations.

The earlier single FIFO deferred queue draft v3011 is insufficient. Cross-control mutations deliver both selectionchange notifications in mutation order before both select notifications, also in mutation order. A single alternating selectionchange/select queue would give the wrong sequence.

Selectionchange coalescing remains active until that target's pending notification is delivered. If A's selectionchange callback changes B while B already has a notification pending, B keeps one selectionchange and two select notifications. If A changes itself from its own selectionchange callback, a new selectionchange is delivered before either select callback. A mutation from select instead produces a later selectionchange/select pair. Listeners observe current retained state at delivery, including direction-only selection changes. Removing a still-live element from the document during selectionchange does not drop its queued select notification.

The native implementation needs distinct pending selectionchange tasks and presentation-turn select tasks, target-local coalescing cleared at delivery, snapshot/reentry rules, generation-checked targets, and released engine/listener/task borrows before callbacks. A public owning-thread task barrier and Linux/C integration remain required. A reference pass is not a native API pass. The scalar Unicode range API, direction metadata and composition neighbors remain unfinished.
