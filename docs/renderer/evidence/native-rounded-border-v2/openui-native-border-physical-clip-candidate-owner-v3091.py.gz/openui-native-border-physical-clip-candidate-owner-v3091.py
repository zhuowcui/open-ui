import fcntl,hashlib,importlib.util,json,os,shutil,signal,subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from PIL import Image,ImageChops
MAIN=Path('/home/nero/code/open-ui');ROOT=MAIN/'out/private-native-input-metadata-source-v2767';RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';REF=RAW/'native-rounded-border-oracle-v2732';OUT=Path('/mnt/e/openui-v02-qualification-d174ea0b/native-border-physical-clip-candidate-v3091')
app=json.loads(Path('/tmp/openui-native-rounded-layer-physical-clip-application-v3090.json').read_bytes());assert app['applied_to_private_checkpoint']
for pid in [3507419,3593477,3595040,3598039,3604702,3606925,3608592]:assert not Path('/proc/'+str(pid)).exists()
for name in ['cargo','rustc','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
spec=importlib.util.spec_from_file_location('parallel_identity','/tmp/openui-parallel-source-identity-v3047.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
def identities():
 with ThreadPoolExecutor(max_workers=2) as pool:
  public=pool.submit(module.identity,MAIN);private=pool.submit(module.identity,ROOT);return public.result(),private.result()
public,private=identities();assert public['clean'] and private['clean'] and private['commit']==app['private_commit'];assert public['commit']=='187079185c1e701d8995aeb6a72cbdbf49286326'
assert not OUT.exists();OUT.mkdir();(RAW/OUT.name).symlink_to(OUT,target_is_directory=True)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
report=dict(schema_version=1,source=public,private_source=private,all_commands_terminal=False,steps=[],border_rows=[],source_checks=[],implementation_integrated=False,pixel_qualification=False,all_native_apis_qualified=False,release_qualification=False,javascript_executed_by_openui=False,driver_sha256=sha(__file__),reader_sha256=sha('/tmp/openui-parallel-source-identity-v3047.py'),application=app)
def save():(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
def check(stage):
 p,q=identities();assert p==public and q==private;report['source_checks'].append(dict(stage=stage,source=p,private_source=q));save();print(json.dumps(dict(source_check=stage,unchanged=True)),flush=True)
env=dict(os.environ,CARGO_TARGET_DIR='/mnt/e/openui-v02-cargo-c73754e2/target',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='4',RUST_MIN_STACK='4194304',PYTHONDONTWRITEBYTECODE='1',TMPDIR='/dev/shm')
def run(stage,args):
 path=OUT/(stage+'.log')
 with path.open('xb') as log:
  child=subprocess.Popen(args,cwd=ROOT/'bindings/rust',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);report['current_process']=dict(pid=child.pid,stage=stage);save()
  try:code=child.wait()
  except BaseException:
   if child.poll() is None:os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=20)
   raise
 report.pop('current_process');report['steps'].append(dict(stage=stage,command=args,observed_exit_code=code,log_sha256=sha(path)));save();print(json.dumps(dict(stage=stage,observed_exit_code=code)),flush=True);assert code==0,stage;return path.read_bytes()
save()
try:
 cargo=['cargo','--config',str(ROOT/'bindings/rust/.cargo/config.chromium.toml')]
 metadata=json.loads(run('metadata',cargo+['metadata','--locked','--offline','--format-version','1']));local={p['id']:p for p in metadata['packages'] if p['source'] is None};assert all(Path(p['manifest_path']).resolve().is_relative_to(ROOT.resolve()) for p in local.values())
 # Clean only local framework packages to prove all linked framework artifacts belong to this source.
 run('clean-local',cargo+['clean','--locked']+[arg for pid in local for arg in ['-p',pid]])
 raw=run('build',cargo+['build','--locked','--offline','-p','openui','--example','native_rounded_border','--message-format=json'])
 artifacts=[];seen=set();executable=None
 for line in raw.splitlines():
  if not line.startswith(b'{'):continue
  record=json.loads(line)
  if record.get('reason')!='compiler-artifact' or record['target']['kind']==['custom-build'] or record['package_id'] not in local:continue
  assert not record['fresh'];assert Path(record['target']['src_path']).resolve().is_relative_to(ROOT.resolve());artifacts.append(dict(record=record,sha256={p:sha(p) for p in record['filenames']}));seen.add(local[record['package_id']]['name'])
  if record['target']['name']=='native_rounded_border':executable=record['executable']
 assert {'openui','openui-geometry','openui-style','openui-text','openui-dom','openui-layout','openui-paint','openui-engine'}<=seen and executable
 report['local_artifacts']=artifacts;report['all_linked_framework_artifacts_fresh']=True;border=OUT/'border-native';shutil.copy2(executable,border);report['border_binary_sha256']=sha(border);save();check('after-build')
 refs=json.loads((REF/'receipt.json').read_bytes());assert refs['all_commands_terminal'] and refs['observed_exit_code']==0
 baseline=json.loads((RAW/'native-border-shared-candidate-v3053/receipt.json').read_bytes());assert baseline['all_commands_terminal'] and baseline['observed_exit_code']==0
 for i,row in enumerate(refs['rows']):
  v=row['parameters'];directory=OUT/('border-'+str(i));directory.mkdir();run('border-'+str(i),[str(border),str(directory),str(row['scale']),str(v['phase']),str(v['radius']),str(v['width']),str(v['alpha']),v['attachment'],v['hidden']])
  oracle=REF/(str(row['scale'])+'-'+str(i%7))/'1.png';assert sha(oracle)==row['images'][0]['png_sha256'];native=directory/'openui.png'
  with Image.open(native) as a,Image.open(oracle) as b:
   a=a.convert('RGBA');b=b.convert('RGBA');assert a.size==b.size;da=a.tobytes();db=b.tobytes();delta=ImageChops.difference(a,b);pixels=sum(da[n:n+4]!=db[n:n+4] for n in range(0,len(da),4));bounds=delta.convert('RGB').getbbox();maximum=max(abs(x-y) for x,y in zip(da,db))
  result=dict(index=i,scale=row['scale'],parameters=v,exact=pixels==0,different_pixels=pixels,max_channel_delta=maximum,difference_bounds=list(bounds) if bounds else None,native_png_sha256=sha(native),native_rgba_sha256=hashlib.sha256(da).hexdigest(),oracle_png_sha256=sha(oracle),oracle_rgba_sha256=hashlib.sha256(db).hexdigest(),geometry=json.loads((directory/'geometry.json').read_bytes()),baseline_different_pixels=baseline['border_rows'][i]['different_pixels'])
  assert result['oracle_rgba_sha256']==row['images'][0]['rgba_sha256'];report['border_rows'].append(result);save();print(json.dumps(dict(index=i,scale=row['scale'],different_pixels=pixels,baseline_different_pixels=result['baseline_different_pixels'])),flush=True)
 # A second native process for each parameter row must preserve PNG bytes
 # and callback/geometry records as well as the exact Chromium comparison.
 report['repeat_rows']=[]
 for i,row in enumerate(list(report['border_rows'])):
  v=row['parameters'];directory=OUT/('border-repeat-'+str(i));directory.mkdir()
  run('border-repeat-'+str(i),[str(border),str(directory),str(row['scale']),str(v['phase']),str(v['radius']),str(v['width']),str(v['alpha']),v['attachment'],v['hidden']])
  native=directory/'openui.png';assert sha(native)==row['native_png_sha256']
  assert (directory/'geometry.json').read_bytes()==(OUT/('border-'+str(i))/'geometry.json').read_bytes()
  report['repeat_rows'].append(dict(index=i,native_png_sha256=sha(native),geometry_sha256=sha(directory/'geometry.json'),native_png_and_geometry_byte_identical=True));save()
 report['all_native_repeats_identical']=True
 check('final');report['source_unchanged']=True;report['private_source_unchanged']=True;report['native_matrix_exact']=all(x['exact'] for x in report['border_rows']);report['exact_gains']=sum(x['exact'] and x['baseline_different_pixels']>0 for x in report['border_rows']);report['exact_losses']=sum(not x['exact'] and x['baseline_different_pixels']==0 for x in report['border_rows']);report['worsened']=sum(x['different_pixels']>x['baseline_different_pixels'] for x in report['border_rows']);report['observed_exit_code']=int(not report['native_matrix_exact'])
except BaseException as error:report.update(observed_exit_code=1,failure=repr(error));raise
finally:
 if not report.get('source_unchanged'):
  p,q=identities();report['source_unchanged']=p==public;report['private_source_unchanged']=q==private;report['source_after']=p;report['private_source_after']=q
 report['all_commands_terminal']=True;save()
print(json.dumps(dict(all_commands_terminal=True,observed_exit_code=report['observed_exit_code'],rows=len(report['border_rows']),exact=sum(x['exact'] for x in report['border_rows']))),flush=True)

raise SystemExit(report["observed_exit_code"])
