import fcntl, hashlib, json, subprocess, sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui')
SDK=MAIN
RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1/native-rounded-layer-main-renderer-v3139'
OUT=Path('/tmp/openui-public-rounded-layer-completed-audit-v3171.json')
assert not OUT.exists()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert subprocess.run(['ps','-p','3719941'],capture_output=True).returncode==1
for name in ['cargo','rustc','pixel_compare','rustfmt']:
    assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(2**20),b''):h.update(b)
    return h.hexdigest()
def load(p):return json.loads(Path(p).read_bytes())
receipt=load(RAW/'receipt.json')
assert receipt['all_commands_terminal'] and receipt['stage']=='terminal'
assert receipt['observed_exit_code']==1 and receipt['candidate_nonregression_verified']
assert receipt['source']==receipt['source_after'] and receipt['public_source']==receipt['public_source_after']
for p,h in receipt['source_identity_io_executor']['input_sha256'].items():assert sha(p)==h,p
for step in receipt['steps']:assert sha(RAW/(step['name']+'.log'))==step['log_sha256']
build=load(RAW/'trial/guarded-build/receipt.json')
assert sha(RAW/'trial/guarded-build/receipt.json')==receipt['guarded_build_receipt_sha256']
assert build['all_commands_terminal'] and build['source_unchanged'] and build['renderer_library_provenance_verified']
assert build['source']==build['source_after']==receipt['source'] and build['observed_exit_code']==0
for step in build['steps']:
    assert step['observed_exit_code']==0
    for stream in ['stdout','stderr']:
        assert sha(RAW/'trial/guarded-build'/(step['name']+'.'+stream))==step[stream+'_sha256']
artifact_proof=dict(build['compiled_artifact_sha256'])
for artifact in receipt['native_border_app_artifacts']:
    r=artifact['record'];assert Path(r['manifest_path']).is_relative_to(MAIN)
    assert Path(r['target']['src_path']).is_relative_to(MAIN)
    if r['fresh']:assert all(artifact_proof.get(p)==h for p,h in artifact['sha256'].items())
    artifact_proof.update(artifact['sha256'])
for p,h in artifact_proof.items():assert sha(p)==h,p
assert sha(RAW/'native_rounded_border')==receipt['native_border_app_sha256']

for name,artifacts in build['artifacts'].items():
    for a in artifacts:
        assert a['fresh'] is False,name
        assert Path(a['manifest_path']).is_relative_to(SDK.resolve())
        assert Path(a['target']['src_path']).is_relative_to(SDK.resolve())
assert sha(build['binary'])==build['binary_sha256']
assert sha('/tmp/openui-native-rounded-layer-main-renderer-v3139.py')==receipt['probe_sha256']
assert receipt['source']['commit']=='5b05e1b5283519adfcae5355971f329a49e70aa1'
assert receipt['source_identity_io_executor']['official_current_source_crosscheck']
embedded=load(RAW/'embedded-source-identity.json');assert embedded['source']==receipt['source']
native_dir=RAW/'native-border-app-matrix';native=load(native_dir/'receipt.json')
assert sha(native_dir/'receipt.json')==receipt['native_border_app_matrix_receipt_sha256']
assert native['all_commands_terminal'] and native['observed_exit_code']==0 and native['exact']==native['total']==35
assert native['binary_sha256']==receipt['native_border_app_sha256']
assert len(native['steps'])==70
for step in native['steps']:
    assert step['actual_exit_code']==0
    assert sha(native_dir/(step['name']+'.log'))==step['log_sha256']
reference_dir=MAIN/'out/renderer-evidence/native-viewport-scroll-v1/native-rounded-border-oracle-v2732'
assert sha(reference_dir/'receipt.json')==native['reference_receipt_sha256']
reference=load(reference_dir/'receipt.json')
from PIL import Image
def rgba(p):
    with Image.open(p) as image:return hashlib.sha256(image.convert('RGBA').tobytes()).hexdigest()
for row, ref in zip(native['rows'],reference['rows']):
    folder=reference_dir/(str(ref['scale'])+'-'+str(row['index']%7))
    assert sha(folder/'test.html')==ref['fixture_sha256']
    assert row['exact'] and row['repeats_identical'] and row['parameters']==ref['parameters']
    for observation in row['observations']:
        dest=native_dir/('border-'+str(row['index'])+'-'+str(observation['repeat']))
        assert sha(dest/'openui.png')==observation['native_png_sha256']
        assert rgba(dest/'openui.png')==observation['native_rgba_sha256']==row['reference_rgba_sha256']
        assert sha(dest/'geometry.json')==observation['geometry_sha256']
        assert observation['geometry']==load(dest/'geometry.json') and observation['geometry']['callback_count']==1
        refpng=folder/(str(observation['repeat'])+'.png')
        assert sha(refpng)==ref['images'][observation['repeat']-1]['png_sha256']
        assert rgba(refpng)==ref['images'][observation['repeat']-1]['rgba_sha256']

sys.path.insert(0,'/tmp')
from openui_parallel_source_identity_v3060 import identity
sys.path.insert(0,str(SDK/'tools/qualification'))
from residuals import canonical_sha256
print('Verifying complete source identities and matrix rows',flush=True)
current_source=identity(MAIN);assert current_source==receipt['public_source']==receipt['source']
rows=0; results={}
for suite in ['focused','primitive','full','expanded']:
    path=RAW/'trial'/(suite+'-matrix')/(suite+'-summary.json')
    matrix=load(path); m=receipt['matrices']['trial-'+suite]
    assert sha(path)==m['summary_sha256']
    assert matrix['source']==matrix['source_after']==receipt['source'] and matrix['complete_contract_scope']
    baseline=load(receipt['comparisons'][suite]['baseline_summary'])
    assert sha(receipt['comparisons'][suite]['baseline_summary'])==receipt['comparisons'][suite]['baseline_summary_sha256']
    old={(p['profile'],t['id']):t for p in baseline['profiles'] for t in p['tests']}
    exact=different=errors=gains=losses=worsened=0
    for p in matrix['profiles']:
        assert p['result_sha256']==canonical_sha256(p['tests'])
        for t in p['tests']:
            prior=old.pop((p['profile'],t['id']))
            for field in receipt['comparisons'][suite]['fields']:
                if field.startswith('chromium_'):assert prior[field]==t[field]
            exact+=t['status']=='exact'; different+=t['status']=='different'; errors+=t['status']=='error'
            gains+=prior['status']!='exact' and t['status']=='exact'
            losses+=prior['status']=='exact' and t['status']!='exact'
            worsened+=t['mismatched_pixels']>prior['mismatched_pixels']
    assert not old and errors==0 and losses==0 and worsened==0
    assert exact==matrix['results']['exact'] and exact+different==matrix['results']['total']
    assert gains==receipt['comparisons'][suite]['exact_gains']
    results[suite]=dict(total=exact+different,exact=exact,different=different,errors=errors,gains=gains,losses=losses,worsened=worsened,actual_exit_code=m['observed_exit_code'])
    rows+=exact+different
out=dict(schema_version=1,owner_terminal=True,actual_whole_exit_code=1,all_source_bytes_unchanged=True,compiled_artifacts_verified=len(artifact_proof),fresh_local_packages=len(build['artifacts']),logs_verified=len(receipt['steps'])+2*len(build['steps']),matrix_rows_verified=rows,chromium_reference_fields_unchanged=True,extra_executor_inputs_verified=True,pixel_tolerance=0,results=results,public_combined_source_nonregression=True,implementation_integrated=True,native_border_exact=35,native_border_repeated_commands=70,all_native_apis_qualified=False,release_qualified=False,javascript_executed_by_openui=False,receipt_sha256=sha(RAW/'receipt.json'))
OUT.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
print(json.dumps(out),flush=True)
