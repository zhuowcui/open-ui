import json
import os
from pathlib import Path

ROOT = Path('/home/nero/code/open-ui')
load = lambda p: json.loads(Path(p).read_bytes())
e = load(ROOT / 'docs/renderer/generated/native-monochrome-strikes-v2.json')
r = e['renderer']
assert e['all_local_commands_terminal'] and not r['candidate_nonregression']
assert e['source']['commit'] == '40ff617878f8288eddc61fe7b783e3e1b71ca438'
full = r['results']['full']
expanded = r['results']['expanded']
assert full['actual_exit_code'] == expanded['actual_exit_code'] == 1
assert full['errors'] == expanded['errors'] == 0

def atomic(path, text):
    tmp = path.with_name(path.name + '.monochrome-clean.tmp')
    assert not tmp.exists()
    tmp.write_text(text)
    os.replace(tmp, path)

for file, level, link in [
    ('README.md', '###', 'docs/renderer/generated/'),
    ('docs/progress/current-status.md', '###', '../renderer/generated/'),
    ('docs/renderer/contract.md', '##', 'generated/'),
    ('docs/v02/release.md', '##', '../renderer/generated/'),
]:
    p = ROOT / file
    text = p.read_text()
    start = text.index(level + ' Monochrome text candidate\n')
    end = text.index(level + ' Previous complete checkpoint\n', start)
    block = f'''{level} Monochrome text regression (rejected)

Fresh CPU verification at clean `40ff6178` is exact on focused **640/640**
and primitive **960/960** comparisons. Original **{full['exact']:,}/22,924**
and expanded **{expanded['exact']:,}/23,728** are exact, with zero render errors.
The full pixel gates still exit 1 for **{full['different']:,} / {expanded['different']:,} differences**.
All **48,252 rows** and fresh compiled artifacts are audited. There are
{full['gains']} exact gains but **{full['losses']} exact losses and {full['worsened']} worsened comparisons**
in each full census. Chromium reference fields are unchanged. This candidate
is rejected for complete renderer qualification; the smaller passing suites
did not catch its effect on existing rotated and ruby text.

The [native Rust consumer]({'bindings/rust/openui/examples/native_shaping_wrap.rs' if file == 'README.md' else '../../bindings/rust/openui/examples/native_shaping_wrap.rs'})
changes widths through a Rust click callback. All **10/10 whole images** and
**70/70 bounds** match unchanged, independently repeated pinned Chromium
captures at the four required profiles and a 3× neighbor. Separate process
and unchanged-frame repeats, the callback count and weak teardown pass.
Hinted author monochrome strikes use Fontations-compatible outlines;
explicitly unhinted resolved strikes retain their original font.

All **8,642 locked all-targets tests** and **8,644 workspace and documentation
tests** pass with every feature enabled, with zero failures and 13 existing
workspace ignores. All **30 C and 24 C++ consumers** pass, preserving **131
exports and 34 layouts**. Format checks, ordinary CI and all seven explicitly
dispatched hardening jobs pass on the same source:
[hardening run 38082198110](https://github.com/zhuowcui/open-ui/actions/runs/38082198110).

The earlier rejected font variants and dirty diagnostics remain preserved in
[candidate evidence]({link}native-monochrome-strikes-v1.json).
Repairing this raster-policy regression, full Chromium equality, reviewed
residual ownership, generic font-family
shaping, remaining native APIs, compositor, physical lab and release
qualification remain open. Open UI never executes JavaScript; native apps
use public Rust APIs and Rust callbacks over the shared Engine.
[Completed failed census and clean checks]({link}native-monochrome-strikes-v2.json).

'''
    text = text[:start] + block + text[end:]
    text = text.replace(level + ' Previous complete checkpoint\n',
                        level + ' Previous wrapping checkpoint\n', 1)
    atomic(p, text)

p = ROOT / 'docs/v02/supported-platforms.md'
text = p.read_text()
start = text.index('The new monochrome font candidate matches all 10 images')
end = text.index('\n## No JavaScript runtime', start)
text = text[:start] + '''Clean `40ff6178` closes those measured glyph differences: all **10/10
images and 70/70 bounds** match unchanged Chromium captures, including the 3×
neighbor, with stable process and unchanged-frame repeats. Fresh complete
focused and primitive suites are exact; workspace, C/C++ consumers and all
seven hosted hardening jobs pass on the same source. The original and expanded
pixel gates regress by 16 lost exact comparisons and 34 worsened differences;
this font candidate is rejected for complete renderer qualification. Generic
font-family shaping and every remaining needed
native API remain implementation work.
[Completed failed census and clean checks](../renderer/generated/native-monochrome-strikes-v2.json).
''' + text[end:]
atomic(p, text)

p = ROOT / 'docs/v02/unsupported-features.md'
text = p.read_text()
old = '''- logical wrapping across shaping runs matches all 70 measured native bounds.
  The new font candidate also matches all ten images in dirty-source diagnostics;
  fresh clean complete renderer/workspace/ABI/hosted qualification remains pending.
  [Font candidate evidence](../renderer/generated/native-monochrome-strikes-v1.json).
'''
assert text.count(old) == 1
text = text.replace(old, '''- clean `40ff6178` matches all ten measured native shaping images and 70
  bounds. Focused/primitive pixels, workspace, ABI consumers and all seven
  hosted hardening jobs pass, but the complete Chromium gates lose 16 exact
  comparisons and worsen 34 differences. The font candidate is rejected
  pending repair of its effect on rotated and ruby text.
  [Failed full census and clean checks](../renderer/generated/native-monochrome-strikes-v2.json).
''')
atomic(p, text)

summary_root = Path('/mnt/d/openui-v02-qualification-d174ea0b/native-monochrome-renderer-v3760')
original = load(summary_root / 'full-matrix/full-summary.json')
extra = load(summary_root / 'expanded-matrix/expanded-summary.json')
original_ids = {t['id'] for profile in original['profiles'] for t in profile['tests']}
residual_ids = {t['id'] for profile in original['profiles'] for t in profile['tests'] if t['status'] != 'exact'}
extra_rows = {}
for profile in extra['profiles']:
    for test in profile['tests']:
        if test['id'] not in original_ids:
            extra_rows.setdefault(test['id'], []).append(test['status'])
assert len(extra_rows) == 201 and all(len(statuses) == 4 for statuses in extra_rows.values())
extra_exact = sum(all(status == 'exact' for status in statuses) for statuses in extra_rows.values())

def update_rows(path, replacements):
    lines = path.read_text().splitlines(keepends=True)
    for prefix, row in replacements.items():
        matches = [i for i, line in enumerate(lines) if line.startswith(prefix)]
        assert len(matches) == 1, prefix
        lines[matches[0]] = row + '\n'
    atomic(path, ''.join(lines))

link = '[Completed rejected font checkpoint](../renderer/generated/native-monochrome-strikes-v2.json)'
update_rows(ROOT / 'docs/progress/current-status.md', {
    '| Latest complete clean umbrella census |': f'| Latest complete clean umbrella census | {link} at `40ff6178`: {full["exact"]:,}/22,924 exact, {full["different"]:,} different, 0 errors; expanded {expanded["exact"]:,}/23,728 exact, {expanded["different"]:,} different; both actual exits 1; {len(residual_ids)} residual original IDs |',
    '| Last accepted complete clean census against cached Chromium captures |': '| Previous native event census | `1c8540e9`: 21,334/22,924 exact, 1,590 different, 0 errors; expanded 22,137/23,728 exact, 1,591 different, 0 errors. Historical measurement; both pixel gates failed |',
    '| Focused / primitive 40-profile matrices |': f'| Focused / primitive 40-profile matrices | 640/640 / 960/960 exact at clean `40ff6178`; all 1,600 native images and Chromium reference fields unchanged from the previous matrices. {link} |',
    '| Expanded native final-state additions |': f'| Expanded native final-state additions | {extra_exact}/201 additional cases exact at all four profiles in the clean `40ff6178` run |',
    '| Pending native final-state candidates |': '| Pending native final-state candidates | 35 AST-lowered cases remain outside this clean manifest; [earlier pending recheck](../renderer/generated/pending-mutation-candidates-v7.json) does not qualify them on `40ff6178` |',
    '| Frozen / current C exports |': f'| Frozen / current C exports | 84 / 131; 34 current ABI layouts; clean `40ff6178` source preserves existing symbols and layouts. {link} |',
    '| C examples / C++ consumers |': f'| C / C++ consumers | 30 / 24 pass on clean `40ff6178`; hosted X11/Wayland conformance passes on the same source. Physical release lab remains open. {link} |',
    '| Workspace tests |': f'| Workspace tests | 8,642 all-targets and 8,644 workspace/documentation pass with all features at clean `40ff6178`; 0 failed, 13 existing workspace ignores. {link} |',
})
update_rows(ROOT / 'docs/v02/release.md', {
    '| Four-profile renderer matrix |': f'| Four-profile renderer matrix | {link} at clean `40ff6178`: {full["exact"]:,}/22,924 exact, {full["different"]:,} different, zero errors; actual exit 1. All Chromium inputs stay fixed; {len(residual_ids)} residual original IDs need closure | fail |',
    '| Focused and primitive raster |': f'| Focused and primitive raster | {link} at clean `40ff6178`: 640/640 focused and 960/960 primitive exact; all 1,600 native images and Chromium reference fields remain unchanged | source-attributed scoped pass |',
    '| Expanded native final-state fixtures |': f'| Expanded native final-state fixtures | {link} at clean `40ff6178`: {expanded["exact"]:,}/23,728 exact, {expanded["different"]:,} different, zero errors; actual exit 1. {extra_exact}/201 additions exact at all four profiles. The other 35 AST-lowered cases remain [pending](../renderer/generated/pending-mutation-candidates-v7.json). Open UI runs no JavaScript | open |',
    '| Rust workspace and docs |': f'| Rust workspace and docs | {link} at clean `40ff6178`: 8,642 all-targets and 8,644 workspace/documentation tests pass, zero failed, 13 existing workspace ignores; 30 C and 24 C++ consumers pass, with 131 exports and 34 layouts | scoped verification pass; full pixel gates fail |',
    '| Rust 1.85 MSRV |': '| Rust 1.85 MSRV | [Same-source explicit hardening](https://github.com/zhuowcui/open-ui/actions/runs/38082198110): MSRV job passes at `40ff6178`; all seven jobs succeed, zero skips | pass |',
    '| Rust/C application contract |': f'| Rust/C application contract | 58 conformance scenarios; 131 current exports and 34 layouts, with all preceding symbols and layouts preserved. Clean `40ff6178` build and 30 C/24 C++ consumers pass; same-source hosted conformance passes | scoped verification pass; remaining API review and physical lab qualification open |',
})
print('Updated six documents and their current measurement tables from the completed rejected checkpoint.', flush=True)
