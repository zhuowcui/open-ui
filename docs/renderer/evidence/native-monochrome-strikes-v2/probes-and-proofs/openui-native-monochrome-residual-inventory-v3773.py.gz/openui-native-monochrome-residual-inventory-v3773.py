import collections
import hashlib
import json
from pathlib import Path

ROOT = Path('/home/nero/code/open-ui')
OUT = Path('/mnt/d/openui-v02-qualification-d174ea0b/native-monochrome-renderer-v3760')
DEST = Path('/tmp/openui-native-monochrome-residual-inventory-v3773.json')
load = lambda p: json.loads(Path(p).read_bytes())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
r = load(OUT / 'receipt.json')
a = load('/tmp/openui-native-monochrome-renderer-completed-audit-v3761.json')
assert r['all_commands_terminal'] and a['complete']
p = OUT / 'full-matrix/full-summary.json'
assert sha(p) == r['matrices']['full']['summary_sha256']
m = load(p)
assert m['source'] == a['source'] and m['source']['clean']
rows = [(profile['profile'], test) for profile in m['profiles'] for test in profile['tests'] if test['status'] != 'exact']
assert len(rows) == m['results']['different'] and m['results']['errors'] == 0
ids = sorted({test['id'] for _, test in rows})
ledger = ROOT / 'tools/qualification/residual-ownership-v2.json'
entries = {e['test_id']: e for e in load(ledger)['entries']}
matched = sorted(set(ids) & entries.keys())
missing = sorted(set(ids) - entries.keys())
assert not DEST.exists()
result = dict(schema_version=1, source=m['source'], full_summary_sha256=sha(p),
              renderer_completed_audit_sha256=sha('/tmp/openui-native-monochrome-renderer-completed-audit-v3761.json'),
              ownership_ledger_sha256=sha(ledger), remaining_comparisons=len(rows),
              remaining_test_ids=len(ids),
              test_directory_counts=dict(collections.Counter(test['id'].split('/')[1] for _, test in rows).most_common()),
              classification_kind='source directory only; does not assign root cause or ownership',
              reviewed_ledger_entries=len(entries), residual_ids_with_ledger_entry=matched,
              residual_ids_without_ledger_entry=missing,
              ownership_gate_passed=not missing, renderer_qualified=False,
              all_native_apis_qualified=False, release_qualified=False,
              pixel_target='pinned Chromium', pixel_tolerance=0, javascript_executed_by_openui=False)
DEST.write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
print(json.dumps(dict(remaining_comparisons=len(rows), remaining_test_ids=len(ids),
                      ids_without_reviewed_ledger_entry=len(missing), output=str(DEST))), flush=True)
