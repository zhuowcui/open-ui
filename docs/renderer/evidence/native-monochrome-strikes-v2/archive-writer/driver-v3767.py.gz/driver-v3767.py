import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path('/home/nero/code/open-ui')
BASE = Path('/mnt/d/openui-v02-qualification-d174ea0b')
DEST = ROOT / 'docs/renderer/evidence/native-monochrome-strikes-v2'
INDEX = ROOT / 'docs/renderer/generated/native-monochrome-strikes-v2.json'
load = lambda p: json.loads(Path(p).read_bytes())
sha = lambda b: hashlib.sha256(b).hexdigest()
native = load('/tmp/openui-native-monochrome-clean-terminal-v3759.json')
renderer = load('/tmp/openui-native-monochrome-renderer-completed-audit-v3761.json')
native_reaped = load('/tmp/openui-native-monochrome-clean-reaped-v3763.json')
renderer_reaped = load('/tmp/openui-native-monochrome-renderer-reaped-v3768.json')
assert native['source'] == renderer['source'] and native['source']['clean']
assert native['native_exact_images'] == 10 and native['native_exact_bounds'] == 70
assert native['actual_owner_exit_code'] == 0 and renderer['complete']
assert renderer['matrix_rows_verified'] == 48252
assert not renderer['candidate_nonregression']
for record in [native_reaped, renderer_reaped]:
    assert record['all_local_commands_terminal'] and record['owners_absent']
assert not DEST.exists() and not INDEX.exists()
DEST.mkdir(parents=True)
members = []
excluded = []

def add(data, name):
    p = DEST / name
    compressed = not name.endswith('.png')
    stored = gzip.compress(data, mtime=0) if compressed else data
    if compressed:
        p = p.with_name(p.name + '.gz')
    p.parent.mkdir(parents=True, exist_ok=True)
    assert not p.exists()
    p.write_bytes(stored)
    reread = p.read_bytes()
    assert reread == stored
    assert (gzip.decompress(reread) if compressed else reread) == data
    members.append(dict(path=str(p.relative_to(ROOT)), bytes=len(stored),
                        sha256=sha(stored), raw_bytes=len(data), raw_sha256=sha(data),
                        compression='gzip' if compressed else 'none'))

d = BASE / 'native-monochrome-clean-checks-v3758'
for p in sorted(d.rglob('*')):
    if not p.is_file():
        continue
    if p.name == 'native_shaping_wrap':
        excluded.append(dict(path=str(p), bytes=p.stat().st_size,
                             sha256=sha(p.read_bytes()), reason='owned native executable; exact compiler provenance and hash preserved'))
        continue
    add(p.read_bytes(), 'native/' + str(p.relative_to(d)))

d = BASE / 'native-shaping-wrap-candidate-chromium-v3696'
add((d / 'receipt.json').read_bytes(), 'immutable-reference/receipt.json')
for p in sorted(d.glob('profile-*/*')):
    if p.is_file() and (p.name == 'test.html' or p.name.startswith('chromium-')):
        add(p.read_bytes(), 'immutable-reference/' + str(p.relative_to(d)))

d = BASE / 'native-monochrome-renderer-v3760'
b = load(d / 'guarded-build/receipt.json')
excluded.append(dict(path=b['binary'], sha256=b['binary_sha256'],
                     reason='owned renderer executable; exact compiler provenance and hash preserved'))
for p in sorted(d.iterdir()):
    if p.is_file():
        add(p.read_bytes(), 'renderer/' + p.name)
for p in sorted((d / 'guarded-build').iterdir()):
    if p.is_file() and p.name != 'pixel_compare':
        add(p.read_bytes(), 'renderer/guarded-build/' + p.name)
for suite in ['focused', 'primitive', 'full', 'expanded']:
    add((d / (suite + '-matrix') / (suite + '-summary.json')).read_bytes(),
        'renderer/' + suite + '-summary.json')

for name in [
    'openui-native-monochrome-clean-checks-v3758.py',
    'openui-native-monochrome-clean-audit-v3759.py',
    'openui-native-monochrome-clean-terminal-v3759.json',
    'openui-native-monochrome-clean-reaped-v3763.json',
    'openui-native-monochrome-renderer-v3760.py',
    'openui-native-monochrome-renderer-audit-v3761.py',
    'openui-native-monochrome-renderer-completed-audit-v3761.json',
    'openui-native-monochrome-renderer-reaped-v3768.json',
    'openui-native-monochrome-hosted-v3762.json',
    'openui-native-monochrome-hosted-v3765.json',
    'openui-native-monochrome-hardening-v3766.json',
    'openui-native-monochrome-hosted-complete-v3772.json',
    'openui-native-monochrome-prior-inventory-v3764.json',
    'openui-native-monochrome-residual-inventory-v3773.py',
    'openui-native-monochrome-residual-inventory-v3773.json',
    'openui-native-font-family-gates-review-v3771.json',
    'openui-native-monochrome-renderer-reaping-v3768.py',
    'openui_parallel_source_identity_v3060.py',
]:
    add((Path('/tmp') / name).read_bytes(), 'probes-and-proofs/' + name)

for path in ['bindings/rust/openui-paint/src/text_painter.rs',
             'bindings/rust/openui-text/src/shaping/shape_result.rs',
             'bindings/rust/openui/examples/native_shaping_wrap.rs']:
    add((ROOT / path).read_bytes(), 'measured-source/' + path)

hosted = load('/tmp/openui-native-monochrome-hardening-v3766.json')['data']
assert hosted['headSha'] == native['source']['commit']
assert hosted['conclusion'] == 'success' and len(hosted['jobs']) == 7
assert all(j['status'] == 'completed' and j['conclusion'] == 'success' for j in hosted['jobs'])
hosted_runs = load('/tmp/openui-native-monochrome-hosted-complete-v3772.json')
assert len(hosted_runs) == 3
assert all(h['actual_exit_code'] == 0 and h['data']['headSha'] == native['source']['commit'] and h['data']['conclusion'] == 'success' and all(j['conclusion'] == 'success' for j in h['data']['jobs']) for h in hosted_runs)
result = dict(
    schema_version=2, status='rejected-renderer-regression-clean-measurement',
    diagnostic_only=False, source=native['source'], native=native, renderer=renderer,
    hosted_hardening=dict(head=hosted['headSha'], url=hosted['url'],
                         conclusion=hosted['conclusion'],
                         jobs=[dict(name=j['name'], conclusion=j['conclusion'], url=j['url']) for j in hosted['jobs']]),
    all_local_commands_terminal=True, all_members_hash_verified=True,
    pixel_target='pinned Chromium', pixel_tolerance=0,
    javascript_executed_by_openui=False, historical_openui_archive_is_a_pixel_target=False,
    full_renderer_contract_qualified=False, all_native_apis_qualified=False, release_qualified=False,
    residual_inventory=load('/tmp/openui-native-monochrome-residual-inventory-v3773.json'),
    hosted_checks=[dict(run=h['run'], head=h['data']['headSha'], conclusion=h['data']['conclusion'], url=h['data']['url'], jobs=[dict(name=j['name'], conclusion=j['conclusion'], url=j['url']) for j in h['data']['jobs']]) for h in hosted_runs],
    prior_candidate_evidence='docs/renderer/generated/native-monochrome-strikes-v1.json',
    pending=['repair raster policy regression before accepting the font candidate',
             'remaining original and expanded pixel differences',
             'reviewed residual ownership and reduced native reproducers',
             'generic font-family shaping and remaining native APIs',
             'compositor, physical lab and release qualification'],
    archive=dict(files=len(members), bytes=sum(m['bytes'] for m in members), members=members, excluded=excluded))
INDEX.write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
print(json.dumps(dict(files=len(members), bytes=result['archive']['bytes'], index=str(INDEX))), flush=True)
