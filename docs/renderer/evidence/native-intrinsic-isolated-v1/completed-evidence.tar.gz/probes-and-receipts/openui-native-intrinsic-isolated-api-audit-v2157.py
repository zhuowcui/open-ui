"""Compare two repeated native sources with the same immutable Chromium observer."""
import collections,hashlib,json
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';OUT=RAW/'native-intrinsic-isolated-api-audit-v2157.json';assert not OUT.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
owner_path=RAW/'native-intrinsic-isolated-pipeline-v2155/receipt.json';owner=json.loads(owner_path.read_bytes());assert owner['all_commands_terminal'] and owner['source_unchanged'] and owner['native_intrinsic_app_source_unchanged']
baseline_path=owner_path;baseline_owner=owner
assert owner['public_baseline_app_source_unchanged'] and owner['public_baseline_sdk_source_unchanged']
assert owner['public_baseline_sdk_source']['clean']
oracle_path=RAW/'native-intrinsic-api-chromium-v2052/receipt.json';oracle=json.loads(oracle_path.read_bytes());assert oracle['all_commands_terminal'] and oracle['observed_exit_code']==0 and oracle['source_unchanged']
keys=['kind','scale','family','size','writing','text','position','decorated','scenario'];key=lambda r:tuple(r.get(k) for k in keys)
bylabel={}
for label in ['baseline','current']:
 if label=='baseline':
  first=owner_path.parent/'public-baseline-first.log';second=owner_path.parent/'public-baseline-second.log'
 else:
  first=owner_path.parent/'native-intrinsic-app-first.log';second=owner_path.parent/'native-intrinsic-app-second.log'
 assert first.read_bytes()==second.read_bytes()
 rows=[json.loads(line) for line in first.read_text().splitlines()];assert len(rows)==3690
 bylabel[label]={key(r):r for r in rows};assert len(bylabel[label])==3690
counts=collections.Counter();groups=collections.defaultdict(collections.Counter);rows=[]
for profile in oracle['profiles']:
 for obs in profile['observations']:
  prototype=obs['native_case'];chrome=obs['chromium'];old=bylabel['baseline'].pop(key(prototype));new=bylabel['current'].pop(key(prototype));fields=['natural','minimum'] if old['kind']=='original' else ['before','after'];axis='width' if old['writing']=='horizontal-tb' else 'height'
  for field in fields:
   old_exact=old[field]==chrome[field];new_exact=new[field]==chrome[field];old_inline=old[field][axis]==chrome[field][axis];new_inline=new[field][axis]==chrome[field][axis]
   values=dict(states=1,baseline_full_rect_exact=int(old_exact),full_rect_exact=int(new_exact),baseline_inline_axis_exact=int(old_inline),inline_axis_exact=int(new_inline),full_rect_gains=int(new_exact and not old_exact),full_rect_losses=int(old_exact and not new_exact),inline_axis_gains=int(new_inline and not old_inline),inline_axis_losses=int(old_inline and not new_inline))
   counts.update(values)
   for label in [old['kind'],old['family'],old['writing'],str(old['size']),old.get('scenario','text:'+old.get('text',''))]:groups[label].update(values)
   rows.append(dict(case={k:old[k] for k in keys if k in old},state=field,baseline=old[field],native=new[field],chromium=chrome[field],baseline_full_rect_exact=old_exact,full_rect_exact=new_exact,baseline_inline_axis_exact=old_inline,inline_axis_exact=new_inline))
assert all(not rows for rows in bylabel.values()) and len(rows)==7380
report=dict(schema_version=1,source=owner['source'],baseline_source=owner['public_baseline_sdk_source'],geometry_only_diagnostic=True,native_pixels_captured=False,release_qualification=False,promotion_allowed=False,new_release_states_admitted=0,javascript_executed_by_openui=False,viewport_policy_matched=True,earlier_unmatched_viewport_results_preserved=True,oracle_receipt_sha256=sha(oracle_path),native_receipt_sha256=sha(owner_path),baseline_native_receipt_sha256=sha(baseline_path),current_public_native_consumers_have_identical_rust_source=True,totals=dict(counts),groups={k:dict(v) for k,v in sorted(groups.items())},observations=rows,probe_sha256=sha(Path(__file__)))
OUT.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(path=str(OUT),sha256=sha(OUT),totals=dict(counts))),flush=True)
