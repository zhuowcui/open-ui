"""Revalidate both complete trees and finish the failed relocation with stable paths."""
import concurrent.futures,fcntl,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');original=MAIN/'out/column-start-clean-expanded-v3'
target=Path('/mnt/e/openui-v02-qualification-d174ea0b/terminal-expanded-results-relocated-v2154')
backup=original.with_name('column-start-clean-expanded-v3-verified-backup-v2165')
receipt=Path('/tmp/openui-terminal-matrix-verified-finish-v2165.json')
assert not receipt.exists() and not backup.exists() and not original.is_symlink()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','ninja','pixel_compare','chrome']:
 assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
sys.path.insert(0,str(MAIN/'tools/qualification'));from renderer_source_identity import repository_source_identity
source=repository_source_identity(MAIN);assert source['clean']
audit_path=Path('/tmp/openui-terminal-matrix-filelist-audit-v2162.json');audit=json.loads(audit_path.read_bytes());assert audit['file_sets_exact'] and audit['failed_assertion_compared_two_different_sort_orders']
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(2**20),b''):h.update(chunk)
 return h.hexdigest()
files=sorted((p for p in original.rglob('*') if p.is_file()),key=lambda p:str(p.relative_to(original)))
assert len(files)==audit['expected_files']==71173 and all(not p.is_symlink() for p in files)
def verify(p):
 relative=str(p.relative_to(original));q=target/relative
 before=sha(p);after=sha(q);size=p.stat().st_size
 assert before==after and q.stat().st_size==size
 return dict(path=relative,bytes=size,source_sha256=before,target_sha256=after)
records=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=16) as pool:
 for count,row in enumerate(pool.map(verify,files),1):
  records.append(row)
  if count%10000==0:print(json.dumps(dict(stage='fresh-source-and-target-byte-audit',files=count)),flush=True)
assert repository_source_identity(MAIN)==source
original.rename(backup);original.symlink_to(target,target_is_directory=True)
assert original.resolve()==target and sha(original/'expanded-summary.json')==next(r['source_sha256'] for r in records if r['path']=='expanded-summary.json')
shutil.rmtree(backup)
assert repository_source_identity(MAIN)==source
report=dict(schema_version=1,all_commands_terminal=True,source_before=source,source_after=repository_source_identity(MAIN),failed_copy_probe_preserved='/tmp/openui-terminal-matrix-relocation-v2154.py',failed_copy_actual_exit=1,filelist_audit_path=str(audit_path),filelist_audit_sha256=sha(audit_path),file_sets_exact=True,files=len(records),bytes=sum(r['bytes'] for r in records),records=records,original_path=str(original),relocated_path=str(target),original_paths_preserved=True,all_files_byte_identical=True,reference_bytes_rewritten=0,cargo_or_native_queries_started=0,release_qualification=False,home_free_after=shutil.disk_usage(MAIN).free,probe_sha256=sha(Path(__file__)))
receipt.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(files=report['files'],bytes=report['bytes'],all_files_byte_identical=True,home_free=report['home_free_after'])),flush=True)
