"""Compare the complete clean candidate with accepted rows and native references."""
import hashlib, json, sys
from pathlib import Path

MAIN = Path('/home/nero/code/open-ui')
RAW = MAIN / 'out/renderer-evidence/native-viewport-scroll-v1'
OUT = RAW / 'native-intrinsic-isolated-renderer-audit-v2159.json'
assert not OUT.exists()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_bytes())
sys.path.insert(0, str(MAIN / 'tools/qualification'))
from residuals import canonical_sha256

owner_path = RAW / 'native-intrinsic-isolated-pipeline-v2155/receipt.json'
owner = load(owner_path)
assert owner['all_commands_terminal'] and owner['source_unchanged']
assert owner['source'] == owner['source_after'] and owner['source']['clean']
assert owner['strict_rgba_guard_actually_executed'] and owner['native_fractional_line_height_guard_actually_executed']
assert owner['native_intrinsic_guard_actually_executed']
report = dict(schema_version=1, source=owner['source'], all_commands_terminal=True,
              release_qualification=False, promotion_allowed=False, pixel_tolerance=0,
              javascript_executed_by_openui=False, new_release_states_admitted=0,
              whole_owner_receipt_sha256=sha(owner_path), suites={},
              formal_original_residual_ownership_unchanged=True, probe_sha256=sha(Path(__file__)))
invariants = ['openui_png_sha256', 'openui_rgba_sha256', 'chromium_png_sha256',
              'chromium_rgba_sha256', 'chromium_oracle_identity_sha256',
              'chromium_oracle_rgba_sha256', 'status', 'mismatched_pixels', 'diff_signature']
for suite, total in [('full', 22924), ('expanded', 23728), ('focused', 640), ('primitive', 960)]:
    current_path = owner_path.parent / (suite + '-matrix') / (suite + '-summary.json')
    old_path = RAW / ('native-event-targets-clean-' + suite + '-v1456') / (suite + '-summary.json')
    current, old = load(current_path), load(old_path)
    assert current['source'] == current['source_after'] == owner['source']
    assert current['results']['total'] == total and current['results']['errors'] == 0
    assert current['results']['profile_result_sha256'] == canonical_sha256([r['result_sha256'] for r in current['profiles']])
    for profile in current['profiles']:
        assert profile['result_sha256'] == canonical_sha256(profile['tests'])
    flatten = lambda d: {(p['profile'], r['id']): r for p in d['profiles'] for r in p['tests']}
    before, after = flatten(old), flatten(current)
    assert before.keys() == after.keys() and len(after) == total
    changes = []
    for key, row in after.items():
        previous = before[key]
        assert all(row[n] == previous[n] for n in invariants[2:6]), 'immutable Chromium input changed'
        changed = [n for n in invariants if row[n] != previous[n]]
        if changed:
            changes.append(dict(profile=key[0], id=key[1], changed_fields=changed,
                                prior_status=previous['status'], status=row['status'],
                                prior_mismatched_pixels=previous['mismatched_pixels'],
                                mismatched_pixels=row['mismatched_pixels'],
                                more_wrong_pixels=row['mismatched_pixels'] > previous['mismatched_pixels'],
                                exact_loss=previous['status'] == 'exact' and row['status'] != 'exact',
                                exact_gain=previous['status'] != 'exact' and row['status'] == 'exact'))
    report['suites'][suite] = dict(results=current['results'],
                                  actual_exit=owner['matrices'][suite]['observed_exit_code'],
                                  summary_sha256=sha(current_path), prior_summary_sha256=sha(old_path),
                                  comparisons=total, immutable_chromium_rows=total,
                                  changed_comparisons=changes,
                                  worsened_comparisons=sum(r['more_wrong_pixels'] for r in changes),
                                  exact_losses=sum(r['exact_loss'] for r in changes),
                                  exact_gains=sum(r['exact_gain'] for r in changes))
    del current, old, before, after

geometry_path = RAW / 'native-intrinsic-isolated-api-audit-v2157.json'
geometry = load(geometry_path)
assert geometry['source'] == owner['source'] and geometry['baseline_source'] == owner['public_baseline_sdk_source']
report.update(native_geometry_only=True, native_pixel_qualification=False,
              native_geometry_receipt_sha256=sha(geometry_path), native_geometry_totals=geometry['totals'],
              observed_exit_code=int(any(s['exact_losses'] or s['worsened_comparisons'] for s in report['suites'].values()) or geometry['totals']['full_rect_losses']))
OUT.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(receipt_sha256=sha(OUT),native_geometry=report['native_geometry_totals'],
    suites={name:{k:row[k] for k in ['comparisons','exact_losses','exact_gains','worsened_comparisons']} | {'exact':row['results']['exact'],'different':row['results']['different'],'errors':row['results']['errors'],'changed_rows':len(row['changed_comparisons'])} for name,row in report['suites'].items()})),flush=True)
raise SystemExit(report['observed_exit_code'])
