"""Prepare the complete shared sizing measurement in a separate immutable checkout."""
import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');BASE=MAIN/'out/private-native-api-isolated-v2150';ROOT=MAIN/'out/private-native-api-shaped-v2168';APP=MAIN/'out/private-native-apps/native-intrinsic-shaped-v2169';OLDAPP=MAIN/'out/private-native-apps/native-intrinsic-isolated-v2151';PATCH=Path('/tmp/openui-native-intrinsic-shaped-change-v2170.patch')
OUT=Path('/tmp/openui-native-intrinsic-shaped-prepare-v2168.json');assert not ROOT.exists() and not APP.exists() and not OUT.exists()
sys.path.insert(0,str(MAIN/'tools/qualification'));from renderer_source_identity import repository_source_identity
before=repository_source_identity(BASE);public=repository_source_identity(MAIN);assert before['clean'] and before['commit']=='48af2cf497c23dcc004e88821f1b05d49eea9cfe' and public['clean']
subprocess.run(['git','clone','--shared','--no-checkout',str(BASE),str(ROOT)],check=True,capture_output=True)
for name in ['user.name','user.email']:
 value=subprocess.check_output(['git','config','--get',name],cwd=MAIN,text=True).strip();subprocess.run(['git','config',name,value],cwd=ROOT,check=True,capture_output=True)
subprocess.run(['git','read-tree',before['commit']],cwd=ROOT,check=True,capture_output=True)
for name in filter(None,subprocess.check_output(['git','ls-files','-z'],cwd=BASE).decode().split('\0')):
 src=BASE/name;dst=ROOT/name;dst.parent.mkdir(parents=True,exist_ok=True)
 if src.is_symlink():dst.symlink_to(os.readlink(src))
 else:os.link(src,dst)
assert repository_source_identity(ROOT)==before
name='bindings/rust/openui-layout/src/intrinsic_sizing.rs';p=ROOT/name;tmp=p.with_name(p.name+'.owned-copy');shutil.copy2(p,tmp);os.replace(tmp,p)
subprocess.run(['git','update-index','--refresh'],cwd=ROOT,check=True,capture_output=True)
subprocess.run(['git','apply','--index',str(PATCH)],cwd=ROOT,check=True,capture_output=True)
subprocess.run(['git','commit','-m','Measure intrinsic text through the shared shaper and preserve positive advances'],cwd=ROOT,check=True,capture_output=True)
source=repository_source_identity(ROOT);assert source['clean']
assert repository_source_identity(BASE)==before and repository_source_identity(MAIN)==public
APP.mkdir()
for name in ['Cargo.toml','Cargo.lock','src/main.rs']:
 dst=APP/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(OLDAPP/name,dst)
p=APP/'Cargo.toml';s=p.read_text();assert str(BASE) in s;p.write_text(s.replace(str(BASE),str(ROOT)))
subprocess.run(['git','init'],cwd=APP,check=True,capture_output=True)
for name in ['user.name','user.email']:
 value=subprocess.check_output(['git','config','--get',name],cwd=MAIN,text=True).strip();subprocess.run(['git','config',name,value],cwd=APP,check=True,capture_output=True)
subprocess.run(['git','add','.'],cwd=APP,check=True,capture_output=True);subprocess.run(['git','commit','-m','Prepare the identical native Rust consumer against shared shaping measurement'],cwd=APP,check=True,capture_output=True)
d=dict(schema_version=1,source=source,parent_source=before,public_source=public,root=str(ROOT),app_root=str(APP),source_only_preparation=True,prior_sources_unchanged=True,cargo_commands_run=0,native_queries_started=0,images_generated=0,private_fontations_and_caption_changes_included=False,near_grid_normalizer_removed=True,positive_shaped_fractions_preserved=True,source_patch=str(PATCH),source_patch_sha256=hashlib.sha256(PATCH.read_bytes()).hexdigest(),release_qualification=False,promotion_allowed=False,javascript_executed_by_openui=False,all_commands_terminal=True,probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
OUT.write_text(json.dumps(d,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(source=source,root=str(ROOT),prior_sources_unchanged=True,cargo_commands_run=0)))
