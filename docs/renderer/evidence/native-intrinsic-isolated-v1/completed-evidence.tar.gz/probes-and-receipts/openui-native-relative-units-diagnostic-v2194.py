"""Record every native relative-unit residual and its shared subsystem owner."""
import collections, hashlib, json, subprocess
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui')
RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1'
OUT=RAW/'native-relative-units-diagnostic-v2194.json'
assert not OUT.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
path=RAW/'native-relative-units-pipeline-v2189/receipt.json'
r=json.loads(path.read_bytes())
assert r['all_commands_terminal'] and r['source_unchanged'] and r['observed_exit_code']==0
assert subprocess.run(['ps','-p',str(r['owner_pid'])],capture_output=True).returncode!=0
counts=collections.Counter()
groups=collections.defaultdict(collections.Counter)
observations=[]
for p in r['profiles']:
    for x in p['observations']:
        n=x['native_case']
        for state,exact in x['full_rect_exact'].items():
            counts.update(dict(states=1,exact=int(exact),different=int(not exact)))
            groups[n['unit']].update(dict(states=1,exact=int(exact),different=int(not exact)))
            if not exact:
                chrome=x['chromium'][state]
                native=n[state]['bounds']
                observations.append(dict(case={k:n[k] for k in ['scale','family','size','line_height','unit','coefficient']},
                    state=state,native=n[state],chromium=chrome,
                    deltas={k:native[k]-chrome[k] for k in ['x','y','width','height']},
                    owner='openui-text font platform metrics' if n['unit'] in ['ch','ex'] else 'openui-text font-relative line-height conversion',
                    source_reviewed=True,fix_qualified=False))
assert counts['states']==2400 and counts['exact']==1810 and len(observations)==590
primaries=[RAW/'native-font-relative-primary-v2192/receipt.json',RAW/'native-font-cache-primary-v2193/receipt.json',
    RAW/'native-line-height-and-strike-primary-v2160/receipt.json',RAW/'native-font-orientation-primary-v2178/receipt.json']
report=dict(schema_version=1,source=r['source'],source_unchanged=True,all_commands_terminal=True,
    totals=dict(counts),by_unit={k:dict(v) for k,v in groups.items()},residuals=observations,
    unresolved_root_cause=False,root_cause_review_is_not_fix_qualification=True,
    root_causes=[
        'The platform metric converter uses raw SkFont measure_str for zero width; Chromium rounds a glyph width when its SkFont is not subpixel.',
        'Resolved font instances retain raw floating sizes; pinned Chromium floors effective font-cache sizes to two decimal places before constructing platform data.',
        'The lh helper multiplies raw font size by numeric line height; Chromium truncates the font-size and percentage product to LayoutUnit before multiplying the length coefficient.'
    ],primary_records=[dict(path=str(p),sha256=sha(p)) for p in primaries],
    capture_cleanup_race_diagnosed=True,failed_attempts_preserved=['native-relative-units-pipeline-v2183','native-relative-units-pipeline-v2188'],
    successful_capture_retry='native-relative-units-pipeline-v2189',capture_harness_file_unchanged=True,
    diagnostic_capture_lifecycle_wrapper_used=True,native_pixels_captured=False,
    javascript_executed_by_openui=False,manual_helper_does_not_complete_reactive_native_unit_declarations=True,
    release_qualification=False,promotion_allowed=False,new_release_states_admitted=0,
    receipt_sha256=sha(path),probe_sha256=sha(Path(__file__)))
OUT.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(path=str(OUT),sha256=sha(OUT),totals=dict(counts),by_unit=report['by_unit'])),flush=True)
