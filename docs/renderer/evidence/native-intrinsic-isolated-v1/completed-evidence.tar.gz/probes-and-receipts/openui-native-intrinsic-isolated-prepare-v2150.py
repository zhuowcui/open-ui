"""Create a separate clean native sizing trial without the private caption/font factory."""
import fcntl,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');ROOT=MAIN/'out/private-native-api-isolated-v2150'
APP=MAIN/'out/private-native-apps/native-intrinsic-isolated-v2151';OLDAPP=MAIN/'out/private-native-apps/native-intrinsic-matched-v2119'
PATCH=Path('/tmp/openui-native-intrinsic-isolated-change-v2142.patch');OUT=Path('/tmp/openui-native-intrinsic-isolated-prepare-v2150.json')
assert not ROOT.exists() and not APP.exists() and not OUT.exists()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','ninja','pixel_compare']:
 assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
sys.path.insert(0,str(MAIN/'tools/qualification'));from renderer_source_identity import repository_source_identity
before=repository_source_identity(MAIN);assert before['clean'] and before['commit']=='1dd7a23ea51a1ee7fceff1b659b6b999390fbad8'
subprocess.run(['git','clone','--shared','--no-checkout',str(MAIN),str(ROOT)],check=True,capture_output=True)
for name in ['user.name','user.email']:
 value=subprocess.check_output(['git','config','--get',name],cwd=MAIN,text=True).strip()
 assert value
 subprocess.run(['git','config',name,value],cwd=ROOT,check=True,capture_output=True)
subprocess.run(['git','read-tree',before['commit']],cwd=ROOT,check=True,capture_output=True)
files=subprocess.check_output(['git','ls-files','-z'],cwd=MAIN).decode().split('\0')
for name in filter(None,files):
 src=MAIN/name;dst=ROOT/name;dst.parent.mkdir(parents=True,exist_ok=True)
 if src.is_symlink():dst.symlink_to(os.readlink(src))
 else:os.link(src,dst)
assert repository_source_identity(ROOT)==before
changed=['bindings/rust/openui-engine/src/lib.rs','bindings/rust/openui-layout/src/intrinsic_sizing.rs','bindings/rust/openui-layout/src/out_of_flow.rs','bindings/rust/openui-layout/tests/sp11_round16_fix_tests.rs','bindings/rust/openui-text/src/font/relative.rs']
for name in changed:
 p=ROOT/name;tmp=p.with_name(p.name+'.private-copy');shutil.copy2(p,tmp);os.replace(tmp,p)
subprocess.run(['git','update-index','--refresh'],cwd=ROOT,check=True,capture_output=True)
subprocess.run(['git','apply','--index',str(PATCH)],cwd=ROOT,check=True,capture_output=True)
subprocess.run(['git','commit','-m','Isolate native intrinsic bounds and exact line heights from the private font trial'],cwd=ROOT,check=True,capture_output=True)
source=repository_source_identity(ROOT);assert source['clean']
assert repository_source_identity(MAIN)==before
APP.mkdir()
for name in ['Cargo.toml','Cargo.lock','src/main.rs']:
 p=APP/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(OLDAPP/name,p)
p=APP/'Cargo.toml';s=p.read_text();old='/dev/shm/openui-native-intrinsic-api-retry-v2118';assert old in s;p.write_text(s.replace(old,str(ROOT)))
subprocess.run(['git','init'],cwd=APP,check=True,capture_output=True)
for name in ['user.name','user.email']:
 value=subprocess.check_output(['git','config','--get',name],cwd=MAIN,text=True).strip()
 subprocess.run(['git','config',name,value],cwd=APP,check=True,capture_output=True)
subprocess.run(['git','add','.'],cwd=APP,check=True,capture_output=True)
subprocess.run(['git','commit','-m','Prepare the same native Rust callback consumer against isolated sizing changes'],cwd=APP,check=True,capture_output=True)
report=dict(schema_version=1,public_source=before,source=source,root=str(ROOT),app_root=str(APP),patch_path=str(PATCH),patch_sha256=hashlib.sha256(PATCH.read_bytes()).hexdigest(),public_source_unchanged=repository_source_identity(MAIN)==before,private_fontations_and_caption_changes_included=False,source_only_preparation=True,cargo_commands_run=0,images_generated=0,release_qualification=False,promotion_allowed=False,javascript_executed_by_openui=False,all_commands_terminal=True,probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
OUT.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(root=str(ROOT),source=source,app_root=str(APP),public_source_unchanged=True,cargo_commands_run=0)))
