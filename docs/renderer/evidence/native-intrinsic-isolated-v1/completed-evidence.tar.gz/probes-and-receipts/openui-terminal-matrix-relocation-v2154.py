"""Relocate completed historical results byte for byte while retaining their paths."""
import concurrent.futures
import fcntl
import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path

MAIN = Path('/home/nero/code/open-ui')
RAW = MAIN / 'out/renderer-evidence/native-viewport-scroll-v1'
owner = json.loads((RAW / 'native-intrinsic-verification-pipeline-v2120/receipt.json').read_bytes())
assert owner['all_commands_terminal'] and owner['source_unchanged']
lock = open('/tmp/openui-native-cargo-raster-owner.lock', 'a+')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
for name in ['cargo', 'rustc', 'ninja', 'pixel_compare', 'chrome']:
    assert subprocess.run(['pgrep', '-x', name], capture_output=True).returncode == 1
original = MAIN / 'out/column-start-clean-expanded-v3'
target = Path('/mnt/e/openui-v02-qualification-d174ea0b/terminal-expanded-results-relocated-v2154')
backup = original.with_name('column-start-clean-expanded-v3-verified-backup-v2154')
receipt_path = Path('/tmp/openui-terminal-matrix-relocation-v2154.json')
assert original.is_dir() and not original.is_symlink()
assert not target.exists() and not backup.exists() and not receipt_path.exists()
assert shutil.disk_usage(target.parent).free > 10 * 2**30

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(2**20), b''):
            h.update(chunk)
    return h.hexdigest()

files = sorted(p for p in original.rglob('*') if p.is_file())
assert files and all(not p.is_symlink() for p in files)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    hashes = list(pool.map(sha, files))
records = [dict(path=str(p.relative_to(original)), bytes=p.stat().st_size, sha256=h)
    for p, h in zip(files, hashes)]
target.mkdir()
print(json.dumps(dict(stage='copy', files=len(files))), flush=True)
def copy_file(item):
    path, expected_hash = item
    destination = target / path.relative_to(original)
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, destination)
    assert sha(destination) == expected_hash
    return True
with concurrent.futures.ThreadPoolExecutor(max_workers=16) as pool:
    for count, ok in enumerate(pool.map(copy_file, zip(files, hashes)), 1):
        assert ok
        if count % 2000 == 0:
            print(json.dumps(dict(stage='copy-hash-verified', files=count)), flush=True)
print(json.dumps(dict(stage='final-tree-verification', files=len(files))), flush=True)
assert sorted(str(p.relative_to(target)) for p in target.rglob('*') if p.is_file()) == [r['path'] for r in records]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    after = list(pool.map(sha, [target / r['path'] for r in records]))
assert after == hashes
assert all((target / r['path']).stat().st_size == r['bytes'] for r in records)
# The original remains intact until every copied file has been verified.
original.rename(backup)
original.symlink_to(target, target_is_directory=True)
assert original.resolve() == target and original.is_dir()
shutil.rmtree(backup)
receipt = dict(schema_version=1, all_commands_terminal=True,
    original_path=str(original), relocated_path=str(target),
    original_paths_preserved=True, all_files_byte_identical=True,
    reference_images_rewritten=0, cargo_or_native_queries_started=0,
    files=len(records), bytes=sum(r['bytes'] for r in records), records=records,
    home_free_after=shutil.disk_usage(MAIN).free, probe_sha256=sha(Path(__file__)))
receipt_path.write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
print(json.dumps({k: receipt[k] for k in ['files', 'bytes', 'all_files_byte_identical', 'home_free_after']}))
