"""Preserve completed own-source measurements, source patches and storage repairs."""
import gzip, hashlib, io, json, subprocess, tarfile
from pathlib import Path
MAIN = Path('/home/nero/code/open-ui')
RAW = MAIN / 'out/renderer-evidence/native-viewport-scroll-v1'
OWNER = RAW / 'native-intrinsic-isolated-pipeline-v2155'
INDEX = MAIN / 'docs/renderer/generated/native-intrinsic-isolated-v1.json'
ARCHIVE = MAIN / 'docs/renderer/evidence/native-intrinsic-isolated-v1/completed-evidence.tar.gz'
assert not INDEX.exists() and not ARCHIVE.exists()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_bytes())
owner = load(OWNER / 'receipt.json')
assert owner['all_commands_terminal'] and owner['source_unchanged']
assert owner['native_intrinsic_app_source_unchanged'] and owner['public_baseline_app_source_unchanged']
assert owner['public_baseline_sdk_source_unchanged']
assert subprocess.run(['ps', '-p', str(owner['owner_pid'])], capture_output=True).returncode != 0
api = load(RAW / 'native-intrinsic-isolated-api-audit-v2157.json')
renderer = load(RAW / 'native-intrinsic-isolated-renderer-audit-v2159.json')
assert api['source'] == renderer['source'] == owner['source']
inputs = {}
def add(path, name):
    assert path.is_file() and name not in inputs
    inputs[name] = path
def direct(directory, prefix):
    for path in sorted(directory.iterdir()):
        if path.is_file() and path.suffix in ['.json', '.log', '.patch', '.cc', '.h', '.cpp']:
            add(path, prefix + '/' + path.name)
direct(OWNER, 'whole-owner')
shaped_path = RAW / 'native-intrinsic-shaped-pipeline-v2190/receipt.json'
shaped = load(shaped_path)
assert shaped['all_commands_terminal'] and shaped['source_unchanged'] and shaped['public_source_unchanged']
assert shaped['native_app_source_unchanged']
assert subprocess.run(['ps', '-p', str(shaped['owner_pid'])], capture_output=True).returncode != 0
direct(shaped_path.parent, 'shaped-own-source-diagnostic')
shaped_summary = shaped_path.parent / 'sizing-neighbors-matrix/full-summary.json'
add(shaped_summary, 'shaped-own-source-diagnostic/sizing-neighbors-summary.json')
for path in sorted((shaped_path.parent / 'sizing-neighbors-matrix').rglob('*')):
    if path.is_file() and path.suffix in ['.png', '.html']:
        add(path, 'shaped-own-source-diagnostic/matrix-images/' + str(path.relative_to(shaped_path.parent / 'sizing-neighbors-matrix')))
for suite in ['full', 'expanded', 'focused', 'primitive']:
    add(OWNER / (suite + '-matrix') / (suite + '-summary.json'), 'matrices/' + suite + '-summary.json')
names = [
 'native-intrinsic-isolated-checks-v2152',
 'native-intrinsic-isolated-source-repro-v2179',
 'native-intrinsic-shaped-checks-v2172',
 'native-intrinsic-shaped-source-repro-v2173',
 'native-line-height-and-strike-primary-v2160',
 'native-font-strike-and-length-primary-v2163',
 'native-shaping-primary-v2176',
 'native-shaping-local-primary-v2177',
 'native-font-orientation-primary-v2178',
 'native-font-relative-primary-v2192',
 'native-font-cache-primary-v2193',
 'native-intrinsic-umbrella-checks-v2136',
 'native-intrinsic-umbrella-hosted-v2137',
]
for name in names:
    direct(RAW / name, 'records/' + name)
for name in ['initial-main.rs', 'current-main.rs', 'font-loaded-main.rs', 'receipt.json']:
    add(RAW / 'native-relative-units-prepared-source-v2182' / name,
        'relative-unit-prepared-source/' + name)
relative_path = RAW / 'native-relative-units-pipeline-v2189/receipt.json'
relative = None
if relative_path.exists():
    relative = load(relative_path)
    assert relative['all_commands_terminal'] and relative['source_unchanged']
    assert relative['source'] == owner['source']
    assert subprocess.run(['ps', '-p', str(relative['owner_pid'])], capture_output=True).returncode != 0
    for path in sorted(relative_path.parent.rglob('*')):
        if path.is_file() and path.suffix in ['.json', '.log', '.png', '.html']:
            add(path, 'relative-unit-diagnostic/' + str(path.relative_to(relative_path.parent)))
for failed_name in ['native-relative-units-pipeline-v2183', 'native-relative-units-pipeline-v2188']:
    failed_dir = RAW / failed_name
    failed_receipt = load(failed_dir / 'receipt.json')
    assert failed_receipt['all_commands_terminal'] and failed_receipt['source_unchanged']
    assert subprocess.run(['ps', '-p', str(failed_receipt['owner_pid'])], capture_output=True).returncode != 0
    for path in sorted(failed_dir.rglob('*')):
        if path.is_file() and path.suffix in ['.json', '.log', '.png', '.html']:
            add(path, 'failed-relative-unit-attempts/' + failed_name + '/' + str(path.relative_to(failed_dir)))
for name in [
 'native-intrinsic-isolated-api-audit-v2157.json',
 'native-intrinsic-isolated-axis-audit-v2187.json',
 'native-relative-units-diagnostic-v2194.json',
 'native-intrinsic-isolated-renderer-audit-v2159.json',
 'native-intrinsic-isolated-geometry-diagnostics-v2171.json',
 'native-intrinsic-isolated-shaping-review-v2167.json',
 'native-relative-length-source-review-v2164.json',
]:
    add(RAW / name, 'records/' + name)
for app in ['native-intrinsic-isolated-v2151', 'native-intrinsic-public-v2158', 'native-intrinsic-shaped-v2169', 'native-relative-units-v2182']:
    for app_file in ['Cargo.toml', 'Cargo.lock', 'src/main.rs']:
        add(MAIN / 'out/private-native-apps' / app / app_file, 'native-apps/' + app + '/' + app_file)
for pattern in [
 'openui-native-intrinsic-isolated-prepare-v2150.*',
 'openui-native-intrinsic-isolated-pipeline-v2155.py',
 'openui-native-intrinsic-isolated-api-audit-v2157.py',
 'openui-native-intrinsic-isolated-renderer-audit-v2159.py',
 'openui-native-intrinsic-isolated-checks-v2152.py',
 'openui-native-intrinsic-isolated-change-v2142.patch',
 'openui-terminal-matrix-relocation-v2154.*',
 'openui-terminal-matrix-filelist-audit-v2162.*',
 'openui-terminal-matrix-verified-finish-v2165.*',
 'openui-terminal-binaries-relocation-v2175.*',
 'openui-terminal-binaries-relocation-v2201.*',
 'openui-native-intrinsic-shaped-pipeline-v2190.py',
 'openui-native-intrinsic-shaped-prepare-v2168.*',
 'openui-native-intrinsic-shaped-change-v2170.patch',
 'openui-native-intrinsic-shaped-checks-v2172.py',
 'openui-native-intrinsic-isolated-source-repro-v2179.py',
 'openui-native-shaping-primary-v2176.py',
 'openui-native-font-orientation-primary-v2178.py',
 'openui-native-relative-units-prepare-v2182.json',
 'openui-native-relative-units-pipeline-v2183.py',
 'openui-native-relative-units-pipeline-v2188.py',
 'openui-native-relative-units-pipeline-v2189.py',
 'openui-native-intrinsic-isolated-axis-audit-v2187.py',
 'openui-native-relative-units-diagnostic-v2194.py',
 'openui-native-font-relative-primary-v2192.py',
 'openui-native-font-cache-primary-v2193.py',
]:
    matches = list(Path('/tmp').glob(pattern))
    assert matches, pattern
    for path in matches:
        add(path, 'probes-and-receipts/' + path.name)
add(Path(__file__), 'probes-and-receipts/' + Path(__file__).name)
ARCHIVE.parent.mkdir(parents=True)
members = []
with ARCHIVE.open('xb') as output:
    with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0, compresslevel=6) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, path in sorted(inputs.items()):
                raw = path.read_bytes()
                info = tarfile.TarInfo(name)
                info.size = len(raw)
                info.mode = 0o644
                info.mtime = 0
                archive.addfile(info, io.BytesIO(raw))
                members.append(dict(name=name, source_path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()))
with tarfile.open(ARCHIVE, 'r:gz') as archive:
    assert [m.name for m in archive.getmembers()] == [m['name'] for m in members]
    for row in members:
        raw = archive.extractfile(row['name']).read()
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
        assert sha(inputs[row['name']]) == row['sha256']
checks = load(RAW / 'native-intrinsic-isolated-checks-v2152/receipt.json')
assert checks['source'] == owner['source'] and all(c['observed_exit_code'] == 0 for c in checks['checks'])
workspace = next(row for row in owner['steps'] if row['name'] == 'workspace')
report = dict(schema_version=1, source=owner['source'], source_after=owner['source_after'],
              all_commands_terminal=True, candidate_applied_to_umbrella=False,
              native_geometry=api['totals'], native_geometry_only=True,
              native_pixels_captured=False, native_callback_calls_per_run=2880,
              native_outputs_repeat_byte_identically=True, workspace_tests=workspace,
              read_only_checks_passed=len(checks['checks']), suites=renderer['suites'],
              native_guard_count=2, strict_rgba_guards_actually_executed=True,
              legacy_bytes_unchanged=owner['tracked_diagnostic_png_unchanged'],
              private_fontations_and_caption_changes_included=False,
              native_inline_axis_losses=10, native_dimension_gate_passed=False,
              strict_axis_audit_exit_code=1,
              failed_relative_capture_attempts_preserved=True,
              successful_relative_diagnostic_is_not_pixel_qualification=True,
              shaped_followup=dict(source=shaped['source'], all_commands_terminal=True,
                  observed_exit_code=shaped['observed_exit_code'], native_geometry=shaped['native_geometry'],
                  workspace=next(row for row in shaped['steps'] if row['name'] == 'workspace'),
                  sizing_neighbors=shaped['matrices']['sizing-neighbors'],
                  full_matrices_not_run_on_this_source=True, candidate_applied=False, release_qualification=False),
              relative_unit_api_review_is_source_only=relative is None,
              relative_unit_diagnostic=None if relative is None else {
                  key: relative.get(key) for key in ['observed_exit_code', 'geometry_states',
                      'full_rect_exact', 'native_cases', 'native_outputs_byte_identical',
                      'native_app_source', 'native_app_source_unchanged',
                      'manual_resolution_does_not_complete_reactive_length_declarations']},
              relative_unit_totals=load(RAW / 'native-relative-units-diagnostic-v2194.json')['by_unit'],
              entire_candidate_tree_reconstructs_exactly=True,
              failed_storage_verification_and_verified_recovery_preserved=True,
              unused_historical_binaries_relocated_byte_identically=True,
              full_census_individual_image_caches_not_duplicated=True,
              release_qualification=False, promotion_allowed=False,
              new_release_states_admitted=0, javascript_executed_by_openui=False,
              pixel_tolerance=0, formal_original_residual_ownership_unchanged=True,
              archive=dict(path=str(ARCHIVE.relative_to(MAIN)), bytes=ARCHIVE.stat().st_size,
                           sha256=sha(ARCHIVE), all_members_hash_verified=True, members=members),
              probe_sha256=sha(Path(__file__)))
INDEX.write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
print(json.dumps(dict(index=str(INDEX), index_sha256=sha(INDEX), archive_bytes=ARCHIVE.stat().st_size,
                      archive_members=len(members), native_geometry=api['totals'])), flush=True)
