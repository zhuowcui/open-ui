"""Read the pinned primary shaping callbacks without running either renderer."""
import base64, concurrent.futures, hashlib, json, urllib.error, urllib.request
from pathlib import Path

OUT = Path('/home/nero/code/open-ui/out/renderer-evidence/native-viewport-scroll-v1/native-shaping-primary-v2176')
assert not OUT.exists()
OUT.mkdir()
blink = 'https://chromium.googlesource.com/chromium/src/+/147.0.7727.50/'
skia = 'https://skia.googlesource.com/skia/+/2b5c647f2843dae179b02e10e267403e6e80ce29/'
inputs = [
    (blink, 'third_party/blink/renderer/platform/fonts/shaping/harfbuzz_face.cc'),
    (blink, 'third_party/blink/renderer/platform/fonts/shaping/harfbuzz_shaper.cc'),
    (blink, 'third_party/blink/renderer/platform/fonts/shaping/harfbuzz_font_data.h'),
    (skia, 'modules/skshaper/src/SkShaper_harfbuzz.cpp'),
]
def fetch(item):
    base, relative = item
    url = base + relative + '?format=TEXT'
    try:
        with urllib.request.urlopen(url, timeout=30) as response:
            encoded = response.read()
        raw = base64.b64decode(encoded, validate=True)
        target = OUT / Path(relative).name
        target.write_bytes(raw)
        return dict(url=url, path=str(target), bytes=len(raw), observed_exit_code=0,
                    sha256=hashlib.sha256(raw).hexdigest())
    except urllib.error.HTTPError as error:
        return dict(url=url, observed_exit_code=1, http_status=error.code)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    rows = list(pool.map(fetch, inputs))
report = dict(schema_version=1, files=rows, all_commands_terminal=True,
              native_queries_started=0, chromium_processes_started=0,
              source_only_not_runtime_qualification=True, source_changed=False,
              root_cause_reviewed=False, release_qualification=False,
              probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(OUT / 'receipt.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
print(json.dumps(rows), flush=True)
