"""Read pinned Chromium font-metric initialization; source review only."""
import base64, concurrent.futures, hashlib, json, urllib.error, urllib.request
from pathlib import Path
OUT=Path('/home/nero/code/open-ui/out/renderer-evidence/native-viewport-scroll-v1/native-font-relative-primary-v2192')
assert not OUT.exists()
OUT.mkdir()
base='https://chromium.googlesource.com/chromium/src/+/147.0.7727.50/'
inputs=['third_party/blink/renderer/platform/fonts/simple_font_data.cc',
        'third_party/blink/renderer/platform/fonts/font_metrics.h',
        'third_party/blink/renderer/platform/fonts/font_metrics.cc',
        'third_party/blink/renderer/platform/fonts/font_platform_data.h',
        'third_party/blink/renderer/platform/fonts/skia/skia_text_metrics.h']
def fetch(relative):
    url=base+relative+'?format=TEXT'
    try:
        with urllib.request.urlopen(url,timeout=30) as response: raw=base64.b64decode(response.read(),validate=True)
        p=OUT/Path(relative).name
        p.write_bytes(raw)
        return dict(url=url,path=str(p),bytes=len(raw),observed_exit_code=0,sha256=hashlib.sha256(raw).hexdigest())
    except urllib.error.HTTPError as error:
        return dict(url=url,observed_exit_code=1,http_status=error.code)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool: rows=list(pool.map(fetch,inputs))
report=dict(schema_version=1,files=rows,all_commands_terminal=True,source_only_not_runtime_qualification=True,
    native_queries_started=0,chromium_processes_started=0,source_changed=False,release_qualification=False,
    probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps(rows),flush=True)
