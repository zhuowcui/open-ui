"""Move unused historical binaries with exact byte verification and stable paths."""
import hashlib, json, os, shutil, sys
from pathlib import Path

MAIN = Path('/home/nero/code/open-ui')
DEST = Path('/mnt/e/openui-v02-qualification-d174ea0b/terminal-binaries-relocated-v2201')
RECEIPT = Path('/tmp/openui-terminal-binaries-relocation-v2201.json')
assert not DEST.exists() and not RECEIPT.exists()
sys.path.insert(0, str(MAIN / 'tools/qualification'))
from renderer_source_identity import repository_source_identity

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(2**20), b''):
            h.update(chunk)
    return h.hexdigest()

before = repository_source_identity(MAIN)
assert before['clean']
paths = [
    MAIN / 'out/renderer-evidence/native-pixel-binary-stage-v2156/pixel_compare',
    MAIN / 'out/renderer-evidence/native-pixel-binary-stage-v2191/pixel_compare',
]
for name in ['native-intrinsic-isolated-pipeline-v2155','native-intrinsic-shaped-pipeline-v2190']:
    owner_path = MAIN / 'out/renderer-evidence/native-viewport-scroll-v1' / name / 'receipt.json'
    receipt = json.loads(owner_path.read_bytes())
    assert receipt['all_commands_terminal'] and receipt['source_unchanged']
    assert not Path('/proc', str(receipt['owner_pid'])).exists()

running = []
for entry in Path('/proc').iterdir():
    if entry.name.isdecimal():
        try:
            running.append((int(entry.name), (entry / 'exe').resolve(strict=True)))
        except (OSError, RuntimeError):
            pass
assert not [(pid, str(exe)) for pid, exe in running if exe in paths]
DEST.mkdir()
report = dict(schema_version=1, source_before=before, all_commands_terminal=False,
              home_free_before=shutil.disk_usage(MAIN).free, rows=[],
              original_paths_preserved=True, reference_bytes_changed=0,
              active_pipeline_modified=False, release_qualification=False,
              promotion_allowed=False, probe_sha256=sha(Path(__file__)))
def save():
    RECEIPT.write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
save()
for index, original in enumerate(paths):
    assert original.is_file() and not original.is_symlink() and original.stat().st_nlink == 1
    digest = sha(original)
    size = original.stat().st_size
    target = DEST / (str(index) + '-' + original.name)
    shutil.copy2(original, target)
    assert sha(original) == digest == sha(target) and target.stat().st_size == size
    backup = original.with_name(original.name + '.verified-relocation-v2201')
    assert not backup.exists()
    original.rename(backup)
    original.symlink_to(target)
    assert original.is_symlink() and sha(original) == digest and sha(backup) == digest
    backup.unlink()
    report['rows'].append(dict(original=str(original), target=str(target), bytes=size,
                              original_sha256=digest, copied_sha256=sha(target),
                              final_path_sha256=sha(original), process_was_not_running=True))
    save()
    print(json.dumps(dict(index=index, bytes=size, home_free=shutil.disk_usage(MAIN).free)), flush=True)
after = repository_source_identity(MAIN)
assert after == before
report.update(source_after=after, source_unchanged=True, all_commands_terminal=True,
              home_free_after=shutil.disk_usage(MAIN).free, observed_exit_code=0)
save()
print(json.dumps(dict(receipt=str(RECEIPT), receipt_sha256=sha(RECEIPT), bytes=sum(r['bytes'] for r in report['rows']))), flush=True)
