"""Keep dimension losses visible even when a previously incorrect full rectangle improves."""
import hashlib, json
from pathlib import Path
RAW = Path('/home/nero/code/open-ui/out/renderer-evidence/native-viewport-scroll-v1')
API = RAW / 'native-intrinsic-isolated-api-audit-v2157.json'
RENDERER = RAW / 'native-intrinsic-isolated-renderer-audit-v2159.json'
OUT = RAW / 'native-intrinsic-isolated-axis-audit-v2187.json'
assert not OUT.exists()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
api = json.loads(API.read_bytes())
renderer = json.loads(RENDERER.read_bytes())
assert api['source'] == renderer['source']
losses = [row for row in api['observations'] if row['baseline_inline_axis_exact'] and not row['inline_axis_exact']]
assert len(losses) == api['totals']['inline_axis_losses'] == 10
assert all(row['state'] == 'minimum' and not row['baseline_full_rect_exact'] and not row['full_rect_exact'] for row in losses)
assert all(row['native']['height'] - row['chromium']['height'] == 1 / 64 for row in losses)
assert all(row['native']['width'] == row['chromium']['width'] for row in losses)
pixel_losses = sum(suite['exact_losses'] + suite['worsened_comparisons'] for suite in renderer['suites'].values())
report = dict(schema_version=1, source=api['source'], all_commands_terminal=True,
              native_api_audit_sha256=sha(API), renderer_audit_sha256=sha(RENDERER),
              prior_renderer_audit_actual_exit=renderer['observed_exit_code'],
              prior_renderer_audit_did_not_gate_inline_dimension_losses=True,
              native_totals=api['totals'], inline_dimension_losses=losses,
              changed_original_pixel_rows=len(renderer['suites']['full']['changed_comparisons']),
              pixel_losses=pixel_losses, candidate_applied_to_umbrella=False,
              native_dimension_gate_passed=False, release_qualification=False,
              promotion_allowed=False, native_pixels_captured=False,
              javascript_executed_by_openui=False, new_release_states_admitted=0,
              owner='shared intrinsic text measurement',
              shaped_followup_requires_its_own_runtime_and_pixel_evidence=True,
              observed_exit_code=int(bool(losses or pixel_losses or api['totals']['full_rect_losses'])),
              probe_sha256=sha(Path(__file__)))
OUT.write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
print(json.dumps(dict(receipt=str(OUT), receipt_sha256=sha(OUT), inline_dimension_losses=len(losses),
                      full_rectangle_gains=api['totals']['full_rect_gains'], pixel_losses=pixel_losses,
                      observed_exit_code=report['observed_exit_code'])), flush=True)
raise SystemExit(report['observed_exit_code'])
