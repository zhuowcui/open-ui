"""Read the pinned font setup path for unresolved rotated text measurements."""
import base64, concurrent.futures, hashlib, json, urllib.error, urllib.request
from pathlib import Path
OUT = Path('/home/nero/code/open-ui/out/renderer-evidence/native-viewport-scroll-v1/native-font-orientation-primary-v2178')
assert not OUT.exists()
OUT.mkdir()
base = 'https://chromium.googlesource.com/chromium/src/+/147.0.7727.50/'
paths = [
 'third_party/blink/renderer/platform/fonts/font_platform_data.cc',
 'third_party/blink/renderer/platform/fonts/linux/font_platform_data_linux.cc',
 'third_party/blink/renderer/platform/fonts/linux/font_cache_linux.cc',
 'third_party/blink/renderer/platform/fonts/skia/skia_text_metrics.cc',
]
def fetch(path):
 url = base + path + '?format=TEXT'
 try:
  with urllib.request.urlopen(url, timeout=30) as response:
   raw = base64.b64decode(response.read(), validate=True)
  destination = OUT / Path(path).name
  destination.write_bytes(raw)
  return dict(url=url, path=str(destination), observed_exit_code=0,
              bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
 except urllib.error.HTTPError as error:
  return dict(url=url, observed_exit_code=1, http_status=error.code)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 rows = list(pool.map(fetch, paths))
report = dict(schema_version=1, files=rows, all_commands_terminal=True,
              source_only_not_runtime_qualification=True, release_qualification=False,
              root_cause_reviewed=False, native_queries_started=0,
              chromium_processes_started=0,
              probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(OUT / 'receipt.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
print(json.dumps(rows), flush=True)
