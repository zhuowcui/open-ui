"""Measure existing public Rust font-relative helpers against repeated pinned Chromium queries."""
import fcntl, hashlib, html, json, os, shutil, signal, subprocess, sys, time
from pathlib import Path
MAIN = Path('/home/nero/code/open-ui')
SDK = MAIN / 'out/private-native-api-isolated-v2150'
APP = MAIN / 'out/private-native-apps/native-relative-units-v2182'
RAW = MAIN / 'out/renderer-evidence/native-viewport-scroll-v1'
NAME = 'native-relative-units-pipeline-v2189'
OUT = RAW / NAME
STORE = Path('/mnt/e/openui-v02-qualification-d174ea0b') / NAME
lock = open('/tmp/openui-native-cargo-raster-owner.lock', 'a+')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
previous = json.loads((RAW / 'native-intrinsic-isolated-pipeline-v2155/receipt.json').read_bytes())
assert previous['all_commands_terminal'] and previous['source_unchanged']
assert subprocess.run(['ps', '-p', str(previous['owner_pid'])], capture_output=True).returncode != 0
for program in ['cargo', 'rustc', 'ninja', 'pixel_compare']:
    assert subprocess.run(['pgrep', '-x', program], capture_output=True).returncode == 1
assert not OUT.exists() and not STORE.exists()
STORE.mkdir()
OUT.symlink_to(STORE, target_is_directory=True)
sys.path.insert(0, str(SDK / 'tools/qualification'))
from renderer_source_identity import repository_source_identity
sys.path.insert(0, str(SDK / 'tools/accountability'))
import run_all_pixel_comparisons as capture
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source = repository_source_identity(SDK)
assert source == previous['source'] and source['clean']
tmp = STORE / 'compiler-tmp'
tmp.mkdir()
env = dict(os.environ, OPENUI_NATIVE_WHOLE_OWNER=NAME,
           CARGO_TARGET_DIR='/mnt/e/openui-v02-cargo-c73754e2/target',
           CARGO_INCREMENTAL='0', RUST_MIN_STACK='4194304', CARGO_BUILD_JOBS='4',
           PYTHONDONTWRITEBYTECODE='1', TMPDIR=str(tmp),
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0')
chrome = MAIN / 'chrome/linux-147.0.7727.50/chrome-linux64/chrome'
assert sha(chrome) == '0ba87684df0afc11faaea40ac57bd2f1d68b67191443b38215a36b90e6f08848'
report = dict(schema_version=1, source=source, owner_pid=os.getpid(), all_commands_terminal=False,
              prior_failed_attempt_receipt=str(RAW / 'native-relative-units-pipeline-v2188/receipt.json'),
              prior_failed_attempt_sha256=sha(RAW / 'native-relative-units-pipeline-v2188/receipt.json'),
              geometry_only_diagnostic=True, native_pixels_captured=False,
              release_qualification=False, promotion_allowed=False, new_release_states_admitted=0,
              javascript_executed_by_openui=False, offline_javascript_executed_only_in_chromium=True,
              manual_resolution_does_not_complete_reactive_length_declarations=True,
              capture_switches_added=['--disable-dev-shm-usage'], capture_environment_is_diagnostic=True,
              diagnostic_process_cleanup_occurs_before_profile_removal=True,
              pinned_capture_harness_content_unchanged=True,
              chromium_binary_sha256=sha(chrome), steps=[], profiles=[],
              probe_sha256=sha(Path(__file__)))
def save():
    (OUT / 'receipt.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
def run(name, command):
    path = OUT / (name + '.log')
    with path.open('xb') as stream:
        child = subprocess.Popen(command, cwd=APP, env=env, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        report['current_process'] = dict(pid=child.pid, stage=name)
        save()
        guard = False
        while child.poll() is None:
            if shutil.disk_usage(MAIN).free < 512 * 2**20 or shutil.disk_usage(STORE).free < 10 * 2**30:
                guard = True
                os.killpg(child.pid, signal.SIGTERM)
                child.wait(timeout=20)
                break
            time.sleep(1)
    row = dict(name=name, observed_exit_code=child.returncode, disk_guard_triggered=guard, log_sha256=sha(path))
    report.pop('current_process')
    report['steps'].append(row)
    save()
    print(json.dumps(row), flush=True)
    assert not guard and child.returncode == 0
    assert repository_source_identity(SDK) == source
def app_identity():
    return dict(commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=APP, text=True).strip(),
                tree=subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=APP, text=True).strip(),
                clean=not subprocess.check_output(['git', 'status', '--porcelain'], cwd=APP))
original_ws = capture._CdpWebSocket
def observe(page, picture, expression, scale):
    observations = []
    exceptions = []
    commands = []
    def trace(frame, event, arg):
        if event == 'exception' and frame.f_code.co_filename == str(SDK / 'tools/accountability/run_all_pixel_comparisons.py'):
            exceptions.append(dict(function=frame.f_code.co_name, type=arg[0].__name__, message=str(arg[1])))
        return trace
    class QueryWebSocket(original_ws):
        def command(self, method, params=None):
            result = super().command(method, params)
            commands.append(dict(method=method, screenshot_sha256=hashlib.sha256(result['data'].encode()).hexdigest() if method == 'Page.captureScreenshot' and 'data' in result else None))
            if method == 'Runtime.evaluate' and not observations:
                response = super().command('Runtime.evaluate', dict(expression=expression, returnByValue=True))
                assert 'exceptionDetails' not in response, response.get('exceptionDetails')
                observations.append(response['result']['value'])
            return result
    capture._CdpWebSocket = QueryWebSocket
    processes = []
    original_popen = capture.subprocess.Popen
    original_tmpdir = capture.tempfile.TemporaryDirectory
    cleanup_events = []
    class StoppedChromeProfile(original_tmpdir):
        def __exit__(self, exc, value, tb):
            for process in processes:
                if process.poll() is None:
                    process.terminate()
                    try:
                        process.wait(timeout=15)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait(timeout=15)
                cleanup_events.append(dict(pid=process.pid, actual_exit=process.poll(), stopped_before_profile_removal=True))
            return super().__exit__(exc, value, tb)
    stderr = picture.with_suffix('.stderr.log')
    with stderr.open('xb') as stream:
        def launch(command, *args, **kwargs):
            if command and command[0] == str(chrome):
                command = [command[0], '--disable-dev-shm-usage', *command[1:]]
                kwargs['stderr'] = stream
            process = original_popen(command, *args, **kwargs)
            processes.append(process)
            return process
        capture.subprocess.Popen = launch
        capture.tempfile.TemporaryDirectory = StoppedChromeProfile
        sys.settrace(trace)
        try:
            ok = capture.render_chrome(str(page), str(picture), str(chrome), str(chrome.parent),
                                       use_ahem_noaa=True, logical_width=800, logical_height=600, device_scale=scale)
        finally:
            sys.settrace(None)
            capture._CdpWebSocket = original_ws
            capture.subprocess.Popen = original_popen
            capture.tempfile.TemporaryDirectory = original_tmpdir
    attempt = dict(cleanup_events=cleanup_events, exceptions=exceptions, commands=commands, observations=observations, capture_ok=ok, query_count=len(observations), process_actual_exits=[p.poll() for p in processes], stderr_sha256=sha(stderr))
    picture.with_suffix('.attempt.json').write_text(json.dumps(attempt, sort_keys=True, indent=2) + '\n')
    assert ok and len(observations) == 1
    return observations[0]
try:
    base = ['cargo', '--config', str(SDK / 'bindings/rust/.cargo/config.chromium.toml')]
    run('native-format', ['bash', '-c', 'ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true --check src/main.rs'])
    run('native-metadata', base + ['metadata', '--offline', '--format-version', '1'])
    if subprocess.check_output(['git', 'status', '--porcelain'], cwd=APP):
        subprocess.run(['git', 'add', '.'], cwd=APP, check=True, capture_output=True)
        subprocess.run(['git', 'commit', '-m', 'Lock the public native font-relative consuming app'], cwd=APP, check=True, capture_output=True)
    report['native_app_source'] = app_identity()
    assert report['native_app_source']['clean']
    save()
    run('native-build', base + ['build', '--offline', '--locked'])
    binary = OUT / 'openui-native-relative-units-api'
    shutil.copy2(Path(env['CARGO_TARGET_DIR']) / 'debug/openui-native-relative-units-api', binary)
    report['native_binary_sha256'] = sha(binary)
    save()
    run('native-first', [str(binary)])
    run('native-second', [str(binary)])
    assert (OUT / 'native-first.log').read_bytes() == (OUT / 'native-second.log').read_bytes()
    rows = [json.loads(line) for line in (OUT / 'native-first.log').read_text().splitlines()]
    assert len(rows) == 1200 and sum(row['callback_calls'] for row in rows) == 1200
    report['native_outputs_byte_identical'] = True
    report['native_cases'] = len(rows)
    save()
    line_heights = dict(normal='normal', number_1_2='1.2', number_1_275='1.275', percent_127_5='127.5%', fixed_19_2='19.2px')
    for scale in [1.0, 1.25, 1.5, 2.0, 3.0]:
        chosen = [row for row in rows if row['scale'] == scale]
        assert len(chosen) == 240
        directory = OUT / str(scale)
        directory.mkdir()
        parts = ['<!doctype html><style>*{margin:0;padding:0;box-sizing:content-box}html{overflow:hidden}div{position:absolute;left:0;top:0;height:10px;font-synthesis:none}</style>']
        for index, row in enumerate(chosen):
            size = next(size for size in [15.0, 16.0, 18.72, 18.73] if abs(size - row['size']) < .00001)
            declarations = f'font-family:"{row["family"]}";font-size:{size}px;line-height:{line_heights[row["line_height"]]};width:{row["coefficient"]}{row["unit"]}'
            parts.append(f'<div id="r{index}" data-size="{size}" style="{html.escape(declarations, quote=True)}">X</div>')
        page = directory / 'test.html'
        page.write_text(''.join(parts))
        expression = r'''(() => {const nodes=[...document.querySelectorAll('body>div')];const rect=n=>{const b=n.getBoundingClientRect();return {x:b.x,y:b.y,width:b.width,height:b.height}};const before=nodes.map(rect);nodes.forEach(n=>n.style.fontSize='20.37px');const result=nodes.map((n,i)=>({id:n.id,before:before[i],after:rect(n)}));nodes.forEach(n=>n.style.fontSize=n.dataset.size+'px');return result;})()'''
        queries = []
        for repeat in [1, 2]:
            query = observe(page, directory / (str(repeat) + '.png'), expression, scale)
            (directory / (str(repeat) + '-geometry.json')).write_text(json.dumps(query, sort_keys=True, indent=2) + '\n')
            queries.append(query)
        assert queries[0] == queries[1] and (directory / '1.png').read_bytes() == (directory / '2.png').read_bytes()
        observations = []
        for index, (native, chromium) in enumerate(zip(chosen, queries[0])):
            assert chromium['id'] == 'r' + str(index)
            exact = {state: native[state]['bounds'] == chromium[state] for state in ['before', 'after']}
            observations.append(dict(native_case=native, chromium=chromium, full_rect_exact=exact))
        profile = dict(scale=scale, html_sha256=sha(page), first_png_sha256=sha(directory / '1.png'),
                       second_png_sha256=sha(directory / '2.png'), repeated_png_and_queries_identical=True,
                       observations=observations)
        report['profiles'].append(profile)
        save()
        print(json.dumps(dict(scale=scale, cases=len(observations), full_rect_exact=sum(sum(row['full_rect_exact'].values()) for row in observations))), flush=True)
    report.update(observed_exit_code=0, geometry_states=2400,
                  full_rect_exact=sum(sum(row['full_rect_exact'].values()) for profile in report['profiles'] for row in profile['observations']))
except BaseException as error:
    report.update(observed_exit_code=1, failure=str(error))
    raise
finally:
    report.update(all_commands_terminal=True, source_after=repository_source_identity(SDK))
    report['source_unchanged'] = report['source_after'] == source
    if 'native_app_source' in report:
        report['native_app_source_after'] = app_identity()
        report['native_app_source_unchanged'] = report['native_app_source_after'] == report['native_app_source']
    assert report['source_unchanged'] and sha(chrome) == report['chromium_binary_sha256']
    save()
raise SystemExit(report['observed_exit_code'])
