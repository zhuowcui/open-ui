"""Diagnose the terminal relocation's file-list assertion without changing either tree."""
import concurrent.futures,hashlib,json,os,subprocess
from pathlib import Path
original=Path('/home/nero/code/open-ui/out/column-start-clean-expanded-v3')
target=Path('/mnt/e/openui-v02-qualification-d174ea0b/terminal-expanded-results-relocated-v2154')
assert not original.is_symlink()
files=sorted(p for p in original.rglob('*') if p.is_file())
path_order=[str(p.relative_to(original)) for p in files];canonical=sorted(path_order)
# Scan directory entries concurrently and use their file types; do not stat
# every result via a serial pathlib traversal across the mounted volume.
def scan(path):
 dirs=[];files=[]
 with os.scandir(path) as entries:
  for entry in entries:
   if entry.is_symlink():raise AssertionError('unexpected symbolic link '+entry.path)
   if entry.is_dir(follow_symlinks=False):dirs.append(Path(entry.path))
   elif entry.is_file(follow_symlinks=False):files.append(str(Path(entry.path).relative_to(target)))
   else:raise AssertionError('unexpected file type '+entry.path)
 return dirs,files
names=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=16) as pool:
 pending={pool.submit(scan,target)}
 while pending:
  done,pending=concurrent.futures.wait(pending,return_when=concurrent.futures.FIRST_COMPLETED)
  for future in done:
   dirs,rows=future.result();names.extend(rows);pending.update(pool.submit(scan,p) for p in dirs)
actual=sorted(names);assert len(actual)==len(set(actual))
missing=sorted(set(canonical)-set(actual));extra=sorted(set(actual)-set(canonical))
first=next((dict(index=i,path_order=x,string_order=y) for i,(x,y) in enumerate(zip(path_order,canonical)) if x!=y),None)
report=dict(schema_version=1,failed_probe='/tmp/openui-terminal-matrix-relocation-v2154.py',failed_actual_exit=1,failed_stage='final-tree-verification',original_tree_unchanged=True,original_path_not_redirected=True,expected_files=len(canonical),actual_files=len(actual),file_sets_exact=actual==canonical,path_order_equals_string_order=path_order==canonical,first_sort_difference=first,missing_files=missing,extra_files=extra,failed_assertion_compared_two_different_sort_orders=actual==canonical and path_order!=canonical,byte_revalidation_required=True,source_images_rewritten=0,release_qualification=False,all_commands_terminal=True,probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
out=Path('/tmp/openui-terminal-matrix-filelist-audit-v2162.json');assert not out.exists();out.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['expected_files','actual_files','file_sets_exact','first_sort_difference','failed_assertion_compared_two_different_sort_orders']}),flush=True)
