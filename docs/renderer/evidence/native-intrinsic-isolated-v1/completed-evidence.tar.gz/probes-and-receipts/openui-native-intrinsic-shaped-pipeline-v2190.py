"""Own-source native sizing and regression diagnostics, with no release admission."""
import collections, fcntl, hashlib, json, os, re, shutil, signal, subprocess, sys, time
from pathlib import Path
MAIN = Path('/home/nero/code/open-ui')
ROOT = MAIN / 'out/private-native-api-shaped-v2168'
APP = MAIN / 'out/private-native-apps/native-intrinsic-shaped-v2169'
RAW = MAIN / 'out/renderer-evidence/native-viewport-scroll-v1'
NAME = 'native-intrinsic-shaped-pipeline-v2190'
OUT = RAW / NAME
STORE = Path('/mnt/e/openui-v02-qualification-d174ea0b') / NAME
lock = open('/tmp/openui-native-cargo-raster-owner.lock', 'a+')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
for program in ['cargo', 'rustc', 'pixel_compare', 'ninja']:
    assert subprocess.run(['pgrep', '-x', program], capture_output=True).returncode == 1
assert not OUT.exists() and not STORE.exists()
STORE.mkdir()
OUT.symlink_to(STORE, target_is_directory=True)
tmp = STORE / 'compiler-tmp'
tmp.mkdir()
env = dict(os.environ, OPENUI_NATIVE_WHOLE_OWNER=NAME,
           CARGO_TARGET_DIR='/mnt/e/openui-v02-cargo-c73754e2/target',
           CARGO_INCREMENTAL='0', RUST_MIN_STACK='4194304', CARGO_BUILD_JOBS='4',
           PYTHONDONTWRITEBYTECODE='1', TMPDIR=str(tmp),
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0')
sys.path.insert(0, str(ROOT / 'tools/qualification'))
from renderer_source_identity import repository_source_identity
from residuals import canonical_sha256
source = repository_source_identity(ROOT)
public = repository_source_identity(MAIN)
assert source['clean'] and source['commit'] == '584ab9dd32413ee8078e13525ada3fc51bf41a1d'
assert public['clean'] and public['commit'] == '1dd7a23ea51a1ee7fceff1b659b6b999390fbad8'
def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(2**20), b''):
            h.update(chunk)
    return h.hexdigest()
load = lambda p: json.loads(p.read_bytes())
tracked = ROOT / 'tests/pixel_text/openui_renders/basic_text_openui.png'
if tracked.stat().st_nlink > 1:
    detached = tracked.with_name(tracked.name + '.owned-copy-v2190')
    shutil.copy2(tracked, detached)
    os.replace(detached, tracked)
tracked_sha = sha(tracked)
refs = {str(p.relative_to(ROOT)): sha(p) for p in (ROOT / 'tests/pixel_text/chromium_refs').rglob('*') if p.is_file()}
prior_path = RAW / 'native-intrinsic-isolated-pipeline-v2155/receipt.json'
prior = load(prior_path)
assert prior['all_commands_terminal'] and prior['public_baseline_sdk_source'] == public
assert prior['public_baseline_sdk_source_unchanged'] and prior['public_baseline_app_source_unchanged']
assert (APP / 'src/main.rs').read_bytes() == (MAIN / 'out/private-native-apps/native-intrinsic-public-v2158/src/main.rs').read_bytes()
report = dict(schema_version=1, source=source, public_source=public, owner_pid=os.getpid(),
              all_commands_terminal=False, steps=[], matrices={},
              release_qualification=False, promotion_allowed=False, new_release_states_admitted=0,
              native_geometry_only=True, native_pixels_captured=False, pixel_tolerance=0,
              private_fontations_and_caption_changes_included=False,
              baseline_native_outputs_reused_from_completed_paired_public_run=True,
              baseline_receipt_sha256=sha(prior_path), baseline_source=public,
              javascript_executed_by_openui=False, probe_sha256=sha(Path(__file__)))
def save():
    (OUT / 'receipt.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
def run(name, command, cwd=ROOT / 'bindings/rust', zero=True):
    path = OUT / (name + '.log')
    with path.open('xb') as stream:
        child = subprocess.Popen(command, cwd=cwd, env=env, stdout=stream,
                                 stderr=subprocess.STDOUT, start_new_session=True)
        report['current_process'] = dict(pid=child.pid, stage=name)
        save()
        guard = False
        while child.poll() is None:
            if shutil.disk_usage(MAIN).free < 512*2**20 or shutil.disk_usage(STORE).free < 10*2**30:
                guard = True
                os.killpg(child.pid, signal.SIGTERM)
                child.wait(timeout=20)
                break
            time.sleep(1)
        child.wait()
    totals = [tuple(map(int, m)) for m in re.findall(rb'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', path.read_bytes())]
    row = dict(name=name, observed_exit_code=child.returncode, disk_guard_triggered=guard,
               log_sha256=sha(path), passed=sum(t[0] for t in totals),
               failed=sum(t[1] for t in totals), ignored=sum(t[2] for t in totals))
    report.pop('current_process')
    report['steps'].append(row)
    save()
    print(json.dumps(row), flush=True)
    assert not guard and repository_source_identity(ROOT) == source
    assert repository_source_identity(MAIN) == public
    assert sha(tracked) == tracked_sha and all(sha(ROOT / p) == h for p,h in refs.items())
    if zero:
        assert child.returncode == 0, name
    return row
def app_identity():
    return dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=APP,text=True).strip(),
                tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=APP,text=True).strip(),
                clean=not subprocess.check_output(['git','status','--porcelain'],cwd=APP))
base = ['cargo', '--config', '.cargo/config.chromium.toml']
try:
    run('locked-metadata', base + ['metadata','--offline','--locked','--no-deps','--format-version','1'])
    metadata = json.loads(subprocess.check_output(base + ['metadata','--offline','--locked','--no-deps','--format-version','1'],cwd=ROOT/'bindings/rust',env=env))
    packages = [p['name'] for p in metadata['packages'] if p['id'] in metadata['workspace_members']]
    assert len(packages) == 18
    run('clean-workspace', base + ['clean','--locked'] + [a for p in packages for a in ['-p',p]])
    run('workspace',base + ['test','--offline','--locked','--workspace','--no-fail-fast','--features','openui-ffi/linux'],zero=False)
    content = (OUT / 'workspace.log').read_bytes()
    names = [b'native_intrinsic_keywords_apply_both_limits_and_reflow_vertical_width',
             b'native_fractional_line_heights_keep_chromium_grid_through_callbacks',
             b'reference_comparison_rejects_single_bit_rgba_changes',
             b'surface_comparison_preserves_rgba_order_and_straight_alpha']
    report['required_guards_actually_executed_and_passed'] = all(b'test '+name+b' ... ok' in content for name in names)
    assert report['required_guards_actually_executed_and_passed']
    save()
    app_base = ['cargo','--config',str(ROOT/'bindings/rust/.cargo/config.chromium.toml')]
    run('native-app-metadata',app_base+['metadata','--offline','--format-version','1'],cwd=APP)
    if subprocess.check_output(['git','status','--porcelain'],cwd=APP):
        subprocess.run(['git','add','.'],cwd=APP,check=True,capture_output=True)
        subprocess.run(['git','commit','-m','Lock the native consuming app to shared shaping measurement'],cwd=APP,check=True,capture_output=True)
    report['native_app_source'] = app_identity()
    assert report['native_app_source']['clean']
    run('native-app-build',app_base+['build','--offline','--locked'],cwd=APP)
    binary = OUT / 'openui-native-intrinsic-api'
    shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/openui-native-intrinsic-api',binary)
    report['native_binary_sha256'] = sha(binary)
    run('native-first',[str(binary)],cwd=APP)
    run('native-second',[str(binary)],cwd=APP)
    assert (OUT/'native-first.log').read_bytes() == (OUT/'native-second.log').read_bytes()
    report['native_outputs_repeat_byte_identically'] = True
    # Compare the same Rust consumer with an immutable earlier Chromium query.
    keys=['kind','scale','family','size','writing','text','position','decorated','scenario']
    key=lambda r:tuple(r.get(k) for k in keys)
    old={key(r):r for r in map(json.loads,(prior_path.parent/'public-baseline-first.log').read_text().splitlines())}
    new={key(r):r for r in map(json.loads,(OUT/'native-first.log').read_text().splitlines())}
    assert len(old)==len(new)==3690
    assert (prior_path.parent/'public-baseline-first.log').read_bytes()==(prior_path.parent/'public-baseline-second.log').read_bytes()
    oracle_path=RAW/'native-intrinsic-api-chromium-v2052/receipt.json'
    oracle=load(oracle_path)
    assert oracle['all_commands_terminal'] and oracle['observed_exit_code']==0 and oracle['source_unchanged']
    totals=collections.Counter()
    observations=[]
    for profile in oracle['profiles']:
        for obs in profile['observations']:
            before=old.pop(key(obs['native_case']))
            current=new.pop(key(obs['native_case']))
            axis='width' if before['writing']=='horizontal-tb' else 'height'
            for state in ['natural','minimum'] if before['kind']=='original' else ['before','after']:
                chrome=obs['chromium'][state]
                oe=before[state]==chrome
                ne=current[state]==chrome
                oi=before[state][axis]==chrome[axis]
                ni=current[state][axis]==chrome[axis]
                totals.update(dict(states=1,baseline_full_rect_exact=int(oe),full_rect_exact=int(ne),
                    baseline_inline_axis_exact=int(oi),inline_axis_exact=int(ni),
                    full_rect_gains=int(ne and not oe),full_rect_losses=int(oe and not ne),
                    inline_axis_gains=int(ni and not oi),inline_axis_losses=int(oi and not ni)))
                observations.append(dict(case={k:current[k] for k in keys if k in current},state=state,
                    baseline=before[state],native=current[state],chromium=chrome,
                    full_rect_exact=ne,inline_axis_exact=ni,full_rect_loss=oe and not ne,inline_axis_loss=oi and not ni))
    assert not old and not new and totals['states']==7380
    audit=dict(source=source,baseline_source=public,totals=dict(totals),observations=observations,
        native_pixels_captured=False,release_qualification=False,oracle_receipt_sha256=sha(oracle_path))
    path=OUT/'native-geometry-audit.json'
    path.write_text(json.dumps(audit,sort_keys=True,indent=2)+'\n')
    report['native_geometry']=dict(totals)
    report['native_geometry_audit_sha256']=sha(path)
    print(json.dumps(dict(native_geometry=dict(totals))),flush=True)
    run('pixel-build',base+['build','--offline','--locked','-p','pixel-compare','--bin','pixel_compare'])
    local=MAIN/'out/renderer-evidence/native-pixel-binary-stage-v2191'
    assert not local.exists()
    local.mkdir()
    pixel=OUT/'pixel_compare'
    pixel.symlink_to(local/'pixel_compare')
    shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/pixel_compare',pixel)
    report['pixel_binary_sha256']=sha(pixel)
    ident=json.loads(subprocess.check_output([str(pixel),'build-source-identity'],cwd=ROOT,env=env))
    assert ident['source']==source
    report['build_identity']=ident
    assert shutil.disk_usage(MAIN).free>700*2**20
    result=OUT/'sizing-neighbors-matrix'
    result.mkdir()
    ids=['wpt/css_sizing/block-size-with-min-or-max-content-1-ref',
         'wpt/css_sizing/block-size-with-min-or-max-content-1a',
         'wpt/css_sizing/block-size-with-min-or-max-content-1b']
    command=[sys.executable,str(ROOT/'tools/qualification/run_renderer_matrix.py'),'--suite','full',
        '--results-dir',str(result),'--cache-dir','/mnt/e/openui-v02-qualification-d174ea0b/renderer-cache',
        '--oracle-cache-dir',str(MAIN/'out/renderer-qualification-cache/chromium-oracle'),
        '--pixel-compare',str(pixel),'--chrome',str(MAIN/'chrome/linux-147.0.7727.50/chrome-linux64/chrome'),
        '--raster-backend','cpu-skia','--jobs','4']+[arg for test_id in ids for arg in ['--test-id',test_id]]
    stage=run('sizing-neighbors-matrix',command,cwd=ROOT,zero=False)
    summary_path=result/'full-summary.json'
    summary=load(summary_path)
    assert summary['source']==summary['source_after']==source and summary['results']['total']==12
    old_summary_path=RAW/'native-event-targets-clean-full-v1456/full-summary.json'
    old_summary=load(old_summary_path)
    before={(p['profile'],r['id']):r for p in old_summary['profiles'] for r in p['tests']}
    changes=[]
    fields=['chromium_png_sha256','chromium_rgba_sha256','chromium_oracle_identity_sha256','chromium_oracle_rgba_sha256']
    for p in summary['profiles']:
        assert p['result_sha256']==canonical_sha256(p['tests'])
        for row in p['tests']:
            old=before[(p['profile'],row['id'])]
            assert all(row[f]==old[f] for f in fields)
            changes.append(dict(profile=p['profile'],id=row['id'],prior_status=old['status'],status=row['status'],
                prior_mismatched_pixels=old['mismatched_pixels'],mismatched_pixels=row['mismatched_pixels'],
                more_wrong_pixels=row['mismatched_pixels']>old['mismatched_pixels'],
                exact_loss=old['status']=='exact' and row['status']!='exact',
                openui_rgba_unchanged=row['openui_rgba_sha256']==old['openui_rgba_sha256']))
    report['matrices']['sizing-neighbors']=dict(summary_sha256=sha(summary_path),results=summary['results'],
        observed_exit_code=stage['observed_exit_code'],partial_selection_not_qualifying=True,
        comparisons=changes,worsened_comparisons=sum(x['more_wrong_pixels'] for x in changes),
        exact_losses=sum(x['exact_loss'] for x in changes))
    report['observed_exit_code']=int(any(x['observed_exit_code'] for x in report['steps'] if x['name']!='sizing-neighbors-matrix')
        or totals['full_rect_losses'] or totals['inline_axis_losses']
        or report['matrices']['sizing-neighbors']['worsened_comparisons'] or report['matrices']['sizing-neighbors']['exact_losses'])
except BaseException as error:
    report.update(observed_exit_code=1,failure=str(error))
    raise
finally:
    report.update(all_commands_terminal=True,source_after=repository_source_identity(ROOT),public_source_after=repository_source_identity(MAIN))
    report['source_unchanged']=report['source_after']==source
    report['public_source_unchanged']=report['public_source_after']==public
    report['tracked_diagnostic_png_unchanged']=sha(tracked)==tracked_sha
    if 'native_app_source' in report:
        report['native_app_source_after']=app_identity()
        report['native_app_source_unchanged']=report['native_app_source_after']==report['native_app_source']
    save()
print(json.dumps(dict(observed_exit_code=report['observed_exit_code'],native_geometry=report.get('native_geometry'),matrices=report['matrices'])),flush=True)
raise SystemExit(report['observed_exit_code'])
