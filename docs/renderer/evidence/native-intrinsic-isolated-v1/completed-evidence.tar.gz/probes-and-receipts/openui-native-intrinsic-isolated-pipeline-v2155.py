import fcntl,hashlib,importlib.util,json,os,re,shutil,signal,subprocess,sys,time
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');ROOT=Path('/home/nero/code/open-ui/out/private-native-api-isolated-v2150');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';NAME='native-intrinsic-isolated-pipeline-v2155'
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for program in ['cargo','rustc','pixel_compare','ninja']:assert subprocess.run(['pgrep','-x',program],capture_output=True).returncode==1
OUT=RAW/NAME;STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/NAME;assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
TMP=STORE/'compiler-tmp';TMP.mkdir();env=dict(os.environ,OPENUI_NATIVE_WHOLE_OWNER=NAME,CARGO_TARGET_DIR='/mnt/e/openui-v02-cargo-c73754e2/target',CARGO_INCREMENTAL='0',RUST_MIN_STACK='4194304',CARGO_BUILD_JOBS='4',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(TMP),CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
base=['cargo','--config','.cargo/config.chromium.toml']
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(2**20),b''):h.update(chunk)
 return h.hexdigest()
sys.path.insert(0,str(ROOT/'tools/qualification'));from renderer_source_identity import repository_source_identity
source=repository_source_identity(ROOT);assert source['clean'] and source['commit']=='48af2cf497c23dcc004e88821f1b05d49eea9cfe'
tracked=ROOT/'tests/pixel_text/openui_renders/basic_text_openui.png'
# Detach this tracked diagnostic so any accidental old test write cannot reach
# the public checkpoint through a hard link; its bytes remain fixed.
if tracked.stat().st_nlink>1:
 detached=tracked.with_name(tracked.name+'.owned-copy-v2155');shutil.copy2(tracked,detached);os.replace(detached,tracked)
tracked_sha=sha(tracked)
assert repository_source_identity(ROOT)==source
ref_files=sorted(p for p in (ROOT/'tests/pixel_text/chromium_refs').rglob('*') if p.is_file());ref_sha={str(p.relative_to(ROOT)):sha(p) for p in ref_files}
report=dict(schema_version=1,source=source,all_commands_terminal=False,whole_pipeline_lock_covers_all_stages_and_gaps=True,owner_pid=os.getpid(),release_qualification=False,promotion_allowed=False,javascript_executed_by_openui=False,new_release_states_admitted=0,steps=[],matrices={},tracked_diagnostic_png_sha256=tracked_sha,legacy_reference_files=ref_sha,source_rewrites_allowed=False,private_fontations_and_caption_changes_included=False,native_geometry_is_not_pixel_qualification=True,probe_sha256=sha(Path(__file__)))
save=lambda:(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');save()
def run(name,command,cwd=ROOT/'bindings/rust',require_zero=True):
 log=OUT/(name+'.log')
 with log.open('xb') as stream:
  child=subprocess.Popen(command,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True);report['current_process']=dict(pid=child.pid,stage=name);save();guard=False
  while child.poll() is None:
   if shutil.disk_usage(MAIN).free<512*2**20 or shutil.disk_usage(STORE).free<10*2**30:
    guard=True;os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=20);break
   time.sleep(1)
  child.wait()
 report.pop('current_process');totals=[tuple(map(int,m)) for m in re.findall(rb'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',log.read_bytes())]
 row=dict(name=name,observed_exit_code=child.returncode,disk_guard_triggered=guard,log_sha256=sha(log),passed=sum(x[0] for x in totals),failed=sum(x[1] for x in totals),ignored=sum(x[2] for x in totals));report['steps'].append(row);save();print(json.dumps(row),flush=True)
 assert not guard
 assert repository_source_identity(ROOT)==source,'source changed during a committed stage'
 assert sha(tracked)==tracked_sha and all(sha(ROOT/p)==h for p,h in ref_sha.items()),'legacy source or reference bytes changed'
 if require_zero:assert child.returncode==0,name+' failed'
 return row
try:
 run('locked-metadata',base+['metadata','--offline','--locked','--no-deps','--format-version','1'])
 run('isolated-intrinsic-format',['bash','-c','ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true --check bindings/rust/openui-engine/src/lib.rs bindings/rust/openui-layout/src/intrinsic_sizing.rs bindings/rust/openui-layout/src/out_of_flow.rs bindings/rust/openui-layout/tests/sp11_round16_fix_tests.rs bindings/rust/openui-text/src/font/relative.rs bindings/rust/openui/tests/native_intrinsic_constraints.rs'],cwd=ROOT)
 run('strict-comparison-format',['bash','-c','ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true --check bindings/rust/openui-paint/tests/pixel_comparison_tests.rs'],cwd=ROOT)
 run('dependency-policy',[sys.executable,'tools/release/generate_v02_contract.py','--check'],cwd=ROOT)
 metadata=json.loads(subprocess.check_output(base+['metadata','--offline','--locked','--no-deps','--format-version','1'],cwd=ROOT/'bindings/rust',env=env));members=set(metadata['workspace_members']);packages=[p['name'] for p in metadata['packages'] if p['id'] in members];assert len(packages)==18
 run('clean-workspace',base+['clean','--locked']+[a for package in packages for a in ['-p',package]])
 run('exact-comparison-tests',base+['test','--offline','--locked','-p','openui-paint','--test','pixel_comparison_tests'])
 run('native-intrinsic-guard',base+['test','--offline','--locked','-p','openui','--test','native_intrinsic_constraints'])
 assert b'test native_intrinsic_keywords_apply_both_limits_and_reflow_vertical_width ... ok' in (OUT/'native-intrinsic-guard.log').read_bytes()
 assert b'test native_fractional_line_heights_keep_chromium_grid_through_callbacks ... ok' in (OUT/'native-intrinsic-guard.log').read_bytes()
 report['native_fractional_line_height_guard_actually_executed']=True
 report['native_intrinsic_guard_actually_executed']=True;save()
 run('workspace',base+['test','--offline','--locked','--workspace','--no-fail-fast','--features','openui-ffi/linux'],require_zero=False)
 content=(OUT/'workspace.log').read_bytes();report['strict_guards_observed_in_workspace'] = all(name in content for name in [b'test reference_comparison_rejects_single_bit_rgba_changes ... ok',b'test surface_comparison_preserves_rgba_order_and_straight_alpha ... ok'])
 assert report['strict_guards_observed_in_workspace']
 report['strict_rgba_guard_actually_executed']=True;report['tracked_diagnostic_png_unchanged_through_workspace']=sha(tracked)==tracked_sha;save()
 api_root=Path('/home/nero/code/open-ui/out/private-native-apps/native-intrinsic-isolated-v2151')
 api_base=['cargo','--config',str(ROOT/'bindings/rust/.cargo/config.chromium.toml')]
 run('native-intrinsic-app-format',['bash','-c','ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true --check src/main.rs'],cwd=api_root)
 run('native-intrinsic-app-metadata',api_base+['metadata','--offline','--format-version','1'],cwd=api_root)
 if subprocess.check_output(['git','status','--porcelain'],cwd=api_root):
  subprocess.run(['git','add','.'],cwd=api_root,check=True,capture_output=True)
  subprocess.run(['git','commit','-m','Lock the native consumer to the isolated sizing source'],cwd=api_root,check=True,capture_output=True)
 def api_identity():return dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=api_root,text=True).strip(),tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=api_root,text=True).strip(),clean=not subprocess.check_output(['git','status','--porcelain'],cwd=api_root))
 report['native_intrinsic_app_source']=api_identity();assert report['native_intrinsic_app_source']['clean'];save()
 run('native-intrinsic-app-build',api_base+['build','--offline','--locked'],cwd=api_root)
 api_binary=OUT/'openui-native-intrinsic-api';shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/openui-native-intrinsic-api',api_binary);report['native_intrinsic_app_binary_sha256']=sha(api_binary);save()
 run('native-intrinsic-app-first',[str(api_binary)],cwd=api_root);run('native-intrinsic-app-second',[str(api_binary)],cwd=api_root)
 assert (OUT/'native-intrinsic-app-first.log').read_bytes()==(OUT/'native-intrinsic-app-second.log').read_bytes()
 api_rows=[json.loads(line) for line in (OUT/'native-intrinsic-app-first.log').read_text().splitlines()];assert len(api_rows)==3690
 report['native_intrinsic_app_totals']=dict(cases=len(api_rows),geometry_states=len(api_rows)*2,callback_calls=sum(row.get('callback_calls',0) for row in api_rows),repeated_output_byte_identical=True)
 assert report['native_intrinsic_app_totals']['callback_calls']==2880
 assert api_identity()==report['native_intrinsic_app_source'];save()
 baseline_root=MAIN/'out/private-native-apps/native-intrinsic-public-v2158'
 assert (baseline_root/'src/main.rs').read_bytes()==(api_root/'src/main.rs').read_bytes()
 report['public_baseline_sdk_source']=repository_source_identity(MAIN)
 assert report['public_baseline_sdk_source']['clean'] and report['public_baseline_sdk_source']['commit']=='1dd7a23ea51a1ee7fceff1b659b6b999390fbad8'
 baseline_base=['cargo','--config',str(MAIN/'bindings/rust/.cargo/config.chromium.toml')]
 run('public-baseline-format',['bash','-c','ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true --check src/main.rs'],cwd=baseline_root)
 run('public-baseline-metadata',baseline_base+['metadata','--offline','--format-version','1'],cwd=baseline_root)
 if subprocess.check_output(['git','status','--porcelain'],cwd=baseline_root):
  subprocess.run(['git','add','.'],cwd=baseline_root,check=True,capture_output=True)
  subprocess.run(['git','commit','-m','Lock the same native consumer to the public checkpoint'],cwd=baseline_root,check=True,capture_output=True)
 def baseline_identity():return dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=baseline_root,text=True).strip(),tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=baseline_root,text=True).strip(),clean=not subprocess.check_output(['git','status','--porcelain'],cwd=baseline_root))
 report['public_baseline_app_source']=baseline_identity();assert report['public_baseline_app_source']['clean'];save()
 run('public-baseline-build',baseline_base+['build','--offline','--locked'],cwd=baseline_root)
 baseline_binary=OUT/'openui-native-intrinsic-public-api';shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/openui-native-intrinsic-api',baseline_binary)
 report['public_baseline_binary_sha256']=sha(baseline_binary);save()
 run('public-baseline-first',[str(baseline_binary)],cwd=baseline_root);run('public-baseline-second',[str(baseline_binary)],cwd=baseline_root)
 assert (OUT/'public-baseline-first.log').read_bytes()==(OUT/'public-baseline-second.log').read_bytes()
 baseline_rows=[json.loads(line) for line in (OUT/'public-baseline-first.log').read_text().splitlines()];assert len(baseline_rows)==3690
 report['public_baseline_totals']=dict(cases=len(baseline_rows),geometry_states=len(baseline_rows)*2,callback_calls=sum(row.get('callback_calls',0) for row in baseline_rows),repeated_output_byte_identical=True)
 assert report['public_baseline_totals']['callback_calls']==2880
 assert baseline_identity()==report['public_baseline_app_source'] and repository_source_identity(MAIN)==report['public_baseline_sdk_source'];save()
 run('ffi-build',base+['build','--offline','--locked','-p','openui-ffi','--features','linux'])
 lib=OUT/'libopenui_ffi.so';shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/libopenui_ffi.so',lib);soname=OUT/'libopenui.so.0';soname.symlink_to(lib.name);report['ffi_binary_sha256']=sha(lib);save()
 run('ffi-consumers',[sys.executable,str(ROOT/'tools/ffi/verify_abi.py'),'--library',str(lib)],cwd=ROOT)
 run('pixel-build',base+['build','--offline','--locked','-p','pixel-compare','--bin','pixel_compare'])
 local=MAIN/'out/renderer-evidence/native-pixel-binary-stage-v2156';assert not local.exists();local.mkdir();pixel=OUT/'pixel_compare';pixel.symlink_to(local/'pixel_compare');shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/pixel_compare',pixel);report['pixel_binary_sha256']=sha(pixel);ident=json.loads(subprocess.check_output([str(pixel),'build-source-identity'],cwd=ROOT,env=env));assert ident['source']==source;report['build_identity']=ident;save()
 assert shutil.disk_usage(MAIN).free>700*2**20
 report['home_free_before_pixel_matrices']=shutil.disk_usage(MAIN).free;report['terminal_result_relocation_receipt']='/tmp/openui-terminal-matrix-verified-finish-v2165.json';save()
 for suite in ['full','expanded']:
  result=OUT/(suite+'-matrix');result.mkdir()
  command=[sys.executable,str(ROOT/'tools/qualification/run_renderer_matrix.py'),'--suite',suite,'--results-dir',str(result),'--cache-dir','/mnt/e/openui-v02-qualification-d174ea0b/renderer-cache','--oracle-cache-dir','/home/nero/code/open-ui/out/renderer-qualification-cache/chromium-oracle','--pixel-compare',str(pixel),'--chrome',str(MAIN/'chrome/linux-147.0.7727.50/chrome-linux64/chrome'),'--raster-backend','cpu-skia','--jobs','8']
  stage=run(suite+'-matrix',command,cwd=ROOT,require_zero=False)
  summary=result/(suite+'-summary.json');s=json.loads(summary.read_bytes());assert s['source']==s['source_after']==source;assert s['results']['total']==(22924 if suite=='full' else 23728) and s['results']['errors']==0
  report['matrices'][suite]=dict(summary_sha256=sha(summary),results=s['results'],observed_exit_code=stage['observed_exit_code']);save();print(json.dumps(dict(suite=suite,results=s['results'],actual_exit=stage['observed_exit_code'])),flush=True)
 for suite in ['focused','primitive']:
  result=OUT/(suite+'-matrix');result.mkdir()
  command=[sys.executable,str(ROOT/'tools/qualification/run_renderer_matrix.py'),'--suite',suite,'--results-dir',str(result),'--cache-dir','/mnt/e/openui-v02-qualification-d174ea0b/renderer-cache','--oracle-cache-dir','/home/nero/code/open-ui/out/renderer-qualification-cache/chromium-oracle','--pixel-compare',str(pixel),'--chrome',str(MAIN/'chrome/linux-147.0.7727.50/chrome-linux64/chrome'),'--raster-backend','cpu-skia','--jobs','4']
  stage=run(suite+'-matrix',command,cwd=ROOT,require_zero=False)
  summary=result/(suite+'-summary.json');s=json.loads(summary.read_bytes());assert s['source']==s['source_after']==source
  report['matrices'][suite]=dict(summary_sha256=sha(summary),results=s['results'],observed_exit_code=stage['observed_exit_code']);save();print(json.dumps(dict(suite=suite,results=s['results'])),flush=True)
 report['observed_exit_code']=int(any(row['observed_exit_code'] for row in report['steps']))
except BaseException as error:
 report.update(observed_exit_code=1,failure=str(error));raise
finally:
 report['all_commands_terminal']=True;report['source_after']=repository_source_identity(ROOT);report['source_unchanged']=report['source_after']==source
 if not report['source_unchanged']:report.update(observed_exit_code=1,failure='source identity changed during pipeline')
 if 'native_intrinsic_app_source' in report:
  report['native_intrinsic_app_source_after']=api_identity();report['native_intrinsic_app_source_unchanged']=report['native_intrinsic_app_source_after']==report['native_intrinsic_app_source']
  if not report['native_intrinsic_app_source_unchanged']:report.update(observed_exit_code=1,failure='native API app source changed')
 if 'public_baseline_app_source' in report:
  report['public_baseline_app_source_after']=baseline_identity();report['public_baseline_app_source_unchanged']=report['public_baseline_app_source_after']==report['public_baseline_app_source']
  report['public_baseline_sdk_source_after']=repository_source_identity(MAIN);report['public_baseline_sdk_source_unchanged']=report['public_baseline_sdk_source_after']==report['public_baseline_sdk_source']
  if not report['public_baseline_app_source_unchanged'] or not report['public_baseline_sdk_source_unchanged']:report.update(observed_exit_code=1,failure='public native baseline source changed')
 report['tracked_diagnostic_png_unchanged']=sha(tracked)==tracked_sha;save()
raise SystemExit(report['observed_exit_code'])
