use openui::prelude::*;
use serde_json::{json, Value};
use std::{cell::Cell, error::Error, rc::Rc};

fn bounds(element: &Element) -> Result<Value, Box<dyn Error>> {
    let b = element.bounding_rect()?.ok_or("bounds required")?;
    Ok(json!({"x":b.x,"y":b.y,"width":b.width,"height":b.height}))
}

fn families(family: &str) -> FontFamilyList {
    if family == "deterministic" {
        FontFamilyList {
            families: [
                "Ahem",
                "Droid Sans Fallback",
                "Noto Sans Devanagari",
                "Noto Color Emoji",
                "DejaVu Sans",
            ]
            .into_iter()
            .map(|name| FontFamily::Named(name.into()))
            .collect(),
        }
    } else {
        FontFamilyList::single(family)
    }
}

fn writing_name(writing: WritingMode) -> &'static str {
    match writing {
        WritingMode::HorizontalTb => "horizontal-tb",
        WritingMode::VerticalLr => "vertical-lr",
        WritingMode::VerticalRl => "vertical-rl",
        _ => unreachable!(),
    }
}

fn element(
    document: &Document,
    family: &str,
    size: f32,
    writing: WritingMode,
    position: Position,
) -> Result<Element, Box<dyn Error>> {
    // The immutable Chromium observer uses html { overflow: hidden }.
    // Apply the same viewport policy through public native Rust setters.
    document.body().set_overflow_x(Overflow::Hidden)?;
    document.body().set_overflow_y(Overflow::Hidden)?;
    let element = Element::create(document, "div")?;
    element.set_position(position)?;
    element.set_left(Length::px(0.0))?;
    element.set_top(Length::px(0.0))?;
    element.set_font_family(families(family))?;
    element.set_font_size(LengthValue::px(size))?;
    element.set_font_kerning(FontKerning::None)?;
    element.set_font_variant_ligatures(FontVariantLigatures::none())?;
    element.set_line_height(LineHeight::Number(1.0))?;
    element.set_writing_mode(writing)?;
    document.body().append_child(&element)?;
    Ok(element)
}

fn axis_lengths(
    element: &Element,
    writing: WritingMode,
    preferred: Length,
    minimum: Length,
    maximum: Length,
) -> Result<(), Box<dyn Error>> {
    if writing == WritingMode::HorizontalTb {
        element.set_width(preferred.into())?;
        element.set_min_width(minimum.into())?;
        element.set_max_width(maximum.into())?;
    } else {
        element.set_height(preferred.into())?;
        element.set_min_height(minimum.into())?;
        element.set_max_height(maximum.into())?;
    }
    Ok(())
}

fn main() -> Result<(), Box<dyn Error>> {
    let fonts = FontCollection::deterministic_test();
    let raster = RasterConfiguration::deterministic_aliased(false);
    for scale in [1.0, 1.25, 1.5, 2.0, 3.0] {
        for family in ["deterministic", "DejaVu Sans"] {
            for size in [15.0, 16.0, 18.72] {
                for writing in [
                    WritingMode::HorizontalTb,
                    WritingMode::VerticalLr,
                    WritingMode::VerticalRl,
                ] {
                    let document = Document::with_font_collection_and_options(
                        ViewportMetrics::from_logical_size(800.0, 600.0, scale)?,
                        fonts.clone(),
                        EngineOptions {
                            raster_configuration: raster,
                        },
                    )?;
                    let text_element =
                        element(&document, family, size, writing, Position::Absolute)?;
                    for text in [
                        "X",
                        "XX",
                        "XXXXXXXXXXXXX",
                        "non-spanner",
                        "in",
                        "caption",
                        "non-spanner in caption",
                        "in the box",
                        "min",
                    ] {
                        text_element.set_text(text)?;
                        axis_lengths(
                            &text_element,
                            writing,
                            Length::auto(),
                            Length::auto(),
                            Length::none(),
                        )?;
                        let natural = bounds(&text_element)?;
                        axis_lengths(
                            &text_element,
                            writing,
                            Length::min_content(),
                            Length::auto(),
                            Length::none(),
                        )?;
                        println!(
                            "{}",
                            json!({"kind":"original","scale":scale,"family":family,"size":size,"writing":writing_name(writing),"text":text,"natural":natural,"minimum":bounds(&text_element)?})
                        );
                    }
                    drop(text_element);
                    drop(document);
                    for position in [Position::Absolute, Position::Fixed] {
                        for decorated in [false, true] {
                            for (scenario, preferred, minimum, maximum) in [
                                (
                                    "preferred_min",
                                    Length::min_content(),
                                    Length::auto(),
                                    Length::none(),
                                ),
                                (
                                    "preferred_max",
                                    Length::max_content(),
                                    Length::auto(),
                                    Length::none(),
                                ),
                                (
                                    "preferred_fit",
                                    Length::fit_content(),
                                    Length::auto(),
                                    Length::none(),
                                ),
                                (
                                    "min_then_fixed_max",
                                    Length::px(120.0),
                                    Length::min_content(),
                                    Length::px(60.0),
                                ),
                                (
                                    "fixed_min_then_max",
                                    Length::px(120.0),
                                    Length::px(10.0),
                                    Length::min_content(),
                                ),
                                (
                                    "both_intrinsic",
                                    Length::px(120.0),
                                    Length::min_content(),
                                    Length::max_content(),
                                ),
                                (
                                    "min_beats_max",
                                    Length::px(10.0),
                                    Length::max_content(),
                                    Length::min_content(),
                                ),
                                (
                                    "maximum_max",
                                    Length::px(300.0),
                                    Length::auto(),
                                    Length::max_content(),
                                ),
                            ] {
                                let document = Document::with_font_collection_and_options(
                                    ViewportMetrics::from_logical_size(80.0, 64.0, scale)?,
                                    fonts.clone(),
                                    EngineOptions {
                                        raster_configuration: raster,
                                    },
                                )?;
                                let text_element =
                                    element(&document, family, size, writing, position)?;
                                text_element.set_text("non-spanner in caption")?;
                                if decorated {
                                    text_element.set_padding_left(LengthValue::px(3.0))?;
                                    text_element.set_padding_right(LengthValue::px(5.0))?;
                                    text_element.set_padding_top(LengthValue::px(2.0))?;
                                    text_element.set_padding_bottom(LengthValue::px(4.0))?;
                                }
                                if scenario == "preferred_fit" {
                                    text_element.set_left(Length::px(3.0))?;
                                    text_element.set_right(Length::px(5.0))?;
                                    text_element.set_top(Length::px(3.0))?;
                                    text_element.set_bottom(Length::px(5.0))?;
                                }
                                axis_lengths(&text_element, writing, preferred, minimum, maximum)?;
                                let before = bounds(&text_element)?;
                                let owned = text_element
                                    .bounding_rect()?
                                    .ok_or("owned snapshot required")?;
                                let weak = text_element.downgrade();
                                let target = weak.clone();
                                let calls = Rc::new(Cell::new(0));
                                let observed = Rc::clone(&calls);
                                text_element.on("click", move |_| {
                                    target.upgrade().unwrap().set_text("XX").unwrap();
                                    observed.set(observed.get() + 1);
                                })?;
                                text_element.click()?;
                                assert_eq!(calls.get(), 1);
                                assert_eq!(text_element.text_content()?, "XX");
                                assert_eq!(
                                    before,
                                    json!({"x":owned.x,"y":owned.y,"width":owned.width,"height":owned.height})
                                );
                                assert_eq!(document.raster_configuration()?, raster);
                                println!(
                                    "{}",
                                    json!({"kind":"constraints","scale":scale,"family":family,"size":size,"writing":writing_name(writing),"position":if position==Position::Fixed {"fixed"} else {"absolute"},"decorated":decorated,"scenario":scenario,"before":before,"after":bounds(&text_element)?,"callback_calls":calls.get(),"owned_snapshot_unchanged":true})
                                );
                                drop(text_element);
                                drop(document);
                                assert!(weak.upgrade().is_none());
                            }
                        }
                    }
                }
            }
        }
    }
    Ok(())
}
