import base64, fcntl, hashlib, json, os, shutil, signal, subprocess, sys, time, tomllib
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b')
DRAFT=BASE/'native-fitted-monochrome-source-v4103';PROJECT=DRAFT/'project'
OUT=BASE/'native-fitted-monochrome-v4104';TARGET=Path('/mnt/e/openui-v02-cargo-c73754e2/target')
sys.path[:0]=[str(ROOT),str(ROOT/'tools/qualification'),'/tmp']
from openui_parallel_source_identity_v3060 import identity
from tools.accountability import run_all_pixel_comparisons as capture
from residuals import analyze_image_difference
load=lambda p:json.loads(Path(p).read_bytes())
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(2**20),b''):h.update(block)
    return h.hexdigest()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
prior=load('/tmp/openui-font-baseline-reaped-v4097.json')
assert prior['all_local_commands_terminal']
for name in ['cargo','rustc','rustfmt','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
plan=load(DRAFT/'plan.json');source=identity(ROOT)
assert source==plan['source'] and source['clean'] and not OUT.exists()
OUT.mkdir()
inputs={str(PROJECT/'src/main.rs'):plan['consumer_source_sha256'],str(PROJECT/'Cargo.toml'):plan['consumer_manifest_sha256'],str(PROJECT/'Cargo.lock'):plan['consumer_lock_sha256'],str(DRAFT/'plan.json'):sha(DRAFT/'plan.json'),str(DRAFT/'workspace-lock-template.txt'):plan['workspace_lock_template_sha256']}
def guard():
    assert identity(ROOT)==source
    for path,digest in inputs.items():assert sha(path)==digest,path
    for path,limit in [(ROOT,128*2**20),(OUT,10*2**30),(TARGET,10*2**30),(Path('/dev/shm'),256*2**20)]:assert shutil.disk_usage(path).free>limit,str(path)
env=dict(os.environ,CARGO_TARGET_DIR=str(TARGET),CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='4',RUST_MIN_STACK='4194304',PYTHONDONTWRITEBYTECODE='1',TMPDIR='/dev/shm')
env.pop('LD_PRELOAD',None);env.pop('LD_LIBRARY_PATH',None)
cargo=['cargo','--config',str(ROOT/'bindings/rust/.cargo/config.chromium.toml')]
manifest=['--manifest-path',str(PROJECT/'Cargo.toml')]
chrome=ROOT/'chrome/linux-147.0.7727.50/chrome-linux64/chrome'
chrome_env=capture.chrome_environment(str(chrome.parent),True,False);chrome_env['TMPDIR']='/dev/shm'
r=dict(schema_version=1,owner_pid=os.getpid(),source=source,input_sha256=inputs,driver_sha256=sha(__file__),prior_terminal_proof_sha256=sha('/tmp/openui-font-baseline-reaped-v4097.json'),cases=[],steps=[],all_commands_terminal=False,chromium_binary_sha256=sha(chrome),chromium_version=subprocess.check_output([str(chrome),'--version'],env=chrome_env,text=True).strip(),capture_harness_sha256=sha(ROOT/'tools/accountability/run_all_pixel_comparisons.py'),fontconfig_sha256=sha(chrome_env['FONTCONFIG_FILE']),pixel_target='pinned Chromium',pixel_tolerance=0,javascript_executed_by_openui=False,scripts_run_only_in_separate_chromium_reference_process=True,historical_openui_archive_is_a_pixel_target=False,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False)
assert r['chromium_version'].split()[-1]=='147.0.7727.50'
def save():
    p=OUT/'receipt.tmp';p.write_text(json.dumps(r,sort_keys=True,indent=2)+'\n');os.replace(p,OUT/'receipt.json')
def run(name,command,cwd=ROOT,timeout=1200):
    guard();print('Starting '+name,flush=True);log=OUT/(name+'.log');child=None
    try:
        with log.open('xb') as stream:
            child=subprocess.Popen(command,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
            r['current_process']=dict(name=name,pid=child.pid);save();start=time.monotonic()
            while child.poll() is None:
                assert time.monotonic()-start<timeout,name
                for path,limit in [(ROOT,128*2**20),(OUT,10*2**30),(TARGET,10*2**30),(Path('/dev/shm'),256*2**20)]:assert shutil.disk_usage(path).free>limit,str(path)
                time.sleep(1)
            code=child.wait()
    finally:
        if child is not None and child.poll() is None:
            os.killpg(child.pid,signal.SIGTERM)
            try:child.wait(timeout=20)
            except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
        r.pop('current_process',None);r['steps'].append(dict(name=name,command=command,pid=None if child is None else child.pid,actual_exit_code=None if child is None else child.returncode,log_sha256=sha(log)));save()
    guard();print(json.dumps(dict(stage=name,actual_exit_code=code)),flush=True);return code,log
reference_owner=BASE/'native-monochrome-font-v4074'
reference=load(reference_owner/'receipt.json')
r['reference_receipt_sha256']=sha(reference_owner/'receipt.json');r['reference_files_sha256']={}
for i,row in enumerate(reference['cases']):
    for stage in ['before','after']:
        for suffix in ['.json','-metrics.json','-capture-1.png','-platform-fonts.json']:
            path=reference_owner/f'profile-{i}/chromium-1-system-{stage}{suffix}'
            r['reference_files_sha256'][str(path)]=sha(path)
inputs.update(r['reference_files_sha256'])
save();code=1
try:
    status,log=run('metadata',cargo+['metadata','--locked','--offline','--format-version','1']+manifest,ROOT/'bindings/rust');assert status==0
    metadata=load(log);local_ids={p['id'] for p in metadata['packages'] if Path(p['manifest_path']).resolve().is_relative_to(ROOT) or Path(p['manifest_path']).resolve().is_relative_to(PROJECT)}
    status,_=run('clean-local-packages',cargo+['clean','--locked','--offline']+manifest+[a for pid in sorted(local_ids) for a in ['-p',pid]],ROOT/'bindings/rust');assert status==0
    status,log=run('native-build',cargo+['build','--locked','--offline','--message-format=json-render-diagnostics']+manifest,ROOT/'bindings/rust');assert status==0
    artifacts=[];compiled={}
    for line in log.read_text().splitlines():
        try:row=json.loads(line)
        except json.JSONDecodeError:continue
        if row.get('reason')=='compiler-artifact' and row['package_id'] in local_ids:
            assert row['fresh'] is False;artifacts.append(row)
            for path in row['filenames']:compiled[path]=sha(path)
    assert len({row['package_id'] for row in artifacts})==len(local_ids)
    binary=TARGET/'debug/openui-native-flex-measurement';r['binary']=str(binary);r['binary_sha256']=sha(binary);r['compiler_artifacts']=artifacts;r['compiled_artifact_sha256']=compiled;save()
    for i,ref in enumerate(reference['cases']):
        profile=ref['profile'];directory=OUT/f'profile-{i}';directory.mkdir()
        row=dict(profile=profile,native={});r['cases'].append(row)
        for config in plan['native_configurations']:
            backend=config['backend'];mode=config['font_mode'];key=config['key']
            result=dict(runs=[],stages={});row['native'][key]=result
            for repeat in [1,2]:
                native=directory/f'native-{key}-{repeat}'
                status,_=run(f'profile-{i}-{key}-{repeat}',[str(binary),str(native),str(profile['width']),str(profile['height']),str(profile['scale']),mode,backend],timeout=120);assert status==0
                assert load(native/'lifecycle.json')==dict(callbacks=1,weak_teardown_passed=True,javascript_executed_by_openui=False)
                result['runs'].append(dict(directory=str(native),files={path.name:sha(path) for path in sorted(native.iterdir())}));save()
            assert result['runs'][0]['files']==result['runs'][1]['files']
            for stage in ['before','after']:
                expected=ref['chromium_geometry'][f'system-{stage}'];bounds=load(directory/f'native-{key}-1/{stage}.json')
                assert len(bounds)==len(expected)==48
                result['stages'][stage]=dict(native_bounds=bounds,chromium_bounds=expected,exact_bounds=sum(a==b for a,b in zip(bounds,expected)),bounds_count=48,analysis=analyze_image_difference(reference_owner/f'profile-{i}/chromium-1-system-{stage}-capture-1.png',directory/f'native-{key}-1/{stage}.png'))
            save();print(json.dumps(dict(profile=profile,backend=backend,font_mode=mode,exact_bounds={k:v['exact_bounds'] for k,v in result['stages'].items()},different_pixels={k:v['analysis']['mismatched_pixels'] for k,v in result['stages'].items()})),flush=True)
    snapshot=OUT/'native-consumer';shutil.copyfile(binary,snapshot);assert sha(snapshot)==r['binary_sha256'];r['retained_binary']=str(snapshot)
    r['totals']={backend:dict(images=10,exact_images=sum(stage['analysis']['mismatched_pixels']==0 for row in r['cases'] for stage in row['native'][backend]['stages'].values()),bounds=480,exact_bounds=sum(stage['exact_bounds'] for row in r['cases'] for stage in row['native'][backend]['stages'].values())) for backend in [v['key'] for v in plan['native_configurations']]}
    code=int(any(v['exact_images']!=v['images'] or v['exact_bounds']!=v['bounds'] for v in r['totals'].values()))
except BaseException as exc:
    r['failure']=repr(exc);raise
finally:
    r['source_after']=identity(ROOT);r['source_unchanged']=r['source_after']==source;r['inputs_unchanged']=all(sha(path)==digest for path,digest in inputs.items());r['all_commands_terminal']=True;r['observed_exit_code']=code;save()
print(json.dumps(dict(actual_exit_code=code,totals=r.get('totals'),source_unchanged=r['source_unchanged'])),flush=True)
raise SystemExit(code)
