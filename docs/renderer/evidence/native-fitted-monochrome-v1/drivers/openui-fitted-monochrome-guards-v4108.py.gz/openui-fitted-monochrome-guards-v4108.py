import base64, fcntl, hashlib, json, os, shutil, signal, subprocess, sys, time, tomllib
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b')
DRAFT=BASE/'native-fitted-monochrome-source-v4103';PROJECT=DRAFT/'project'
OUT=BASE/'native-fitted-monochrome-guards-v4108';TARGET=Path('/mnt/e/openui-v02-cargo-c73754e2/target')
sys.path[:0]=[str(ROOT),str(ROOT/'tools/qualification'),'/tmp']
from openui_parallel_source_identity_v3060 import identity
from tools.accountability import run_all_pixel_comparisons as capture
from residuals import analyze_image_difference
load=lambda p:json.loads(Path(p).read_bytes())
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(2**20),b''):h.update(block)
    return h.hexdigest()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
prior=load('/tmp/openui-fitted-monochrome-reaped-v4119.json')
assert prior['all_local_commands_terminal'] and prior['owners_absent']
for name in ['cargo','rustc','rustfmt','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
plan=load(DRAFT/'plan.json');source=identity(ROOT)
assert source==plan['source'] and source['clean'] and not OUT.exists()
OUT.mkdir()
inputs={str(PROJECT/'src/main.rs'):plan['consumer_source_sha256'],str(PROJECT/'Cargo.toml'):plan['consumer_manifest_sha256'],str(PROJECT/'Cargo.lock'):plan['consumer_lock_sha256'],str(DRAFT/'plan.json'):sha(DRAFT/'plan.json'),str(DRAFT/'workspace-lock-template.txt'):plan['workspace_lock_template_sha256']}
def guard():
    assert identity(ROOT)==source
    for path,digest in inputs.items():assert sha(path)==digest,path
    for path,limit in [(ROOT,128*2**20),(OUT,10*2**30),(TARGET,10*2**30),(Path('/dev/shm'),256*2**20)]:assert shutil.disk_usage(path).free>limit,str(path)
env=dict(os.environ,CARGO_TARGET_DIR=str(TARGET),CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='4',RUST_MIN_STACK='4194304',PYTHONDONTWRITEBYTECODE='1',TMPDIR='/dev/shm')
env.pop('LD_PRELOAD',None);env.pop('LD_LIBRARY_PATH',None)
cargo=['cargo','--config',str(ROOT/'bindings/rust/.cargo/config.chromium.toml')]
manifest=['--manifest-path',str(PROJECT/'Cargo.toml')]
chrome=ROOT/'chrome/linux-147.0.7727.50/chrome-linux64/chrome'
chrome_env=capture.chrome_environment(str(chrome.parent),True,False);chrome_env['TMPDIR']='/dev/shm'
r=dict(schema_version=1,owner_pid=os.getpid(),source=source,input_sha256=inputs,driver_sha256=sha(__file__),prior_terminal_proof_sha256=sha('/tmp/openui-fitted-monochrome-reaped-v4119.json'),cases=[],steps=[],all_commands_terminal=False,chromium_binary_sha256=sha(chrome),chromium_version=subprocess.check_output([str(chrome),'--version'],env=chrome_env,text=True).strip(),capture_harness_sha256=sha(ROOT/'tools/accountability/run_all_pixel_comparisons.py'),fontconfig_sha256=sha(chrome_env['FONTCONFIG_FILE']),pixel_target='pinned Chromium',pixel_tolerance=0,javascript_executed_by_openui=False,scripts_run_only_in_separate_chromium_reference_process=True,historical_openui_archive_is_a_pixel_target=False,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False)
assert r['chromium_version'].split()[-1]=='147.0.7727.50'
def save():
    p=OUT/'receipt.tmp';p.write_text(json.dumps(r,sort_keys=True,indent=2)+'\n');os.replace(p,OUT/'receipt.json')
def run(name,command,cwd=ROOT,timeout=1200):
    guard();print('Starting '+name,flush=True);log=OUT/(name+'.log');child=None
    try:
        with log.open('xb') as stream:
            child=subprocess.Popen(command,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
            r['current_process']=dict(name=name,pid=child.pid);save();start=time.monotonic()
            while child.poll() is None:
                assert time.monotonic()-start<timeout,name
                for path,limit in [(ROOT,128*2**20),(OUT,10*2**30),(TARGET,10*2**30),(Path('/dev/shm'),256*2**20)]:assert shutil.disk_usage(path).free>limit,str(path)
                time.sleep(1)
            code=child.wait()
    finally:
        if child is not None and child.poll() is None:
            os.killpg(child.pid,signal.SIGTERM)
            try:child.wait(timeout=20)
            except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
        r.pop('current_process',None);r['steps'].append(dict(name=name,command=command,pid=None if child is None else child.pid,actual_exit_code=None if child is None else child.returncode,log_sha256=sha(log)));save()
    guard();print(json.dumps(dict(stage=name,actual_exit_code=code)),flush=True);return code,log
save();code=1
try:
    status,log=run('native-font-units',cargo+['test','--locked','--offline','-p','openui','--test','native_font_units'],ROOT/'bindings/rust')
    assert status==0
    text=log.read_text();assert 'test result: ok. 3 passed; 0 failed; 0 ignored;' in text
    status,log=run('legacy-alias-paint-policy',cargo+['test','--locked','--offline','-p','openui-paint','--lib','aliased_ahem_start_replay_uses_integral_physical_magnification'],ROOT/'bindings/rust')
    assert status==0 and 'test result: ok. 1 passed; 0 failed; 0 ignored;' in log.read_text()
    r['results']=dict(native_font_units=dict(passed=3,failed=0,ignored=0),legacy_alias_policy=dict(passed=1,failed=0,ignored=0));code=0
except BaseException as exc:
    r['failure']=repr(exc);raise
finally:
    r['source_after']=identity(ROOT);r['source_unchanged']=r['source_after']==source;r['inputs_unchanged']=all(sha(path)==digest for path,digest in inputs.items());r['all_commands_terminal']=True;r['observed_exit_code']=code;save()
print(json.dumps(dict(actual_exit_code=code,results=r.get('results'),source_unchanged=r['source_unchanged'])),flush=True)
raise SystemExit(code)
