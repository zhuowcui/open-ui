import hashlib,json,shutil,sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b')
sys.path.insert(0,'/tmp');from openui_parallel_source_identity_v3060 import identity
OLD=BASE/'native-monochrome-backend-source-v4087';OUT=BASE/'native-fitted-monochrome-source-v4103'
assert not OUT.exists();source=identity(ROOT);assert source['clean'] and source['commit'].startswith('1576f01a')
prior=Path('/tmp/openui-font-baseline-reaped-v4097.json');assert json.loads(prior.read_text())['all_local_commands_terminal']
shutil.copytree(OLD/'project',OUT/'project');shutil.copyfile(OLD/'workspace-lock-template.txt',OUT/'workspace-lock-template.txt')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
plan=json.loads((OLD/'plan.json').read_text());plan.update(source=source,preparation='Verify shared removal of legacy row replay for fitted monochrome author strikes at five scales, two font collections and both explicit CPU paint paths; unchanged immutable Chromium references.',prior_reaping_sha256=sha(prior),consumer_source_sha256=sha(OUT/'project/src/main.rs'),consumer_manifest_sha256=sha(OUT/'project/Cargo.toml'),consumer_lock_sha256=sha(OUT/'project/Cargo.lock'),native_configurations=[dict(key=backend+'-'+mode,backend=backend,font_mode=mode) for backend in ['chromium','skia'] for mode in ['registered','system']])
(OUT/'plan.json').write_text(json.dumps(plan,sort_keys=True,indent=2)+'\n')
old=Path('/tmp/openui-native-monochrome-backend-v4088.py').read_text()
s=old.replace('native-monochrome-backend-source-v4087','native-fitted-monochrome-source-v4103').replace('native-monochrome-backend-v4088','native-fitted-monochrome-v4104').replace('native-monochrome-final-v4086','font-baseline-reaped-v4097').replace("prior['all_local_owners_helpers_readers_terminal']","prior['all_local_commands_terminal']")
s=s.replace("for backend in plan['native_backends']:","for config in plan['native_configurations']:\n            backend=config['backend'];mode=config['font_mode'];key=config['key']")
s=s.replace("row['native'][backend]=result","row['native'][key]=result").replace("f'native-{backend}-{repeat}'","f'native-{key}-{repeat}'").replace("f'profile-{i}-{backend}-{repeat}'","f'profile-{i}-{key}-{repeat}'")
s=s.replace("'system',backend]","mode,backend]").replace("f'native-{backend}-1/","f'native-{key}-1/")
s=s.replace('profile=profile,backend=backend,exact_bounds=','profile=profile,backend=backend,font_mode=mode,exact_bounds=')
s=s.replace("for backend in plan['native_backends']}","for backend in [v['key'] for v in plan['native_configurations']]}")
assert "plan['native_backends']" not in s
compile(s,'/tmp/openui-fitted-monochrome-v4104.py','exec')
p=Path('/tmp/openui-fitted-monochrome-v4104.py');assert not p.exists();p.write_text(s)
print(json.dumps(dict(source=source,source_directory=str(OUT),driver=str(p),native_configurations=plan['native_configurations'])))
