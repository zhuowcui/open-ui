from pathlib import Path
old=Path('/tmp/openui-native-monochrome-font-v4074.py').read_text()
prefix=old[:old.index('READY=')]
prefix=prefix.replace('native-monochrome-font-source-v4073','native-font-baseline-source-v4094').replace('native-monochrome-font-v4074','native-font-baseline-v4095').replace('native-monochrome-font-reaped-v4070','native-monochrome-backend-reaped-v4090')
start=prefix.index("inputs[str(ROOT/'tools/accountability/data/wpt_ported/all_wpt_templates.json')]")
end=prefix.index('def guard():',start)
prefix=prefix[:start]+prefix[end:]
body=old[old.index('READY='):old.index('save();code=1')]
body=body.replace('ou4041-','ou4095-')
body=body.replace("len(observations[0])==(6 if stage=='original' else plan['native_node_count'])","len(observations[0])==plan['native_node_count']")
body=body.replace("selector='#flexbox' if stage=='original' else '#word-0'","selector='#word-0'")
tail='''save();code=1
try:
    for i,p in enumerate(plan['required_profiles']):
        directory=OUT/f'profile-{i}';directory.mkdir()
        observations=[oracle(directory,repeat,p) for repeat in [1,2]]
        assert observations[0]==observations[1]
        baseline=reference_owner/f'profile-{i}'
        comparisons={}
        for stage in plan['stages']:
            assert sha(directory/f'chromium-1-{stage}-capture-1.png')==sha(directory/f'chromium-2-{stage}-capture-1.png')
            comparisons[stage]=analyze_image_difference(baseline/f'chromium-1-system-{stage}-capture-1.png',directory/f'chromium-1-{stage}-capture-1.png')
            assert comparisons[stage]['mismatched_pixels']==0
            original=load(baseline/f'chromium-1-system-{stage}.json')
            retained=[value for value in observations[0][stage] if not value['name'].startswith('baseline-')]
            assert retained==original
        r['cases'].append(dict(profile=p,chromium_geometry=observations[0],chromium_process_repeats_equal=True,marker_pixels_unchanged=comparisons));save()
        print(json.dumps(dict(stage='chromium-baseline-marker',profile=p,baseline_markers=[v for v in observations[0]['before'] if v['name'].startswith('baseline-')])),flush=True)
    status,log=run('metadata',cargo+['metadata','--locked','--offline','--format-version','1']+manifest,ROOT/'bindings/rust');assert status==0
    metadata=load(log);local_ids={p['id'] for p in metadata['packages'] if Path(p['manifest_path']).resolve().is_relative_to(ROOT) or Path(p['manifest_path']).resolve().is_relative_to(PROJECT)}
    status,_=run('clean-local-packages',cargo+['clean','--locked','--offline']+manifest+[a for pid in sorted(local_ids) for a in ['-p',pid]],ROOT/'bindings/rust');assert status==0
    status,log=run('native-build',cargo+['build','--locked','--offline','--message-format=json-render-diagnostics']+manifest,ROOT/'bindings/rust');assert status==0
    artifacts=[];compiled={}
    for line in log.read_text().splitlines():
        try:row=json.loads(line)
        except json.JSONDecodeError:continue
        if row.get('reason')=='compiler-artifact' and row['package_id'] in local_ids:
            assert row['fresh'] is False;artifacts.append(row)
            for path in row['filenames']:compiled[path]=sha(path)
    assert len({row['package_id'] for row in artifacts})==len(local_ids)
    binary=TARGET/'debug/openui-native-flex-measurement';r['binary']=str(binary);r['binary_sha256']=sha(binary);r['compiler_artifacts']=artifacts;r['compiled_artifact_sha256']=compiled;save()
    for i,row in enumerate(r['cases']):
        p=row['profile'];directory=OUT/f'profile-{i}';row['native']={}
        for mode in plan['native_profiles']:
            result=dict(runs=[],stages={});row['native'][mode]=result
            for repeat in [1,2]:
                native=directory/f'native-{mode}-{repeat}'
                status,_=run(f'profile-{i}-native-{mode}-{repeat}',[str(binary),str(native),str(p['width']),str(p['height']),str(p['scale']),'system',mode],timeout=120);assert status==0
                assert load(native/'lifecycle.json')==dict(callbacks=1,weak_teardown_passed=True,javascript_executed_by_openui=False)
                result['runs'].append(dict(directory=str(native),files={path.name:sha(path) for path in sorted(native.iterdir())}));save()
            assert result['runs'][0]['files']==result['runs'][1]['files']
            for stage in plan['stages']:
                bounds=load(directory/f'native-{mode}-1/{stage}.json');reference=row['chromium_geometry'][stage]
                assert len(bounds)==len(reference)==56 and [v['name'] for v in bounds]==[v['name'] for v in reference]
                markers=[dict(native=a,chromium=b,exact=a==b) for a,b in zip(bounds,reference) if a['name'].startswith('baseline-')]
                result['stages'][stage]=dict(native_bounds=bounds,chromium_bounds=reference,exact_bounds=sum(a==b for a,b in zip(bounds,reference)),bounds_count=56,baseline_markers=markers,analysis=analyze_image_difference(directory/f'chromium-1-{stage}-capture-1.png',directory/f'native-{mode}-1/{stage}.png'))
                if mode=='full':
                    previous=reference_owner/f'profile-{i}/native-system-1/{stage}.png'
                    result['stages'][stage]['marker_pixels_unchanged']=analyze_image_difference(previous,directory/f'native-{mode}-1/{stage}.png')
                    assert result['stages'][stage]['marker_pixels_unchanged']['mismatched_pixels']==0
            save();print(json.dumps(dict(profile=p,mode=mode,exact_bounds={k:v['exact_bounds'] for k,v in result['stages'].items()},baseline_markers=result['stages']['before']['baseline_markers'],different_pixels={k:v['analysis']['mismatched_pixels'] for k,v in result['stages'].items()})),flush=True)
    snapshot=OUT/'native-consumer';shutil.copyfile(binary,snapshot);assert sha(snapshot)==r['binary_sha256'];r['retained_binary']=str(snapshot);save()
    r['totals']={mode:dict(images=10,exact_images=sum(stage['analysis']['mismatched_pixels']==0 for row in r['cases'] for stage in row['native'][mode]['stages'].values()),bounds=560,exact_bounds=sum(stage['exact_bounds'] for row in r['cases'] for stage in row['native'][mode]['stages'].values()),baseline_markers=80,exact_baseline_markers=sum(marker['exact'] for row in r['cases'] for stage in row['native'][mode]['stages'].values() for marker in stage['baseline_markers'])) for mode in plan['native_profiles']}
    code=int(any(v['exact_images']!=v['images'] or v['exact_bounds']!=v['bounds'] for v in r['totals'].values()))
except BaseException as exc:
    r['failure']=repr(exc);raise
finally:
    r['source_after']=identity(ROOT);r['source_unchanged']=r['source_after']==source;r['inputs_unchanged']=all(sha(path)==digest for path,digest in inputs.items());r['all_commands_terminal']=True;r['observed_exit_code']=code;save()
print(json.dumps(dict(actual_exit_code=code,totals=r.get('totals'),source_unchanged=r['source_unchanged'])),flush=True)
raise SystemExit(code)
'''
refs='''reference_owner=BASE/'native-monochrome-font-v4074'
r['reference_receipt_sha256']=sha(reference_owner/'receipt.json')
for i in range(5):
    for stage in ['before','after']:
        for name in [f'chromium-1-system-{stage}-capture-1.png',f'chromium-1-system-{stage}.json',f'native-system-1/{stage}.png']:
            p=reference_owner/f'profile-{i}'/name;inputs[str(p)]=sha(p)
r['input_sha256']=inputs
r['alternate_chromium_font_engine_flags_not_used']=True
r['font_engine_selection_reason']='Pinned constructor gates FontDataManager on sandboxEnabled(); this existing --no-sandbox oracle cannot prove service typeface selection from a feature flag.'
'''
script=prefix+refs+body+tail
compile(script,'/tmp/openui-font-baseline-v4095.py','exec')
p=Path('/tmp/openui-font-baseline-v4095.py');assert not p.exists();p.write_text(script)
print(str(p))
