import hashlib, json, shutil, subprocess, sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b')
sys.path.insert(0,'/tmp')
from openui_parallel_source_identity_v3060 import identity
OLD=BASE/'native-monochrome-backend-source-v4087'
OUT=BASE/'native-font-baseline-source-v4094';assert not OUT.exists()
assert json.loads(Path('/tmp/openui-native-monochrome-backend-reaped-v4090.json').read_text())['all_local_commands_terminal']
source=identity(ROOT);assert source['clean']
shutil.copytree(OLD/'project',OUT/'project')
shutil.copyfile(OLD/'workspace-lock-template.txt',OUT/'workspace-lock-template.txt')
main=OUT/'project/src/main.rs';s=main.read_text()
s=s.replace('use openui_text::{Font, FontDescription, TextShaper};','use openui_text::{Font, FontDescription, TextShaper};\nuse openui_text::shaping::TextRasterPolicy;')
old='''    let backend = match args.next().as_deref() {
        Some("chromium") => RasterBackend::ChromiumLinux,
        Some("skia") => RasterBackend::Skia,
        _ => return Err("backend requires chromium or skia".into()),
    };'''
new='''    let raster_configuration = match args.next().as_deref() {
        Some("full") => RasterConfiguration::chromium_linux_monochrome(),
        Some("none") => RasterConfiguration::deterministic_aliased(false),
        _ => return Err("profile requires full or none".into()),
    };'''
assert old in s;s=s.replace(old,new)
old='''            raster_configuration: RasterConfiguration::chromium_linux_monochrome()
                .with_backend(backend),'''
assert old in s;s=s.replace(old,'            raster_configuration,')
old='''            nodes.push((format!("item-{i}-{j}"), item));'''
new='''            nodes.push((format!("item-{i}-{j}"), item.clone()));
            if j == 0 {
                item.set_text_wrap_mode(TextWrapMode::Nowrap)?;
                let marker = Element::create(&document, "span")?;
                item.append_child(&marker)?;
                marker.set_display(Display::InlineBlock)?;
                marker.set_width(LengthValue::px(0.0))?;
                marker.set_height(LengthValue::px(0.0))?;
                marker.set_vertical_align(VerticalAlign::Baseline)?;
                nodes.push((format!("baseline-item-{i}"), marker));
            }'''
assert old in s;s=s.replace(old,new)
old='''        nodes.push((format!("word-{i}"), word));'''
new='''        nodes.push((format!("word-{i}"), word.clone()));
        word.set_text_wrap_mode(TextWrapMode::Nowrap)?;
        let marker = Element::create(&document, "span")?;
        word.append_child(&marker)?;
        marker.set_display(Display::InlineBlock)?;
        marker.set_width(LengthValue::px(0.0))?;
        marker.set_height(LengthValue::px(0.0))?;
        marker.set_vertical_align(VerticalAlign::Baseline)?;
        nodes.push((format!("baseline-word-{i}"), marker));'''
assert old in s;s=s.replace(old,new)
old='''            serde_json::json!({"text":text,"unshaped_width":font.width(text)'''
new='''            let blob_bounds = [TextRasterPolicy::Skia, TextRasterPolicy::ChromiumAuthorAliased].iter().map(|policy| {
                let bounds=shaped.to_text_blob_with_raster_policy_at_scale(None,*policy,physical_scale).map(|blob| {
                    let b=blob.bounds();serde_json::json!({"left":b.left,"top":b.top,"right":b.right,"bottom":b.bottom})
                });
                serde_json::json!({"policy":format!("{:?}",policy),"bounds":bounds})
            }).collect::<Vec<_>>();
            serde_json::json!({"physical_blob_bounds":blob_bounds,"text":text,"unshaped_width":font.width(text)'''
assert old in s;s=s.replace(old,new)
fmt=subprocess.run(['rustfmt','--edition','2021','--config','skip_children=true','--emit','stdout'],input=s.encode(),capture_output=True);assert fmt.returncode==0,fmt.stderr.decode();main.write_bytes(fmt.stdout)
refs=BASE/'native-monochrome-font-source-v4073'
html_sha={}
for stage in ['before','after']:
 html=(refs/f'oracle-system-{stage}.html').read_text()
 marker=lambda name:'<span id="'+name+'" style="display:inline-block;width:0;height:0;vertical-align:baseline"></span>'
 for i in range(6):
  old=f'<div class="item" id="item-{i}-0">DIV1</div>';new=f'<div class="item" id="item-{i}-0" style="white-space:nowrap">DIV1'+marker(f'baseline-item-{i}')+'</div>'
  assert old in html;html=html.replace(old,new)
 for i in range(2):
  old=f'<span id="word-{i}" style="display:inline-block">ABCDEFGHI</span>';new=f'<span id="word-{i}" style="display:inline-block;white-space:nowrap">ABCDEFGHI'+marker(f'baseline-word-{i}')+'</span>'
  assert old in html;html=html.replace(old,new)
 p=OUT/f'oracle-{stage}.html';p.write_text(html);html_sha[stage]=hashlib.sha256(p.read_bytes()).hexdigest()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
plan=json.loads((OLD/'plan.json').read_text());plan.update(source=source,preparation='Measure zero-sized inline baseline markers and physical glyph bounds; compare Chromium engine flags and native Full/None settings. Alternate engine captures do not replace frozen references.',consumer_source_sha256=sha(main),consumer_manifest_sha256=sha(OUT/'project/Cargo.toml'),consumer_lock_sha256=sha(OUT/'project/Cargo.lock'),workspace_lock_template_sha256=sha(OUT/'workspace-lock-template.txt'),reference_html_sha256=html_sha,native_profiles=['full','none'],chromium_engines=['default','Freetype','Fontations'],native_node_count=56,stages=['before','after'],source_review_sha256=sha(BASE/'chromium-font-baseline-source-v4093/receipt.json'),prior_reaping_sha256=sha('/tmp/openui-native-monochrome-backend-reaped-v4090.json'))
(OUT/'plan.json').write_text(json.dumps(plan,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(project=str(OUT/'project'),source=source,consumer_sha256=sha(main),reference_html_sha256=html_sha)))
