import fcntl, hashlib, json, subprocess, sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui')
OUT=Path('/mnt/d/openui-v02-qualification-d174ea0b/native-monochrome-backend-v4088')
DEST=Path('/tmp/openui-native-monochrome-backend-audit-v4089.json')
sys.path.insert(0,'/tmp')
from openui_parallel_source_identity_v3060 import identity
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(2**20),b''): h.update(block)
    return h.hexdigest()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
r=json.loads((OUT/'receipt.json').read_bytes())
assert not DEST.exists() and r['observed_exit_code']==int(sys.argv[1])
assert r['all_commands_terminal'] and 'failure' not in r
assert identity(ROOT)==r['source']==r['source_after'] and r['source_unchanged'] and r['inputs_unchanged']
assert sha('/tmp/openui-native-monochrome-backend-v4088.py')==r['driver_sha256']
for path,digest in r['input_sha256'].items(): assert sha(path)==digest
for name in ['cargo','rustc','rustfmt','pixel_compare']:
    assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
for pid in [r['owner_pid']]+[s['pid'] for s in r['steps']]:
    assert subprocess.run(['ps','-p',str(pid)],capture_output=True).returncode==1
for s in r['steps']:
    assert s['actual_exit_code']==0 and sha(OUT/(s['name']+'.log'))==s['log_sha256']
for path,digest in r['compiled_artifact_sha256'].items(): assert sha(path)==digest
for artifact in r['compiler_artifacts']: assert artifact['fresh'] is False
assert sha(r['binary'])==sha(r['retained_binary'])==r['binary_sha256']
sys.path.insert(0,str(ROOT/'tools/qualification'))
from residuals import analyze_image_difference
reference_owner=Path('/mnt/d/openui-v02-qualification-d174ea0b/native-monochrome-font-v4074')
assert sha(reference_owner/'receipt.json')==r['reference_receipt_sha256']
reference=json.loads((reference_owner/'receipt.json').read_bytes())
for path,digest in r['reference_files_sha256'].items():assert sha(path)==digest
assert len(r['cases'])==5
totals={};files={}
for i,row in enumerate(r['cases']):
    directory=OUT/f'profile-{i}'
    for backend,result in row['native'].items():
        assert result['runs'][0]['files']==result['runs'][1]['files']
        for run in result['runs']:
            for name,digest in run['files'].items():assert sha(Path(run['directory'])/name)==digest
            assert json.loads((Path(run['directory'])/'lifecycle.json').read_bytes())==dict(callbacks=1,weak_teardown_passed=True,javascript_executed_by_openui=False)
        total=totals.setdefault(backend,dict(images=0,exact_images=0,bounds=0,exact_bounds=0))
        for stage,data in result['stages'].items():
            ref=reference_owner/f'profile-{i}/chromium-1-system-{stage}-capture-1.png'
            actual=directory/f'native-{backend}-1/{stage}.png'
            assert analyze_image_difference(ref,actual)==data['analysis']
            assert data['chromium_bounds']==reference['cases'][i]['chromium_geometry'][f'system-{stage}']
            assert data['native_bounds']==json.loads((directory/f'native-{backend}-1/{stage}.json').read_bytes())
            exact=sum(a==b for a,b in zip(data['native_bounds'],data['chromium_bounds']));assert exact==data['exact_bounds']
            total['images']+=1;total['exact_images']+=data['analysis']['mismatched_pixels']==0;total['bounds']+=48;total['exact_bounds']+=exact
            if backend=='chromium':assert sha(actual)==sha(reference_owner/f'profile-{i}/native-system-1/{stage}.png')
    for path in directory.rglob('*'):
        if path.is_file():files[str(path.relative_to(OUT))]=sha(path)
assert totals==r['totals']
assert r['observed_exit_code']==int(any(v['exact_images']!=v['images'] or v['exact_bounds']!=v['bounds'] for v in totals.values()))
p=dict(schema_version=1,complete=True,owner_absent=True,source=r['source'],actual_owner_exit_code=r['observed_exit_code'],receipt_sha256=sha(OUT/'receipt.json'),audit_driver_sha256=sha(__file__),fresh_compiler_records=len(r['compiler_artifacts']),compiled_paths_verified=len(r['compiled_artifact_sha256']),totals=totals,baseline_pixels_unchanged=True,all_files_sha256=files,production_source_unchanged=True,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,retired_for_reexecution_after_source_or_target_mutation=True)
DEST.write_text(json.dumps(p,sort_keys=True,indent=2)+'\n')
print(json.dumps(p),flush=True)
