from pathlib import Path
old=Path('/tmp/openui-native-monochrome-backend-reaping-v4090.py').read_text()
s=old.replace('native-monochrome-backend-v4088','native-font-baseline-v4095').replace('native-monochrome-backend-audit-v4089','font-baseline-audit-v4096').replace('native-monochrome-backend-reaped-v4090','font-baseline-reaped-v4097')
exec(compile(s,__file__,'exec'))
