import gzip,hashlib,json,subprocess
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b')
OUT=ROOT/'docs/renderer/evidence/native-fitted-monochrome-v1';INDEX=ROOT/'docs/renderer/generated/native-fitted-monochrome-v1.json'
load=lambda p:json.loads(Path(p).read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest()
assert not OUT.exists() and not INDEX.exists()
proof=load('/tmp/openui-fitted-monochrome-guards-reaped-v4110.json')
assert proof['all_local_commands_terminal'] and proof['owners_absent']
native=load(BASE/'native-fitted-monochrome-v4104/receipt.json');audit=load('/tmp/openui-fitted-monochrome-audit-v4118.json')
assert native['source']['clean'] and native['source']==proof['source'] and native['all_commands_terminal'] and native['observed_exit_code']==0
assert native['totals']=={key:dict(images=10,exact_images=10,bounds=480,exact_bounds=480) for key in ['chromium-registered','chromium-system','skia-registered','skia-system']}
assert audit['complete'] and audit['three_times_pixels_now_exact']
baseline=load(BASE/'native-font-baseline-v4095/receipt.json');baseline_audit=load('/tmp/openui-font-baseline-audit-v4096.json')
assert baseline['observed_exit_code']==1 and baseline_audit['exact_baseline_y']==dict(full=80,none=80)
previous=[]
for name,expected in [('native-monochrome-font-v1','fce8b94ceb70a8a14a24997143aae736fc01af62021a09844be9e9d0e7ad7879'),('native-font-origin-v1','b509eb250454a6b449201aa5236dc56f36a9602dbc7b1866d99260157217ff6b')]:
 p=ROOT/f'docs/renderer/generated/{name}.json';assert sha(p.read_bytes())==expected
 for row in load(p)['archive']['members']:
  stored=(ROOT/row['path']).read_bytes();assert sha(stored)==row['sha256']
  raw=gzip.decompress(stored) if row['compression']=='gzip' else stored;assert sha(raw)==row['raw_sha256']
 previous.append(dict(path=str(p.relative_to(ROOT)),sha256=expected,members_verified=load(p)['archive']['files']))
members=[];excluded=[]
def add(source,relative):
 raw=Path(source).read_bytes();compressed=Path(source).suffix not in ['.png','.gz'];data=gzip.compress(raw,compresslevel=9,mtime=0) if compressed else raw
 p=OUT/(relative+('.gz' if compressed else ''));assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 assert (gzip.decompress(p.read_bytes()) if compressed else p.read_bytes())==raw
 members.append(dict(path=str(p.relative_to(ROOT)),compression='gzip' if compressed else 'none',bytes=len(data),sha256=sha(data),raw_bytes=len(raw),raw_sha256=sha(raw)))
directories=['native-monochrome-backend-source-v4087','native-monochrome-backend-v4088','native-monochrome-hosted-v4091','chromium-glyph-backend-source-v4092','chromium-font-baseline-source-v4093','native-font-baseline-source-v4094','native-font-baseline-v4095','chromium-font-manager-source-v4098','chromium-skia-mono-source-v4099','chromium-skia-fontations-lock-v4100','chromium-fontations-versions-v4101','chromium-fontations-code-v4102','native-fitted-monochrome-source-v4103','native-fitted-monochrome-v4104','native-fitted-monochrome-hosted-parent-v4107','native-fitted-monochrome-guards-v4108']
for name in directories:
 for p in sorted((BASE/name).rglob('*')):
  if not p.is_file():continue
  if p.name=='native-consumer':
   r=load(BASE/name/'receipt.json');assert hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==r['binary_sha256']
   excluded.append(dict(path=str(p),sha256=r['binary_sha256'],reason='Owned measured executable retained outside Git.'))
  else:add(p,str(Path(name)/p.relative_to(BASE/name)))
for name in ['openui-native-monochrome-backend-audit-v4089','openui-native-monochrome-backend-reaped-v4090','openui-font-baseline-audit-v4096','openui-font-baseline-reaped-v4097','openui-fitted-monochrome-audit-v4118','openui-fitted-monochrome-reaped-v4119','openui-fitted-monochrome-guards-audit-v4109','openui-fitted-monochrome-guards-reaped-v4110']:
 add(Path('/tmp')/(name+'.json'),'proofs/'+name+'.json')
for name in ['openui-native-monochrome-backend-v4088','openui-native-monochrome-backend-audit-v4089','openui-native-monochrome-backend-reaping-v4090','openui-font-baseline-prepare-v4094','openui-font-baseline-driver-prepare-v4095','openui-font-baseline-v4095','openui-font-baseline-audit-v4096','openui-font-baseline-reaping-v4097','openui-fitted-monochrome-prepare-v4103','openui-fitted-monochrome-v4104','openui-fitted-monochrome-audit-v4105','openui-fitted-monochrome-reaping-v4106','openui-fitted-monochrome-hosted-parent-v4107','openui-fitted-monochrome-guards-v4108','openui-fitted-monochrome-guards-audit-v4109','openui-fitted-monochrome-guards-reaping-v4110','openui-fitted-monochrome-archive-v4111']:
 add(Path('/tmp')/(name+'.py'),'drivers/'+name+'.py')
add(ROOT/'bindings/rust/openui-paint/src/painter.rs','runtime/painter.rs')
add(BASE/'native-fitted-monochrome-audit-failure-v4105.json','failed-attempts/audit-v4105.json')
add('/tmp/openui-fitted-monochrome-audit-v4118.py','drivers/openui-fitted-monochrome-audit-v4118.py')
add('/tmp/openui-fitted-monochrome-reaping-v4119.py','drivers/openui-fitted-monochrome-reaping-v4119.py')
local_cpp=Path('/home/nero/.cargo/git/checkouts/rust-skia-b4d79b6a888cdb4c/a31b86b/skia-bindings/skia/src/ports/SkTypeface_fontations.cpp')
primary_cpp=BASE/'chromium-skia-mono-source-v4099/src/ports/SkTypeface_fontations.cpp'
local_hint=ROOT/'bindings/rust/vendor/skrifa-v0_40/src/outline/hint.rs'
primary_hint=BASE/'chromium-fontations-code-v4102/third_party/rust/chromium_crates_io/vendor/skrifa-v0_40/src/outline/hint.rs'
assert local_cpp.read_bytes()==primary_cpp.read_bytes() and local_hint.read_bytes()==primary_hint.read_bytes()
add(local_cpp,'local-source/SkTypeface_fontations.cpp');add(local_hint,'local-source/skrifa-hint.rs')
patch=subprocess.check_output(['git','show','--format=','1576f01a','--','bindings/rust/openui-paint/src/painter.rs'],cwd=ROOT)
p=BASE/'native-fitted-monochrome-runtime-patch-v4111.patch';assert not p.exists();p.write_bytes(patch);add(p,'runtime/fitted-monochrome.patch')
index=dict(schema_version=1,measured_source=native['source'],all_measurement_commands_terminal=True,all_archive_hashes_verified=True,pixel_target='pinned Chromium',pixel_tolerance=0,javascript_executed_by_openui=False,historical_openui_archive_is_a_pixel_target=False,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,archive=dict(files=len(members),bytes=sum(r['bytes'] for r in members),members=members,excluded=excluded),previous_immutable_evidence=previous,
 native_application=dict(totals=native['totals'],images=40,exact_images=40,bounds=1920,exact_bounds=1920,independent_native_processes=40,configuration='RasterConfiguration::chromium_linux_monochrome()',explicit_cpu_paths=['ChromiumLinux','Skia'],font_collections=['registered','system'],scales=[1,2,1.25,1.5,3],fresh_compiler_records=len(native['compiler_artifacts']),compiled_paths=len(native['compiled_artifact_sha256']),callbacks_process_repeats_unchanged_frames_weak_teardown=True),
 baseline_investigation=dict(source=baseline['source'],full_hint_baseline_markers=80,full_hint_exact_baseline_markers=80,no_hint_baseline_y=80,no_hint_exact_baseline_y=80,marker_pixels_unchanged=True,full_hint_images_before_repair=8,full_hint_image_count=10,physical_glyph_top_at_3x=-39,physical_glyph_bottom_at_3x=10),
 reviewed_root_cause=dict(owner='openui-paint',mechanism='Legacy unhinted Ahem row replay ran over already fitted monochrome outlines and drew an extra block-start physical row.',correction='Use the selected author/native/embedded raster configuration; fitted monochrome strikes skip the legacy second draw.',production_change='13 added Rust lines, no font/test-ID/size/scale selector, no tolerance or reference change.',scope='Reduced native application and its five-scale two-collection two-CPU-path checks. Formal original census residual ownership is not completed.'),
 chromium_source_review=dict(version='147.0.7727.50',font_data_manager_installation_requires_sandbox=True,capture_harness_uses_no_sandbox=True,service_typeface_feature_flag_is_not_runtime_backend_proof=True,default_fci_font_scanner_in_source='Fontations',skia_cpp_matches_pinned_chromium_source=True,skrifa_hint_source_matches_pinned_chromium_source=True,actual_internal_strike_capture_available=False),
 regression_guards=load(BASE/'native-fitted-monochrome-guards-v4108/receipt.json')['results'],parent_hosted=load(BASE/'native-fitted-monochrome-hosted-parent-v4107/receipt.json'),
 pending=['Focused/primitive 40-profile and original/expanded censuses with the explicit monochrome profile have not run.','The original strict-ceil renderer candidate remains rejected with 21 exact losses.','Every remaining rendering gap, needed public native API, compositor and external release gate remains required.'])
INDEX.write_text(json.dumps(index,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(index=str(INDEX),members=len(members),bytes=index['archive']['bytes'],sha256=sha(INDEX.read_bytes()))),flush=True)
