import fcntl,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b')
OUT=BASE/'native-font-baseline-v4095';DEST=Path('/tmp/openui-font-baseline-audit-v4096.json')
sys.path[:0]=['/tmp',str(ROOT/'tools/qualification')]
from openui_parallel_source_identity_v3060 import identity
from residuals import analyze_image_difference
load=lambda p:json.loads(Path(p).read_bytes())
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as stream:
  for block in iter(lambda:stream.read(2**20),b''):h.update(block)
 return h.hexdigest()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
r=load(OUT/'receipt.json');assert not DEST.exists()
assert int(sys.argv[1])==r['observed_exit_code'] and r['all_commands_terminal'] and 'failure' not in r
assert identity(ROOT)==r['source']==r['source_after'] and r['source_unchanged'] and r['inputs_unchanged']
assert sha('/tmp/openui-font-baseline-v4095.py')==r['driver_sha256']
for p,digest in r['input_sha256'].items():assert sha(p)==digest,p
for name in ['cargo','rustc','rustfmt','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
for pid in [r['owner_pid']]+[s['pid'] for s in r['steps']]:assert subprocess.run(['ps','-p',str(pid)],capture_output=True).returncode==1
for step in r['steps']:
 if 'log_sha256' in step:assert step['actual_exit_code']==0 and sha(OUT/(step['name']+'.log'))==step['log_sha256']
 else:assert 'chromium' in step['name'] and step['actual_exit_code'] in [0,-15]
for p,digest in r['compiled_artifact_sha256'].items():assert sha(p)==digest
assert len(r['compiler_artifacts'])==16 and all(a['fresh'] is False for a in r['compiler_artifacts'])
assert sha(r['binary'])==sha(r['retained_binary'])==r['binary_sha256']
REF=BASE/'native-monochrome-font-v4074';assert sha(REF/'receipt.json')==r['reference_receipt_sha256']
totals={};marker_y_exact={};files={}
assert len(r['cases'])==5
for i,row in enumerate(r['cases']):
 directory=OUT/f'profile-{i}'
 for stage in ['before','after']:
  for repeat in [1,2]:
   assert load(directory/f'chromium-{repeat}-{stage}.json')==row['chromium_geometry'][stage]
   assert sha(directory/f'chromium-{repeat}-{stage}-capture-1.png')==sha(directory/f'chromium-{repeat}-{stage}-capture-2.png')==sha(directory/f'chromium-1-{stage}-capture-1.png')
  actual=directory/f'chromium-1-{stage}-capture-1.png';prior=REF/f'profile-{i}/chromium-1-system-{stage}-capture-1.png'
  assert analyze_image_difference(prior,actual)==row['marker_pixels_unchanged'][stage]
  assert row['marker_pixels_unchanged'][stage]['mismatched_pixels']==0
  assert [v for v in row['chromium_geometry'][stage] if not v['name'].startswith('baseline-')]==load(REF/f'profile-{i}/chromium-1-system-{stage}.json')
 for mode,result in row['native'].items():
  assert result['runs'][0]['files']==result['runs'][1]['files']
  for run in result['runs']:
   for name,digest in run['files'].items():assert sha(Path(run['directory'])/name)==digest
   assert load(Path(run['directory'])/'lifecycle.json')==dict(callbacks=1,weak_teardown_passed=True,javascript_executed_by_openui=False)
  total=totals.setdefault(mode,dict(images=0,exact_images=0,bounds=0,exact_bounds=0,baseline_markers=0,exact_baseline_markers=0))
  marker_y_exact.setdefault(mode,0)
  for stage,data in result['stages'].items():
   bounds=load(directory/f'native-{mode}-1/{stage}.json');reference=row['chromium_geometry'][stage]
   assert data['native_bounds']==bounds and data['chromium_bounds']==reference and len(bounds)==len(reference)==56
   markers=[dict(native=a,chromium=b,exact=a==b) for a,b in zip(bounds,reference) if a['name'].startswith('baseline-')]
   assert markers==data['baseline_markers']
   marker_y_exact[mode]+=sum(v['native']['bounds']['y']==v['chromium']['bounds']['y'] for v in markers)
   exact=sum(a==b for a,b in zip(bounds,reference));assert exact==data['exact_bounds']
   actual=directory/f'native-{mode}-1/{stage}.png';expected=directory/f'chromium-1-{stage}-capture-1.png'
   assert analyze_image_difference(expected,actual)==data['analysis']
   if mode=='full':
    assert analyze_image_difference(REF/f'profile-{i}/native-system-1/{stage}.png',actual)==data['marker_pixels_unchanged']
    assert data['marker_pixels_unchanged']['mismatched_pixels']==0
   total['images']+=1;total['exact_images']+=data['analysis']['mismatched_pixels']==0;total['bounds']+=56;total['exact_bounds']+=exact;total['baseline_markers']+=len(markers);total['exact_baseline_markers']+=sum(v['exact'] for v in markers)
 for path in directory.rglob('*'):
  if path.is_file():files[str(path.relative_to(OUT))]=sha(path)
assert totals==r['totals']
assert r['observed_exit_code']==int(any(v['exact_images']!=v['images'] or v['exact_bounds']!=v['bounds'] for v in totals.values()))
p=dict(schema_version=1,complete=True,owner_absent=True,source=r['source'],actual_owner_exit_code=r['observed_exit_code'],receipt_sha256=sha(OUT/'receipt.json'),audit_driver_sha256=sha(__file__),fresh_compiler_records=len(r['compiler_artifacts']),compiled_paths_verified=len(r['compiled_artifact_sha256']),totals=totals,exact_baseline_y=marker_y_exact,marker_pixels_unchanged=True,all_files_sha256=files,production_source_unchanged=True,pixel_mechanism_reviewed=False,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,retired_for_reexecution_after_source_or_target_mutation=True)
DEST.write_text(json.dumps(p,sort_keys=True,indent=2)+'\n');print(json.dumps({k:v for k,v in p.items() if k!='all_files_sha256'}),flush=True)
