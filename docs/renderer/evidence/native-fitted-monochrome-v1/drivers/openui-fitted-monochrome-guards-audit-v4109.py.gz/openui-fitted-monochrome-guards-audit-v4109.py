import fcntl, hashlib, json, subprocess, sys
from pathlib import Path
ROOT = Path('/home/nero/code/open-ui')
OUT = Path('/mnt/d/openui-v02-qualification-d174ea0b/native-fitted-monochrome-guards-v4108')
DEST = Path('/tmp/openui-fitted-monochrome-guards-audit-v4109.json')
sys.path.insert(0, '/tmp')
from openui_parallel_source_identity_v3060 import identity
def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(2**20), b''):
            h.update(block)
    return h.hexdigest()
lock = open('/tmp/openui-native-cargo-raster-owner.lock', 'a+')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
r = json.loads((OUT/'receipt.json').read_bytes())
assert not DEST.exists()
assert r['all_commands_terminal'] and r['observed_exit_code'] == int(sys.argv[1]) == 0
assert r['source_unchanged'] and r['inputs_unchanged']
assert identity(ROOT) == r['source'] == r['source_after']
assert sha('/tmp/openui-fitted-monochrome-guards-v4108.py') == r['driver_sha256']
for path, digest in r['input_sha256'].items():
    assert sha(path) == digest
for name in ['cargo', 'rustc', 'rustfmt', 'pixel_compare']:
    assert subprocess.run(['pgrep', '-x', name], capture_output=True).returncode == 1
for pid in [r['owner_pid']] + [s['pid'] for s in r['steps']]:
    assert subprocess.run(['ps', '-p', str(pid)], capture_output=True).returncode == 1
assert [(s['name'],s['actual_exit_code']) for s in r['steps']]==[('native-font-units',0),('legacy-alias-paint-policy',0)]
assert sha(OUT/'native-font-units.log')==r['steps'][0]['log_sha256']
assert r['results']==dict(native_font_units=dict(passed=3,failed=0,ignored=0),legacy_alias_policy=dict(passed=1,failed=0,ignored=0))
assert 'test result: ok. 3 passed; 0 failed; 0 ignored;' in (OUT/'native-font-units.log').read_text()
assert sha(OUT/'legacy-alias-paint-policy.log')==r['steps'][1]['log_sha256']
assert 'test result: ok. 1 passed; 0 failed; 0 ignored;' in (OUT/'legacy-alias-paint-policy.log').read_text()
p=dict(schema_version=1,complete=True,owner_absent=True,source=r['source'],actual_owner_exit_code=0,receipt_sha256=sha(OUT/'receipt.json'),audit_driver_sha256=sha(__file__),results=r['results'],source_and_inputs_unchanged=True,all_child_processes_absent=True,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,retired_for_reexecution_after_source_or_target_mutation=True)
DEST.write_text(json.dumps(p, sort_keys=True, indent=2)+'\n')
print(json.dumps(p), flush=True)
