import json,subprocess,sys
from pathlib import Path
out=Path('/mnt/d/openui-v02-qualification-d174ea0b')/('native-strict-intrinsic-ceil-hosted-v'+sys.argv[1]);assert not out.exists();out.mkdir();head='d6d9dfe97e44e2200afc1e9d87141de134ebf918';runs=[]
for rid,count,name in [(38137511272,2,'Format Check'),(38137511211,3,'CI'),(38137522007,7,'Hardening')]:
 rows={}
 for suffix in ['', '/jobs?per_page=100']:
  p=subprocess.run(['gh','api',f'repos/zhuowcui/open-ui/actions/runs/{rid}{suffix}'],capture_output=True,timeout=45);assert p.returncode==0,p.stderr.decode();(out/(str(rid)+'-'+('jobs.json' if suffix else 'run.json'))).write_bytes(p.stdout);rows['jobs' if suffix else 'run']=json.loads(p.stdout)
 r=rows['run'];jobs=rows['jobs']['jobs'];assert r['head_sha']==head and len(jobs)==count;runs.append(dict(run_id=rid,name=name,head_sha=head,url=r['html_url'],status=r['status'],conclusion=r['conclusion'],jobs=[dict(id=j['id'],name=j['name'],status=j['status'],conclusion=j['conclusion']) for j in jobs]))
r=dict(schema_version=1,source_commit=head,runs=runs,total_jobs=12,all_jobs_success=all(j['conclusion']=='success' for r in runs for j in r['jobs']),all_commands_terminal=True,renderer_qualified=False,physical_lab_qualified=False,release_qualified=False);(out/'receipt.json').write_text(json.dumps(r,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(source_commit=head,all_jobs_success=r['all_jobs_success'],jobs=[j for row in runs for j in row['jobs']])),flush=True)
