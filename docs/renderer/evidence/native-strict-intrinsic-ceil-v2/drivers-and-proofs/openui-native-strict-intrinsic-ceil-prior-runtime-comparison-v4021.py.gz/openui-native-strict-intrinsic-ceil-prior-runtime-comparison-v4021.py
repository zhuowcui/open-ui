import hashlib,json
from pathlib import Path
BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b');NEW=BASE/'native-strict-intrinsic-ceil-clean-full-v4012';OLD=BASE/'native-float-clearance-clean-full-v3967';DEST=BASE/'native-strict-intrinsic-ceil-prior-runtime-comparison-v4021.json'
load=lambda p:json.loads(Path(p).read_bytes());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=load(NEW/'receipt.json');a=load('/tmp/openui-native-strict-intrinsic-ceil-clean-full-audit-v4013.json');proof=load('/tmp/openui-native-strict-intrinsic-ceil-clean-full-reaped-v4014.json')
assert r['all_commands_terminal'] and a['complete'] and proof['all_local_commands_terminal'] and proof['owners_absent']
assert a['receipt_sha256']==proof['receipt_sha256']==sha(NEW/'receipt.json')
result=dict(schema_version=1,new_source=r['source'],prior_source=load(OLD/'receipt.json')['source'],comparison_scope='Previous applied runtime; does not replace the required accepted-98d nonregression result.',suites={})
fields=['openui_png_sha256','openui_rgba_sha256','chromium_png_sha256','chromium_rgba_sha256','chromium_oracle_identity_sha256','chromium_oracle_rgba_sha256','mismatched_pixels','status','diff_signature']
for suite in ['focused','primitive','full','expanded']:
 np=NEW/(suite+'-matrix')/(suite+'-summary.json');op=OLD/(suite+'-matrix')/(suite+'-summary.json');n=load(np);o=load(op)
 assert n['complete_contract_scope'] and o['complete_contract_scope'] and n['contract_sha256']==o['contract_sha256']
 before={(p['profile'],t['id']):t for p in o['profiles'] for t in p['tests']};changes=[];gains=losses=worse=count=0
 for p in n['profiles']:
  for t in p['tests']:
   old=before.pop((p['profile'],t['id']));count+=1
   assert all(old[k]==t[k] for k in fields if k.startswith('chromium_'))
   gains+=old['status']!='exact' and t['status']=='exact';losses+=old['status']=='exact' and t['status']!='exact';worse+=t['mismatched_pixels']>old['mismatched_pixels']
   changed=[k for k in fields if old[k]!=t[k]]
   if changed:changes.append(dict(profile=p['profile'],id=t['id'],fields=changed,before={k:old[k] for k in changed},after={k:t[k] for k in changed}))
 assert not before and count==n['results']['total']
 result['suites'][suite]=dict(new_summary_sha256=sha(np),previous_summary_sha256=sha(op),rows=count,exact_gains=gains,exact_losses=losses,worsened=worse,changed_rows=len(changes),changes=changes,chromium_reference_changed_rows=0)
assert not DEST.exists();DEST.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps({s:{k:v for k,v in r.items() if k in ['rows','exact_gains','exact_losses','worsened','changed_rows']} for s,r in result['suites'].items()}),flush=True)
