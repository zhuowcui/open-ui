import fcntl,gzip,hashlib,json,shutil,subprocess
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b');OUT=BASE/'native-strict-intrinsic-ceil-clean-full-v4012'
DEST=ROOT/'docs/renderer/evidence/native-strict-intrinsic-ceil-v2';INDEX=ROOT/'docs/renderer/generated/native-strict-intrinsic-ceil-v2.json'
load=lambda p:json.loads(Path(p).read_bytes());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof=load('/tmp/openui-native-strict-intrinsic-ceil-clean-full-reaped-v4014.json');audit=load('/tmp/openui-native-strict-intrinsic-ceil-clean-full-audit-v4013.json');r=load(OUT/'receipt.json');native=load(BASE/'native-strict-intrinsic-ceil-clean-consumer-v4009/receipt.json');np=load('/tmp/openui-native-strict-intrinsic-ceil-clean-consumer-reaped-v4011.json')
assert proof['all_local_commands_terminal'] and proof['owners_absent'] and audit['complete'] and r['all_commands_terminal'] and native['all_commands_terminal']
assert r['source']['clean'] and r['source']==audit['source']==proof['source']==native['source']==np['source']
assert sha(OUT/'receipt.json')==audit['receipt_sha256']==proof['receipt_sha256']
assert native['totals']==dict(images=15,exact_images=0,bounds=210,exact_bounds=190) and native['guard_results']==dict(actual_exit_code=0,passed=1181,failed=0,ignored=0)
for receipt in [r,native]:assert subprocess.run(['ps','-p',str(receipt['owner_pid'])],capture_output=True).returncode==1
for name in ['cargo','rustc','rustfmt','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
sys_source=r['source'];previous=ROOT/'docs/renderer/generated/native-strict-intrinsic-ceil-v1.json';prior=load(previous);previous_hash=sha(previous)
for member in prior['archive']['members']:assert sha(ROOT/member['path'])==member['sha256']
patch=load(BASE/'native-strict-intrinsic-ceil-source-v3988/source.json')
for file in patch['source_files']:assert sha(ROOT/file['path'])==file['after_sha256']
assert not DEST.exists() and not INDEX.exists() and shutil.disk_usage(ROOT).free>128*2**20
DEST.mkdir();members=[];excluded=[]
def add(path,label):
 raw=Path(path).read_bytes();data=gzip.compress(raw,compresslevel=9,mtime=0);out=DEST/(label+'.gz');assert not out.exists();out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data);assert gzip.decompress(out.read_bytes())==raw
 members.append(dict(path=str(out.relative_to(ROOT)),compression='gzip',bytes=len(data),sha256=sha(out),raw_bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest()))
for directory,label in [('native-strict-intrinsic-ceil-clean-source-v4008','consumer-source'),('native-strict-intrinsic-ceil-clean-consumer-v4009','clean-native')]:
 for path in sorted((BASE/directory).rglob('*')):
  if path.is_file():
   if path.name in ['native_font_metrics_consumer','pixel_compare']:excluded.append(dict(path=str(path),sha256=sha(path),reason='Owned executable retained outside Git with fresh compiler hashes.'));continue
   add(path,label+'/'+str(path.relative_to(BASE/directory)))
for path in sorted((OUT/'guarded-build').iterdir()):
 if path.is_file():
  if path.name=='pixel_compare':excluded.append(dict(path=str(path),sha256=sha(path),reason='Owned renderer executable retained outside Git with fresh compiler hashes.'));continue
  add(path,'renderer-build/'+path.name)
for suite in ['focused','primitive','full','expanded']:add(OUT/(suite+'-matrix')/(suite+'-summary.json'),suite+'-summary.json');add(OUT/(suite+'.log'),suite+'.log')
add(OUT/'receipt.json','renderer-receipt.json')
for pattern in ['openui-native-strict-intrinsic-ceil-clean-consumer-v4009.py','openui-native-strict-intrinsic-ceil-clean-consumer-audit-v4010.*','openui-native-strict-intrinsic-ceil-clean-consumer-reap*-v4011.*','openui-native-strict-intrinsic-ceil-clean-full-v4012.py','openui-native-strict-intrinsic-ceil-clean-full-audit-v4013.*','openui-native-strict-intrinsic-ceil-clean-full-reap*-v4014.*','openui-native-strict-intrinsic-ceil-residual-inventory-v4015.*']:
 for path in sorted(Path('/tmp').glob(pattern)):add(path,'drivers-and-proofs/'+path.name)
secondary=BASE/'native-strict-intrinsic-ceil-prior-runtime-comparison-v4021.json'
add(secondary,'previous-runtime-comparison.json')
add(BASE/'native-scroll-button-api-source-review-v4024.json','native-api-source-review.json')
add('/tmp/openui-native-strict-intrinsic-ceil-prior-runtime-comparison-v4021.py','drivers-and-proofs/openui-native-strict-intrinsic-ceil-prior-runtime-comparison-v4021.py')
add('/tmp/openui-native-strict-intrinsic-ceil-hosted-reader-v4023.py','drivers-and-proofs/openui-native-strict-intrinsic-ceil-hosted-reader-v4023.py')
for path in sorted((BASE/'native-strict-intrinsic-ceil-hosted-v4023').iterdir()):
 if path.is_file():add(path,'hosted/'+path.name)
add(__file__,'drivers-and-proofs/'+Path(__file__).name)
assert sha(previous)==previous_hash
result=dict(schema_version=1,candidate_disposition='rejected: complete original and expanded censuses each lose 21 exact comparisons and gain none',measured_source=sys_source,previous_immutable_evidence=dict(path=str(previous.relative_to(ROOT)),sha256=previous_hash,unchanged=True),native_clean=dict(totals=native['totals'],actual_exit_code=1,guards=native['guard_results'],native_api_guards=native['native_api_guard_results'],repeat_and_lifecycle_passed=True,all_app_images_qualified=False,all_native_api_qualification=False),renderer_clean=dict(audit=audit,results=audit['results'],rows_audited=audit['matrix_rows_verified'],candidate_nonregression=audit['candidate_nonregression'],qualification=False),residual_inventory=load('/tmp/openui-native-strict-intrinsic-ceil-residual-inventory-v4015.json'),secondary_comparison=load(secondary),hosted=load(BASE/'native-strict-intrinsic-ceil-hosted-v4023/receipt.json'),all_local_commands_terminal=True,all_members_hash_verified=True,pixel_target='pinned Chromium',pixel_tolerance=0,historical_openui_archive_is_a_pixel_target=False,javascript_executed_by_openui=False,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,pending=['Repair the rejected strict-ceil regression without waiving native fractional-width behavior.','Remaining original and expanded Chromium differences and strict nonregression gate.','Every required native API, reviewed residual ownership, clean full workspace/ABI qualification.','Compositor/3D, physical lab, packaging, signing and publication.'],archive=dict(files=len(members),bytes=sum(m['bytes'] for m in members),members=members,excluded=excluded))
INDEX.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(index=str(INDEX),members=len(members),stored_bytes=result['archive']['bytes'],qualified=False)),flush=True)
