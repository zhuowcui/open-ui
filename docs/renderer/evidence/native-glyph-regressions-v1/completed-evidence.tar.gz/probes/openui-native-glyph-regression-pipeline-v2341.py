"""Measure reduced public Rust input and large-text apps against repeated pinned Chromium."""
import fcntl,hashlib,json,os,shutil,signal,subprocess,sys,time
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');SDK=MAIN/'out/private-native-glyph-logical-transform-v2339'
APP=MAIN/'out/private-native-apps/native-glyph-regression-v2340'
RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';OUT=RAW/'native-glyph-regression-pipeline-v2341'
STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/OUT.name
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for program in ['cargo','rustc','ninja','pixel_compare']:
    assert subprocess.run(['pgrep','-x',program],capture_output=True).returncode==1
assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
sys.path.insert(0,str(SDK/'tools/qualification'))
from renderer_source_identity import repository_source_identity
from residuals import analyze_image_difference
from run_renderer_matrix import image_payload
sys.path.insert(0,str(SDK/'tools/accountability'))
import run_all_pixel_comparisons as capture
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=repository_source_identity(SDK);public=repository_source_identity(MAIN)
assert source['clean'] and source['commit']=='4ae50fdd0e7bffa3d329833f6858383ab4764245'
assert public['clean'] and public['commit']=='b20f92432d3bece41c83935becbe258959f78174'
tmp=STORE/'compiler-tmp';tmp.mkdir()
env=dict(os.environ,OPENUI_NATIVE_WHOLE_OWNER=OUT.name,CARGO_TARGET_DIR='/mnt/e/openui-v02-cargo-c73754e2/target',
         CARGO_INCREMENTAL='0',RUST_MIN_STACK='4194304',CARGO_BUILD_JOBS='4',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(tmp),
         CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
chrome=MAIN/'chrome/linux-147.0.7727.50/chrome-linux64/chrome'
assert sha(chrome)=='0ba87684df0afc11faaea40ac57bd2f1d68b67191443b38215a36b90e6f08848'
original_ws=capture._CdpWebSocket
helper=Path('/tmp/openui-native-sizing-chromium-helper-v2247.py');code=helper.read_text()
compile(code,str(helper),'exec');(OUT/'used-observe.py').write_text(code);exec(compile(code,str(OUT/'used-observe.py'),'exec'))
WIDTH,HEIGHT=800,600
report=dict(schema_version=1,source=source,public_source=public,owner_pid=os.getpid(),all_commands_terminal=False,
            steps=[],cases=[],release_qualification=False,promotion_allowed=False,new_release_states_admitted=0,
            diagnostic_only=True,pixel_tolerance=0,javascript_executed_by_openui=False,
            offline_javascript_executed_only_in_chromium=False,complete_renderer_matrices_not_run=True,
            chromium_captures_run=0,shared_renderer_patch_applied=True,root_cause_not_assumed_proven=True,
            process_group_cleanup=True,helper_sha256=sha(helper),probe_sha256=sha(Path(__file__)),
            chromium_binary_sha256=sha(chrome),pinned_harness_sha256=sha(Path(capture.__file__)))
def save():(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
def run(name,command):
    path=OUT/(name+'.log')
    with path.open('xb') as stream:
        child=subprocess.Popen(command,cwd=APP,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
        report['current_process']=dict(stage=name,pid=child.pid);save();guard=False
        while child.poll() is None:
            if shutil.disk_usage(MAIN).free<512*2**20 or shutil.disk_usage(STORE).free<10*2**30:
                guard=True;os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=20);break
            time.sleep(1)
        child.wait()
    report.pop('current_process');row=dict(name=name,observed_exit_code=child.returncode,disk_guard_triggered=guard,log_sha256=sha(path))
    report['steps'].append(row);save();print(json.dumps(row),flush=True)
    assert not guard and child.returncode==0,name
    assert repository_source_identity(SDK)==source and repository_source_identity(MAIN)==public
def app_identity():
    return dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=APP,text=True).strip(),
                tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=APP,text=True).strip(),
                clean=not subprocess.check_output(['git','status','--porcelain'],cwd=APP))
def identity(path):
    dimensions,rgba=image_payload(path)
    return dict(dimensions=list(dimensions),png_sha256=sha(path),rgba_sha256=hashlib.sha256(rgba).hexdigest())
base=['cargo','--config',str(SDK/'bindings/rust/.cargo/config.chromium.toml')]
expression="(() => {const n=document.querySelector('#frame'),b=n.getBoundingClientRect();return {x:b.x,y:b.y,width:b.width,height:b.height}})()"
save()
try:
    run('native-format',['bash','-c','ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true --check src/main.rs'])
    run('native-metadata',base+['metadata','--offline','--format-version','1'])
    if subprocess.check_output(['git','status','--porcelain'],cwd=APP):
        subprocess.run(['git','add','.'],cwd=APP,check=True,capture_output=True)
        subprocess.run(['git','commit','-m','Lock the native glyph regression consuming app'],cwd=APP,check=True,capture_output=True)
    report['native_app_source']=app_identity();assert report['native_app_source']['clean'];save()
    run('native-build',base+['build','--offline','--locked'])
    binary=OUT/'openui-native-glyph-regression-api';shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/openui-native-glyph-regression-api',binary)
    report['native_binary_sha256']=sha(binary);save()
    for repeat in ['first','second']:run('native-'+repeat,[str(binary),str(OUT/('native-'+repeat))])
    assert (OUT/'native-first.log').read_bytes()==(OUT/'native-second.log').read_bytes()
    rows=[json.loads(line) for line in (OUT/'native-first.log').read_text().splitlines()]
    assert len(rows)==15 and sum(row['callbacks'] for row in rows)==15
    report.update(native_callbacks_per_run=15,native_geometry_outputs_repeat_byte_identically=True);save()
    totals=dict(image_states=0,exact_images=0,different_images=0,geometry_states=0,exact_geometry=0)
    for row in rows:
        scale=row['scale'];writing=row['name'];label=row['label'];WIDTH=row['width'];HEIGHT=row['height']
        # Rust's default f32 Display includes ".0" only when needed, matching :g.
        first=OUT/'native-first'/label;second=OUT/'native-second'/label
        assert first.is_dir() and second.is_dir()
        for state in ['before','after']:
            native_path=first/(state+'.png');assert native_path.read_bytes()==(second/(state+'.png')).read_bytes()
            directory=OUT/(label+'-'+state);directory.mkdir()
            left=top=20 if state=='before' else 21
            size=HEIGHT*0.4+(1 if state=='after' and writing=='sticky' else 0)
            page=directory/'test.html'
            shared='font-family:Ahem,"Droid Sans Fallback","Noto Sans Devanagari","Noto Color Emoji","DejaVu Sans";font-weight:normal;font-style:normal;font-kerning:none;font-variant-ligatures:none;font-synthesis:none;'
            if writing=='input':
                style=f'#frame{{position:absolute;left:{left}px;top:{top}px;width:100px;height:30px;border:1px solid black;padding:10px;font-size:18px;box-sizing:border-box;line-height:1}}'
                content='<input id="frame" type="text" value="foo">'
            elif writing=='large-text':
                style=f'#frame{{position:absolute;left:{left}px;top:{top}px;width:100%;height:100%;font-size:{size}px;background:green;color:white}}'
                content='<div id="frame">PASS</div>'
            else:
                style=f'div{{height:100%;width:100%}}#frame{{position:fixed;left:20px;top:20px;background:red;color:yellow;font-size:{size}px}}#sticky{{position:sticky;bottom:0;background:green;color:white}}'
                content='<div id="frame"><div id="spacer">FAIL</div><div id="sticky">PASS</div></div>'
            page.write_text(f'''<!doctype html><style>*{{margin:0;padding:0;box-sizing:content-box}}
html,body{{width:100%;height:100%}}html{{overflow:hidden}}
body{{background:white;font-size:16px}}
body,body *{{{shared}}}{style}</style>{content}''')
            frozen=RAW/'native-glyph-regression-pipeline-v2309'
            frozen_receipt=json.loads((frozen/'receipt.json').read_bytes())
            assert frozen_receipt['all_commands_terminal'] and frozen_receipt['source_unchanged'] and frozen_receipt['public_source_unchanged']
            old_case=next(c for c in frozen_receipt['cases'] if c['label']==label and c['state']==state)
            original=frozen/(label+'-'+state)
            assert page.read_bytes()==(original/'test.html').read_bytes() and sha(page)==old_case['fixture_sha256']
            queries=[]
            for repeat in [1,2]:
                picture=directory/(str(repeat)+'.png')
                assert identity(original/(str(repeat)+'.png'))==old_case['chromium']
                shutil.copy2(original/(str(repeat)+'.png'),picture)
                query=json.loads((original/(str(repeat)+'-geometry.json')).read_bytes())
                assert query==old_case['chromium_bounds']
                shutil.copy2(original/(str(repeat)+'-geometry.json'),directory/(str(repeat)+'-geometry.json'))
                queries.append(query)
            assert queries[0]==queries[1] and sha(directory/'1.png')==sha(directory/'2.png')
            difference=analyze_image_difference(directory/'1.png',native_path)
            exact=difference['mismatched_pixels']==0;geometry_exact=row[state]==queries[0]
            totals['image_states']+=1;totals['exact_images']+=int(exact);totals['different_images']+=int(not exact)
            totals['geometry_states']+=1;totals['exact_geometry']+=int(geometry_exact)
            report['cases'].append(dict(label=label,scale=scale,writing=writing,state=state,fixture_sha256=sha(page),
                native=identity(native_path),chromium=identity(directory/'1.png'),native_bounds=row[state],chromium_bounds=queries[0],
                exact=exact,geometry_exact=geometry_exact,difference=difference,repeated_png_and_geometry_equal=True))
            report['totals']=totals;save();print(json.dumps(dict(label=label,state=state,wrong_pixels=difference['mismatched_pixels'],geometry_exact=geometry_exact)),flush=True)
    assert totals['image_states']==30
    report.update(observed_exit_code=int(totals['different_images']!=0 or totals['exact_geometry']!=30),native_pngs_repeat_byte_identically=True)
except BaseException as error:
    report.update(observed_exit_code=1,failure=str(error));raise
finally:
    report.update(all_commands_terminal=True,source_after=repository_source_identity(SDK),public_source_after=repository_source_identity(MAIN))
    report['source_unchanged']=report['source_after']==source;report['public_source_unchanged']=report['public_source_after']==public
    if 'native_app_source' in report:
        report['native_app_source_after']=app_identity();report['native_app_source_unchanged']=report['native_app_source']==report['native_app_source_after']
    save()
print(json.dumps(dict(observed_exit_code=report['observed_exit_code'],totals=report['totals'])),flush=True)

raise SystemExit(report['observed_exit_code'])
