import gzip,hashlib,json,os,shutil,subprocess,sys,tarfile
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1'
OUT=RAW/'native-glyph-regressions-archive-v2345';STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/OUT.name
assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
sys.path.insert(0,str(MAIN/'tools/qualification'));from renderer_source_identity import repository_source_identity
public=repository_source_identity(MAIN);assert public['clean'] and public['commit']=='b20f92432d3bece41c83935becbe258959f78174'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_bytes())
baseline=load(RAW/'native-glyph-regression-pipeline-v2309/receipt.json')
before={(c['label'],c['state']):c for c in baseline['cases']}
names=['native-glyph-regression-pipeline-v2307','native-glyph-regression-pipeline-v2309','native-glyph-regression-pipeline-v2314','native-glyph-regression-pipeline-v2321','native-glyph-regression-pipeline-v2327','native-glyph-regression-pipeline-v2336','native-glyph-regression-pipeline-v2341']
cases=[];files={}
def add(path,name):
    assert path.is_file() and name not in files;files[name]=path
def directory(path,prefix):
    for p in sorted(path.rglob('*')):
        if p.is_file() and p.suffix in ['.json','.png','.html','.log','.py']:
            add(p,prefix+'/'+str(p.relative_to(path)))
for name in names:
    p=RAW/name/'receipt.json';r=load(p)
    assert r['all_commands_terminal'] and r['source_unchanged'] and r['public_source_unchanged']
    assert not Path('/proc',str(r['owner_pid'])).exists()
    native_first=RAW/name/'native-first';native_second=RAW/name/'native-second'
    changed=[]
    for c in r['cases']:
        key=(c['label'],c['state']);old=before[key]
        picture=native_first/c['label']/(c['state']+'.png')
        assert sha(picture)==c['native']['png_sha256'] and sha(native_second/c['label']/(c['state']+'.png'))==sha(picture)
        expected=RAW/name/(c['label']+'-'+c['state'])/'1.png'
        assert sha(expected)==c['chromium']['png_sha256']
        if name!='native-glyph-regression-pipeline-v2307':assert c['chromium']==old['chromium']
        changed.append(dict(label=c['label'],state=c['state'],before_wrong_pixels=old['difference']['mismatched_pixels'],wrong_pixels=c['difference']['mismatched_pixels'],exact_gain=not old['exact'] and c['exact'],exact_loss=old['exact'] and not c['exact'],more_wrong_pixels=c['difference']['mismatched_pixels']>old['difference']['mismatched_pixels']))
    row=dict(name=name,source=r['source'],receipt_sha256=sha(p),observed_exit_code=r['observed_exit_code'],totals=r['totals'],exact_gains=sum(x['exact_gain'] for x in changed),exact_losses=sum(x['exact_loss'] for x in changed),more_wrong_states=sum(x['more_wrong_pixels'] for x in changed),changes=changed,all_commands_terminal=True)
    cases.append(row);directory(RAW/name,'runs/'+name)
for name in ['native-aliased-hinting-checks-v2318','native-unhinted-origin-checks-v2324','native-glyph-strike-size-checks-v2329','native-glyph-em-outlines-checks-v2338','native-glyph-logical-transform-checks-v2342','native-glyph-hinting-primary-v2310','native-strike-size-primary-v2328','native-strike-size-primary-v2330','native-glyph-baseline-debug-v2331','native-chromium-baseline-v2332','native-chromium-baseline-v2333','native-chromium-baseline-v2337']:
    directory(RAW/name,'support/'+name)
    for p in sorted((RAW/name).rglob('*.cpp')):add(p,'primary/'+name+'/'+str(p.relative_to(RAW/name)))
    for p in sorted((RAW/name).rglob('*.rs')):add(p,'primary/'+name+'/'+str(p.relative_to(RAW/name)))
for version in [2306,2308,2313,2320,2326,2335,2340]:
    root=MAIN/f'out/private-native-apps/native-glyph-regression-v{version}'
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
    for name in ['Cargo.toml','Cargo.lock','src/main.rs']:add(root/name,f'apps/v{version}/'+name)
roots=['private-native-aliased-mask-v2268','private-native-aliased-hinting-v2312','private-native-unhinted-origin-v2319','private-native-glyph-strike-size-v2325','private-native-glyph-em-outlines-v2334','private-native-glyph-logical-transform-v2339']
sources=[]
for name in roots:
    root=MAIN/'out'/name;identity=repository_source_identity(root);assert identity['clean']
    sources.append(dict(root=name,identity=identity))
    for file in ['bindings/rust/openui-text/src/shaping/shape_result.rs','bindings/rust/openui-paint/src/text_painter.rs']:
        add(root/file,'sources/'+name+'/'+file)
for p in sorted(Path('/tmp').glob('openui-native-*.py')):
    if any('v'+str(v) in p.name for v in range(2306,2346)):add(p,'probes/'+p.name)
for p in sorted(Path('/tmp').glob('openui-native-*.json')):
    if any('v'+str(v) in p.name for v in range(2306,2346)):add(p,'preparation/'+p.name)
for p in sorted(Path('/tmp').glob('openui-native-*.patch')):
    if any('v'+str(v) in p.name for v in [2312,2319,2325,2334,2339]):add(p,'patches/'+p.name)
fontconfig=MAIN/'tools/accountability/data/fonts/ahem_noaa.conf';add(fontconfig,'inputs/ahem_noaa.conf')
manifest=[dict(path=name,bytes=path.stat().st_size,sha256=sha(path)) for name,path in sorted(files.items())]
(OUT/'manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
archive=OUT/'completed-evidence.tar.gz'
with archive.open('xb') as stream:
    with gzip.GzipFile(filename='',mode='wb',fileobj=stream,mtime=0) as gz:
        with tarfile.open(fileobj=gz,mode='w') as tar:
            for name,path in sorted(files.items()):
                info=tar.gettarinfo(str(path),arcname=name);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
                with path.open('rb') as content:tar.addfile(info,content)
            info=tar.gettarinfo(str(OUT/'manifest.json'),arcname='manifest.json');info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
            with (OUT/'manifest.json').open('rb') as content:tar.addfile(info,content)
with tarfile.open(archive,'r:gz') as tar:
    for item in manifest:
        f=tar.extractfile(item['path']);assert f is not None
        assert hashlib.sha256(f.read()).hexdigest()==item['sha256']
assert repository_source_identity(MAIN)==public
report=dict(schema_version=1,public_source=public,sources=sources,runs=cases,archive=dict(path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive),members=len(manifest)+1,all_member_bytes_verified=True),baseline_geometry_exact=True,baseline_images_exact=12,latest_images_exact=20,latest_geometry_exact=30,latest_exact_gains=8,latest_exact_losses=0,latest_more_wrong_states=2,latest_two_desktop_input_states_worsen=True,accepted_original_exact=21334,accepted_original_total=22924,original_expanded_focused_primitive_and_workspace_not_run_on_new_candidates=True,all_candidates_private_and_unapplied=True,no_new_release_state_admitted=True,chromium_reference_bytes_preserved=True,pixel_tolerance=0,javascript_executed_by_openui=False,all_commands_terminal=True,release_qualification=False,promotion_allowed=False,probe_sha256=sha(Path(__file__)))
assert cases[-1]['exact_gains']==8 and cases[-1]['exact_losses']==0 and cases[-1]['more_wrong_states']==2
report['latest_native_image_bytes_equal_em_outline_trial']=all(a['native']==b['native'] for a,b in zip(load(RAW/names[-1]/'receipt.json')['cases'],load(RAW/names[-2]/'receipt.json')['cases']))
(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(archive=report['archive'],runs=[dict(name=r['name'],exact=r['totals']['exact_images'],geometry=r['totals']['exact_geometry'],gains=r['exact_gains'],losses=r['exact_losses'],more_wrong=r['more_wrong_states']) for r in cases],all_commands_terminal=True)))
