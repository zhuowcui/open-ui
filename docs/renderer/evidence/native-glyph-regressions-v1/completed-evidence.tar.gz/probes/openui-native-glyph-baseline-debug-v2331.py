import fcntl,hashlib,json,os,subprocess,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');SDK=MAIN/'out/private-native-aliased-mask-v2268'
RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';OUT=RAW/'native-glyph-baseline-debug-v2331'
STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/OUT.name
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
prior=json.loads((RAW/'native-glyph-regression-pipeline-v2327/receipt.json').read_bytes());assert prior['all_commands_terminal'] and not Path('/proc',str(prior['owner_pid'])).exists()
assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
sys.path.insert(0,str(SDK/'tools/qualification'));from renderer_source_identity import repository_source_identity
source=repository_source_identity(SDK);public=repository_source_identity(MAIN);assert source['clean'] and public['clean']
binary=RAW/'native-aliased-renderer-gates-v2276/pixel_compare'
identity=json.loads(subprocess.check_output([str(binary),'build-source-identity'],cwd=SDK));assert identity['source']==source
steps=[]
for profile,width,height,scale in [('legacy',800,600,1),('mobile',375,667,2),('desktop',1280,720,1.25),('large',1920,1080,1.5)]:
    for name,test in [('input','wpt/css_overflow/input-scrollable-region-001'),('sticky','wpt/css_position/sticky_position-sticky-fixed-ancestor-003')]:
        command=[str(binary),'debug',test,'--viewport',f'{width}x{height}','--scale',str(scale)]
        p=OUT/f'{name}-{profile}.log';result=subprocess.run(command,cwd=SDK,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);p.write_bytes(result.stdout)
        steps.append(dict(profile=profile,name=name,command=command,observed_exit_code=result.returncode,log_sha256=hashlib.sha256(result.stdout).hexdigest()))
        assert result.returncode==0 and repository_source_identity(SDK)==source and repository_source_identity(MAIN)==public
report=dict(schema_version=1,source=source,public_source=public,build_identity=identity,steps=steps,all_commands_terminal=True,source_unchanged=True,public_source_unchanged=True,diagnostic_only=True,pixels_not_captured=True,javascript_executed_by_openui=False,release_qualification=False,first_read_only_debug_attempt_used_invalid_width_flag_and_exited_2=True,probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(steps=len(steps),source=source,all_commands_terminal=True)))
