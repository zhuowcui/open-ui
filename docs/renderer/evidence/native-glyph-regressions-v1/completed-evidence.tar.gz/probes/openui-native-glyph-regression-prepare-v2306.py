import hashlib, json, shutil, subprocess, sys
from pathlib import Path

MAIN=Path('/home/nero/code/open-ui')
SDK=MAIN/'out/private-native-aliased-mask-v2268'
OLD=MAIN/'out/private-native-apps/native-glyph-origin-v2269'
APP=MAIN/'out/private-native-apps/native-glyph-regression-v2306'
sys.path.insert(0,str(MAIN/'tools/qualification'))
from renderer_source_identity import repository_source_identity
source=repository_source_identity(SDK);public=repository_source_identity(MAIN)
assert source['clean'] and source['commit']=='4839e107fee5ae07e28fcda990f3433216263580'
assert public['clean'] and public['commit']=='b20f92432d3bece41c83935becbe258959f78174'
assert shutil.disk_usage(MAIN).free>700*2**20
assert not APP.exists()
APP.mkdir();(APP/'src').mkdir()
name='openui-native-glyph-regression-api'
(APP/'Cargo.toml').write_text((OLD/'Cargo.toml').read_text().replace('openui-native-glyph-origin-api',name))
(APP/'Cargo.lock').write_bytes((OLD/'Cargo.lock').read_bytes())
(APP/'src/main.rs').write_bytes(Path('/tmp/openui-native-glyph-regression-app-v2306.rs').read_bytes())
subprocess.run(['bash','-c','ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true src/main.rs'],cwd=APP,check=True)
subprocess.run(['git','init','-q'],cwd=APP,check=True)
for key in ['user.name','user.email']:
    value=subprocess.check_output(['git','config','--get',key],cwd=MAIN,text=True).strip()
    subprocess.run(['git','config',key,value],cwd=APP,check=True)
subprocess.run(['git','add','.'],cwd=APP,check=True)
subprocess.run(['git','commit','-q','-m','Reduce native input and large-font glyph regressions through Rust callbacks'],cwd=APP,check=True)
s=Path('/tmp/openui-native-glyph-origin-pipeline-v2257.py').read_text()
for old,new in [
 ('private-native-caption-metrics-v2234','private-native-aliased-mask-v2268'),
 ('native-glyph-origin-v2256','native-glyph-regression-v2306'),
 ('native-glyph-origin-pipeline-v2257','native-glyph-regression-pipeline-v2307'),
 ('db177050b5e615abcede59b877bed9b58da8a496',source['commit']),
 ('ee76ec1fc2dd0fbc2bf9281cbd6c1a1d0f55a17b',public['commit']),
 ('openui-native-glyph-origin-api',name),
 ('a reduced public Rust glyph app','reduced public Rust input and large-text apps'),
 ('the native glyph origin consuming app','the native glyph regression consuming app'),
 ('len(rows)==10 and sum(row[\'callbacks\'] for row in rows)==10','len(rows)==15 and sum(row[\'callbacks\'] for row in rows)==15'),
 ('native_callbacks_per_run=10','native_callbacks_per_run=15'),
 ("assert totals['image_states']==20","assert totals['image_states']==30"),
]:
    assert old in s,old;s=s.replace(old,new)
s=s.replace("scale=row['scale'];writing=row['writing'];label=f'{writing}-{scale:g}'", "scale=row['scale'];writing=row['name'];label=row['label'];WIDTH=row['width'];HEIGHT=row['height']")
start=s.index("            if writing=='horizontal':");end=s.index('            queries=[]',start)
s=s[:start]+'''            left=top=20 if state=='before' else 21
            size=HEIGHT*0.4+(1 if state=='after' and writing=='sticky' else 0)
            page=directory/'test.html'
            shared='font-family:Ahem,"Droid Sans Fallback","Noto Sans Devanagari","Noto Color Emoji","DejaVu Sans";font-weight:normal;font-style:normal;font-kerning:none;font-variant-ligatures:none;font-synthesis:none;'
            if writing=='input':
                style=f'#frame{{position:absolute;left:{left}px;top:{top}px;width:100px;height:30px;border:1px solid black;padding:10px;font-size:18px;box-sizing:border-box;line-height:1}}'
                content='<input id="frame" type="text" value="foo">'
            elif writing=='large-text':
                style=f'#frame{{position:absolute;left:{left}px;top:{top}px;width:100%;height:100%;font-size:{size}px;background:green;color:white}}'
                content='<div id="frame">PASS</div>'
            else:
                style=f'div{{height:100%;width:100%}}#frame{{position:fixed;background:red;color:yellow;font-size:{size}px}}#sticky{{position:sticky;bottom:0;background:green;color:white}}'
                content='<div id="frame"><div id="spacer">FAIL</div><div id="sticky">PASS</div></div>'
            page.write_text(f\'''<!doctype html><style>*{{margin:0;padding:0;box-sizing:content-box}}
html,body{{width:100%;height:100%}}html{{overflow:hidden}}
body{{padding:20px;background:white;font-size:16px}}
body,body *{{{shared}}}{style}</style>{content}\''')
''' + s[end:]
s=s.replace("query=observe(page,picture,expression,scale)","query=observe(page,picture,expression,scale);report['chromium_captures_run']+=1")
s=s.replace('offline_javascript_executed_only_in_chromium=True,complete_renderer_matrices_not_run=True,',
'''offline_javascript_executed_only_in_chromium=True,complete_renderer_matrices_not_run=True,
            chromium_captures_run=0,shared_renderer_patch_applied=False,root_cause_not_assumed_proven=True,''')
s=s.replace('report.update(observed_exit_code=0,native_pngs_repeat_byte_identically=True)',
"report.update(observed_exit_code=int(totals['different_images']!=0 or totals['exact_geometry']!=30),native_pngs_repeat_byte_identically=True)")
s+='\nraise SystemExit(report[\'observed_exit_code\'])\n'
pipeline=Path('/tmp/openui-native-glyph-regression-pipeline-v2307.py');assert not pipeline.exists()
compile(s,str(pipeline),'exec');pipeline.write_text(s)
assert repository_source_identity(SDK)==source and repository_source_identity(MAIN)==public
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt=dict(source=source,public_source=public,app=str(APP),app_source_sha256=sha(APP/'src/main.rs'),pipeline=str(pipeline),pipeline_sha256=sha(pipeline),all_commands_terminal=True,source_only=True,cargo_commands_run=0,native_commands_run=0,chromium_commands_run=0,javascript_executed_by_openui=False,release_qualification=False)
Path('/tmp/openui-native-glyph-regression-prepare-v2306.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
print(json.dumps(receipt))
