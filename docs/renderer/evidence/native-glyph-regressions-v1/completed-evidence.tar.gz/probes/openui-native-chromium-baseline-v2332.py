import fcntl,hashlib,json,os,shutil,signal,subprocess,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');SDK=MAIN/'out/private-native-aliased-mask-v2268'
RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';OUT=RAW/'native-chromium-baseline-v2332'
STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/OUT.name
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
sys.path.insert(0,str(SDK/'tools/qualification'));from renderer_source_identity import repository_source_identity
source=repository_source_identity(SDK);public=repository_source_identity(MAIN);assert source['clean'] and public['clean']
sys.path.insert(0,str(SDK/'tools/accountability'));import run_all_pixel_comparisons as capture
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
chrome=MAIN/'chrome/linux-147.0.7727.50/chrome-linux64/chrome';assert sha(chrome)=='0ba87684df0afc11faaea40ac57bd2f1d68b67191443b38215a36b90e6f08848'
original_ws=capture._CdpWebSocket
helper=Path('/tmp/openui-native-sizing-chromium-helper-v2247.py');code=helper.read_text();(OUT/'used-observe.py').write_text(code);exec(compile(code,str(OUT/'used-observe.py'),'exec'))
expression="""(() => {const n=document.querySelector('#sticky'),s=document.createElement('span');s.style.cssText='display:inline-block;width:0;height:0;line-height:0;margin:0;padding:0;border:0;vertical-align:baseline';n.prepend(s);const b=s.getBoundingClientRect(),r=n.getBoundingClientRect(),c=getComputedStyle(n);return {baseline:b.top,x:b.x,frame:{x:r.x,y:r.y,width:r.width,height:r.height},fontSize:c.fontSize,lineHeight:c.lineHeight}})()"""
prior=json.loads((RAW/'native-glyph-regression-pipeline-v2309/receipt.json').read_bytes());assert prior['all_commands_terminal']
report=dict(schema_version=1,source=source,public_source=public,owner_pid=os.getpid(),all_commands_terminal=False,cases=[],pixel_tolerance=0,offline_javascript_executed_only_in_chromium=True,javascript_executed_by_openui=False,release_qualification=False,probe_sha256=sha(Path(__file__)),query_sha256=hashlib.sha256(expression.encode()).hexdigest(),zero_size_baseline_marker_must_not_change_reference_pixels=True)
def save():(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
save()
try:
    for row in prior['cases']:
        if row['writing']!='sticky':continue
        label=row['label'];state=row['state'];scale=row['scale']
        profile=label.removeprefix('sticky-')
        WIDTH,HEIGHT={'legacy':(800,600),'mobile':(375,667),'desktop':(1280,720),'large':(1920,1080),'triple':(800,600)}[profile]
        original=RAW/'native-glyph-regression-pipeline-v2309'/(label+'-'+state)
        directory=OUT/(label+'-'+state);directory.mkdir();page=directory/'test.html';shutil.copy2(original/'test.html',page)
        assert sha(page)==row['fixture_sha256'];queries=[]
        for repeat in [1,2]:
            picture=directory/(str(repeat)+'.png');report['current_capture']=dict(label=label,state=state,repeat=repeat);save()
            query=observe(page,picture,expression,scale)
            assert sha(picture)==row['chromium']['png_sha256'], 'baseline marker changed pixels'
            queries.append(query);(directory/(str(repeat)+'-baseline.json')).write_text(json.dumps(query,sort_keys=True,indent=2)+'\n')
        report.pop('current_capture');assert queries[0]==queries[1]
        report['cases'].append(dict(label=label,state=state,scale=scale,chromium=queries[0],reference_png_sha256=row['chromium']['png_sha256'],all_reference_bytes_unchanged=True));save()
        print(json.dumps(report['cases'][-1]),flush=True)
        assert repository_source_identity(SDK)==source and repository_source_identity(MAIN)==public
    assert len(report['cases'])==10
    report.update(observed_exit_code=0,chromium_captures_run=20)
except BaseException as error:
    report.update(observed_exit_code=1,failure=str(error));raise
finally:
    report.update(all_commands_terminal=True,source_after=repository_source_identity(SDK),public_source_after=repository_source_identity(MAIN))
    report['source_unchanged']=report['source_after']==source;report['public_source_unchanged']=report['public_source_after']==public;save()
