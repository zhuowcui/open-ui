import base64,concurrent.futures,hashlib,json,subprocess,urllib.request
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');OUT=MAIN/'out/renderer-evidence/native-viewport-scroll-v1/native-strike-size-primary-v2330'
STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/OUT.name
assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
paths=['src/core/SkStrikeSpec.cpp','src/core/SkGlyphRunPainter.cpp','src/utils/SkCustomTypeface.cpp']
revisions={'chromium-147':'abbe599fb3c0ef2fa82bfadbb0ddcd321f22faf0','openui-pinned':'2b5c647f2843dae179b02e10e267403e6e80ce29'}
def fetch(item):
    label,revision,path=item;url='https://skia.googlesource.com/skia/+/'+revision+'/'+path+'?format=TEXT'
    if label=='openui-pinned':
        url='https://raw.githubusercontent.com/rust-skia/skia/'+revision+'/'+path
        with urllib.request.urlopen(url,timeout=30) as response:data=response.read()
    else:
        with urllib.request.urlopen(url,timeout=30) as response:data=base64.b64decode(response.read(),validate=True)
    p=OUT/label/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
    local=Path('/home/nero/.cargo/git/checkouts/rust-skia-b4d79b6a888cdb4c/a31b86b/skia-bindings/skia')/path
    return dict(path=str(p.relative_to(OUT)),revision=revision,url=url,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),local_build_source_equal=data==local.read_bytes())
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    rows=list(pool.map(fetch,[(label,revision,path) for label,revision in revisions.items() for path in paths]))
report=dict(schema_version=1,files=rows,all_commands_terminal=True,primary_review_only=True,source_changed=False,release_qualification=False,javascript_executed_by_openui=False,probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(report))
