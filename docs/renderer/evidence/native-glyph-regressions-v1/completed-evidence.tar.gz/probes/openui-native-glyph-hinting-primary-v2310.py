import base64, concurrent.futures, hashlib, json, re, subprocess, urllib.request
from pathlib import Path

MAIN=Path('/home/nero/code/open-ui')
OUT=MAIN/'out/renderer-evidence/native-viewport-scroll-v1/native-glyph-hinting-primary-v2310'
STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/OUT.name
assert not OUT.exists() and not STORE.exists()
before=subprocess.check_output(['git','status','--porcelain'],cwd=MAIN);assert not before
STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
def fetch(url):
    with urllib.request.urlopen(url,timeout=30) as response:
        return base64.b64decode(response.read(),validate=True)
base='https://chromium.googlesource.com/chromium/src/+/147.0.7727.50/'
deps_url=base+'DEPS?format=TEXT';deps=fetch(deps_url)
(OUT/'DEPS').write_bytes(deps)
skia_revision=re.search(rb"'skia_revision':\s*'([0-9a-f]+)'",deps).group(1).decode()
paths=['src/ports/SkTypeface_fontations.cpp','src/ports/fontations/src/hinting.rs','src/ports/fontations/src/verbs_points_pen.rs']
def preserve(path):
    url='https://skia.googlesource.com/skia/+/'+skia_revision+'/'+path+'?format=TEXT'
    data=fetch(url);name=path.rsplit('/',1)[1];(OUT/name).write_bytes(data)
    return dict(name=name,url=url,bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    rows=list(pool.map(preserve,paths))
assert subprocess.check_output(['git','status','--porcelain'],cwd=MAIN)==before
report=dict(schema_version=1,chromium='147.0.7727.50',skia_revision=skia_revision,deps_url=deps_url,deps_sha256=hashlib.sha256(deps).hexdigest(),files=rows,all_commands_terminal=True,source_changed=False,primary_review_only=True,web_tool_could_not_open_primary_page=True,release_qualification=False,javascript_executed_by_openui=False,probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps(report))
