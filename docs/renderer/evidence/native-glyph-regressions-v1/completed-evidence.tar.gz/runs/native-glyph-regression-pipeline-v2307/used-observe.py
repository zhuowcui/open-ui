def observe(page, picture, expression, scale):
    observations = []
    exceptions = []
    commands = []

    def trace(frame, event, arg):
        if event == 'exception' and frame.f_code.co_filename == str(SDK / 'tools/accountability/run_all_pixel_comparisons.py'):
            exceptions.append(dict(function=frame.f_code.co_name, type=arg[0].__name__, message=str(arg[1])))
        return trace

    class QueryWebSocket(original_ws):

        def command(self, method, params=None):
            result = super().command(method, params)
            commands.append(dict(method=method, screenshot_sha256=hashlib.sha256(result['data'].encode()).hexdigest() if method == 'Page.captureScreenshot' and 'data' in result else None))
            if method == 'Runtime.evaluate' and (not observations):
                response = super().command('Runtime.evaluate', dict(expression=expression, returnByValue=True))
                assert 'exceptionDetails' not in response, response.get('exceptionDetails')
                observations.append(response['result']['value'])
            return result
    capture._CdpWebSocket = QueryWebSocket
    processes = []
    original_popen = capture.subprocess.Popen
    original_tmpdir = capture.tempfile.TemporaryDirectory
    cleanup_events = []

    class StoppedChromeProfile(original_tmpdir):

        def __exit__(self, exc, value, tb):
            for process in processes:
                if process.poll() is None:
                    os.killpg(process.pid, signal.SIGTERM)
                    try:
                        process.wait(timeout=15)
                    except subprocess.TimeoutExpired:
                        os.killpg(process.pid, signal.SIGKILL)
                        process.wait(timeout=15)
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                # Wait for group members to stop; zombies cannot write profiles.
                deadline=time.monotonic()+10
                while True:
                    alive=[]
                    for entry in Path('/proc').iterdir():
                        if not entry.name.isdecimal(): continue
                        try:
                            fields=(entry/'stat').read_text().rsplit(')',1)[1].split()
                            if int(fields[2])==process.pid and fields[0]!='Z': alive.append(int(entry.name))
                        except (OSError,ValueError): pass
                    if not alive: break
                    assert time.monotonic()<deadline, alive
                    time.sleep(.01)
                cleanup_events.append(dict(pid=process.pid, actual_exit=process.poll(), stopped_before_profile_removal=True, process_group_stopped=True))
            return super().__exit__(exc, value, tb)
    stderr = picture.with_suffix('.stderr.log')
    with stderr.open('xb') as stream:

        def launch(command, *args, **kwargs):
            if command and command[0] == str(chrome):
                command = [command[0], '--disable-dev-shm-usage', *command[1:]]
                kwargs['stderr'] = stream
            kwargs['start_new_session'] = True
            process = original_popen(command, *args, **kwargs)
            processes.append(process)
            return process
        capture.subprocess.Popen = launch
        capture.tempfile.TemporaryDirectory = StoppedChromeProfile
        sys.settrace(trace)
        try:
            ok = capture.render_chrome(str(page), str(picture), str(chrome), str(chrome.parent), use_ahem_noaa=True, logical_width=WIDTH, logical_height=HEIGHT, device_scale=scale)
        finally:
            sys.settrace(None)
            capture._CdpWebSocket = original_ws
            capture.subprocess.Popen = original_popen
            capture.tempfile.TemporaryDirectory = original_tmpdir
    attempt = dict(cleanup_events=cleanup_events, exceptions=exceptions, commands=commands, observations=observations, capture_ok=ok, query_count=len(observations), process_actual_exits=[p.poll() for p in processes], stderr_sha256=sha(stderr))
    picture.with_suffix('.attempt.json').write_text(json.dumps(attempt, sort_keys=True, indent=2) + '\n')
    assert ok and len(observations) == 1
    return observations[0]
