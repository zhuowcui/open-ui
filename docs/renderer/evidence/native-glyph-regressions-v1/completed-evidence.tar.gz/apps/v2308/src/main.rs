use openui::prelude::*;
use serde_json::{json, Value};
use std::{cell::Cell, error::Error, path::Path, rc::Rc};

fn bounds(element: &Element) -> Result<Value, Box<dyn Error>> {
    let rect = element.bounding_rect()?.ok_or("bounds required")?;
    Ok(json!({"x":rect.x,"y":rect.y,"width":rect.width,"height":rect.height}))
}

fn main() -> Result<(), Box<dyn Error>> {
    let output = std::env::args().nth(1).ok_or("output directory required")?;
    let output = Path::new(&output);
    std::fs::create_dir_all(output)?;
    let fonts = FontCollection::deterministic_test();
    for (profile, width, height, scale) in [
        ("legacy", 800.0, 600.0, 1.0),
        ("mobile", 375.0, 667.0, 2.0),
        ("desktop", 1280.0, 720.0, 1.25),
        ("large", 1920.0, 1080.0, 1.5),
        ("triple", 800.0, 600.0, 3.0),
    ] {
        for name in ["input", "large-text", "sticky"] {
            let label = format!("{name}-{profile}");
            let path = output.join(&label);
            std::fs::create_dir(&path)?;
            let document = Document::with_font_collection_and_options(
                ViewportMetrics::from_logical_size(width, height, scale)?,
                fonts.clone(),
                EngineOptions {
                    raster_configuration: RasterConfiguration::deterministic_aliased(false),
                },
            )?;
            let body = document.body();
            body.set_width(LengthValue::px(width as f32))?;
            body.set_height(LengthValue::px(height as f32))?;
            body.set_overflow_x(Overflow::Hidden)?;
            body.set_overflow_y(Overflow::Hidden)?;
            body.set_background_color(Color::WHITE)?;
            body.set_font_family(FontFamilyList {
                families: [
                    "Ahem",
                    "Droid Sans Fallback",
                    "Noto Sans Devanagari",
                    "Noto Color Emoji",
                    "DejaVu Sans",
                ]
                .into_iter()
                .map(|name| FontFamily::Named(name.into()))
                .collect(),
            })?;
            body.set_font_size(LengthValue::px(16.0))?;
            body.set_font_kerning(FontKerning::None)?;
            body.set_font_variant_ligatures(FontVariantLigatures::none())?;
            let frame = Element::create(&document, if name == "input" { "input" } else { "div" })?;
            frame.set_attribute("id", "frame")?;
            if name == "input" {
                frame.set_attribute("type", "text")?;
                frame.set_control_value("foo")?;
                frame.set_position(Position::Absolute)?;
                frame.set_left(Length::px(20.0))?;
                frame.set_top(Length::px(20.0))?;
                frame.set_width(LengthValue::px(100.0))?;
                frame.set_height(LengthValue::px(30.0))?;
                frame.set_box_sizing(BoxSizing::BorderBox)?;
                frame.set_font_size(LengthValue::px(18.0))?;
                frame.set_line_height(LineHeight::Number(1.0))?;
                frame.set_padding_top(LengthValue::px(10.0))?;
                frame.set_padding_right(LengthValue::px(10.0))?;
                frame.set_padding_bottom(LengthValue::px(10.0))?;
                frame.set_padding_left(LengthValue::px(10.0))?;
                frame.set_border_top_width(1)?;
                frame.set_border_right_width(1)?;
                frame.set_border_bottom_width(1)?;
                frame.set_border_left_width(1)?;
                frame.set_border_top_style(BorderStyle::Solid)?;
                frame.set_border_right_style(BorderStyle::Solid)?;
                frame.set_border_bottom_style(BorderStyle::Solid)?;
                frame.set_border_left_style(BorderStyle::Solid)?;
                frame.set_border_top_color(StyleColor::Resolved(Color::BLACK))?;
                frame.set_border_right_color(StyleColor::Resolved(Color::BLACK))?;
                frame.set_border_bottom_color(StyleColor::Resolved(Color::BLACK))?;
                frame.set_border_left_color(StyleColor::Resolved(Color::BLACK))?;
            } else {
                frame.set_width(LengthValue::px(width as f32))?;
                frame.set_height(LengthValue::px(height as f32))?;
                frame.set_font_size(LengthValue::px(height as f32 * 0.4))?;
                if name == "large-text" {
                    frame.set_position(Position::Absolute)?;
                    frame.set_left(Length::px(20.0))?;
                    frame.set_top(Length::px(20.0))?;
                    frame.set_background_color(Color::from_rgba8(0, 128, 0, 255))?;
                    frame.set_color(Color::WHITE)?;
                    frame.set_text("PASS")?;
                } else {
                    frame.set_position(Position::Fixed)?;
                    frame.set_left(Length::px(20.0))?;
                    frame.set_top(Length::px(20.0))?;
                    frame.set_background_color(Color::from_rgba8(255, 0, 0, 255))?;
                    frame.set_color(Color::from_rgba8(255, 255, 0, 255))?;
                    let spacer = Element::create(&document, "div")?;
                    spacer.set_width(LengthValue::percent(100.0))?;
                    spacer.set_height(LengthValue::percent(100.0))?;
                    spacer.set_text("FAIL")?;
                    frame.append_child(&spacer)?;
                    let sticky = Element::create(&document, "div")?;
                    sticky.set_attribute("id", "sticky")?;
                    sticky.set_width(LengthValue::percent(100.0))?;
                    sticky.set_height(LengthValue::percent(100.0))?;
                    sticky.set_position(Position::Sticky)?;
                    sticky.set_bottom(Length::px(0.0))?;
                    sticky.set_background_color(Color::from_rgba8(0, 128, 0, 255))?;
                    sticky.set_color(Color::WHITE)?;
                    sticky.set_text("PASS")?;
                    frame.append_child(&sticky)?;
                }
            }
            body.append_child(&frame)?;
            let before = bounds(&frame)?;
            let owned = frame.computed_style()?;
            document.render_to_png(path.join("before.png"))?;
            let weak = frame.downgrade();
            let target = weak.clone();
            let calls = Rc::new(Cell::new(0));
            let observed = calls.clone();
            frame.on("click", move |_| {
                let element = target.upgrade().unwrap();
                if name == "sticky" {
                    element
                        .set_font_size(LengthValue::px(height as f32 * 0.4 + 1.0))
                        .unwrap();
                } else {
                    element.set_left(Length::px(21.0)).unwrap();
                    element.set_top(Length::px(21.0)).unwrap();
                }
                observed.set(observed.get() + 1);
            })?;
            frame.click()?;
            let after = bounds(&frame)?;
            document.render_to_png(path.join("after.png"))?;
            assert_eq!(calls.get(), 1);
            let original_font_size = if name == "input" {
                18.0
            } else {
                height as f32 * 0.4
            };
            assert_eq!(owned.font_size, original_font_size);
            println!(
                "{}",
                json!({"label":label,"name":name,"profile":profile,"width":width,"height":height,"scale":scale,"before":before,"after":after,"callbacks":calls.get(),"owned_snapshots_unchanged":true})
            );
            drop(frame);
            drop(body);
            drop(document);
            assert!(weak.upgrade().is_none());
        }
    }
    Ok(())
}
