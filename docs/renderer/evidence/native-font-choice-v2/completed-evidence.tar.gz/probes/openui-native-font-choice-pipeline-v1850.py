"""Own compilation and native raster replay for the immutable Fontations draft."""
import fcntl
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

MAIN = Path('/home/nero/code/open-ui')
ROOT = Path('/dev/shm/openui-native-font-choice-ef8880b0-v1849')
RAW = MAIN / 'out/renderer-evidence/native-viewport-scroll-v1'
NAME = 'native-font-choice-pipeline-v1850'
OUT = RAW / NAME
STORE = Path('/mnt/e/openui-v02-qualification-d174ea0b') / NAME
lock = open('/tmp/openui-native-cargo-raster-owner.lock', 'a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
for program in ['cargo', 'pixel_compare']:
    assert subprocess.run(['pgrep', '-x', program], capture_output=True).returncode == 1
assert not OUT.exists() and not STORE.exists()
STORE.mkdir()
OUT.symlink_to(STORE, target_is_directory=True)
sys.path.insert(0, str(ROOT / 'tools/qualification'))
from renderer_source_identity import repository_source_identity

sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
source = repository_source_identity(ROOT)
assert source['clean'] and source['commit'] == 'ef8880b083876319df54599416c0fe11c543a26c'
check_path = RAW / 'native-font-choice-checks-v1850/receipt.json'
checks = json.loads(check_path.read_bytes())
assert checks['all_commands_terminal'] and checks['source'] == checks['source_after'] == source
assert len(checks['checks']) == 15 and all(c['observed_exit_code'] == 0 for c in checks['checks'])
scripts = [Path('/tmp/openui-native-font-choice-' + name + '-v1850.py') for name in ['build', 'consumer']]
report = dict(schema_version=1, source=source, source_after=source,
    owner_pid=os.getpid(), all_commands_terminal=False, state='prepared-verified',
    release_qualification=False, promotion_allowed=False, new_release_states_admitted=0,
    javascript_executed_by_openui=False, public_native_rust_apis_required=True,
    pixel_tolerance=0, whole_pipeline_lock_covers_all_stages_and_gaps=True,
    steps=[], probe_sha256=sha(Path(__file__)),
    immutable_probe_hashes={str(p): sha(p) for p in scripts},
    read_only_check_receipt_sha256=sha(check_path),
    inherited_rejected_descriptor_change=True,
    full_renderer_matrices_not_attempted_by_this_pipeline=True)
save = lambda: (OUT / 'receipt.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
save()
try:
    for name, script in zip(['build', 'native-fonts'], scripts):
        assert repository_source_identity(ROOT) == source
        assert all(sha(p) == report['immutable_probe_hashes'][str(p)] for p in scripts)
        report['state'] = 'running-' + name
        save()
        log = OUT / (name + '.log')
        with log.open('xb') as stream:
            process = subprocess.Popen([sys.executable, str(script)], cwd=ROOT,
                env=dict(os.environ, OPENUI_NATIVE_WHOLE_OWNER=NAME, PYTHONDONTWRITEBYTECODE='1'),
                stdout=stream, stderr=subprocess.STDOUT)
            report['current_process'] = dict(pid=process.pid, program=script.name)
            save()
            process.wait()
        report.pop('current_process')
        report['steps'].append(dict(name=name, observed_exit_code=process.returncode, log_sha256=sha(log)))
        report['source_after'] = repository_source_identity(ROOT)
        assert report['source_after'] == source
        save()
        print(json.dumps(dict(stage=name, actual_exit=process.returncode)), flush=True)
        path = RAW / ('native-font-choice-build-v1850/build.json' if name == 'build' else 'native-font-choice-consumer-v1850/receipt.json')
        result = json.loads(path.read_bytes())
        assert result['all_commands_terminal']
        if name == 'build':
            assert process.returncode == 0, 'build or native guard failed'
        else:
            assert not result.get('failure') and result['totals']['images'] == 600
    report.update(state='complete-requires-review', observed_exit_code=int(any(s['observed_exit_code'] for s in report['steps'])))
except BaseException as error:
    report.update(state='stopped-on-build-or-harness-failure', failure=str(error), observed_exit_code=1)
    raise
finally:
    report.update(all_commands_terminal=True, source_after=repository_source_identity(ROOT))
    save()
raise SystemExit(report['observed_exit_code'])
