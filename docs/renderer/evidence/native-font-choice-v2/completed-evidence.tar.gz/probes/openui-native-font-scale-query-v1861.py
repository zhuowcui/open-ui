"""Query Chromium baselines and text metrics without replacing reference images."""
import fcntl
import hashlib
import importlib.util
import json
import os
import shutil
import signal
import subprocess
import sys
import tempfile
from pathlib import Path

MAIN = Path('/home/nero/code/open-ui')
RAW = MAIN / 'out/renderer-evidence/native-viewport-scroll-v1'
OUT = RAW / 'native-font-scale-query-v1861'
STORE = Path('/mnt/e/openui-v02-qualification-d174ea0b') / OUT.name
lock = open('/tmp/openui-native-cargo-raster-owner.lock', 'a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
prior_owner = json.loads((RAW / 'native-font-choice-pipeline-v1850/receipt.json').read_bytes())
assert prior_owner['all_commands_terminal']
for program in ['cargo', 'pixel_compare']:
    assert subprocess.run(['pgrep', '-x', program], capture_output=True).returncode == 1
assert not OUT.exists() and not STORE.exists()
STORE.mkdir(); OUT.symlink_to(STORE, target_is_directory=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
prior_path = RAW / 'native-text-style-runtime-consumer-v1677/receipt.json'
prior = json.loads(prior_path.read_bytes())
assert prior['all_commands_terminal']
chrome = MAIN / 'chrome/linux-147.0.7727.50/chrome-linux64/chrome'
assert sha(chrome) == prior['chromium']['binary_sha256']
fontconfig = prior_path.parent / 'fontconfig.conf'
assert sha(fontconfig) == prior['fontconfig_sha256']
harness = MAIN / 'tools/accountability/run_all_pixel_comparisons.py'
assert sha(harness) == prior['capture_harness_sha256']
spec = importlib.util.spec_from_file_location('capture', harness)
capture = importlib.util.module_from_spec(spec); spec.loader.exec_module(capture)
env = capture.chrome_environment(str(chrome.parent), False, True)
env['FONTCONFIG_FILE'] = str(fontconfig)
report = dict(schema_version=1, owner_pid=os.getpid(), all_commands_terminal=False,
    release_qualification=False, javascript_executed_by_openui=False,
    javascript_runs_only_in_separate_chromium_reference_process=True,
    chromium_screenshots_generated=0, prior_reference_images_rewritten=0,
    chromium_binary_sha256=sha(chrome), capture_harness_sha256=sha(harness),
    fontconfig_sha256=sha(fontconfig), prior_reference_receipt_sha256=sha(prior_path),
    probe_sha256=sha(Path(__file__)), observations=[])
save = lambda: (OUT / 'receipt.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
save()
expression = '''(async()=>{
if(document.readyState!=='complete')await new Promise(r=>addEventListener('load',r,{once:true}));
await document.fonts.ready;
await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
const e=document.querySelector('body>div');const s=getComputedStyle(e);
const bounds=()=>{const b=e.getBoundingClientRect();return {x:b.x,y:b.y,width:b.width,height:b.height}};
const range=document.createRange();range.selectNodeContents(e);
const rb=()=>{const b=range.getBoundingClientRect();return {x:b.x,y:b.y,width:b.width,height:b.height}};
const originalBounds=bounds(),originalRangeBounds=rb();
const ctx=document.createElement('canvas').getContext('2d');ctx.font=s.font;
const m=ctx.measureText('X');
const marker=document.createElement('span');marker.style.cssText='display:inline-block;width:0;height:0;font-size:0;line-height:0';e.append(marker);
const markerBounds=marker.getBoundingClientRect();
range.setStart(e.firstChild,0);range.setEnd(e.firstChild,1);
return {metrics:{width:innerWidth,height:innerHeight,dpr:devicePixelRatio},
originalBounds,withMarkerBounds:bounds(),originalRangeBounds,withMarkerRangeBounds:rb(),
baselineY:markerBounds.y,font:s.font,canvasFont:ctx.font,
textMetrics:{width:m.width,fontBoundingBoxAscent:m.fontBoundingBoxAscent,
fontBoundingBoxDescent:m.fontBoundingBoxDescent,actualBoundingBoxAscent:m.actualBoundingBoxAscent,
actualBoundingBoxDescent:m.actualBoundingBoxDescent}};
})()'''
try:
    for scale in [1.0, 1.25, 1.5, 2.0, 3.0]:
        repeats = []
        for repeat in [1, 2]:
            profile = Path(tempfile.mkdtemp(prefix='oui-font-metrics-', dir='/dev/shm/oui1859'))
            process = client = None
            try:
                flag = '--enable-features=FontDataServiceLinux:typeface/Fontations'
                process = subprocess.Popen([str(chrome), '--headless', '--disable-gpu', '--no-sandbox',
                    '--no-first-run', '--no-default-browser-check', '--remote-debugging-port=0',
                    flag, '--user-data-dir=' + str(profile), 'about:blank'], env=env,
                    start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                port = capture._wait_for_devtools_endpoint(str(profile), process)
                client = capture._CdpWebSocket(capture._page_websocket_url(port))
                client.command('Page.enable')
                client.command('Emulation.setDeviceMetricsOverride', dict(width=800, height=600,
                    deviceScaleFactor=scale, mobile=False, screenWidth=800, screenHeight=600))
                observations = []
                for family in ['Ahem', 'DejaVu Sans']:
                    for size in [10, 12, 16]:
                        key = family.replace(' ', '-') + '-' + str(size)
                        path = Path(prior['inputs'][key]['before']['path'])
                        assert sha(path) == prior['inputs'][key]['before']['sha256']
                        client.command('Page.navigate', dict(url=path.resolve().as_uri()))
                        result = client.command('Runtime.evaluate', dict(expression=expression,
                            awaitPromise=True, returnByValue=True))
                        assert 'exceptionDetails' not in result
                        value = result['result']['value']
                        assert capture._device_metrics_match(value['metrics'], 800, 600, scale)
                        assert value['originalBounds'] == value['withMarkerBounds']
                        assert value['originalRangeBounds'] == value['withMarkerRangeBounds']
                        observations.append(dict(family=family, size=size, scale=scale,
                            input_sha256=sha(path), feature_flag=flag, query=value))
                repeats.append(observations)
            finally:
                if client is not None: client.close()
                if process is not None:
                    try: os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError: pass
                    process.wait(timeout=10)
                shutil.rmtree(profile)
        assert repeats[0] == repeats[1], 'independent Chromium metrics queries disagree'
        report['observations'].extend(repeats[0])
        save()
        print(json.dumps(dict(scale=scale, independently_repeated_cases=6)), flush=True)
    report.update(observed_exit_code=0, independent_chromium_processes=10,
        metrics_queries=60, unique_cases=30, independent_pairs_identical=True)
except BaseException as error:
    report.update(observed_exit_code=1, failure=str(error)); raise
finally:
    report.update(all_commands_terminal=True)
    assert sha(prior_path) == report['prior_reference_receipt_sha256']
    assert sha(chrome) == report['chromium_binary_sha256'] and sha(fontconfig) == report['fontconfig_sha256']
    save()
raise SystemExit(report['observed_exit_code'])
