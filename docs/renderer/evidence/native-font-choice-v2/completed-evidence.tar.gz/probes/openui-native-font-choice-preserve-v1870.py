"""Freeze completed Fontations, Chromium metric and hosted job evidence."""
import hashlib
import json
import shutil
import tarfile
from pathlib import Path

ROOT = Path('/home/nero/code/open-ui')
RAW = ROOT / 'out/renderer-evidence/native-viewport-scroll-v1'
DEST = ROOT / 'docs/renderer/evidence/native-font-choice-v2'
INDEX = ROOT / 'docs/renderer/generated/native-font-choice-v2.json'
assert not DEST.exists() and not INDEX.exists()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
owner_path = RAW / 'native-font-choice-pipeline-v1850/receipt.json'
owner = json.loads(owner_path.read_bytes())
consumer_path = RAW / 'native-font-choice-consumer-v1850/receipt.json'
consumer = json.loads(consumer_path.read_bytes())
build_path = RAW / 'native-font-choice-build-v1850/build.json'
build = json.loads(build_path.read_bytes())
metrics_path = RAW / 'native-font-scale-query-v1861/receipt.json'
metrics = json.loads(metrics_path.read_bytes())
hosted_path = RAW / 'native-glyph-umbrella-hosted-v1846/receipt.json'
hosted = json.loads(hosted_path.read_bytes())
for result in [owner, consumer, build, metrics, hosted]:
    assert result['all_commands_terminal']
assert owner['source'] == owner['source_after'] == consumer['source'] == consumer['source_after'] == build['source'] == build['source_after']
assert consumer['source']['clean'] and consumer['source']['commit'] == 'ef8880b083876319df54599416c0fe11c543a26c'
assert not consumer.get('failure') and consumer['totals']['images'] == 600
assert build['observed_exit_code'] == 0 and len(build['steps']) == 8
assert metrics['observed_exit_code'] == 0 and metrics['unique_cases'] == 30 and metrics['metrics_queries'] == 60
assert hosted['source'] == '6974740922acd79ed4c7546704b2f3f892917085'
assert hosted['successful_jobs'] == 13 and hosted['skipped_jobs'] == 5 and hosted['failed_jobs'] == 0
assert hosted['all_six_native_guards_executed_and_passed_in_hosted_parity']
previous_path = RAW / 'native-glyph-current-candidate-consumer-v1828/receipt.json'
previous = json.loads(previous_path.read_bytes())
old = {(c['raster'], c['family'], c['size'], c['scale'], i['state']): i for c in previous['cases'] for i in c['images']}
groups = {}
for raster in ['fontations', 'default', 'chromium-lcd']:
    cases = [c for c in consumer['cases'] if c['raster'] == raster]
    images = [i for c in cases for i in c['images']]
    phases = [p for i in images for p in i['phases']]
    assert len(cases) == 100 and len(images) == 200 and len(phases) == 12800
    group = dict(images=200, exact=sum(i['analysis']['mismatched_pixels'] == 0 for i in images),
        mismatched_pixels=sum(i['analysis']['mismatched_pixels'] for i in images),
        phase_exact=sum(p['mismatched_pixels'] == 0 for p in phases),
        geometry_exact=sum(p['geometry_exact'] for p in phases), geometry_total=12800)
    if raster != 'fontations':
        assert all(i['native_png_sha256'] == old[(raster, c['family'], c['size'], c['scale'], i['state'])]['native_png_sha256'] for c in cases for i in c['images'])
        group['all_200_native_pngs_equal_prior_descriptor_trial'] = True
    assert all(i['chromium_png_sha256'] == old[('default', c['family'], c['size'], c['scale'], i['state'])]['chromium_png_sha256'] for c in cases for i in c['images'])
    group['all_200_chromium_pngs_unchanged'] = True
    groups[raster] = group
assert groups['fontations']['exact'] == 62 and groups['default']['exact'] == groups['chromium-lcd']['exact'] == 0
assert len(consumer['default_prior_image_checks']) == 200 and all(c['same_png'] for c in consumer['default_prior_image_checks'])
sources = {}
directories = [
    'native-font-choice-pipeline-v1850', 'native-font-choice-build-v1850',
    'native-font-choice-consumer-v1850', 'native-font-choice-checks-v1850',
    'native-font-scale-query-v1861', 'native-glyph-umbrella-hosted-v1846',
    'native-glyph-umbrella-checks-v1844']
for name in directories:
    for p in sorted((RAW / name).rglob('*')):
        if p.is_file() and not p.is_symlink() and p.suffix in ['.json', '.log', '.html', '.png']:
            sources[str(p.relative_to(RAW))] = p
for name in ['checks', 'build', 'consumer', 'pipeline']:
    p = Path('/tmp/openui-native-font-choice-' + name + '-v1850.py')
    sources['probes/' + p.name] = p
for p in [Path(__file__), Path('/tmp/openui-native-font-scale-query-v1861.py'),
          Path('/tmp/openui-native-glyph-umbrella-hosted-collect-v1846.py'),
          Path('/tmp/openui-native-glyph-umbrella-checks-v1844.py')]:
    sources['probes/' + p.name] = p
for relative in ['ui/gfx/font_render_params_linux.cc',
    'third_party/blink/renderer/platform/fonts/font_metrics.cc',
    'third_party/blink/renderer/platform/fonts/web_font_render_style.cc', 'chrome/VERSION']:
    sources['reviewed-chromium-source/' + relative] = Path('/home/nero/chromium/src') / relative
DEST.mkdir()
archive = DEST / 'completed-evidence.tar.gz'
members = []
first_by_hash = {}
with tarfile.open(archive, 'w:gz', compresslevel=6, format=tarfile.PAX_FORMAT) as tar:
    for name, path in sorted(sources.items()):
        digest = sha(path)
        row = dict(path=name, bytes=path.stat().st_size, sha256=digest)
        info = tar.gettarinfo(str(path), arcname=name)
        if digest in first_by_hash:
            info.type = tarfile.LNKTYPE; info.linkname = first_by_hash[digest]; info.size = 0
            tar.addfile(info)
        else:
            first_by_hash[digest] = name
            with path.open('rb') as stream: tar.addfile(info, stream)
        members.append(row)
with tarfile.open(archive, 'r:gz') as tar:
    actual = tar.getmembers()
    assert len(actual) == len(members)
    for member, row in zip(actual, members):
        assert member.name == row['path']
        data = tar.extractfile(member).read()
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
manifest = DEST / 'archive-members.json'
manifest.write_text(json.dumps(members, sort_keys=True, indent=2) + '\n')
artifacts = [dict(path=str(p.relative_to(ROOT)), bytes=p.stat().st_size, sha256=sha(p)) for p in [archive, manifest]]
index = dict(schema_version=1, source=consumer['source'], source_after=consumer['source_after'],
    all_commands_terminal=True, release_qualification=False, promotion_allowed=False,
    option_is_private_unintegrated_outline_adapter=True,
    font_matching_shaping_and_metrics_still_use_freetype=True,
    inherits_rejected_descriptor_change=True, inherited_full_census_exact_losses=29,
    new_source_full_original_and_expanded_matrices_not_measured=True,
    javascript_executed_by_openui=False, chromium_is_only_pixel_target=True,
    pixel_tolerance=0, new_release_states_admitted=0,
    build_stages_passed=8, text_tests_passed=343, workspace_tests_passed=8560,
    native=consumer['totals'], configurations=groups,
    fontations_unit_scale_exact=40, fontations_unit_scale_total=40,
    fontations_larger_scales_exact=22, fontations_larger_scales_total=160,
    all_400_old_native_images_unchanged=True, all_reference_images_unchanged=True,
    repeated_chromium_metrics_cases=30, chromium_metrics_queries=60,
    chromium_metrics_reference_images_rewritten=0,
    reviewed_chromium_source_version='147.0.7727.24', measured_chromium_binary_version='147.0.7727.50',
    local_source_review_is_not_a_runtime_typeface_factory_trace=True,
    hosted_source=hosted['source'], hosted_jobs=dict(success=13, skipped=5, failed=0),
    hosted_all_six_native_guards_executed_and_passed=True,
    skipped_jobs_are_not_release_passes=True,
    previous_font_choice_index=dict(path='docs/renderer/generated/native-font-choice-v1.json',
        sha256=sha(ROOT / 'docs/renderer/generated/native-font-choice-v1.json')),
    receipts_sha256={str(p.relative_to(RAW)): sha(p) for p in [owner_path, consumer_path, build_path, metrics_path, hosted_path]},
    archived_members=len(members), artifacts=artifacts, preserver_sha256=sha(Path(__file__)))
INDEX.write_text(json.dumps(index, sort_keys=True, indent=2) + '\n')
print(json.dumps(dict(index=str(INDEX), index_sha256=sha(INDEX), members=len(members),
    archive_bytes=archive.stat().st_size, native_fontations_exact=62,
    all_reference_and_400_prior_native_images_unchanged=True)), flush=True)
