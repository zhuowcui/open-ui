import hashlib,json,os
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');INDEX=ROOT/'docs/renderer/generated/native-float-clearance-v1.json';r=json.loads(INDEX.read_bytes());proof=json.loads(Path('/tmp/openui-native-float-clearance-archive-terminal-v3954.json').read_bytes());assert proof['archive_writer_reaped'] and proof['actual_archive_writer_exit_code']==0 and r['all_local_commands_terminal']
assert r['native_candidate']['totals']==dict(images=8,exact_images=8,bounds=320,exact_bounds=320) and r['native_candidate']['guards']['passed']==1182
m=r['renderer_candidate']['results'];assert m['focused']['exact']==640 and m['primitive']['exact']==960 and m['selected']['exact']==17
text="""## Cleared empty boxes (native repair; clean full verification pending)

The shared block layout now calculates clearance using the complete collapsed
margin group of an empty cleared box. Previously it placed the box before the
descendant bottom margin was known, then counted that margin again. The repair
retains the shared float width calculation and adds no font-name, size, scale,
test-ID or output-pixel correction.

A consuming Rust app creates eight reduced cases, including four nonempty
neighbors, and removes margins through a Rust click callback. The dirty-source
repair matches pinned Chromium in **8/8 images and 320/320 bounds** across all
four required profiles. Its clean prior baseline was **4/8 images and 256/320
bounds exact**. Independent process and unchanged-frame repeats, callback
counts and weak teardown pass. All **1,182 layout/text/paint tests** pass, with
zero failures or ignores, including eight oracle-derived Engine scenarios.

A selected sweep restores **all 16 exact comparisons** lost by the preceding
atomic sizing change. Its **17/20 exact** comparisons have zero errors and no
exact losses against the earlier clean renderer. Three existing scroll-button
appearance differences remain, including the earlier worsened comparison.
Focused **640/640** and primitive **960/960** are exact and unchanged; all
**1,620 selected/focused/primitive rows**, fresh linked artifacts and unchanged
Chromium reference fields are audited.

These are dirty-source diagnostic results. Clean native execution, complete
original and expanded censuses, full workspace/ABI and current checkpoint
hosted checks remain pending. This repair does not establish full renderer,
complete native API or release qualification. Open UI never executes
JavaScript; applications use public Rust operations and callbacks. Chromium
alone defines expected pixels.
[Immutable repair evidence]({link}).

"""
changes=[]
for name,link in [('README.md','docs/renderer/generated/native-float-clearance-v1.json'),('docs/progress/current-status.md','../renderer/generated/native-float-clearance-v1.json'),('docs/renderer/contract.md','generated/native-float-clearance-v1.json'),('docs/v02/release.md','../renderer/generated/native-float-clearance-v1.json')]:
 p=ROOT/name;old=p.read_text();heading='### Shared atomic sizing' if name=='README.md' else '## Shared atomic sizing';assert heading in old and '## Cleared empty boxes' not in old;pos=old.index(heading);section=text.format(link=link)
 if name=='README.md':section=section.replace('## Cleared empty boxes','### Cleared empty boxes',1)
 new=old[:pos]+section+old[pos:];tmp=p.with_name(p.name+'.tmp');tmp.write_text(new);os.replace(tmp,p);changes.append(name)
p=ROOT/'docs/v02/unsupported-features.md';old=p.read_text();marker='These are implementation gaps, not accepted final-v0.2 omissions:\n\n';assert marker in old;bullet="""- the cleared-empty-box repair has scoped dirty-source evidence: 8/8 native
  images and 320/320 bounds exact, all 1,182 layout/text/paint tests passing,
  and all 16 lost float-clearance comparisons restored. Focused 640/640 and
  primitive 960/960 remain exact. Three selected scroll-button differences
  remain; one still worsens against the earlier clean renderer. Clean native,
  complete original/expanded censuses, workspace/ABI and current hosted checks
  remain pending. [Evidence](../renderer/generated/native-float-clearance-v1.json);
""";new=old.replace(marker,marker+bullet,1);tmp=p.with_name(p.name+'.tmp');tmp.write_text(new);os.replace(tmp,p);changes.append(str(p.relative_to(ROOT)))
example=ROOT/'bindings/rust/openui/examples/native_float_clearance.rs';assert not example.exists();source=Path('/mnt/d/openui-v02-qualification-d174ea0b/native-float-clearance-source-v3937/project/src/main.rs');example.write_bytes(source.read_bytes());assert hashlib.sha256(example.read_bytes()).hexdigest()==hashlib.sha256(source.read_bytes()).hexdigest()
p=Path('/tmp/openui-native-float-clearance-docs-v3955.json');assert not p.exists();p.write_text(json.dumps(dict(schema_version=1,edited_documents=changes,example=str(example.relative_to(ROOT)),example_bytes_identical_to_measured_consumer=True,qualified=False),sort_keys=True,indent=2)+'\n');print(json.dumps(dict(edited_documents=len(changes),native_example=True,qualified=False)))
