import fcntl,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b');OUT=BASE/'native-float-clearance-candidate-v3946';PROJECT=BASE/'native-float-clearance-source-v3937/project';DEST=Path('/tmp/openui-native-float-clearance-candidate-audit-v3947.json')
load=lambda p:json.loads(Path(p).read_bytes());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
sys.path.insert(0,'/tmp');from openui_parallel_source_identity_v3060 import identity
r=load(OUT/'receipt.json');assert r['all_commands_terminal'] and r['observed_exit_code']==int(sys.argv[1]) and r['source_unchanged'];assert r['source']==r['source_after']==identity(ROOT)
assert subprocess.run(['ps','-p',str(r['owner_pid'])],capture_output=True).returncode==1
for name in ['cargo','rustc','rustfmt','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
assert 'failure' not in r and sha(__file__.replace('candidate-audit-v3947','candidate-v3946'))==r['driver_sha256']
assert sha(PROJECT/'src/main.rs')==r['consumer_source_sha256'] and sha(PROJECT/'Cargo.lock')==r['consumer_lock_sha256'] and sha(PROJECT/'Cargo.toml')==r['consumer_manifest_sha256']
assert sha(OUT/'native_clearance_consumer')==r['native_binary_sha256']
for step in r['steps']:assert step['actual_exit_code']==0 and sha(OUT/(step['name']+'.log'))==step['log_sha256']
for row in r['local_artifacts']:
 assert not row['fresh']
 for path,digest in row['sha256'].items():assert sha(path)==digest
 for field in ['manifest_path']:
  p=Path(row[field]).resolve();assert p.is_relative_to(ROOT) or p.is_relative_to(PROJECT)
assert len(r['cases'])==4
images=bounds=0
for i,c in enumerate(r['cases']):
 assert c['runs'][0]['files']==c['runs'][1]['files']
 for repeat in [1,2]:
  for name,digest in c['runs'][repeat-1]['files'].items():assert sha(OUT/f'profile-{i}/native-{repeat}'/name)==digest
 for stage,s in c['stages'].items():
  assert len(s['native_bounds'])==len(s['chromium_bounds'])==40
  assert load(OUT/f'profile-{i}/native-1/{stage}.json')==s['native_bounds']
  assert s['exact_bounds']==sum(a==b for a,b in zip(s['native_bounds'],s['chromium_bounds']))
  images+=s['analysis']['mismatched_pixels']==0;bounds+=s['exact_bounds']
assert r['totals']==dict(images=8,exact_images=images,bounds=320,exact_bounds=bounds)
assert r['guard_results']==dict(actual_exit_code=0,passed=1182,failed=0,ignored=0)
assert not DEST.exists();proof=dict(schema_version=1,complete=True,source=r['source'],actual_owner_exit_code=int(sys.argv[1]),owner_absent=True,receipt_sha256=sha(OUT/'receipt.json'),compiled_records=len(r['local_artifacts']),totals=r['totals'],all_output_hashes={str(p.relative_to(OUT)):sha(p) for p in OUT.rglob('*') if p.is_file()},renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,retired_after_source_or_target_mutation=True)
DEST.write_text(json.dumps(proof,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(proof=str(DEST),totals=r['totals'],compiled_records=len(r['local_artifacts']))))
