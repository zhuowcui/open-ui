import fcntl,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');OUT=Path('/mnt/d/openui-v02-qualification-d174ea0b/native-float-clearance-chromium-v3938');DEST=Path('/tmp/openui-native-float-clearance-chromium-audit-v3939.json')
load=lambda p:json.loads(Path(p).read_bytes());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
sys.path.insert(0,'/tmp');from openui_parallel_source_identity_v3060 import identity
r=load(OUT/'receipt.json');assert r['all_commands_terminal'] and r['observed_exit_code']==0 and r['source']==r['source_after']==identity(ROOT);assert subprocess.run(['ps','-p',str(r['owner_pid'])],capture_output=True).returncode==1
assert sha('/tmp/openui-native-float-clearance-chromium-v3938.py')==r['driver_sha256'];assert sha(ROOT/'chrome/linux-147.0.7727.50/chrome-linux64/chrome')==r['chromium_binary_sha256']
for step in r['steps']:assert step['actual_exit_code'] is not None and subprocess.run(['ps','-p',str(step['pid'])],capture_output=True).returncode==1
assert len(r['cases'])==4
for i,case in enumerate(r['cases']):
 assert case['independent_processes_equal']
 for stage in ['before','after']:
  assert len(case['geometry'][stage])==40
  for repeat in [1,2]:
   assert load(OUT/f'profile-{i}/chromium-{repeat}-{stage}.json')==case['geometry'][stage]
   for capture in [1,2]:assert sha(OUT/f'profile-{i}/chromium-{repeat}-{stage}-capture-{capture}.png')==case['png_sha256'][stage]
assert not DEST.exists();proof=dict(schema_version=1,complete=True,actual_owner_exit_code=0,actual_owner_session=14704,owner_reaped=True,owner_absent=True,source=r['source'],receipt_sha256=sha(OUT/'receipt.json'),all_output_hashes={str(p.relative_to(OUT)):sha(p) for p in OUT.rglob('*') if p.is_file()},chromium_images=8,chromium_bounds=320,independent_process_repeats=2,consecutive_capture_repeats=2,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,retired_after_source_or_target_mutation=True)
DEST.write_text(json.dumps(proof,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(proof=str(DEST),bounds=320,images=8,owner_absent=True)))
