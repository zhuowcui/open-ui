import fcntl,gzip,hashlib,json,shutil,subprocess
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b');DEST=ROOT/'docs/renderer/evidence/native-float-clearance-v1';INDEX=ROOT/'docs/renderer/generated/native-float-clearance-v1.json'
load=lambda p:json.loads(Path(p).read_bytes());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof=load('/tmp/openui-native-float-clearance-matrices-reaped-v3952.json');audit=load('/tmp/openui-native-float-clearance-matrices-audit-v3951.json');matrix=load(BASE/'native-float-clearance-matrices-v3950/receipt.json');native=load(BASE/'native-float-clearance-candidate-v3946/receipt.json');baseline=load(BASE/'native-float-clearance-baseline-v3941/receipt.json')
assert proof['all_local_commands_terminal'] and proof['owners_absent'] and audit['complete'] and matrix['all_commands_terminal'] and native['all_commands_terminal'] and baseline['all_commands_terminal']
assert proof['source']==audit['source']==matrix['source']==native['source'] and sha(BASE/'native-float-clearance-matrices-v3950/receipt.json')==proof['receipt_sha256']==audit['receipt_sha256']
assert native['totals']==dict(images=8,exact_images=8,bounds=320,exact_bounds=320) and native['guard_results']==dict(actual_exit_code=0,passed=1182,failed=0,ignored=0)
assert audit['results']['selected']['exact']==17 and audit['results']['selected']['total']==20 and audit['results']['selected']['losses']==0
assert audit['results']['focused']['exact']==640 and audit['results']['primitive']['exact']==960
for r in [matrix,native,baseline]:assert subprocess.run(['ps','-p',str(r['owner_pid'])],capture_output=True).returncode==1
for name in ['cargo','rustc','rustfmt','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
source=load(BASE/'native-float-clearance-candidate-source-v3945/receipt.json');assert sha(ROOT/'bindings/rust/openui-layout/src/block.rs')==source['after_sha256']
previous=ROOT/'docs/renderer/generated/native-font-families-v5.json';previous_hash=sha(previous)
for member in load(previous)['archive']['members']:assert sha(ROOT/member['path'])==member['sha256']
assert not DEST.exists() and not INDEX.exists() and shutil.disk_usage(ROOT).free>128*2**20;DEST.mkdir();members=[];excluded=[]
def add(p,label):
 raw=Path(p).read_bytes();stored=gzip.compress(raw,compresslevel=9,mtime=0);out=DEST/(label+'.gz');assert not out.exists();out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(stored);assert gzip.decompress(out.read_bytes())==raw
 members.append(dict(path=str(out.relative_to(ROOT)),compression='gzip',bytes=len(stored),sha256=sha(out),raw_bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest()))
for directory,label in [('native-float-clearance-source-v3937','consumer-source'),('native-float-clearance-chromium-v3938','chromium'),('native-float-clearance-baseline-v3941','native-baseline'),('native-float-clearance-candidate-source-v3945','runtime-source'),('native-float-clearance-candidate-v3946','native-candidate')]:
 for p in sorted((BASE/directory).rglob('*')):
  if p.is_file():
   if p.name=='native_clearance_consumer':excluded.append(dict(path=str(p),sha256=sha(p),reason='Owned native binary retained outside Git with fresh compiler hashes.'));continue
   add(p,label+'/'+str(p.relative_to(BASE/directory)))
out=BASE/'native-float-clearance-matrices-v3950'
for p in sorted((out/'guarded-build').iterdir()):
 if p.is_file():
  if p.name=='pixel_compare':excluded.append(dict(path=str(p),sha256=sha(p),reason='Owned renderer binary retained outside Git with fresh compiler hashes.'));continue
  add(p,'renderer-build/'+p.name)
for suite in ['selected','focused','primitive']:add(out/(suite+'-matrix')/(('full' if suite=='selected' else suite)+'-summary.json'),suite+'-summary.json');add(out/(suite+'.log'),suite+'.log')
add(out/'receipt.json','renderer-receipt.json');add(BASE/'native-float-clearance-selected-ids-v3949.json','selected-ids.json')
for pattern in ['openui-native-float-clearance-chromium-v3938.py','openui-native-float-clearance-chromium-audit-v3939.*','openui-native-float-clearance-chromium-reaped-v3940.json','openui-native-float-clearance-baseline-v3941.py','openui-native-float-clearance-baseline-audit-v3942.*','openui-native-float-clearance-baseline-reaped-v3943.json','openui-native-float-clearance-candidate-v3946.py','openui-native-float-clearance-candidate-audit-v3947.*','openui-native-float-clearance-candidate-reaped-v3948.json','openui-native-float-clearance-matrices-v3950.py','openui-native-float-clearance-matrices-audit-v3951.*','openui-native-float-clearance-matrices-reap*-v3952.*']:
 for p in sorted(Path('/tmp').glob(pattern)):add(p,'drivers-and-proofs/'+p.name)
add(__file__,'drivers-and-proofs/'+Path(__file__).name)
assert sha(previous)==previous_hash
result=dict(schema_version=1,measured_source=native['source'],runtime_source=source,previous_immutable_evidence=dict(path=str(previous.relative_to(ROOT)),sha256=previous_hash,unchanged=True),baseline=dict(source=baseline['source'],totals=baseline['totals'],actual_exit_code=1),native_candidate=dict(totals=native['totals'],actual_exit_code=0,guards=native['guard_results'],repeat_and_lifecycle_passed=True,qualification=False),renderer_candidate=dict(audit=audit,results=audit['results'],rows_audited=audit['matrix_rows_verified'],candidate_nonregression=audit['candidate_nonregression'],qualification=False),reviewed_cause=dict(owner='openui-layout',cause='Provisional clearance is chosen before the complete margin group from a self-collapsing cleared box is known; the descendant bottom margin is added to clearance again.',native_before='Empty cleared boxes sit 75 or 100px too low, and inflate their atomic ancestor by the same amount.',chromium='Atomic width 100px, outer height 100px, empty fit-content width and height zero. A 20px minimum width prevents self collapse and retains the margin contribution.',repair='Save pre-clearance flow state and recompute the border edge using the complete self-collapsing margin group.',minimized_native_application=True,engine_guard_cases=8,restored_original_exact_comparisons=16,complete_current_source_census_pending=True),all_local_commands_terminal=True,all_members_hash_verified=True,pixel_target='pinned Chromium',pixel_tolerance=0,historical_openui_archive_is_a_pixel_target=False,javascript_executed_by_openui=False,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,pending=['Current clean native consumer, full original and expanded censuses, workspace/ABI and hosted qualification.','Existing scroll-button appearance differences, including the earlier worsened comparison.','Every remaining rendering gap and needed native API; compositor/3D, physical lab and release.'],archive=dict(files=len(members),bytes=sum(m['bytes'] for m in members),members=members,excluded=excluded))
INDEX.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(index=str(INDEX),members=len(members),stored_bytes=result['archive']['bytes'],qualified=False)),flush=True)
