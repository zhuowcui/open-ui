import fcntl,hashlib,json,os,subprocess,sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');OUT=Path('/mnt/d/openui-v02-qualification-d174ea0b/native-mono-strike-v3737');TARGET=Path('/mnt/e/openui-v02-cargo-c73754e2/target')
sys.path.insert(0,'/tmp')
from openui_parallel_source_identity_v3060 import identity
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for n in ['cargo','rustc','pixel_compare']:assert subprocess.run(['pgrep','-x',n],capture_output=True).returncode==1
b=json.loads(Path('/mnt/d/openui-v02-qualification-d174ea0b/native-font-alias-build-v3731/receipt.json').read_bytes());source=identity(ROOT);assert source==b['source'];assert not OUT.exists();OUT.mkdir()
args=['rustc','--edition=2021','/tmp/openui-native-mono-strike-v3737.rs','-o',str(OUT/'mono-strike'),'-L','dependency='+str(TARGET/'debug/deps')]
linked=[]
for name in ['openui-text','openui-style','openui-geometry']:
 row=next(a for a in b['local_artifacts'] if a['target']['name']==name.replace('-','_'))
 p=next(p for p in row['sha256'] if p.endswith('.rlib'));assert sha(p)==row['sha256'][p];args+=['--extern',name.replace('-','_')+'='+p];linked.append(dict(path=p,sha256=sha(p)))
# The linked Skia artifact is the dependency used by this measured compiler record.
p=TARGET/'debug/deps/libskia_safe-'+Path('/dev/null').name if False else None
rows=[]
for line in Path('/mnt/d/openui-v02-qualification-d174ea0b/native-font-alias-build-v3731/native-build.log').read_text().splitlines():
 try:a=json.loads(line)
 except json.JSONDecodeError:continue
 if a.get('reason')=='compiler-artifact' and a['target']['name']=='skia_safe':rows.append(a)
assert len(rows)==1
p=next(p for p in rows[0]['filenames'] if p.endswith('.rlib'));args+=['--extern','skia_safe='+p];linked.append(dict(path=p,sha256=sha(p)))
r=dict(schema_version=1,diagnostic_only=True,source=source,owner_pid=os.getpid(),linked=linked,steps=[],all_commands_terminal=False,javascript_executed_by_openui=False,renderer_qualified=False,release_qualified=False)
try:
 for name,command in [('compile',args),('inspect',[str(OUT/'mono-strike')])]:
  with (OUT/(name+'.log')).open('xb') as log:child=subprocess.Popen(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT);code=child.wait(timeout=120)
  r['steps'].append(dict(name=name,command=command,actual_exit_code=code,log_sha256=sha(OUT/(name+'.log'))))
  if code:break
except BaseException as e:
 r['failure']=repr(e);code=1
finally:
 r.update(source_after=identity(ROOT),all_commands_terminal=True,actual_exit_code=code)
 assert r['source_after']==source
 (OUT/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(dict(actual_exit_code=code)),flush=True)
sys.exit(code)
