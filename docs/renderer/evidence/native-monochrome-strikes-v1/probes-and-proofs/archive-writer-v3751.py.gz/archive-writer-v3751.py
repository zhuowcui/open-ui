import gzip,hashlib,json,subprocess
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b')
DEST=ROOT/'docs/renderer/evidence/native-monochrome-strikes-v1';INDEX=ROOT/'docs/renderer/generated/native-monochrome-strikes-v1.json'
load=lambda p:json.loads(Path(p).read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
native=load('/tmp/openui-native-font-alias-comparison-v3742.json')
matrix=load('/tmp/openui-native-font-alias-renderer-completed-audit-v3745.json')
guards=load('/tmp/openui-native-font-alias-guards-terminal-v3749.json')
for p in ['/tmp/openui-native-font-alias-reaped-v3743.json','/tmp/openui-native-font-alias-renderer-reaped-v3747.json','/tmp/openui-native-font-alias-guards-reaped-v3750.json']:
 assert load(p)['all_local_commands_terminal']
assert native['exact_images']==native['images']==10 and native['exact_bounds']==native['bounds']==70
assert matrix['matrix_rows_verified']==1600 and matrix['actual_whole_exit_code']==0
assert guards['actual_owner_exit_code']==0 and guards['passed']==510 and guards['failed']==guards['ignored']==0
assert not DEST.exists() and not INDEX.exists();DEST.mkdir(parents=True);members=[];excluded=[]
def add(data,name):
 p=DEST/name;compressed=not name.endswith('.png');stored=gzip.compress(data,mtime=0) if compressed else data
 if compressed:p=p.with_name(p.name+'.gz')
 p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(stored)
 assert (gzip.decompress(stored) if compressed else stored)==data
 members.append(dict(path=str(p.relative_to(ROOT)),bytes=len(stored),sha256=sha(stored),raw_bytes=len(data),raw_sha256=sha(data),compression='gzip' if compressed else 'none'))
for scope,name in [('first-full-hint-variant','native-font-alias-build-v3726'),('second-subpixel-variant','native-font-alias-build-v3731'),('corrected-native','native-font-alias-build-v3740'),('inspection-link-failure','native-mono-strike-v3737'),('inspection','native-mono-strike-v3738'),('guards','native-font-alias-guards-v3748')]:
 d=BASE/name;assert d.is_dir()
 for p in sorted(d.rglob('*')):
  if not p.is_file():continue
  if p.name in ['native_shaping_wrap','mono-strike'] or p.suffix=='.o':
   excluded.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p.read_bytes()),reason='owned executable or link object excluded; exact hash and provenance preserved'));continue
  add(p.read_bytes(),scope+'/'+str(p.relative_to(d)))
# Reference captures stay identical to the independently repeated earlier oracle.
d=BASE/'native-shaping-wrap-candidate-chromium-v3696'
add((d/'receipt.json').read_bytes(),'immutable-reference/receipt.json')
for p in sorted(d.glob('profile-*/*')):
 if p.is_file() and (p.name=='test.html' or p.name.startswith('chromium-')):add(p.read_bytes(),'immutable-reference/'+str(p.relative_to(d)))
d=BASE/'native-font-alias-renderer-v3744';build=load(d/'guarded-build/receipt.json')
excluded.append(dict(path=build['binary'],sha256=build['binary_sha256'],reason='owned renderer executable excluded; compiler provenance preserved'))
for name in ['receipt.json','guarded-build.log','focused.log','primitive.log']:add((d/name).read_bytes(),'renderer/'+name)
for suite in ['focused','primitive']:add((d/(suite+'-matrix')/(suite+'-summary.json')).read_bytes(),'renderer/'+suite+'-summary.json')
for p in sorted((d/'guarded-build').iterdir()):
 if p.is_file() and p.name!='pixel_compare':add(p.read_bytes(),'renderer/guarded-build/'+p.name)
for p in sorted(Path('/tmp').glob('openui*')):
 if p.is_file() and any(('v'+str(v)) in p.name for v in range(3725,3751)) and p.suffix in ['.py','.json','.rs','.txt','.patch']:add(p.read_bytes(),'probes-and-proofs/'+p.name)
for name in ['openui_parallel_source_identity_v3060.py','openui-native-shaping-wrap-font-policy-review-v3706.json','openui-native-shaping-wrap-font-primary-sources-v3707.json','openui-chromium-font-cache-skia-m147-v3703.cc','openui-chromium-font-render-params-m147-v3704.cc','openui-chromium-font-platform-data-m147-v3705.cc','openui-chromium-font-utils-m147-v3705.cc']:add((Path('/tmp')/name).read_bytes(),'primary-sources/'+name)
for path in ['bindings/rust/openui-paint/src/text_painter.rs','bindings/rust/openui-text/src/shaping/shape_result.rs']:add((ROOT/path).read_bytes(),'source/'+path)
add(subprocess.check_output(['git','diff','--binary','--','bindings/rust/openui-paint/src/text_painter.rs','bindings/rust/openui-text/src/shaping/shape_result.rs'],cwd=ROOT),'source/candidate.patch')
result=dict(schema_version=1,status='diagnostic-candidate-awaiting-clean-complete-qualification',diagnostic_only=True,native=native,renderer=matrix,guards=guards,rejected_variants=[load('/tmp/openui-native-font-alias-comparison-v3728.json'),load('/tmp/openui-native-font-alias-comparison-v3733.json')],all_local_commands_terminal=True,all_members_hash_verified=True,pixel_target='pinned Chromium',pixel_tolerance=0,javascript_executed_by_openui=False,historical_openui_archive_is_a_pixel_target=False,full_renderer_contract_qualified=False,all_native_apis_qualified=False,release_qualified=False,pending=['fresh clean original and expanded censuses','fresh clean workspace and ABI qualification','hosted checks on the new source','remaining native APIs and font-family shaping','compositor, physical lab and release qualification'],archive=dict(files=len(members),bytes=sum(m['bytes'] for m in members),members=members,excluded=excluded))
INDEX.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(files=len(members),bytes=result['archive']['bytes'],index=str(INDEX))),flush=True)
