use openui_geometry::RasterConfiguration;
use openui_style::{FontFamily, FontFamilyList};
use openui_text::font::{Font, FontCollection, FontDescription};
use openui_text::shaping::{TextDirection, TextRasterPolicy, TextShaper};
use skia_safe::{font::Edging, Font as SkFont, FontHinting, TextBlobIter};

fn main() {
    let collection = FontCollection::deterministic_test();
    for family in ["Ahem", "DejaVu Sans"] {
        for scale in [1.0, 1.25, 1.5, 2.0, 3.0] {
            let mut description = FontDescription::new();
            description.family = FontFamilyList { families: vec![FontFamily::Named(family.into())] };
            description.raster_configuration = RasterConfiguration::deterministic_aliased(false);
            description.device_scale_factor = scale as f64;
            let font = Font::new_in_collection(description, collection.clone());
            let shape = TextShaper::new().shape("X", &font, TextDirection::Ltr);
            let blob = shape.to_text_blob_with_raster_policy_at_scale(None, TextRasterPolicy::ChromiumAliased, scale).unwrap();
            let source = &shape.runs[0];
            let mut physical = source.font_data.sk_font().clone();
            physical.set_size(physical.size() * scale);
            let glyph = source.glyphs[0];
            println!("family={family:?} scale={scale} glyph={glyph} source_size={} source_hint={:?} source_subpixel={} source_bounds={:?} metrics={:?}", physical.size(), physical.hinting(), physical.is_subpixel(), physical.get_path(glyph).map(|p| *p.bounds()), physical.metrics());
            for run in TextBlobIter::new(&blob) {
                let mut compatible = SkFont::from_typeface(run.typeface().as_ref().unwrap().clone(), 1.0);
                compatible.set_hinting(FontHinting::None);
                compatible.set_edging(Edging::Alias);
                println!("compatible_bounds={:?}", compatible.get_path(glyph).map(|p| *p.bounds()));
            }
        }
    }
}
