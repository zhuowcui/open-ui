import fcntl,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');OUT=Path('/mnt/d/openui-v02-qualification-d174ea0b/native-font-origin-v4041');DEST=Path('/tmp/openui-native-font-origin-audit-v4042.json')
sys.path[:0]=[str(ROOT/'tools/qualification'),'/tmp']
from openui_parallel_source_identity_v3060 import identity
from residuals import analyze_image_difference
load=lambda p:json.loads(Path(p).read_bytes())
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as stream:
  for block in iter(lambda:stream.read(2**20),b''):h.update(block)
 return h.hexdigest()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
r=load(OUT/'receipt.json');assert r['all_commands_terminal'] and r['observed_exit_code']==int(sys.argv[1])
assert subprocess.run(['ps','-p',str(r['owner_pid'])],capture_output=True).returncode==1
for name in ['cargo','rustc','rustfmt','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
assert identity(ROOT)==r['source']==r['source_after'] and r['source_unchanged'] and r['inputs_unchanged']
assert sha('/tmp/openui-native-font-origin-v4041.py')==r['driver_sha256']
for path,digest in r['input_sha256'].items():assert sha(path)==digest
assert sha(r['binary'])==r['binary_sha256']
for path,digest in r['compiled_artifact_sha256'].items():assert sha(path)==digest
for row in r['compiler_artifacts']:assert row['fresh'] is False and row['reason']=='compiler-artifact'
for row in r['steps']:
 assert subprocess.run(['ps','-p',str(row['pid'])],capture_output=True).returncode==1
 if 'log_sha256' in row:assert sha(OUT/(row['name']+'.log'))==row['log_sha256'] and row['actual_exit_code']==0
totals={};files={};observations=[]
for i,row in enumerate(r['cases']):
 directory=OUT/f'profile-{i}';assert row['chromium_process_repeats_equal']
 for stage,geometry in row['chromium_geometry'].items():
  reference=directory/f'chromium-1-{stage}-capture-1.png'
  for repeat in [1,2]:
   assert load(directory/f'chromium-{repeat}-{stage}.json')==geometry
   for suffix in ['metrics','platform-fonts']:assert load(directory/f'chromium-{repeat}-{stage}-{suffix}.json')==load(directory/f'chromium-1-{stage}-{suffix}.json')
   for capture in [1,2]:assert sha(directory/f'chromium-{repeat}-{stage}-capture-{capture}.png')==sha(reference)
  platform=load(directory/f'chromium-1-{stage}-platform-fonts.json')['fonts']
  assert platform and all(face['familyName']=='Ahem' and face['isCustomFont']==stage.startswith('registered-') for face in platform)
  assert len(geometry)==(6 if stage=='original' else 48)
 for mode,result in row['native'].items():
  assert result['runs'][0]['files']==result['runs'][1]['files']
  for run in result['runs']:
   for name,digest in run['files'].items():assert sha(Path(run['directory'])/name)==digest
   assert load(Path(run['directory'])/'lifecycle.json')==dict(callbacks=1,weak_teardown_passed=True,javascript_executed_by_openui=False)
  total=totals.setdefault(mode,dict(images=0,exact_images=0,bounds=0,exact_bounds=0))
  for stage,data in result['stages'].items():
   native=directory/f'native-{mode}-1/{stage}.png';reference=directory/f'chromium-1-{mode}-{stage}-capture-1.png'
   assert load(directory/f'native-{mode}-1/{stage}.json')==data['native_bounds']
   assert data['chromium_bounds']==row['chromium_geometry'][f'{mode}-{stage}'] and len(data['native_bounds'])==48
   assert analyze_image_difference(reference,native)==data['analysis']
   exact=sum(a==b for a,b in zip(data['native_bounds'],data['chromium_bounds']));assert exact==data['exact_bounds']
   total['images']+=1;total['exact_images']+=data['analysis']['mismatched_pixels']==0;total['bounds']+=48;total['exact_bounds']+=exact
 for stage in ['before','after']:
  for mode in ['registered','system']:
   browser=load(directory/f'chromium-1-{mode}-{stage}-metrics.json');native=load(directory/f'native-{mode}-1/{stage}-metrics.json')
   assert len(browser)==len(native)==8
   assert all(v['fontSize']=='16px' and 'Ahem' in v['canvasFont'] for v in browser)
   for left,right in zip(browser,native):
    assert left['name']==right['name']
    for chrome_sample,native_sample in zip(left['advances'],right['samples']):
     assert chrome_sample['text']==native_sample['text']
     if mode=='registered':assert chrome_sample['width']==native_sample['unshaped_width']
   cg={v['name']:v['bounds'] for v in row['chromium_geometry'][f'{mode}-{stage}']};ng={v['name']:v['bounds'] for v in row['native'][mode]['stages'][stage]['native_bounds']}
   observations.append(dict(profile=row['profile'],mode=mode,stage=stage,chromium_word_width=cg['word-0']['width'],native_word_width=ng['word-0']['width'],chromium_first_flex_item_x=cg['item-0-0']['x'],native_first_flex_item_x=ng['item-0-0']['x']))
 for path in directory.rglob('*'):
  if path.is_file():files[str(path.relative_to(OUT))]=sha(path)
assert len(r['cases'])==5 and totals==r['totals']
assert sha('/mnt/d/openui-v02-qualification-d174ea0b/native-strict-intrinsic-ceil-clean-full-v4012/full-matrix/full-summary.json')==r['original_full_summary_sha256']
assert len(r['original_oracle_comparisons'])==4
for i,row in enumerate(r['original_oracle_comparisons']):
 assert sha(row['reference_png'])==row['reference_png_sha256']
 # The first four plan profiles are exactly the original four required profiles.
 actual=OUT/f'profile-{i}/chromium-1-original-capture-1.png';assert sha(actual)==row['actual_png_sha256']
 assert analyze_image_difference(row['reference_png'],actual)==row['analysis']
assert r['original_cached_oracle_matches_fresh']==all(row['analysis']['mismatched_pixels']==0 for row in r['original_oracle_comparisons'])
assert r['observed_exit_code']==int(any(t['exact_images']!=t['images'] or t['exact_bounds']!=t['bounds'] for t in totals.values()) or not r['original_cached_oracle_matches_fresh'])
assert 'failure' not in r and not DEST.exists()
proof=dict(schema_version=1,complete=True,owner_absent=True,source=r['source'],actual_owner_exit_code=r['observed_exit_code'],receipt_sha256=sha(OUT/'receipt.json'),audit_driver_sha256=sha(__file__),fresh_compiler_records=len(r['compiler_artifacts']),compiled_paths_verified=len(r['compiled_artifact_sha256']),all_files_sha256=files,totals=totals,installed_and_loaded_font_bytes_identical=True,chromium_platform_font_origin_verified=True,canvas_advance_probe_qualified=True,original_cached_oracle_matches_fresh=r['original_cached_oracle_matches_fresh'],original_chromium_comparisons=4,native_callback_repeats_and_weak_teardown_verified=True,geometry_observations=observations,root_cause_scope='Installed-font measurement mismatch is reproduced and its layout propagation is measured. Actual Chromium strike flags and the backend mechanism remain uncaptured; no global implementation repair is qualified.',pixel_target='pinned Chromium',pixel_tolerance=0,javascript_executed_by_openui=False,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,retired_for_reexecution_after_source_or_target_mutation=True)
DEST.write_text(json.dumps(proof,sort_keys=True,indent=2)+'\n');print(json.dumps({k:proof[k] for k in ['complete','actual_owner_exit_code','fresh_compiler_records','compiled_paths_verified','totals','original_cached_oracle_matches_fresh','canvas_advance_probe_qualified']}),flush=True)
