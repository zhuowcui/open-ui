import fcntl, hashlib, json, subprocess, sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');OUT=Path('/mnt/d/openui-v02-qualification-d174ea0b/native-font-origin-v4041');AUDIT=Path('/tmp/openui-native-font-origin-audit-v4042.json');DEST=Path('/tmp/openui-native-font-origin-reaped-v4043.json')
load=lambda p:json.loads(Path(p).read_bytes());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=load(OUT/'receipt.json');a=load(AUDIT);assert a['complete'] and a['owner_absent'] and r['all_commands_terminal']
assert int(sys.argv[1])==r['observed_exit_code']==a['actual_owner_exit_code'] and int(sys.argv[2])==0
assert sha(OUT/'receipt.json')==a['receipt_sha256']
assert subprocess.run(['ps','-p',str(r['owner_pid'])],capture_output=True).returncode==1
for name in ['cargo','rustc','rustfmt','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
sys.path.insert(0,'/tmp');from openui_parallel_source_identity_v3060 import identity
assert identity(ROOT)==r['source']==a['source'] and not DEST.exists()
p=dict(schema_version=1,source=r['source'],all_local_commands_terminal=True,owners_absent=True,receipt_sha256=sha(OUT/'receipt.json'),completed_audit_sha256=sha(AUDIT),actual_owner_exit_code=int(sys.argv[1]),actual_audit_exit_code=int(sys.argv[2]),actual_sessions=[dict(session=int(sys.argv[4]),exit_code=int(sys.argv[1]),reaped=True),dict(session=int(sys.argv[3]),exit_code=0,reaped=True)],totals=r['totals'],renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False)
DEST.write_text(json.dumps(p,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(proof=str(DEST),totals=p['totals'])),flush=True)
