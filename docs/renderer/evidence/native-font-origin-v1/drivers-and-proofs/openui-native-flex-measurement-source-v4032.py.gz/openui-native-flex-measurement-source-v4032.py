import base64
import hashlib
import json
import os
import subprocess
from pathlib import Path

ROOT=Path('/home/nero/code/open-ui')
BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b')
OUT=BASE/'native-flex-measurement-source-v4032'
PROJECT=OUT/'project'
old=BASE/'native-strict-intrinsic-ceil-clean-source-v4008/project'
assert not PROJECT.exists()
PROJECT.joinpath('src').mkdir(parents=True)
source=(OUT/'main.rs').read_bytes()
formatted=subprocess.run(['rustfmt','--edition','2021','--config','skip_children=true','--emit','stdout'],input=source,capture_output=True)
assert formatted.returncode==0,formatted.stderr.decode()
(PROJECT/'src/main.rs').write_bytes(formatted.stdout)
for name in ['Cargo.toml','Cargo.lock']:
    text=(old/name).read_text()
    assert text.count('openui-native-font-metrics-consumer')==1
    (PROJECT/name).write_text(text.replace('openui-native-font-metrics-consumer','openui-native-flex-measurement'))
(OUT/'workspace-lock-template.txt').write_bytes((ROOT/'bindings/rust/Cargo.lock').read_bytes())
font=base64.b64encode((ROOT/'bindings/rust/openui-text/fonts/Ahem.ttf').read_bytes()).decode()
families=['Ahem,Droid Sans Fallback,Noto Sans Devanagari,Noto Color Emoji,DejaVu Sans','Ahem']
for stage in ['before','after']:
    fragments=[]
    for i in range(6):
        items=[]
        for j in range(5):
            if j:
                if i%3==0: items.append(' \n'+('\u00a0' if stage=='before' else 'A')+'\n ')
                elif i%3==1: items.append(' \nA\n ')
                else: items.append(f'<span id="gap-{i}-{j}">\u00a0</span>')
            items.append(f'<div class="item" id="item-{i}-{j}">DIV{j+1}</div>')
        fragments.append(f'<div class="flex" id="flex-{i}" style="top:{20+i*55}px;font-family:{families[i//3]}">'+''.join(items)+'</div>')
    for i in range(2):
        fragments.append(f'<div id="host-{i}" style="position:absolute;left:{20+i*180}px;top:420px;width:75px;font-family:Ahem;font-kerning:{"none" if i==0 else "auto"}"><span id="word-{i}" style="display:inline-block">ABCDEFGHI</span></div>')
    html=f'''<!doctype html><meta charset="utf-8"><style>@font-face{{font-family:Ahem;src:url(data:font/ttf;base64,{font})}}body{{margin:0;padding:0;background:white;font:16px/16px Ahem;font-kerning:none;font-variant-ligatures:none}}.flex{{position:absolute;left:20px;width:300px;height:40px;background:green;display:flex;justify-content:flex-end}}.item{{width:50px;height:30px;background:rgb(242,210,80);color:rgb(41,119,248)}}</style>'''+''.join(fragments)
    (OUT/f'oracle-{stage}.html').write_text(html)
import sys
sys.path.insert(0,'/tmp')
from openui_parallel_source_identity_v3060 import identity
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
plan=dict(schema_version=1,source=identity(ROOT),stages=['before','after'],required_profiles=[dict(width=800,height=600,scale=1.0),dict(width=375,height=667,scale=2.0),dict(width=1280,height=720,scale=1.25),dict(width=1920,height=1080,scale=1.5),dict(width=800,height=600,scale=3.0)],consumer_source_sha256=sha(PROJECT/'src/main.rs'),consumer_manifest_sha256=sha(PROJECT/'Cargo.toml'),consumer_lock_sha256=sha(PROJECT/'Cargo.lock'),workspace_lock_template_sha256=sha(OUT/'workspace-lock-template.txt'),reference_html_sha256={stage:sha(OUT/f'oracle-{stage}.html') for stage in ['before','after']},fonts_sha256={name:sha(ROOT/'bindings/rust/openui-text/fonts'/name) for name in ['Ahem.ttf','DejaVuSans.ttf']},native_node_count=48,pixel_target='pinned Chromium',javascript_executed_by_openui=False,reference_script_queries_only_inside_chromium=True,not_compiled=True)
assert plan['source']['clean']
assert not (OUT/'plan.json').exists()
(OUT/'plan.json').write_text(json.dumps(plan,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(source=plan['source'],native_nodes=48,source_prepared=True)),flush=True)
