import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b');OLD=BASE/'native-flex-measurement-source-v4032';OUT=BASE/'native-font-origin-source-v4040';PROJECT=OUT/'project'
assert not OUT.exists();PROJECT.joinpath('src').mkdir(parents=True)
proof=json.loads(Path('/tmp/openui-native-flex-measurement-reaped-v4035.json').read_bytes());assert proof['all_local_commands_terminal'] and proof['owners_absent']
source=(OLD/'project/src/main.rs').read_text();needle='    let fonts = FontCollection::deterministic_test();';assert source.count(needle)==1
source=source.replace(needle,'    let font_mode = args.next().ok_or("font mode")?;\n    let fonts = match font_mode.as_str() {\n        "registered" => FontCollection::deterministic_test(),\n        "system" => FontCollection::system(),\n        _ => return Err("unknown font mode".into()),\n    };')
formatted=subprocess.run(['rustfmt','--edition','2021','--config','skip_children=true','--emit','stdout'],input=source.encode(),capture_output=True);assert formatted.returncode==0,formatted.stderr.decode();(PROJECT/'src/main.rs').write_bytes(formatted.stdout)
for name in ['Cargo.toml','Cargo.lock']:shutil.copyfile(OLD/'project'/name,PROJECT/name)
shutil.copyfile(OLD/'workspace-lock-template.txt',OUT/'workspace-lock-template.txt')
for stage in ['before','after']:
    html=(OLD/f'oracle-{stage}.html').read_text()
    (OUT/f'oracle-registered-{stage}.html').write_text(html)
    start=html.index('@font-face{');end=html.index('}body{',start)+1
    system=html[:start]+html[end:]
    assert '@font-face' not in system and html.count('@font-face')==1
    (OUT/f'oracle-system-{stage}.html').write_text(system)
sys.path[:0]=[str(ROOT),'/tmp']
from openui_parallel_source_identity_v3060 import identity
from tools.accountability import run_all_pixel_comparisons as capture
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
templates=ROOT/'tools/accountability/data/wpt_ported/all_wpt_templates.json';test_id='wpt/css_flexbox/css-box-justify-content'
html=capture.build_html_document(json.loads(templates.read_bytes())[test_id]);(OUT/'oracle-original.html').write_text(html)
installed=Path('/home/nero/.local/share/fonts/Ahem.ttf');font=ROOT/'bindings/rust/openui-text/fonts/Ahem.ttf';assert sha(installed)==sha(font)
plan=json.loads((OLD/'plan.json').read_bytes());plan.update(source=identity(ROOT),native_modes=['registered','system'],stages=['registered-before','registered-after','system-before','system-after','original'],native_stages=['before','after'],reference_html_sha256={stage:sha(OUT/f'oracle-{stage}.html') for stage in ['registered-before','registered-after','system-before','system-after','original']},consumer_source_sha256=sha(PROJECT/'src/main.rs'),consumer_manifest_sha256=sha(PROJECT/'Cargo.toml'),consumer_lock_sha256=sha(PROJECT/'Cargo.lock'),installed_font_path=str(installed),installed_font_sha256=sha(installed),registered_and_installed_ahem_bytes_identical=True,original_test_id=test_id,original_templates_sha256=sha(templates),prior_reaping_sha256=sha('/tmp/openui-native-flex-measurement-reaped-v4035.json'))
assert plan['source']['clean'];(OUT/'plan.json').write_text(json.dumps(plan,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(prepared=True,modes=plan['native_modes'],ahem_same_bytes=True,source=plan['source'])),flush=True)
