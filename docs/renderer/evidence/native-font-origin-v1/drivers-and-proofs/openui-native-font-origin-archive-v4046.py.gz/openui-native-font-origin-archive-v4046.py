import fcntl,gzip,hashlib,json,shutil,subprocess,sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');BASE=Path('/mnt/d/openui-v02-qualification-d174ea0b')
DEST=ROOT/'docs/renderer/evidence/native-font-origin-v1';INDEX=ROOT/'docs/renderer/generated/native-font-origin-v1.json'
load=lambda p:json.loads(Path(p).read_bytes())
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as stream:
  for block in iter(lambda:stream.read(2**20),b''):h.update(block)
 return h.hexdigest()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
r=load(BASE/'native-font-origin-v4041/receipt.json');a=load('/tmp/openui-native-font-origin-audit-v4042.json');proof=load('/tmp/openui-native-font-origin-reaped-v4043.json');first=load(BASE/'native-flex-measurement-v4033/receipt.json');first_audit=load('/tmp/openui-native-flex-measurement-audit-v4034.json');first_proof=load('/tmp/openui-native-flex-measurement-reaped-v4035.json')
assert r['all_commands_terminal'] and a['complete'] and proof['all_local_commands_terminal'] and proof['owners_absent']
assert first['all_commands_terminal'] and first_audit['complete'] and first_proof['all_local_commands_terminal'] and first_proof['owners_absent']
assert sha(BASE/'native-font-origin-v4041/receipt.json')==a['receipt_sha256']==proof['receipt_sha256']
assert sha(BASE/'native-flex-measurement-v4033/receipt.json')==first_audit['receipt_sha256']==first_proof['receipt_sha256']
assert r['source']==first['source'] and r['source']['clean']
for report in [r,first]:assert subprocess.run(['ps','-p',str(report['owner_pid'])],capture_output=True).returncode==1
for name in ['cargo','rustc','rustfmt','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
for path,digest in r['input_sha256'].items():assert sha(path)==digest
for path,digest in a['all_files_sha256'].items():assert sha(BASE/'native-font-origin-v4041'/path)==digest
for path,digest in first_audit['all_files_sha256'].items():assert sha(BASE/'native-flex-measurement-v4033'/path)==digest
prior_path=ROOT/'docs/renderer/generated/native-strict-intrinsic-ceil-v2.json';prior=load(prior_path);prior_sha=sha(prior_path)
for member in prior['archive']['members']:assert sha(ROOT/member['path'])==member['sha256']
assert not INDEX.exists() and not DEST.exists() and shutil.disk_usage(ROOT).free>128*2**20
current_binary=BASE/'native-font-origin-v4041/native-consumer';assert not current_binary.exists();assert sha(r['binary'])==r['binary_sha256'];shutil.copyfile(r['binary'],current_binary);assert sha(current_binary)==r['binary_sha256']
DEST.mkdir();members=[]
def add(path,label):
 raw=Path(path).read_bytes();data=gzip.compress(raw,compresslevel=9,mtime=0);out=DEST/(label+'.gz');assert not out.exists();out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data);assert gzip.decompress(out.read_bytes())==raw
 members.append(dict(path=str(out.relative_to(ROOT)),compression='gzip',bytes=len(data),sha256=sha(out),raw_bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest()))
for directory,label in [('native-flex-measurement-source-v4032','first-consumer-source'),('native-flex-measurement-v4033','first-measurement'),('native-font-origin-source-v4040','origin-consumer-source'),('native-font-origin-v4041','origin-measurement'),('native-font-origin-hosted-v4045','hosted')]:
 for path in sorted((BASE/directory).rglob('*')):
  if path.is_file() and path!=current_binary:add(path,label+'/'+str(path.relative_to(BASE/directory)))
for row in r['original_oracle_comparisons']:add(row['reference_png'],'original-cached-chromium/'+row['profile']+'.png')
for path in ['openui-native-flex-measurement-source-v4032.py','openui-native-flex-measurement-v4033.py','openui-native-flex-measurement-audit-v4034.py','openui-native-flex-measurement-audit-v4034.json','openui-native-flex-measurement-reaping-v4035.py','openui-native-flex-measurement-reaped-v4035.json','openui-native-font-origin-source-v4040.py','openui-native-font-origin-v4041.py','openui-native-font-origin-audit-v4042.py','openui-native-font-origin-audit-v4042.json','openui-native-font-origin-reaping-v4043.py','openui-native-font-origin-reaped-v4043.json','openui-native-font-origin-hosted-v4045.py']:add('/tmp/'+path,'drivers-and-proofs/'+path)
for directory,relative in [('chromium-font-source-v3854','third_party/blink/renderer/platform/fonts/font_platform_data.cc'),('chromium-font-source-v3855','third_party/blink/renderer/platform/fonts/web_font_render_style.cc')]:add(BASE/directory/relative,'primary-source/'+relative);add(BASE/directory/'receipt.json','primary-source/'+directory+'-receipt.json')
for path in ['bindings/rust/openui-layout/src/intrinsic_sizing.rs','bindings/rust/openui-layout/src/flex/algorithm.rs','bindings/rust/openui-text/src/font/font.rs','bindings/rust/openui-text/src/font/collection.rs','bindings/rust/openui-text/src/font/platform.rs']:add(ROOT/path,'native-source/'+path)
add(__file__,'drivers-and-proofs/'+Path(__file__).name)
assert sha(prior_path)==prior_sha
result=dict(schema_version=1,measured_source=r['source'],pixel_target='pinned Chromium',pixel_tolerance=0,javascript_executed_by_openui=False,scripts_run_only_in_separate_chromium_reference_process=True,historical_openui_archive_is_a_pixel_target=False,previous_immutable_evidence=dict(path=str(prior_path.relative_to(ROOT)),sha256=prior_sha,unchanged=True),native_consumer=dict(path='bindings/rust/openui/examples/native_font_origin.rs',sha256=r['input_sha256'][str(BASE/'native-font-origin-source-v4040/project/src/main.rs')],callback_count_per_run=1,weak_teardown_and_process_and_frame_repeats_passed=True),first_diagnostic=dict(totals=first['totals'],audit=first_audit,canvas_probe_qualified=False),font_origin_comparison=dict(totals=r['totals'],audit=a,original_cached_oracle_matches_fresh=r['original_cached_oracle_matches_fresh'],original_reference_comparisons=r['original_oracle_comparisons'],scope='Installed and loaded Ahem have the same byte hash. Chromium platform-font APIs distinguish the paths, and repeated widths and positions differ. Native currently retains loaded-font-sized unshaped advances for both. Backend and strike mechanism remain unverified.'),hosted=load(BASE/'native-font-origin-hosted-v4045/receipt.json'),original_renderer_gate=dict(measured_source=prior['measured_source'],results=prior['renderer_clean']['results'],candidate_disposition=prior['candidate_disposition'],required_native_api_qualification=False),all_measurement_commands_terminal=True,all_archive_hashes_verified=True,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,pending=['Fix installed-font advances and preserve loaded-font fractions through shared native rendering data flow.','Verify actual backend/strike parameters and loaded-font raster differences.','Repair 21 full-census exact regressions; every needed native API, reviewed residual ownership, compositor/3D and physical release gates remain open.'],archive=dict(files=len(members),bytes=sum(v['bytes'] for v in members),members=members,excluded=[dict(path=str(current_binary),sha256=r['binary_sha256'],reason='Current owned executable retained outside Git.'),dict(path=first['binary'],sha256=first['binary_sha256'],reason='Earlier diagnostic executable was replaced in the shared target only after its audit and reaping proof; its measurement-time compiler identity and complete source/lock remain preserved. No current binary claim is made for it.')]))
INDEX.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(index=str(INDEX),members=len(members),stored_bytes=result['archive']['bytes'],original_oracles_match=True,runtime_fix_qualified=False)),flush=True)
