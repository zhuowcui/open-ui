import fcntl, hashlib, json, subprocess, sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');OUT=Path('/mnt/d/openui-v02-qualification-d174ea0b/native-flex-measurement-v4033');DEST=Path('/tmp/openui-native-flex-measurement-audit-v4034.json')
sys.path[:0]=[str(ROOT/'tools/qualification'),'/tmp']
from openui_parallel_source_identity_v3060 import identity
from residuals import analyze_image_difference
load=lambda p:json.loads(Path(p).read_bytes())
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as stream:
  for block in iter(lambda:stream.read(2**20),b''):h.update(block)
 return h.hexdigest()
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
r=load(OUT/'receipt.json');assert r['all_commands_terminal'] and r['observed_exit_code']==int(sys.argv[1])
assert subprocess.run(['ps','-p',str(r['owner_pid'])],capture_output=True).returncode==1
for name in ['cargo','rustc','rustfmt','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
assert identity(ROOT)==r['source']==r['source_after'] and r['source_unchanged'] and r['inputs_unchanged']
assert sha('/tmp/openui-native-flex-measurement-v4033.py')==r['driver_sha256']
for path,digest in r['input_sha256'].items():assert sha(path)==digest
assert sha(r['binary'])==r['binary_sha256']
for path,digest in r['compiled_artifact_sha256'].items():assert sha(path)==digest
for row in r['compiler_artifacts']:assert row['fresh'] is False and row['reason']=='compiler-artifact'
for row in r['steps']:
 assert subprocess.run(['ps','-p',str(row['pid'])],capture_output=True).returncode==1
 if 'log_sha256' in row:assert sha(OUT/(row['name']+'.log'))==row['log_sha256'] and row['actual_exit_code']==0
images=bounds=exact_images=exact_bounds=0;files={}
for i,row in enumerate(r['cases']):
 directory=OUT/f'profile-{i}'
 assert row['chromium_process_repeats_equal'] and row['native_runs'][0]['files']==row['native_runs'][1]['files']
 for repeat in [1,2]:
  run=row['native_runs'][repeat-1]
  for name,digest in run['files'].items():assert sha(Path(run['directory'])/name)==digest
  assert load(Path(run['directory'])/'lifecycle.json')==dict(callbacks=1,weak_teardown_passed=True,javascript_executed_by_openui=False)
 for stage,result in row['stages'].items():
  native=directory/f'native-1/{stage}.png';reference=directory/f'chromium-1-{stage}-capture-1.png'
  for repeat in [1,2]:
   assert load(directory/f'chromium-{repeat}-{stage}.json')==result['chromium_bounds']
   assert load(directory/f'chromium-{repeat}-{stage}-metrics.json')==load(directory/f'chromium-1-{stage}-metrics.json')
   for capture in [1,2]:assert sha(directory/f'chromium-{repeat}-{stage}-capture-{capture}.png')==sha(reference)
  assert load(directory/f'native-1/{stage}.json')==result['native_bounds']
  assert analyze_image_difference(reference,native)==result['analysis']
  assert len(result['native_bounds'])==len(result['chromium_bounds'])==48
  exact=sum(a==b for a,b in zip(result['native_bounds'],result['chromium_bounds']));assert exact==result['exact_bounds']
  images+=1;bounds+=48;exact_images+=result['analysis']['mismatched_pixels']==0;exact_bounds+=exact
 for path in directory.rglob('*'):
  if path.is_file():files[str(path.relative_to(OUT))]=sha(path)
assert len(r['cases'])==5 and r['totals']==dict(images=images,exact_images=exact_images,bounds=bounds,exact_bounds=exact_bounds)
assert r['observed_exit_code']==int(exact_images!=images or exact_bounds!=bounds)
assert 'failure' not in r and not DEST.exists()
proof=dict(schema_version=1,complete=True,source=r['source'],owner_absent=True,actual_owner_exit_code=r['observed_exit_code'],receipt_sha256=sha(OUT/'receipt.json'),audit_driver_sha256=sha(__file__),driver_sha256=r['driver_sha256'],compiled_paths_verified=len(r['compiled_artifact_sha256']),fresh_compiler_records=len(r['compiler_artifacts']),all_files_sha256=files,totals=r['totals'],geometry_exact=exact_bounds==bounds,independent_process_and_unchanged_frame_repeats_verified=True,native_callback_and_weak_teardown_verified=True,pixel_target='pinned Chromium',pixel_tolerance=0,javascript_executed_by_openui=False,canvas_advance_probe_qualified=False,canvas_probe_limitation='Computed CSS font shorthand was empty with these variant settings; canvas fell back to its default font. Those canvas values are not used as measurement evidence. Element/Range bounds and rendered screenshots remain valid.',root_cause_reviewed=False,renderer_qualified=False,all_native_apis_qualified=False,release_qualified=False,retired_for_reexecution_after_source_or_target_mutation=True)
DEST.write_text(json.dumps(proof,sort_keys=True,indent=2)+'\n');print(json.dumps({k:proof[k] for k in ['complete','actual_owner_exit_code','fresh_compiler_records','compiled_paths_verified','totals','canvas_advance_probe_qualified']}),flush=True)
