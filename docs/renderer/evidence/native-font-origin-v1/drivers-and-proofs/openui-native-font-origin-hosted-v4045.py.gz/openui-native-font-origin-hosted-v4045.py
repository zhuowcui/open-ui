import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/home/nero/code/open-ui')
OUT = Path('/mnt/d/openui-v02-qualification-d174ea0b/native-font-origin-hosted-v4045')
HEAD = '031799565e6ebc11c7271012120376f6dcd1709f'
assert not OUT.exists()
OUT.mkdir()
def read(command, label):
    child = subprocess.run(command, capture_output=True, timeout=45)
    assert child.returncode == 0, child.stderr.decode()
    (OUT / label).write_bytes(child.stdout)
    return json.loads(child.stdout)
pr = read(['gh', 'pr', 'view', '3', '--json', 'number,state,isDraft,headRefOid,body,url'], 'pr.json')
assert pr['headRefOid'] == HEAD and pr['state'] == 'OPEN' and pr['isDraft']
body = Path('/tmp/openui-native-strict-intrinsic-ceil-clean-pr-body-v4026.md').read_text()
assert pr['body'] == body
rows = read(['gh', 'run', 'list', '--branch', 'agent/v02-final-closure', '--commit', HEAD, '--limit', '30', '--json', 'databaseId,workflowName,event,status,conclusion,headSha,url'], 'runs.json')
selected = []
for name, count in [('Format Check', 2), ('CI', 3), ('v0.2 Hardening', 7)]:
    candidates = [row for row in rows if row['workflowName'] == name and (name != 'v0.2 Hardening' or row['event'] == 'workflow_dispatch')]
    assert candidates, name
    row = max(candidates, key=lambda item: item['databaseId'])
    rid = row['databaseId']
    jobs = read(['gh', 'api', f'repos/zhuowcui/open-ui/actions/runs/{rid}/jobs?per_page=100'], str(rid) + '-jobs.json')['jobs']
    assert row['headSha'] == HEAD and len(jobs) == count
    run = read(['gh', 'api', f'repos/zhuowcui/open-ui/actions/runs/{rid}'], str(rid) + '-run.json')
    assert run['head_sha'] == HEAD
    selected.append(dict(workflow=name, run_id=rid, url=row['url'], status=run['status'], conclusion=run['conclusion'], jobs=[{k: job[k] for k in ['id', 'name', 'status', 'conclusion']} for job in jobs]))
jobs = [job for row in selected for job in row['jobs']]
assert len(jobs) == 12
receipt = dict(schema_version=1, source_commit=HEAD, pr_open_draft=True, pr_body_exact=True, pr_body_sha256=hashlib.sha256(body.encode()).hexdigest(), runs=selected, total_jobs=12, success=sum(job['conclusion'] == 'success' for job in jobs), failed=sum(job['conclusion'] in ['failure', 'cancelled', 'timed_out', 'action_required'] for job in jobs), skipped=sum(job['conclusion'] == 'skipped' for job in jobs), pending=sum(job['status'] != 'completed' for job in jobs), all_jobs_success=all(job['conclusion'] == 'success' for job in jobs), all_commands_terminal=True, renderer_qualified=False, all_native_apis_qualified=False, physical_lab_qualified=False, release_qualified=False)
(OUT / 'receipt.json').write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
