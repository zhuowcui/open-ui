"""Retry automatic vertical width with an actual aspect-ratio check."""
import fcntl,json,os,shutil,subprocess
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');OLD=Path('/dev/shm/openui-native-intrinsic-api-fix-v2054');ROOT=Path('/dev/shm/openui-native-intrinsic-api-fix-v2058')
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','ninja','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
assert not ROOT.exists() and not subprocess.check_output(['git','status','--porcelain'],cwd=OLD)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=OLD,text=True).strip();assert head=='a423e9ba198701e5205a83207ebc501e97a208ec'
subprocess.run(['git','worktree','add','--no-checkout','--detach',str(ROOT),head],cwd=MAIN,check=True,capture_output=True)
for encoded in subprocess.check_output(['git','ls-tree','-r','--name-only','-z',head],cwd=MAIN).split(b'\0'):
 if not encoded:continue
 name=encoded.decode();a,b=OLD/name,ROOT/name;b.parent.mkdir(parents=True,exist_ok=True)
 if a.is_symlink():b.symlink_to(os.readlink(a))
 else:os.link(a,b)
subprocess.run(['git','read-tree',head],cwd=ROOT,check=True,capture_output=True)
p=ROOT/'bindings/rust/openui-layout/src/out_of_flow.rs';s=p.read_text();old='        && !width_from_ar;';assert s.count(old)==1
s=s.replace(old,'''        // width_from_ar also marks auto widths eligible for constraint transfer;
        // only a present ratio makes this width depend on that transfer.
        && effective_aspect_ratio.is_none();''',1)
t=p.with_name(p.name+'.isolated-v2058');t.write_text(s);os.replace(t,p)
subprocess.run(['bash','-c','ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true bindings/rust/openui-layout/src/out_of_flow.rs'],cwd=ROOT,check=True)
subprocess.run(['git','add','bindings/rust/openui-layout/src/out_of_flow.rs'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','Let vertical auto widths use actual column extent without an aspect ratio'],cwd=ROOT,check=True,capture_output=True)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=OLD)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
app=Path('/dev/shm/openui-native-intrinsic-api-v2059');oldapp=Path('/dev/shm/openui-native-intrinsic-api-v2055');assert not app.exists();app.mkdir();(app/'src').mkdir()
(app/'Cargo.toml').write_text((oldapp/'Cargo.toml').read_text().replace(str(OLD),str(ROOT)))
for name in ['Cargo.lock','.gitignore','src/main.rs']:shutil.copy2(oldapp/name,app/name)
subprocess.run(['git','init','-q'],cwd=app,check=True)
for key in ['user.name','user.email']:
 value=subprocess.check_output(['git','config','--get',key],cwd=MAIN,text=True).strip();subprocess.run(['git','config','--local',key,value],cwd=app,check=True)
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
s=Path('/tmp/openui-native-intrinsic-api-pipeline-v2056.py').read_text().replace(str(OLD),str(ROOT)).replace(str(oldapp),str(app)).replace('native-intrinsic-api-pipeline-v2056','native-intrinsic-api-pipeline-v2060').replace(head,source)
probe=Path('/tmp/openui-native-intrinsic-api-pipeline-v2060.py');assert not probe.exists();probe.write_text(s)
print(json.dumps(dict(root=str(ROOT),source=source,failed_trial_preserved=True,production_applied=False,release_qualification=False)))
