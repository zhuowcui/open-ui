"""Stage the owner's unchanged pixel executable on the local Linux filesystem."""
import fcntl,hashlib,json,os,shutil,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';p=RAW/'native-intrinsic-verification-pipeline-v2097/receipt.json';owner=json.loads(p.read_text());assert not owner['all_commands_terminal'];os.kill(owner['owner_pid'],0)
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+')
try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
except BlockingIOError:pass
else:raise AssertionError('live owner must retain whole-pipeline lock')
ROOT=Path('/dev/shm/openui-native-intrinsic-api-fix-v2095');sys.path.insert(0,str(ROOT/'tools/qualification'));from renderer_source_identity import repository_source_identity
source=repository_source_identity(ROOT);assert source==owner['source']
local=MAIN/'out/renderer-evidence/native-pixel-binary-stage-v2104';assert not local.exists();local.mkdir()
path=p.parent/'pixel_compare';target=local/'pixel_compare';assert not target.exists()
assert shutil.disk_usage(MAIN).free>800*2**20
staged=False
if not path.exists() and not path.is_symlink():path.symlink_to(target);staged=True
assert repository_source_identity(ROOT)==source
receipt=dict(schema_version=1,owner_pid=owner['owner_pid'],owner_retains_whole_pipeline_lock=True,source=source,output_path=str(path),target_path=str(target),output_symlink_staged_before_build=staged,existing_or_running_binary_modified=False,renderer_or_reference_bytes_modified=False,cargo_or_native_queries_started=0,release_qualification=False,qualification_still_requires_owner_hash_and_actual_source_identity=True,probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
Path('/tmp/openui-native-pixel-binary-staging-v2104.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n');print(json.dumps(receipt))
