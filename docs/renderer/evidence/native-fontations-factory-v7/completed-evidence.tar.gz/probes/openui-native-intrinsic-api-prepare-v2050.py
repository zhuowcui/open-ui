"""Create a native consuming app that measures intrinsic keyword operations."""
import fcntl
import json
import shutil
import subprocess
from pathlib import Path

MAIN = Path('/home/nero/code/open-ui')
SDK = Path('/dev/shm/openui-native-caption-v2034')
ROOT = Path('/dev/shm/openui-native-intrinsic-api-v2050')
lock = open('/tmp/openui-native-cargo-raster-owner.lock', 'a+')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
for name in ['cargo', 'rustc', 'ninja', 'pixel_compare']:
    assert subprocess.run(['pgrep', '-x', name], capture_output=True).returncode == 1
assert not ROOT.exists()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=SDK)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SDK, text=True).strip() == 'c83d24f3cb76ac2f77346a88f73e53860f7f13b3'
ROOT.mkdir()
(ROOT / 'src').mkdir()
old = Path('/dev/shm/openui-native-intrinsic-trace-v2021')
manifest = (old / 'Cargo.toml').read_text().replace('openui-native-intrinsic-trace', 'openui-native-intrinsic-api').replace('/dev/shm/openui-native-rgba-font-v1989', str(SDK))
(ROOT / 'Cargo.toml').write_text(manifest)
shutil.copy2(old / 'Cargo.lock', ROOT / 'Cargo.lock')
(ROOT / '.gitignore').write_text('/target/\n')
shutil.copy2(Path('/tmp/openui-native-intrinsic-api-source-v2050.rs'), ROOT / 'src/main.rs')
subprocess.run(['git', 'init', '-q'], cwd=ROOT, check=True)
for key in ['user.name', 'user.email']:
    value = subprocess.check_output(['git', 'config', '--get', key], cwd=MAIN, text=True).strip()
    subprocess.run(['git', 'config', '--local', key, value], cwd=ROOT, check=True)
print(json.dumps(dict(root=str(ROOT), sdk=str(SDK), production_changes=0)))
