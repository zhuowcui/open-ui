"""Observe exact fractional line-height bounds in pinned Chromium twice."""
import fcntl,hashlib,json,subprocess,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');SDK=Path('/dev/shm/openui-native-intrinsic-api-fix-v2058');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';NAME='native-line-height-chromium-v2074';OUT=RAW/NAME;STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/NAME
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','ninja','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
sys.path.insert(0,str(SDK/'tools/qualification'));from renderer_source_identity import repository_source_identity
sys.path.insert(0,str(SDK/'tools/accountability'));import run_all_pixel_comparisons as capture
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source=repository_source_identity(SDK);assert source['clean'] and source['commit']=='4c2f2e4b715ce5e3df9c15855ead9d2855fd277f'
chrome=MAIN/'chrome/linux-147.0.7727.50/chrome-linux64/chrome';assert sha(chrome)=='0ba87684df0afc11faaea40ac57bd2f1d68b67191443b38215a36b90e6f08848'
report=dict(schema_version=1,source=source,owner_pid=__import__('os').getpid(),all_commands_terminal=False,geometry_only_diagnostic=True,native_pixels_captured=False,release_qualification=False,promotion_allowed=False,javascript_executed_by_openui=False,offline_javascript_executed_only_in_chromium=True,chromium_binary_sha256=sha(chrome),capture_harness_sha256=sha(SDK/'tools/accountability/run_all_pixel_comparisons.py'),capture_process_switches_added=['--disable-dev-shm-usage'],capture_process_environment_is_diagnostic=True,profiles=[],probe_sha256=sha(Path(__file__)))
save=lambda:(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');save()
original_ws=capture._CdpWebSocket
def observe(path,output,expression,width,height,scale):
 observations=[]
 class QueryWebSocket(original_ws):
  def command(self,method,params=None):
   result=super().command(method,params)
   if method=='Runtime.evaluate' and not observations:
    q=super().command('Runtime.evaluate',{'expression':'Promise.resolve('+expression+').then(value => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve(value)))))','awaitPromise':True,'returnByValue':True})
    assert 'exceptionDetails' not in q, q.get('exceptionDetails')
    observations.append(q['result']['value'])
   return result
 capture._CdpWebSocket=QueryWebSocket
 processes=[]; exceptions=[]; stderr_path=output.with_suffix('.stderr.log'); stderr_stream=stderr_path.open('xb'); original_popen=capture.subprocess.Popen
 def launch(command,*args,**kwargs):
  if command and command[0]==str(chrome):
   command=[command[0],'--disable-dev-shm-usage',*command[1:]];kwargs['stderr']=stderr_stream
  process=original_popen(command,*args,**kwargs);processes.append(process);return process
 def trace(frame,event,arg):
  if event=='exception' and frame.f_code.co_filename==str(SDK/'tools/accountability/run_all_pixel_comparisons.py'):
   exceptions.append(dict(function=frame.f_code.co_name,type=arg[0].__name__,message=str(arg[1])))
  return trace
 capture.subprocess.Popen=launch;sys.settrace(trace)
 try:
  ok=capture.render_chrome(str(path),str(output),str(chrome),str(chrome.parent),use_ahem_noaa=True,logical_width=width,logical_height=height,device_scale=scale)
 finally:
  sys.settrace(None);capture._CdpWebSocket=original_ws;capture.subprocess.Popen=original_popen;stderr_stream.close()
  attempt=dict(output=str(output),query_count=len(observations),exceptions=exceptions,process_actual_exits=[p.poll() for p in processes],stderr_sha256=sha(stderr_path));(output.with_suffix('.attempt.json')).write_text(json.dumps(attempt,sort_keys=True,indent=2)+'\n')
  if not observations:print(json.dumps({k:attempt[k] for k in ['output','query_count','process_actual_exits','stderr_sha256']}),flush=True)
 assert ok and len(observations)==1, f'Chromium capture/query failed: capture_ok={ok}, query_count={len(observations)}'
 return observations[0]
try:
 for scale in [1.0,1.25,1.5,2.0,3.0]:
  directory=OUT/str(scale);directory.mkdir();path=directory/'test.html';parts=['<!doctype html><style>*{margin:0;padding:0;box-sizing:content-box}html{overflow:hidden}div{position:absolute;left:0;top:0;font-kerning:none;font-variant-ligatures:none;font-synthesis:none}</style>'];cases=[]
  for family in ['Ahem','DejaVu Sans']:
   for writing in ['horizontal-tb','vertical-lr','vertical-rl']:
    for size,line_height in [(16.0,'1.2'),(16.0,'120%'),(16.0,'19.2px'),(18.72,'1'),(18.72,'1.2'),(18.72,'120%'),(18.72,'18.72px')]:
     axis='width' if writing=='horizontal-tb' else 'height';id='r'+str(len(cases));cases.append(dict(id=id,family=family,writing=writing,size=size,line_height=line_height));parts.append(f'<div id="{id}" style="font-family:&quot;{family}&quot;;font-size:{size}px;writing-mode:{writing};line-height:{line_height};{axis}:100px">Hello</div>')
  assert len(cases)==42;path.write_text(''.join(parts));expression=r'''(() => [...document.querySelectorAll('body>div')].map(n=>{const b=n.getBoundingClientRect();return {id:n.id,x:b.x,y:b.y,width:b.width,height:b.height}}))()'''
  q=[]
  for repeat in [1,2]:
   output=directory/(str(repeat)+'.png');query=observe(path,output,expression,800,600,scale);q.append(query);(directory/(str(repeat)+'-geometry.json')).write_text(json.dumps(query,sort_keys=True,indent=2)+'\n')
  assert q[0]==q[1] and (directory/'1.png').read_bytes()==(directory/'2.png').read_bytes()
  observations=[]
  for case,rect in zip(cases,q[0]):
   assert case['id']==rect['id'];cross=rect['height'] if case['writing']=='horizontal-tb' else rect['width'];observations.append(dict(case=case,bounds=rect,logical_line_height=cross))
   if case['size']==16.0 and case['line_height'] in ['1.2','120%']:assert cross==19.1875
  report['profiles'].append(dict(scale=scale,html_sha256=sha(path),first_png_sha256=sha(directory/'1.png'),second_png_sha256=sha(directory/'2.png'),repeated_png_and_queries_identical=True,observations=observations));save();print(json.dumps(dict(scale=scale,observations=len(observations),relative_16px_line_height=19.1875)),flush=True)
 report.update(observed_exit_code=0,totals=dict(cases=210,repeated_capture_pairs=5,relative_16px_1_2_all_required_scales_exact=True))
except BaseException as error:report.update(observed_exit_code=1,failure=str(error));raise
finally:
 report.update(all_commands_terminal=True,source_after=repository_source_identity(SDK));report['source_unchanged']=report['source_after']==source;assert report['source_unchanged'] and sha(chrome)==report['chromium_binary_sha256'];save()
raise SystemExit(report['observed_exit_code'])
