"""Describe completed native intrinsic work using its actual preserved results."""
import json
import os
from pathlib import Path

MAIN = Path('/home/nero/code/open-ui')
INDEX = MAIN / 'docs/renderer/generated/native-fontations-factory-v7.json'
data = json.loads(INDEX.read_bytes())
assert data['all_commands_terminal'] and not data['release_qualification']
suites = data['suites']
geometry = data['native_geometry']['totals']
audit = json.loads((MAIN / 'out/renderer-evidence/native-viewport-scroll-v1/native-intrinsic-renderer-audit-v2124.json').read_bytes())
assert audit['source'] == data['source']
changed = audit['suites']['full']['changed_comparisons']
worsened = sum(r['mismatched_pixels'] > r['prior_mismatched_pixels'] for r in changed)
font = data['native_font_totals']
assert data['workspace_tests']['passed'] == 8575 and data['workspace_tests']['failed'] == 0
assert data['workspace_tests']['ignored'] == 13 and data['read_only_checks_passed'] == 21
def write_atomic(path, text):
    temporary = path.with_name(path.name + '.native-intrinsic-v7-tmp')
    assert not temporary.exists()
    temporary.write_text(text)
    os.replace(temporary, path)
fmt = lambda n: f'{n:,}'
summary = (
    'The [native intrinsic sizing follow-up]({detail}) at clean private\n'
    '`8f756039` passes **8,575 workspace tests**, zero failed and 13 ignored,\n'
    'all 21 read-only checks, and Rust/C/C++ ABI consumers with 113 exports\n'
    'and 30 layouts. Its consuming Rust app repeats 2,880 callbacks per run\n'
    f'and matches **{fmt(geometry["full_rect_exact"])}/{fmt(geometry["states"])} element bounds**.\n'
    'Twenty vertical text measurements remain different; these geometry\n'
    'results do not prove pixel parity. The new fractional line-height guard\n'
    'also passes against 270 repeated Chromium observations.\n'
    f'Original pixels are **{fmt(suites["full"]["results"]["exact"])}/22,924 exact** and expanded\n'
    f'pixels **{fmt(suites["expanded"]["results"]["exact"])}/23,728 exact**, zero errors, actual exits 1.\n'
    f'The original sweep gains {suites["full"]["exact_gains"]} exact comparisons and loses '
    f'{suites["full"]["exact_losses"]}; the expanded\n'
    f'sweep gains {suites["expanded"]["exact_gains"]} and loses {suites["expanded"]["exact_losses"]}. '
    'All 48,252 Chromium records stay fixed.\n'
    f'{worsened} original comparisons have more wrong pixels than the accepted renderer.\n'
    f'Focused pixels are {suites["focused"]["results"]["exact"]}/640 exact and primitive pixels\n'
    f'{suites["primitive"]["results"]["exact"]}/960 exact.\n'
    'The source remains private and unqualified; the accepted original\n'
    'total stays **21,334/22,924**. Umbrella `376e0ded` has six executed\n'
    'PR jobs passing, five skipped, and all nine native/comparison guards\n'
    'passing. Hosted results belong to that umbrella source. The\n'
    '[v7 evidence]({index}) preserves complete measurements and failed\n'
    'attempts. Open UI never executes JavaScript; needed interaction uses\n'
    'public native Rust APIs and callbacks. v0.2 remains unfinished.\n\n'
)

for filename, detail, index in [
    ('README.md', 'docs/renderer/native-fontations-app.md', 'docs/renderer/generated/native-fontations-factory-v7.json'),
    ('docs/progress/current-status.md', '../renderer/native-fontations-app.md', '../renderer/generated/native-fontations-factory-v7.json'),
    ('docs/v02/release.md', '../renderer/native-fontations-app.md', '../renderer/generated/native-fontations-factory-v7.json'),
]:
    path = MAIN / filename
    text = path.read_text()
    start = text.index('The [caption sizing follow-up](')
    end = text.index('The [shared text measurement trial](', start)
    text = text[:start] + summary.format(detail=detail, index=index) + text[end:]
    write_atomic(path, text)

table = '\n'.join(
    f'| {label} | {fmt(row["results"]["exact"])}/{fmt(row["results"]["total"])} | '
    f'{fmt(row["results"]["different"])} | {row["results"]["errors"]} | {row["actual_exit"]} |'
    for label, row in ((label, suites[name]) for name, label in [
        ('full', 'Original'), ('expanded', 'Expanded'), ('focused', 'Focused'), ('primitive', 'Primitive')])
)
section = f'''## Native intrinsic sizing and fractional line height

Clean private `8f756039` completes its entire verification run. All **8,575
workspace tests pass**, zero failed and 13 ignored, and all **21 read-only
checks pass**. Rust/C/C++ ABI consumers preserve 113 exports and 30 layouts.
Both new public Rust callback guards execute and pass. All stages run under
one exclusive owner; source identities stay clean and unchanged.

The consuming Rust app constructs and changes elements through public methods,
then calls Rust click callbacks, queries owned bounds, and checks teardown.
Both runs perform **2,880 callbacks** and return byte-identical output across
**3,690 cases and 7,380 geometry states**. With viewport overflow explicitly
matched on both sides, **{fmt(geometry['full_rect_exact'])}/7,380 full rectangles** match pinned
Chromium, compared with {fmt(geometry['baseline_full_rect_exact'])}/7,380 on the caption-only source.
There are **{fmt(geometry['full_rect_gains'])} rectangle gains and {geometry['full_rect_losses']} losses**.
These are geometry measurements; native pixels were not captured by this app.

The shared fix maps intrinsic contributions into physical positioned axes,
applies both minimum and maximum bounds, and lets a minimum win a conflict.
Fit-content uses the space left after insets and margins. A vertical box with
automatic width takes its laid-out column extent when insets or an actual
aspect ratio do not fix that width. Unicode soft breaks also apply to ordinary
font families. No fixture, font-name, font-size, backend or test-ID condition
is added by these changes.

Twenty states remain different: `in the box` in DejaVu Sans at 18.72px, in both
vertical directions, across five scales. The native natural inline size is
93px versus Chromium's 92px; its minimum is 33px versus 32px. Shared intrinsic
text advance and strike selection owns the investigation. Its precise cause
is not yet reviewed; the failed states remain open.

The fractional line-height fix follows the pinned Chromium conversion and
fixed-point calculations. At 16px, unitless `1.2` uses **19.1875px**, while
`120%` and a fixed `19.2px` use **19.203125px**. Authored percentages first
become fixed lengths at computed font size, including Chromium's integral
percentage conversion. The native guards cover both font families, three
writing modes and five scales against **270 repeated Chromium observations**.
They also check callback mutations, owned snapshots and weak-handle teardown.
The older approximate line-height assertion is replaced with Chromium's exact
value. Earlier failed guards and captures remain preserved.

| Suite | Exact | Different | Errors | Actual exit |
|---|---:|---:|---:|---:|
{table}

The original census changes **{len(changed)} rows**, gains **{suites['full']['exact_gains']} exact comparisons**
and loses **{suites['full']['exact_losses']}**. The expanded census gains **{suites['expanded']['exact_gains']}** and loses
**{suites['expanded']['exact_losses']}**. All **48,252 Chromium image and oracle records stay fixed**.
The exact focused and primitive gates retain their own actual results above.
**{worsened} original comparisons have more wrong pixels** than the accepted
renderer; improved native geometry does not waive these failures.
Full parity and reviewed ownership of every residual are still required.

An earlier full sweep stopped at the disk-space guard after three profiles;
its partial results are not qualifying. The retry uses a fresh checkout, app,
probe and result directory. Moving the cache preserved all 66,093 files and
their original paths byte for byte. The slow serial transfer was stopped
before it changed the original cache, and its partial copy is preserved.

The [v7 evidence](generated/native-fontations-factory-v7.json) preserves the
complete census summaries, native apps and callbacks, fresh diagnostic
Chromium observations, all failed measured attempts, source checks and image
regions. Every archive member is hash-verified. An independent Git index
reconstructs all four measured failed and final source trees exactly from
public `9f0d2211` and their preserved patches. No oracle is rewritten and no
release state is admitted.

This source remains **private, unapplied and unqualified**. The accepted
original result stays **21,334/22,924 exact**. Hosted umbrella `376e0ded`
passes six executed jobs, with five skips, and all nine native/comparison
guards execute and pass. Those results do not qualify private `8f756039`;
skipped jobs are not release passes.

'''
path = MAIN / 'docs/renderer/native-fontations-app.md'
text = path.read_text()
assert '## Native intrinsic sizing and fractional line height' not in text
marker = '## Caption sizing follow-up\n'
assert text.count(marker) == 1
write_atomic(path, text.replace(marker, section + '## Earlier caption sizing follow-up (`c83d24f3`)\n', 1))
print('Updated four existing documents from completed v7 evidence.')
