"""Prepare a fresh clean checkout and complete owner after the disk-guard stop."""
import fcntl
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

MAIN = Path('/home/nero/code/open-ui')
RAW = MAIN / 'out/renderer-evidence/native-viewport-scroll-v1'
OLD = Path('/dev/shm/openui-native-intrinsic-api-fix-v2095')
ROOT = Path('/dev/shm/openui-native-intrinsic-api-retry-v2118')
OLD_APP = Path('/dev/shm/openui-native-intrinsic-matched-v2096')
APP = MAIN / 'out/private-native-apps/native-intrinsic-matched-v2119'
lock = open('/tmp/openui-native-cargo-raster-owner.lock', 'a+')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
for name in ['cargo', 'rustc', 'ninja', 'pixel_compare', 'chrome']:
    assert subprocess.run(['pgrep', '-x', name], capture_output=True).returncode == 1
owner = json.loads((RAW / 'native-intrinsic-verification-pipeline-v2097/receipt.json').read_bytes())
assert owner['all_commands_terminal'] and owner['source_unchanged']
relocation = json.loads(Path('/tmp/openui-pinned-oracle-cache-relocation-v2131.json').read_bytes())
assert relocation['all_files_byte_identical'] and relocation['reference_images_rewritten'] == 0
assert shutil.disk_usage(MAIN).free > 900 * 2**20
assert shutil.disk_usage('/dev/shm').free > 2**20
assert not ROOT.exists() and not APP.exists()
sys.path.insert(0, str(OLD / 'tools/qualification'))
from renderer_source_identity import repository_source_identity
source = repository_source_identity(OLD)
assert source == owner['source'] and source['clean']
head = source['commit']
subprocess.run(['git', 'worktree', 'add', '--no-checkout', '--detach', str(ROOT), head],
    cwd=MAIN, check=True, capture_output=True)
for encoded in subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', '-z', head], cwd=MAIN).split(b'\0'):
    if not encoded:
        continue
    name = encoded.decode()
    a, b = OLD / name, ROOT / name
    b.parent.mkdir(parents=True, exist_ok=True)
    if a.is_symlink():
        b.symlink_to(os.readlink(a))
    else:
        os.link(a, b)
subprocess.run(['git', 'read-tree', head], cwd=ROOT, check=True, capture_output=True)
assert repository_source_identity(ROOT) == source
APP.mkdir(parents=True)
(APP / 'src').mkdir()
(APP / 'Cargo.toml').write_text((OLD_APP / 'Cargo.toml').read_text().replace(str(OLD), str(ROOT)))
for name in ['Cargo.lock', '.gitignore', 'src/main.rs']:
    shutil.copy2(OLD_APP / name, APP / name)
subprocess.run(['git', 'init', '-q'], cwd=APP, check=True)
for key in ['user.name', 'user.email']:
    value = subprocess.check_output(['git', 'config', '--get', key], cwd=MAIN, text=True).strip()
    subprocess.run(['git', 'config', '--local', key, value], cwd=APP, check=True)

replacements = {
    str(OLD): str(ROOT), str(OLD_APP): str(APP),
    'native-intrinsic-verification-pipeline-v2097': 'native-intrinsic-verification-pipeline-v2120',
    'native-intrinsic-font-consumer-v2098': 'native-intrinsic-font-consumer-v2121',
    'native-intrinsic-checks-v2099': 'native-intrinsic-checks-v2122',
}
for old, new in [
    ('openui-native-intrinsic-verification-pipeline-v2097.py', 'openui-native-intrinsic-verification-pipeline-v2120.py'),
    ('openui-native-intrinsic-font-consumer-v2098.py', 'openui-native-intrinsic-font-consumer-v2121.py'),
    ('openui-native-intrinsic-checks-v2099.py', 'openui-native-intrinsic-checks-v2122.py'),
]:
    text = (Path('/tmp') / old).read_text()
    for a, b in replacements.items():
        text = text.replace(a, b)
    if 'pipeline' in new:
        marker = "pixel=OUT/'pixel_compare';shutil.copy2"
        assert text.count(marker) == 1
        text = text.replace(marker, "local=MAIN/'out/renderer-evidence/native-pixel-binary-stage-v2130';assert not local.exists();local.mkdir();pixel=OUT/'pixel_compare';pixel.symlink_to(local/'pixel_compare');shutil.copy2", 1)
        marker = "for suite in ['full','expanded']:"
        assert text.count(marker) == 1
        text = text.replace(marker, "assert shutil.disk_usage(MAIN).free>700*2**20\n report['home_free_before_pixel_matrices']=shutil.disk_usage(MAIN).free;report['prior_disk_guard_attempt_preserved']='native-intrinsic-verification-pipeline-v2097';save()\n "+marker, 1)
    path = Path('/tmp') / new
    assert not path.exists()
    compile(text, str(path), 'exec')
    path.write_text(text)
assert repository_source_identity(OLD) == repository_source_identity(ROOT) == source
print(json.dumps(dict(root=str(ROOT), source=source, app=str(APP),
    fresh_checkout=True, framework_code_unchanged=True,
    failed_attempt_preserved=True, production_applied=False,
    release_qualification=False, home_free=shutil.disk_usage(MAIN).free)))
