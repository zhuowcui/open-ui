"""Use measured Chromium line heights and preserve earlier failed sources."""
import fcntl,json,os,shutil,subprocess
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';OLD=Path('/dev/shm/openui-native-intrinsic-api-fix-v2058');ROOT=Path('/dev/shm/openui-native-intrinsic-api-fix-v2080')
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','ninja','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
chrome=json.loads((RAW/'native-line-height-chromium-v2086/receipt.json').read_bytes());assert chrome['all_commands_terminal'] and chrome['observed_exit_code']==0 and chrome['source_unchanged']
expected={(16.0,'1.2'):19.1875,(16.0,'120%'):19.203125,(16.0,'19.2px'):19.203125,(18.72,'1'):18.71875,(18.72,'1.2'):22.453125,(18.72,'120%'):22.46875,(18.72,'18.72px'):18.71875,(16.0,'120.5%'):19.203125,(18.72,'120.5%'):22.46875}
assert sum(len(p['observations']) for p in chrome['profiles'])==270
for profile in chrome['profiles']:
 for row in profile['observations']:assert row['logical_line_height']==expected[(row['case']['size'],row['case']['line_height'])]
assert not ROOT.exists() and not subprocess.check_output(['git','status','--porcelain'],cwd=OLD)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=OLD,text=True).strip();assert head=='4c2f2e4b715ce5e3df9c15855ead9d2855fd277f'
subprocess.run(['git','worktree','add','--no-checkout','--detach',str(ROOT),head],cwd=MAIN,check=True,capture_output=True)
for encoded in subprocess.check_output(['git','ls-tree','-r','--name-only','-z',head],cwd=MAIN).split(b'\0'):
 if not encoded:continue
 name=encoded.decode();a,b=OLD/name,ROOT/name;b.parent.mkdir(parents=True,exist_ok=True)
 if a.is_symlink():b.symlink_to(os.readlink(a))
 else:os.link(a,b)
subprocess.run(['git','read-tree',head],cwd=ROOT,check=True,capture_output=True)
def edit(name,transform):
 p=ROOT/name;t=p.with_name(p.name+'.isolated-v2080');t.write_text(transform(p.read_text()));os.replace(t,p)
def relative(s):
 old='''        LineHeight::Percentage(percent) => {
            openui_geometry::LayoutUnit::from_f32(font_size_fixed * percent / 100.0)
        }''';assert s.count(old)==1
 new='''        LineHeight::Percentage(percent) => {
            // StyleBuilderConverter resolves authored percentages to a fixed
            // length at the computed font size, unlike unitless numbers. Its
            // ClampTo<int> preserves Chromium's integral-percent conversion.
            let computed_px = font_size * (percent as i32) as f32 / 100.0;
            openui_geometry::LayoutUnit::from_f32_round(computed_px)
        }'''
 return s.replace(old,new,1)
def old_guard(s):
 s=s.replace('Issue 1: Half-leading preserves sub-pixel precision (no floor/ceil truncation).','Issue 1: Half-leading preserves the measured 1/64px line-height grid.')
 s=s.replace('''    // computed line-height = 16 * 1.2 = 19.2
    // With sub-pixel precision, leading is not integer-truncated.''','''    // Chromium 147.0.7727.50 measures 19.1875px for the unitless value.
    // Its fixed-point line height is retained through half-leading.''')
 start=s.index('    // Computed line-height = 19.2px.');end=s.index('\n}',start)
 return s[:start]+'''    // Exact Chromium geometry at all five required scales. This rejects
    // both whole-pixel truncation to 19 and the old approximate 20px pass.
    assert_eq!(line_height.to_f32(), 19.1875);
'''+s[end:]
edit('bindings/rust/openui-text/src/font/relative.rs',relative)
edit('bindings/rust/openui-layout/tests/sp11_round16_fix_tests.rs',old_guard)
guard=Path('/tmp/openui-native-fractional-line-height-guard-v2075.rs').read_text().replace('(16.0, LineHeight::Percentage(120.0), 19.1875)','(16.0, LineHeight::Percentage(120.0), 19.203125)').replace('(18.72, LineHeight::Percentage(120.0), 22.453125)','(18.72, LineHeight::Percentage(120.0), 22.46875)')
marker='                    (18.72, LineHeight::Length(18.72), 18.71875),';assert guard.count(marker)==1;guard=guard.replace(marker,marker+'''\n                    (16.0, LineHeight::Percentage(120.5), 19.203125),\n                    (18.72, LineHeight::Percentage(120.5), 22.46875),''',1)
rawguard=Path('/tmp/openui-native-fractional-line-height-guard-v2080.rs');assert not rawguard.exists();rawguard.write_text(guard)
edit('bindings/rust/openui/tests/native_intrinsic_constraints.rs',lambda s:s+guard)
paths=['bindings/rust/openui-text/src/font/relative.rs','bindings/rust/openui-layout/tests/sp11_round16_fix_tests.rs','bindings/rust/openui/tests/native_intrinsic_constraints.rs']
subprocess.run(['bash','-c','ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true '+' '.join(paths)],cwd=ROOT,check=True)
subprocess.run(['git','add',*paths],cwd=ROOT,check=True);subprocess.run(['git','commit','-m','Match measured numeric and percentage line heights and strengthen native callback guards'],cwd=ROOT,check=True,capture_output=True)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=OLD);assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
s=Path('/tmp/openui-native-intrinsic-verification-pipeline-v2064.py').read_text().replace(str(OLD),str(ROOT)).replace('native-intrinsic-verification-pipeline-v2064','native-intrinsic-verification-pipeline-v2083').replace('4c2f2e4b715ce5e3df9c15855ead9d2855fd277f',source).replace('/tmp/openui-native-intrinsic-font-consumer-v2065.py','/tmp/openui-native-intrinsic-font-consumer-v2084.py')
s=s.replace("['test','--offline','--locked','--workspace','--features','openui-ffi/linux']","['test','--offline','--locked','--workspace','--no-fail-fast','--features','openui-ffi/linux']")
s=s.replace("content=(OUT/'workspace.log').read_bytes();assert b'test reference_comparison_rejects_single_bit_rgba_changes ... ok' in content\n assert b'test surface_comparison_preserves_rgba_order_and_straight_alpha ... ok' in content","content=(OUT/'workspace.log').read_bytes();report['strict_guards_observed_in_workspace'] = all(name in content for name in [b'test reference_comparison_rejects_single_bit_rgba_changes ... ok',b'test surface_comparison_preserves_rgba_order_and_straight_alpha ... ok'])")
s=s.replace(" report['native_intrinsic_guard_actually_executed']=True;save()"," assert b'test native_fractional_line_heights_keep_chromium_grid_through_callbacks ... ok' in (OUT/'native-intrinsic-guard.log').read_bytes()\n report['native_fractional_line_height_guard_actually_executed']=True\n report['native_intrinsic_guard_actually_executed']=True;save()")
p=Path('/tmp/openui-native-intrinsic-verification-pipeline-v2083.py');assert not p.exists();p.write_text(s)
s=Path('/tmp/openui-native-intrinsic-font-consumer-v2065.py').read_text().replace(str(OLD),str(ROOT)).replace('native-intrinsic-verification-pipeline-v2064','native-intrinsic-verification-pipeline-v2083').replace('native-intrinsic-font-consumer-v2065','native-intrinsic-font-consumer-v2084');p=Path('/tmp/openui-native-intrinsic-font-consumer-v2084.py');assert not p.exists();p.write_text(s)
s=Path('/tmp/openui-native-intrinsic-checks-v2066.py').read_text().replace(str(OLD),str(ROOT)).replace('native-intrinsic-checks-v2066','native-intrinsic-checks-v2085').replace('bindings/rust/openui-text/src/font/relative.rs bindings/rust/openui/tests/native_intrinsic_constraints.rs','bindings/rust/openui-text/src/font/relative.rs bindings/rust/openui/tests/native_intrinsic_constraints.rs bindings/rust/openui-layout/tests/sp11_round16_fix_tests.rs');p=Path('/tmp/openui-native-intrinsic-checks-v2085.py');assert not p.exists();p.write_text(s)
print(json.dumps(dict(root=str(ROOT),source=source,oracle_geometry_cases=270,failed_sources_preserved=True,production_applied=False,release_qualification=False)),flush=True)
