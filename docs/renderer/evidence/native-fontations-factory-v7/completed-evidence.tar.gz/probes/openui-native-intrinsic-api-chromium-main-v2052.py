try:
 for scale in [1.0,1.25,1.5,2.0,3.0]:
  for kind,width,height in [('original',800,600),('constraints',80,64)]:
   chosen=[r for r in rows if r['scale']==scale and r['kind']==kind]
   assert len(chosen)==(162 if kind=='original' else 576)
   directory=OUT/(kind+'-'+str(scale));directory.mkdir();path=directory/'test.html'
   parts=['<!doctype html><style>*{margin:0;padding:0;box-sizing:content-box}html{overflow:hidden}div{left:0;top:0;font-kerning:none;font-variant-ligatures:none;font-synthesis:none;line-height:1}</style>']
   scenarios={'preferred_min':('min-content','auto','none'),'preferred_max':('max-content','auto','none'),'preferred_fit':('fit-content','auto','none'),'min_then_fixed_max':('120px','min-content','60px'),'fixed_min_then_max':('120px','10px','min-content'),'both_intrinsic':('120px','min-content','max-content'),'min_beats_max':('10px','max-content','min-content'),'maximum_max':('300px','auto','max-content')}
   for i,r in enumerate(chosen):
    family='Ahem, "Droid Sans Fallback", "Noto Sans Devanagari", "Noto Color Emoji", "DejaVu Sans"' if r['family']=='deterministic' else '"DejaVu Sans"'
    size='18.72' if abs(r['size']-18.72)<.001 else str(r['size'])
    styles=[f'font-family:{family}',f'font-size:{size}px',f'writing-mode:{r["writing"]}',f'position:{r.get("position","absolute")}']
    if kind=='constraints':
     axis='width' if r['writing']=='horizontal-tb' else 'height'
     preferred,minimum,maximum=scenarios[r['scenario']]
     styles.extend([f'{axis}:{preferred}',f'min-{axis}:{minimum}',f'max-{axis}:{maximum}'])
     if r['decorated']:styles.append('padding:2px 5px 4px 3px')
     if r['scenario']=='preferred_fit':styles.append('left:3px;right:5px;top:3px;bottom:5px')
    text=r['text'] if kind=='original' else 'non-spanner in caption'
    parts.append(f'<div id="r{i}" data-writing="{r["writing"]}" style="{html.escape(";".join(styles),quote=True)}">{html.escape(text)}</div>')
   path.write_text(''.join(parts))
   if kind=='original':
    expression=r'''(() => {const nodes=[...document.querySelectorAll('body>div')]; const rect=n=>{const b=n.getBoundingClientRect();return {x:b.x,y:b.y,width:b.width,height:b.height}};const natural=nodes.map(rect);nodes.forEach(n=>{n.style[n.dataset.writing==='horizontal-tb'?'width':'height']='min-content'});const result=nodes.map((n,i)=>({id:n.id,natural:natural[i],minimum:rect(n)}));nodes.forEach(n=>{n.style.width='auto';n.style.height='auto'});return result;})()'''
   else:
    expression=r'''(() => {const nodes=[...document.querySelectorAll('body>div')];const rect=n=>{const b=n.getBoundingClientRect();return {x:b.x,y:b.y,width:b.width,height:b.height}};const before=nodes.map(rect);nodes.forEach(n=>{n.textContent='XX'});const result=nodes.map((n,i)=>({id:n.id,before:before[i],after:rect(n)}));nodes.forEach(n=>{n.textContent='non-spanner in caption'});return result;})()'''
   queries=[]
   for repeat in [1,2]:
    picture=directory/(str(repeat)+'.png');q=observe(path,picture,expression,width,height,scale);queries.append(q)
    (directory/(str(repeat)+'-geometry.json')).write_text(json.dumps(q,sort_keys=True,indent=2)+'\n')
   assert queries[0]==queries[1] and (directory/'1.png').read_bytes()==(directory/'2.png').read_bytes()
   observations=[]
   for i,(r,c) in enumerate(zip(chosen,queries[0])):
    assert c['id']=='r'+str(i)
    names=['natural','minimum'] if kind=='original' else ['before','after']
    axis='width' if r['writing']=='horizontal-tb' else 'height'
    observations.append(dict(native_case=r,chromium=c,full_rect_exact={name:r[name]==c[name] for name in names},inline_axis_exact={name:r[name][axis]==c[name][axis] for name in names}))
   row=dict(scale=scale,kind=kind,html_sha256=sha(path),first_png_sha256=sha(directory/'1.png'),second_png_sha256=sha(directory/'2.png'),repeated_png_and_queries_identical=True,observations=observations)
   report['profiles'].append(row);save();print(json.dumps(dict(scale=scale,kind=kind,cases=len(observations),full_rect_exact=sum(sum(r['full_rect_exact'].values()) for r in observations),inline_axis_exact=sum(sum(r['inline_axis_exact'].values()) for r in observations))),flush=True)
 report.update(observed_exit_code=0,totals=dict(cases=sum(len(p['observations']) for p in report['profiles']),geometry_states=7380,repeated_capture_pairs=10,full_rect_exact=sum(sum(r['full_rect_exact'].values()) for p in report['profiles'] for r in p['observations']),inline_axis_exact=sum(sum(r['inline_axis_exact'].values()) for p in report['profiles'] for r in p['observations'])))
except BaseException as error:
 report.update(observed_exit_code=1,failure=str(error));raise
finally:
 report.update(all_commands_terminal=True,source_after=repository_source_identity(SDK));report['source_unchanged']=report['source_after']==source
 assert report['source_unchanged'] and sha(chrome)==report['chromium_binary_sha256'] and sha(native_receipt)==report['native_receipt_sha256'];save()
raise SystemExit(report['observed_exit_code'])
