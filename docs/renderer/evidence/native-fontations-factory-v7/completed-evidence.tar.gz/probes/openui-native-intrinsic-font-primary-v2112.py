"""Preserve matching Chromium font setup source for the remaining native measurements."""
import base64,concurrent.futures,hashlib,json,urllib.error,urllib.request
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui/out/renderer-evidence/native-viewport-scroll-v1/native-intrinsic-font-primary-v2112');assert not ROOT.exists();ROOT.mkdir()
paths=['third_party/blink/renderer/platform/fonts/font_render_style.cc','third_party/blink/renderer/platform/fonts/font_platform_data.cc','third_party/blink/renderer/platform/fonts/linux/font_platform_data_linux.cc','third_party/blink/renderer/platform/fonts/skia/skia_text_metrics.cc']
def fetch(path):
 url='https://chromium.googlesource.com/chromium/src/+/147.0.7727.50/'+path+'?format=TEXT'
 try:
  with urllib.request.urlopen(url,timeout=30) as r:raw=r.read()
  data=base64.b64decode(raw,validate=True);target=ROOT/Path(path).name;target.write_bytes(data);return dict(url=url,observed_exit_code=0,bytes=len(data),path=str(target),sha256=hashlib.sha256(data).hexdigest())
 except urllib.error.HTTPError as e:return dict(url=url,observed_exit_code=1,http_status=e.code)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(fetch,paths))
report=dict(revision='147.0.7727.50',files=rows,source_only_not_a_chromium_observation=True,remaining_glyph_advance_root_cause_reviewed=False,release_qualification=False,probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest());(ROOT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(rows),flush=True)
