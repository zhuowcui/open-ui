use openui::prelude::*;
use std::{cell::Cell, rc::Rc};

#[test]
fn native_intrinsic_keywords_apply_both_limits_and_reflow_vertical_width() {
    for scale in [1.0, 1.25, 1.5, 2.0, 3.0] {
        for writing in [WritingMode::HorizontalTb, WritingMode::VerticalLr, WritingMode::VerticalRl] {
            for position in [Position::Absolute, Position::Fixed] {
                for (scenario, preferred, minimum, maximum, before_inline, before_cross, after_inline) in [
                    ("minimum", Length::min_content(), Length::auto(), Length::none(), 112.0, 64.0, 32.0),
                    ("minimum_and_maximum", Length::px(120.0), Length::min_content(), Length::px(60.0), 112.0, 64.0, 60.0),
                    ("both_intrinsic", Length::px(120.0), Length::min_content(), Length::max_content(), 120.0, 64.0, 32.0),
                    ("minimum_wins", Length::px(10.0), Length::max_content(), Length::min_content(), 352.0, 16.0, 32.0),
                ] {
                    let document = Document::with_font_collection_and_options(
                        ViewportMetrics::from_logical_size(800.0, 600.0, scale).unwrap(),
                        FontCollection::deterministic_test(),
                        EngineOptions { raster_configuration: RasterConfiguration::deterministic_aliased(false) },
                    ).unwrap();
                    let text = Element::create(&document, "div").unwrap();
                    text.set_position(position).unwrap();
                    text.set_left(Length::px(0.0)).unwrap();
                    text.set_top(Length::px(0.0)).unwrap();
                    text.set_writing_mode(writing).unwrap();
                    text.set_font_family(FontFamilyList { families: ["Ahem", "Droid Sans Fallback", "Noto Sans Devanagari", "Noto Color Emoji", "DejaVu Sans"].into_iter().map(|s| FontFamily::Named(s.into())).collect() }).unwrap();
                    text.set_font_size(LengthValue::px(16.0)).unwrap();
                    text.set_font_kerning(FontKerning::None).unwrap();
                    text.set_font_variant_ligatures(FontVariantLigatures::none()).unwrap();
                    text.set_line_height(LineHeight::Number(1.0)).unwrap();
                    text.set_text("non-spanner in caption").unwrap();
                    if writing == WritingMode::HorizontalTb {
                        text.set_width(preferred.into()).unwrap();
                        text.set_min_width(minimum.into()).unwrap();
                        text.set_max_width(maximum.into()).unwrap();
                    } else {
                        text.set_height(preferred.into()).unwrap();
                        text.set_min_height(minimum.into()).unwrap();
                        text.set_max_height(maximum.into()).unwrap();
                    }
                    document.body().append_child(&text).unwrap();
                    let before = text.bounding_rect().unwrap().unwrap();
                    let horizontal = writing == WritingMode::HorizontalTb;
                    assert_eq!(if horizontal { before.width } else { before.height }, before_inline, "{scenario} {writing:?} {position:?} {scale}");
                    assert_eq!(if horizontal { before.height } else { before.width }, before_cross, "{scenario} {writing:?} {position:?} {scale}");
                    let owned = before;
                    let weak = text.downgrade();
                    let target = weak.clone();
                    let calls = Rc::new(Cell::new(0));
                    let observed = Rc::clone(&calls);
                    text.on("click", move |_| {
                        target.upgrade().unwrap().set_text("XX").unwrap();
                        observed.set(observed.get() + 1);
                    }).unwrap();
                    text.click().unwrap();
                    assert_eq!(calls.get(), 1);
                    let after = text.bounding_rect().unwrap().unwrap();
                    assert_eq!(if horizontal { after.width } else { after.height }, after_inline, "{scenario} {writing:?}");
                    assert_eq!(if horizontal { after.height } else { after.width }, 16.0, "{scenario} {writing:?}");
                    assert_eq!(owned, before);
                    drop(text);
                    drop(document);
                    assert!(weak.upgrade().is_none());
                }
            }
        }
    }
}
