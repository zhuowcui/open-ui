"""Match the Chromium probe's explicit hidden viewport overflow natively."""
import fcntl,json,shutil,subprocess
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','ninja','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
for number,sdk,oldapp,expected in [(2067,'/dev/shm/openui-native-caption-v2034','/dev/shm/openui-native-intrinsic-api-v2050','c83d24f3cb76ac2f77346a88f73e53860f7f13b3'),(2068,'/dev/shm/openui-native-intrinsic-api-fix-v2058','/dev/shm/openui-native-intrinsic-api-v2059','4c2f2e4b715ce5e3df9c15855ead9d2855fd277f')]:
 root=Path('/dev/shm/openui-native-intrinsic-matched-v'+str(number));assert not root.exists();root.mkdir();(root/'src').mkdir();sdk=Path(sdk);oldapp=Path(oldapp)
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=sdk,text=True).strip()==expected
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=sdk)
 for name in ['Cargo.toml','Cargo.lock','.gitignore']:shutil.copy2(oldapp/name,root/name)
 s=(oldapp/'src/main.rs').read_text();marker='    let element = Element::create(document, "div")?;';assert s.count(marker)==1
 s=s.replace(marker,'''    // The immutable Chromium observer uses html { overflow: hidden }.
    // Apply the same viewport policy through public native Rust setters.
    document.body().set_overflow_x(Overflow::Hidden)?;
    document.body().set_overflow_y(Overflow::Hidden)?;
'''+marker,1);(root/'src/main.rs').write_text(s)
 subprocess.run(['git','init','-q'],cwd=root,check=True)
 for key in ['user.name','user.email']:
  value=subprocess.check_output(['git','config','--get',key],cwd=MAIN,text=True).strip();subprocess.run(['git','config','--local',key,value],cwd=root,check=True)
 print(json.dumps(dict(root=str(root),sdk=str(sdk),source=expected,production_changes=0,oracle_changed=False,release_qualification=False)),flush=True)
