"""Compare native API geometry with unchanged repeated Chromium observations."""
import collections,hashlib,json
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1'
OUT=RAW/'native-intrinsic-api-audit-v2062.json';assert not OUT.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
current_path=RAW/'native-intrinsic-api-pipeline-v2060/receipt.json';current=json.loads(current_path.read_bytes())
assert current['all_commands_terminal'] and current['observed_exit_code']==0 and current['sdk_source_unchanged'] and current['source_unchanged']
baseline_path=RAW/'native-intrinsic-api-pipeline-v2051/receipt.json';baseline=json.loads(baseline_path.read_bytes())
oracle_path=RAW/'native-intrinsic-api-chromium-v2052/receipt.json';oracle=json.loads(oracle_path.read_bytes());assert oracle['all_commands_terminal'] and oracle['observed_exit_code']==0 and oracle['source_unchanged']
newrows=[json.loads(line) for line in (current_path.parent/'native-first.log').read_text().splitlines()]
assert len(newrows)==3690
keys=['kind','scale','family','size','writing','text','position','decorated','scenario']
key=lambda r:tuple(r.get(k) for k in keys)
bykey={key(r):r for r in newrows};assert len(bykey)==len(newrows)
rows=[];counts=collections.Counter();groups=collections.defaultdict(collections.Counter)
for profile in oracle['profiles']:
 for obs in profile['observations']:
  old=obs['native_case'];chrome=obs['chromium'];new=bykey.pop(key(old));fields=['natural','minimum'] if old['kind']=='original' else ['before','after'];axis='width' if old['writing']=='horizontal-tb' else 'height'
  for field in fields:
   old_exact=old[field]==chrome[field];new_exact=new[field]==chrome[field];old_inline=old[field][axis]==chrome[field][axis];new_inline=new[field][axis]==chrome[field][axis]
   values=dict(states=1,baseline_full_rect_exact=int(old_exact),full_rect_exact=int(new_exact),baseline_inline_axis_exact=int(old_inline),inline_axis_exact=int(new_inline),full_rect_gains=int(new_exact and not old_exact),full_rect_losses=int(old_exact and not new_exact),inline_axis_gains=int(new_inline and not old_inline),inline_axis_losses=int(old_inline and not new_inline))
   counts.update(values)
   for label in [old['kind'],old['family'],old['writing'],str(old['size']),old.get('scenario','text:'+old.get('text',''))]:groups[label].update(values)
   rows.append(dict(case={k:old[k] for k in keys if k in old},state=field,baseline=old[field],native=new[field],chromium=chrome[field],baseline_full_rect_exact=old_exact,full_rect_exact=new_exact,baseline_inline_axis_exact=old_inline,inline_axis_exact=new_inline))
assert not bykey and len(rows)==7380
assert counts['baseline_full_rect_exact']==oracle['totals']['full_rect_exact']
assert counts['baseline_inline_axis_exact']==oracle['totals']['inline_axis_exact']
report=dict(schema_version=1,source=current['sdk_source'],geometry_only_diagnostic=True,native_pixels_captured=False,release_qualification=False,promotion_allowed=False,new_release_states_admitted=0,javascript_executed_by_openui=False,oracle_receipt_sha256=sha(oracle_path),native_receipt_sha256=sha(current_path),baseline_receipt_sha256=sha(baseline_path),totals=dict(counts),groups={k:dict(v) for k,v in sorted(groups.items())},observations=rows,probe_sha256=sha(Path(__file__)))
OUT.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(path=str(OUT),sha256=sha(OUT),totals=report['totals'])),flush=True)
for row in rows:
 if row['baseline_full_rect_exact'] and not row['full_rect_exact']:print(json.dumps(dict(loss=row)),flush=True)
