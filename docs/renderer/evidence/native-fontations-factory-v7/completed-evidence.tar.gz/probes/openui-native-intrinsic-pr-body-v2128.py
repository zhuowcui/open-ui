"""Prepare the next draft PR body after completed evidence is committed."""
import hashlib
import json
import subprocess
from pathlib import Path

MAIN = Path('/home/nero/code/open-ui')
RAW = MAIN / 'out/renderer-evidence/native-viewport-scroll-v1'
data = json.loads((MAIN / 'docs/renderer/generated/native-fontations-factory-v7.json').read_bytes())
audit = json.loads((RAW / 'native-intrinsic-renderer-audit-v2124.json').read_bytes())
assert data['all_commands_terminal'] and audit['source'] == data['source']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=MAIN)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=MAIN, text=True).strip()
assert head != '376e0ded2b4ff13b81d66175ded44c9ef03c65f3'
previous = Path('/tmp/openui-pr3-native-viewport-body-v138.md').read_text()
marker = '## Fresh clean umbrella reproduction `50dc0c1e`'
tail = previous[previous.index(marker):]
assert len(tail.encode()) == 59783
assert hashlib.sha256(tail.encode()).hexdigest() == 'db70f2d8bf890e15e8656991433a14fead226f0dd5563c06a55c2c031431fd34'
fmt = lambda n: f'{n:,}'
suites = data['suites']
geometry = data['native_geometry']['totals']
font = data['native_font_totals']
changes = audit['suites']['full']['changed_comparisons']
worsened = sum(r['mismatched_pixels'] > r['prior_mismatched_pixels'] for r in changes)
table = '\n'.join(
    f'| {label} | {fmt(row["results"]["exact"])}/{fmt(row["results"]["total"])} | '
    f'{fmt(row["results"]["different"])} | {row["results"]["errors"]} | {row["actual_exit"]} |'
    for label, row in ((label, suites[name]) for name, label in [
        ('full', 'Original'), ('expanded', 'Expanded'), ('focused', 'Focused'), ('primitive', 'Primitive')])
)
prefix = f'''## Current checkpoint: native intrinsic sizing and exact line height

Umbrella `{head[:8]}` preserves complete clean private `8f756039` measurements,
failed attempts and a reproducible source patch. The native Fontations factory,
caption and intrinsic implementation remain private and unapplied. Accepted
original pixels remain **21,334/22,924 exact**, 1,590 different, zero errors,
actual exit 1. This PR remains OPEN and DRAFT.

### Native Rust behavior

The consuming Rust app constructs and changes elements through public methods,
runs **2,880 Rust callbacks per run**, queries owned bounds and verifies weak
handle teardown. Both runs repeat all **3,690 cases / 7,380 geometry states**
byte-identically. Explicit viewport overflow matches on both sides.
**{fmt(geometry['full_rect_exact'])}/7,380 full rectangles** match pinned Chromium,
with **{fmt(geometry['full_rect_gains'])} gains and {geometry['full_rect_losses']} losses** against the caption-only source.
These are geometry results, not native pixel qualification.

Twenty states remain different: DejaVu Sans at 18.72px, `in the box`, both
vertical writing directions, five scales. Natural inline size is 93px versus
Chromium's 92px; minimum is 33px versus 32px. Shared intrinsic text advance and
strike selection owns the investigation; its precise cause remains unreviewed.

The shared fix projects intrinsic contributions into physical axes, applies
both minimum and maximum bounds, lets minimum win conflicts, resolves
fit-content after insets/margins, and uses laid-out vertical column extent
when width is automatic. Ordinary families also use Unicode soft breaks.
There is no new fixture, font-name, font-size, backend or test-ID condition.

Fractional line height follows Chromium's fixed-point conversion. At 16px,
unitless `1.2` is exactly 19.1875px; `120%` and fixed `19.2px` are 19.203125px.
Authored percentages resolve to fixed lengths at computed font size, including
the pinned integral-percent conversion. **270 repeated Chromium observations**
cover two families, three writing modes and five scales. Both new native Rust
callback guards execute and pass. The old approximate assertion is replaced
with the exact Chromium value; failed trials remain preserved.

### Complete private verification

All **8,575 workspace tests pass**, zero failed and 13 ignored, and all
**21 read-only checks pass**. Linux Rust/C/C++ consumers retain **113 exports
and 30 layouts**. Upstream Fontations tests, caption and strict RGBA guards
execute successfully. One exclusive owner covers every stage and gap; all
source identities remain clean and unchanged.

| Suite | Exact | Different | Errors | Actual exit |
|---|---:|---:|---:|---:|
{table}

Original pixels gain **{suites['full']['exact_gains']} exact comparisons and lose {suites['full']['exact_losses']}**;
expanded pixels gain **{suites['expanded']['exact_gains']} and lose {suites['expanded']['exact_losses']}**.
There are {len(changes)} changed original rows; **{worsened} have more wrong pixels**
than the accepted renderer. All **48,252 Chromium image and oracle records
stay fixed**. The native font app is **{font['pixel_exact']}/{font['images']} images** and
**{fmt(font['geometry_exact'])}/{fmt(font['phase_states'])} bounds exact**, with repeated native output.
Complete pixel gates remain failing. No release state is admitted.

Versioned `docs/renderer/generated/native-fontations-factory-v7.json` preserves
complete summaries, native apps, callbacks, focused/primitive runs, image
regions, diagnostic Chromium queries, failed attempts and source checks.
Every archive member is hash-verified. Four failed and final source trees
reconstruct exactly from public `9f0d2211` in independent Git indexes.
Prior v6 evidence and every oracle remain unchanged.

### Contract and hosted status

**Open UI never executes JavaScript, in any version.** Consuming apps call
public native Rust methods and supply Rust callbacks. Every needed operation,
including state changes, geometry and events, remains required. A fixture or
script-based Chromium test cannot waive API work. **Pinned Chromium alone
defines expected pixels**; old Open UI bytes preserve history. Tolerance is zero.

Public `376e0ded` completes six executed hosted jobs, five skips, zero failures;
all nine native/comparison guards execute and pass. Logs are preserved.
Those results belong to that public source. Hosted checks on this new evidence
head are pending; private source inherits no hosted qualification.

Full parity and reviewed residual ownership, remaining native Rust/C APIs and
font settings, compositor/3D, hardware/accessibility, performance, packaging,
reproducibility, signing and publication remain open. No merge, release tag or
publication occurs. Historical sections below are preserved.


'''
assert len(prefix.encode()) <= 5753
body = prefix + tail
assert len(body.encode()) <= 65536
path = Path('/tmp/openui-pr3-native-viewport-body-v139.md')
assert not path.exists()
path.write_text(body)
print(json.dumps(dict(path=str(path), head=head, bytes=len(body.encode()),
    body_sha256=hashlib.sha256(body.encode()).hexdigest(), historical_tail_unchanged=True)))
