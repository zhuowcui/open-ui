"""Correct the public Engine percentage conversion on a fresh immutable trial."""
import fcntl,json,os,shutil,subprocess
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');OLD=Path('/dev/shm/openui-native-intrinsic-api-fix-v2080');ROOT=Path('/dev/shm/openui-native-intrinsic-api-fix-v2090');lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','ninja','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
assert not ROOT.exists() and not subprocess.check_output(['git','status','--porcelain'],cwd=OLD)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=OLD,text=True).strip();assert head=='c3f9cb15df7a491890c672d50e7523fca9871fce'
subprocess.run(['git','worktree','add','--no-checkout','--detach',str(ROOT),head],cwd=MAIN,check=True,capture_output=True)
for encoded in subprocess.check_output(['git','ls-tree','-r','--name-only','-z',head],cwd=MAIN).split(b'\0'):
 if not encoded:continue
 name=encoded.decode();a,b=OLD/name,ROOT/name;b.parent.mkdir(parents=True,exist_ok=True)
 if a.is_symlink():b.symlink_to(os.readlink(a))
 else:os.link(a,b)
subprocess.run(['git','read-tree',head],cwd=ROOT,check=True,capture_output=True)
p=ROOT/'bindings/rust/openui-engine/src/lib.rs';s=p.read_text();old='fields.font_size * percent / 100.0';assert s.count(old)==1
s=s.replace(old,'fields.font_size * (percent as i32) as f32 / 100.0',1)
marker='                if let openui_style::LineHeight::Percentage(percent) = fields.line_height {';assert s.count(marker)==1
s=s.replace(marker,'''                // Chromium's StyleBuilderConverter fixes authored percentages
                // at this computed font size and clamps the percent to int.
'''+marker,1)
t=p.with_name(p.name+'.isolated-v2090');t.write_text(s);os.replace(t,p)
subprocess.run(['bash','-c','ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true bindings/rust/openui-engine/src/lib.rs'],cwd=ROOT,check=True)
subprocess.run(['git','add','bindings/rust/openui-engine/src/lib.rs'],cwd=ROOT,check=True);subprocess.run(['git','commit','-m','Match Chromium percentage line-height conversion in the shared native Engine'],cwd=ROOT,check=True,capture_output=True)
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT);assert not subprocess.check_output(['git','status','--porcelain'],cwd=OLD)
oldapp=Path('/dev/shm/openui-native-intrinsic-matched-v2088');app=Path('/dev/shm/openui-native-intrinsic-matched-v2091');assert not app.exists();app.mkdir();(app/'src').mkdir();(app/'Cargo.toml').write_text((oldapp/'Cargo.toml').read_text().replace(str(OLD),str(ROOT)))
for name in ['Cargo.lock','.gitignore','src/main.rs']:shutil.copy2(oldapp/name,app/name)
subprocess.run(['git','init','-q'],cwd=app,check=True)
for key in ['user.name','user.email']:
 value=subprocess.check_output(['git','config','--get',key],cwd=MAIN,text=True).strip();subprocess.run(['git','config','--local',key,value],cwd=app,check=True)
s=Path('/tmp/openui-native-intrinsic-verification-pipeline-v2083.py').read_text().replace(str(OLD),str(ROOT)).replace(str(oldapp),str(app)).replace('native-intrinsic-verification-pipeline-v2083','native-intrinsic-verification-pipeline-v2092').replace(head,source).replace('openui-native-intrinsic-font-consumer-v2084.py','openui-native-intrinsic-font-consumer-v2093.py')
p=Path('/tmp/openui-native-intrinsic-verification-pipeline-v2092.py');assert not p.exists();p.write_text(s)
s=Path('/tmp/openui-native-intrinsic-font-consumer-v2084.py').read_text().replace(str(OLD),str(ROOT)).replace('native-intrinsic-verification-pipeline-v2083','native-intrinsic-verification-pipeline-v2092').replace('native-intrinsic-font-consumer-v2084','native-intrinsic-font-consumer-v2093');p=Path('/tmp/openui-native-intrinsic-font-consumer-v2093.py');assert not p.exists();p.write_text(s)
s=Path('/tmp/openui-native-intrinsic-checks-v2085.py').read_text().replace(str(OLD),str(ROOT)).replace('native-intrinsic-checks-v2085','native-intrinsic-checks-v2094').replace('bindings/rust/openui-layout/tests/sp11_round16_fix_tests.rs','bindings/rust/openui-layout/tests/sp11_round16_fix_tests.rs bindings/rust/openui-engine/src/lib.rs');p=Path('/tmp/openui-native-intrinsic-checks-v2094.py');assert not p.exists();p.write_text(s)
print(json.dumps(dict(root=str(ROOT),source=source,failed_source_preserved=True,production_applied=False,release_qualification=False)),flush=True)
