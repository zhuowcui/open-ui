"""Relocate the terminal failed owner's unchanged executable, preserving paths."""
import fcntl
import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path

MAIN = Path('/home/nero/code/open-ui')
RAW = MAIN / 'out/renderer-evidence/native-viewport-scroll-v1'
owner_path = RAW / 'native-intrinsic-verification-pipeline-v2097/receipt.json'
owner = json.loads(owner_path.read_bytes())
assert owner['all_commands_terminal'] and owner['source_unchanged']
lock = open('/tmp/openui-native-cargo-raster-owner.lock', 'a+')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
for name in ['cargo', 'rustc', 'ninja', 'pixel_compare']:
    assert subprocess.run(['pgrep', '-x', name], capture_output=True).returncode == 1

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(2**20), b''):
            h.update(chunk)
    return h.hexdigest()

path = (owner_path.parent / 'pixel_compare').resolve()
assert path == MAIN / 'out/renderer-evidence/native-pixel-binary-stage-v2104/pixel_compare'
expected = owner['pixel_binary_sha256']
assert sha(path) == expected
assert owner['build_identity']['source'] == owner['source']
for proc in Path('/proc').iterdir():
    if proc.name.isdecimal():
        try:
            assert (proc / 'exe').resolve() != path
        except (FileNotFoundError, PermissionError):
            pass
store = Path('/mnt/e/openui-v02-qualification-d174ea0b/relocated-terminal-private-binary-v2114')
assert not store.exists()
store.mkdir()
target = store / path.name
size = path.stat().st_size
shutil.copy2(path, target)
assert sha(target) == expected and target.stat().st_size == size
path.unlink()
path.symlink_to(target)
assert sha(owner_path.parent / 'pixel_compare') == expected
receipt = dict(all_commands_terminal=True, original_path_preserved=True,
    terminal_owner_receipt_sha256=sha(owner_path), bytes=size, sha256=expected,
    original_path=str(path), relocated_path=str(target),
    cargo_or_native_queries_started=0, reference_images_rewritten=0,
    probe_sha256=sha(Path(__file__)))
Path('/tmp/openui-verified-terminal-binary-relocation-v2114.json').write_text(
    json.dumps(receipt, sort_keys=True, indent=2) + '\n')
print(json.dumps(dict(bytes_preserved=size, hash_verified=True,
    home_free=shutil.disk_usage(MAIN).free)))
