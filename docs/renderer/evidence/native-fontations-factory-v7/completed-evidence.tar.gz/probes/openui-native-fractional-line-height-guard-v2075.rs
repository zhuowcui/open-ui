
#[test]
fn native_fractional_line_heights_keep_chromium_grid_through_callbacks() {
    let fonts = FontCollection::deterministic_test();
    for scale in [1.0, 1.25, 1.5, 2.0, 3.0] {
        for family in ["Ahem", "DejaVu Sans"] {
            for writing in [WritingMode::HorizontalTb, WritingMode::VerticalLr, WritingMode::VerticalRl] {
                let document = Document::with_font_collection_and_options(
                    ViewportMetrics::from_logical_size(800.0, 600.0, scale).unwrap(),
                    fonts.clone(),
                    EngineOptions { raster_configuration: RasterConfiguration::deterministic_aliased(false) },
                ).unwrap();
                document.body().set_overflow_x(Overflow::Hidden).unwrap();
                document.body().set_overflow_y(Overflow::Hidden).unwrap();
                let text = Element::create(&document, "div").unwrap();
                text.set_position(Position::Absolute).unwrap();
                text.set_left(Length::px(0.0)).unwrap();
                text.set_top(Length::px(0.0)).unwrap();
                text.set_writing_mode(writing).unwrap();
                text.set_font_family(FontFamilyList::single(family)).unwrap();
                text.set_font_kerning(FontKerning::None).unwrap();
                text.set_font_variant_ligatures(FontVariantLigatures::none()).unwrap();
                text.set_text("Hello").unwrap();
                if writing == WritingMode::HorizontalTb {
                    text.set_width(Length::px(100.0).into()).unwrap();
                } else {
                    text.set_height(Length::px(100.0).into()).unwrap();
                }
                document.body().append_child(&text).unwrap();
                // Exact values observed twice in Chromium 147.0.7727.50 at
                // every required scale, family and writing mode. No tolerance.
                for (size, line_height, expected) in [
                    (16.0, LineHeight::Number(1.2), 19.1875),
                    (16.0, LineHeight::Percentage(120.0), 19.1875),
                    (16.0, LineHeight::Length(19.2), 19.203125),
                    (18.72, LineHeight::Number(1.0), 18.71875),
                    (18.72, LineHeight::Number(1.2), 22.453125),
                    (18.72, LineHeight::Percentage(120.0), 22.453125),
                    (18.72, LineHeight::Length(18.72), 18.71875),
                ] {
                    text.set_font_size(LengthValue::px(size)).unwrap();
                    text.set_line_height(line_height).unwrap();
                    let bounds = text.bounding_rect().unwrap().unwrap();
                    let horizontal = writing == WritingMode::HorizontalTb;
                    assert_eq!(bounds.x, 0.0);
                    assert_eq!(bounds.y, 0.0);
                    assert_eq!(if horizontal { bounds.width } else { bounds.height }, 100.0);
                    assert_eq!(if horizontal { bounds.height } else { bounds.width }, expected, "{family} {writing:?} {scale} {size} {line_height:?}");
                }
                text.set_font_size(LengthValue::px(16.0)).unwrap();
                text.set_line_height(LineHeight::Number(1.2)).unwrap();
                let owned = text.bounding_rect().unwrap().unwrap();
                let weak = text.downgrade();
                let target = weak.clone();
                let calls = Rc::new(Cell::new(0));
                let observed = Rc::clone(&calls);
                text.on("click", move |_| {
                    target.upgrade().unwrap().set_line_height(LineHeight::Length(19.2)).unwrap();
                    observed.set(observed.get() + 1);
                }).unwrap();
                text.click().unwrap();
                let after = text.bounding_rect().unwrap().unwrap();
                assert_eq!(calls.get(), 1);
                let horizontal = writing == WritingMode::HorizontalTb;
                assert_eq!(if horizontal { owned.height } else { owned.width }, 19.1875);
                assert_eq!(if horizontal { after.height } else { after.width }, 19.203125);
                drop(text);
                drop(document);
                assert!(weak.upgrade().is_none());
            }
        }
    }
}
