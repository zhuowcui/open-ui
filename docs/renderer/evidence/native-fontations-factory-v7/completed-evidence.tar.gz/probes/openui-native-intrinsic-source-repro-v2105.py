"""Reconstruct every measured failed and final source without changing it."""
import fcntl,hashlib,json,os,subprocess,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';OUT=RAW/'native-intrinsic-source-repro-v2105';STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/OUT.name
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','ninja','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
owner=json.loads((RAW/'native-intrinsic-verification-pipeline-v2097/receipt.json').read_bytes());assert owner['all_commands_terminal'] and owner['source_unchanged']
assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
sys.path.insert(0,'/dev/shm/openui-native-intrinsic-api-fix-v2095/tools/qualification');from renderer_source_identity import repository_source_identity
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[];base='9f0d22112136bc8b5325d0b0619031bdd8b9adcf'
for number,expected in [(2054,'a423e9ba198701e5205a83207ebc501e97a208ec'),(2058,'4c2f2e4b715ce5e3df9c15855ead9d2855fd277f'),(2080,'c3f9cb15df7a491890c672d50e7523fca9871fce'),(2095,'8f75603958fd07a16dad41770b9b4374d466a145')]:
 root=Path('/dev/shm/openui-native-intrinsic-api-fix-v'+str(number));source=repository_source_identity(root);assert source['clean'] and source['commit']==expected
 p=OUT/('source-v'+str(number)+'.patch');p.write_bytes(subprocess.check_output(['git','diff','--binary',base,expected],cwd=root))
 env=dict(os.environ,GIT_INDEX_FILE=str(STORE/('reproduction-index-v'+str(number))));steps=[]
 for command in [['git','read-tree',base],['git','apply','--cached',str(p)],['git','write-tree']]:
  r=subprocess.run(command,cwd=root,env=env,capture_output=True);steps.append(dict(command=command,observed_exit_code=r.returncode,stdout=r.stdout.decode(),stderr=r.stderr.decode()));assert r.returncode==0
 tree=subprocess.check_output(['git','rev-parse',expected+'^{tree}'],cwd=root,text=True).strip();assert steps[-1]['stdout'].strip()==tree
 assert repository_source_identity(root)==source
 rows.append(dict(source=source,base_commit=base,target_commit=expected,expected_tree=tree,reconstructed_tree=steps[-1]['stdout'].strip(),entire_tracked_tree_exact=True,patch_path=str(p),patch_sha256=sha(p),patch_bytes=p.stat().st_size,steps=steps))
report=dict(schema_version=1,all_commands_terminal=True,release_qualification=False,sources=rows,probe_sha256=sha(Path(__file__)));(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(sources=[r['target_commit'] for r in rows],entire_tracked_trees_exact=True,receipt_sha256=sha(OUT/'receipt.json'))),flush=True)
