import fcntl,hashlib,html,json,subprocess,sys
from pathlib import Path
from PIL import Image
MAIN=Path('/home/nero/code/open-ui');SDK=Path('/dev/shm/openui-native-caption-v2034');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';NAME='native-intrinsic-api-chromium-v2052';OUT=RAW/NAME;STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/NAME
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for program in ['cargo','rustc','ninja','pixel_compare']:assert subprocess.run(['pgrep','-x',program],capture_output=True).returncode==1
assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
sys.path.insert(0,str(SDK/'tools/qualification'));from renderer_source_identity import repository_source_identity
sys.path.insert(0,str(SDK/'tools/accountability'));import run_all_pixel_comparisons as capture
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=repository_source_identity(SDK);assert source['clean'] and source['commit']=='c83d24f3cb76ac2f77346a88f73e53860f7f13b3'
chrome=MAIN/'chrome/linux-147.0.7727.50/chrome-linux64/chrome';assert sha(chrome)=='0ba87684df0afc11faaea40ac57bd2f1d68b67191443b38215a36b90e6f08848'
native_receipt=RAW/'native-intrinsic-api-pipeline-v2051/receipt.json';native=json.loads(native_receipt.read_bytes());assert native['all_commands_terminal'] and native['observed_exit_code']==0 and native['sdk_source']==source
rows=[json.loads(line) for line in (native_receipt.parent/'native-first.log').read_text().splitlines()];assert len(rows)==3690
report=dict(schema_version=1,source=source,all_commands_terminal=False,owner_pid=__import__('os').getpid(),release_qualification=False,promotion_allowed=False,pixel_tolerance=0,javascript_executed_by_openui=False,offline_javascript_executed_only_in_chromium=True,native_pixels_captured=False,geometry_only_diagnostic=True,chromium_binary_sha256=sha(chrome),capture_harness_sha256=sha(SDK/'tools/accountability/run_all_pixel_comparisons.py'),native_receipt_sha256=sha(native_receipt),capture_process_switches_added=['--disable-dev-shm-usage'],capture_process_environment_is_diagnostic=True,new_release_states_admitted=0,profiles=[],probe_sha256=sha(Path(__file__)))
save=lambda:(OUT/'receipt.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');save()
original_ws=capture._CdpWebSocket
def observe(path,output,expression,width,height,scale):
 observations=[]
 class QueryWebSocket(original_ws):
  def command(self,method,params=None):
   result=super().command(method,params)
   if method=='Runtime.evaluate' and not observations:
    q=super().command('Runtime.evaluate',{'expression':'Promise.resolve('+expression+').then(value => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve(value)))))','awaitPromise':True,'returnByValue':True})
    assert 'exceptionDetails' not in q, q.get('exceptionDetails')
    observations.append(q['result']['value'])
   return result
 capture._CdpWebSocket=QueryWebSocket
 processes=[]; exceptions=[]; stderr_path=output.with_suffix('.stderr.log'); stderr_stream=stderr_path.open('xb'); original_popen=capture.subprocess.Popen
 def launch(command,*args,**kwargs):
  if command and command[0]==str(chrome):
   command=[command[0],'--disable-dev-shm-usage',*command[1:]];kwargs['stderr']=stderr_stream
  process=original_popen(command,*args,**kwargs);processes.append(process);return process
 def trace(frame,event,arg):
  if event=='exception' and frame.f_code.co_filename==str(SDK/'tools/accountability/run_all_pixel_comparisons.py'):
   exceptions.append(dict(function=frame.f_code.co_name,type=arg[0].__name__,message=str(arg[1])))
  return trace
 capture.subprocess.Popen=launch;sys.settrace(trace)
 try:
  ok=capture.render_chrome(str(path),str(output),str(chrome),str(chrome.parent),use_ahem_noaa=True,logical_width=width,logical_height=height,device_scale=scale)
 finally:
  sys.settrace(None);capture._CdpWebSocket=original_ws;capture.subprocess.Popen=original_popen;stderr_stream.close()
  attempt=dict(output=str(output),query_count=len(observations),exceptions=exceptions,process_actual_exits=[p.poll() for p in processes],stderr_sha256=sha(stderr_path));(output.with_suffix('.attempt.json')).write_text(json.dumps(attempt,sort_keys=True,indent=2)+'\n')
  if not observations:print(json.dumps({k:attempt[k] for k in ['output','query_count','process_actual_exits','stderr_sha256']}),flush=True)
 assert ok and len(observations)==1, f'Chromium capture/query failed: capture_ok={ok}, query_count={len(observations)}'
 return observations[0]
def rgba(path):
 with Image.open(path) as image:return image.size,image.convert('RGBA').tobytes()
try:
 for scale in [1.0,1.25,1.5,2.0,3.0]:
  for kind,width,height in [('original',800,600),('constraints',80,64)]:
   chosen=[r for r in rows if r['scale']==scale and r['kind']==kind]
   assert len(chosen)==(162 if kind=='original' else 576)
   directory=OUT/(kind+'-'+str(scale));directory.mkdir();path=directory/'test.html'
   parts=['<!doctype html><style>*{margin:0;padding:0;box-sizing:content-box}html{overflow:hidden}div{left:0;top:0;font-kerning:none;font-variant-ligatures:none;font-synthesis:none;line-height:1}</style>']
   scenarios={'preferred_min':('min-content','auto','none'),'preferred_max':('max-content','auto','none'),'preferred_fit':('fit-content','auto','none'),'min_then_fixed_max':('120px','min-content','60px'),'fixed_min_then_max':('120px','10px','min-content'),'both_intrinsic':('120px','min-content','max-content'),'min_beats_max':('10px','max-content','min-content'),'maximum_max':('300px','auto','max-content')}
   for i,r in enumerate(chosen):
    family='Ahem, "Droid Sans Fallback", "Noto Sans Devanagari", "Noto Color Emoji", "DejaVu Sans"' if r['family']=='deterministic' else '"DejaVu Sans"'
    size='18.72' if abs(r['size']-18.72)<.001 else str(r['size'])
    styles=[f'font-family:{family}',f'font-size:{size}px',f'writing-mode:{r["writing"]}',f'position:{r.get("position","absolute")}']
    if kind=='constraints':
     axis='width' if r['writing']=='horizontal-tb' else 'height'
     preferred,minimum,maximum=scenarios[r['scenario']]
     styles.extend([f'{axis}:{preferred}',f'min-{axis}:{minimum}',f'max-{axis}:{maximum}'])
     if r['decorated']:styles.append('padding:2px 5px 4px 3px')
     if r['scenario']=='preferred_fit':styles.append('left:3px;right:5px;top:3px;bottom:5px')
    text=r['text'] if kind=='original' else 'non-spanner in caption'
    parts.append(f'<div id="r{i}" data-writing="{r["writing"]}" style="{html.escape(";".join(styles),quote=True)}">{html.escape(text)}</div>')
   path.write_text(''.join(parts))
   if kind=='original':
    expression=r'''(() => {const nodes=[...document.querySelectorAll('body>div')]; const rect=n=>{const b=n.getBoundingClientRect();return {x:b.x,y:b.y,width:b.width,height:b.height}};const natural=nodes.map(rect);nodes.forEach(n=>{n.style[n.dataset.writing==='horizontal-tb'?'width':'height']='min-content'});const result=nodes.map((n,i)=>({id:n.id,natural:natural[i],minimum:rect(n)}));nodes.forEach(n=>{n.style.width='auto';n.style.height='auto'});return result;})()'''
   else:
    expression=r'''(() => {const nodes=[...document.querySelectorAll('body>div')];const rect=n=>{const b=n.getBoundingClientRect();return {x:b.x,y:b.y,width:b.width,height:b.height}};const before=nodes.map(rect);nodes.forEach(n=>{n.textContent='XX'});const result=nodes.map((n,i)=>({id:n.id,before:before[i],after:rect(n)}));nodes.forEach(n=>{n.textContent='non-spanner in caption'});return result;})()'''
   queries=[]
   for repeat in [1,2]:
    picture=directory/(str(repeat)+'.png');q=observe(path,picture,expression,width,height,scale);queries.append(q)
    (directory/(str(repeat)+'-geometry.json')).write_text(json.dumps(q,sort_keys=True,indent=2)+'\n')
   assert queries[0]==queries[1] and (directory/'1.png').read_bytes()==(directory/'2.png').read_bytes()
   observations=[]
   for i,(r,c) in enumerate(zip(chosen,queries[0])):
    assert c['id']=='r'+str(i)
    names=['natural','minimum'] if kind=='original' else ['before','after']
    axis='width' if r['writing']=='horizontal-tb' else 'height'
    observations.append(dict(native_case=r,chromium=c,full_rect_exact={name:r[name]==c[name] for name in names},inline_axis_exact={name:r[name][axis]==c[name][axis] for name in names}))
   row=dict(scale=scale,kind=kind,html_sha256=sha(path),first_png_sha256=sha(directory/'1.png'),second_png_sha256=sha(directory/'2.png'),repeated_png_and_queries_identical=True,observations=observations)
   report['profiles'].append(row);save();print(json.dumps(dict(scale=scale,kind=kind,cases=len(observations),full_rect_exact=sum(sum(r['full_rect_exact'].values()) for r in observations),inline_axis_exact=sum(sum(r['inline_axis_exact'].values()) for r in observations))),flush=True)
 report.update(observed_exit_code=0,totals=dict(cases=sum(len(p['observations']) for p in report['profiles']),geometry_states=7380,repeated_capture_pairs=10,full_rect_exact=sum(sum(r['full_rect_exact'].values()) for p in report['profiles'] for r in p['observations']),inline_axis_exact=sum(sum(r['inline_axis_exact'].values()) for p in report['profiles'] for r in p['observations'])))
except BaseException as error:
 report.update(observed_exit_code=1,failure=str(error));raise
finally:
 report.update(all_commands_terminal=True,source_after=repository_source_identity(SDK));report['source_unchanged']=report['source_after']==source
 assert report['source_unchanged'] and sha(chrome)==report['chromium_binary_sha256'] and sha(native_receipt)==report['native_receipt_sha256'];save()
raise SystemExit(report['observed_exit_code'])
