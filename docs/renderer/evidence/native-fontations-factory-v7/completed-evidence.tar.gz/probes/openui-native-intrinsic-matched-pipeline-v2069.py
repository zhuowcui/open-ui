"""Measure baseline and trial native API calls with matched viewport overflow."""
import fcntl,hashlib,json,os,shutil,signal,subprocess,sys,time
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';NAME='native-intrinsic-matched-pipeline-v2069'
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','ninja','pixel_compare']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
OUT=RAW/NAME;STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/NAME;assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
TMP=STORE/'compiler-tmp';TMP.mkdir();env=dict(os.environ,CARGO_TARGET_DIR='/mnt/e/openui-v02-cargo-c73754e2/target',CARGO_INCREMENTAL='0',RUST_MIN_STACK='4194304',CARGO_BUILD_JOBS='4',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(TMP),CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
sys.path.insert(0,'/dev/shm/openui-native-caption-v2034/tools/qualification');from renderer_source_identity import repository_source_identity
sdks={'baseline':Path('/dev/shm/openui-native-caption-v2034'),'current':Path('/dev/shm/openui-native-intrinsic-api-fix-v2058')};sources={label:repository_source_identity(root) for label,root in sdks.items()}
assert all(s['clean'] for s in sources.values())
assert sources['baseline']['commit']=='c83d24f3cb76ac2f77346a88f73e53860f7f13b3' and sources['current']['commit']=='4c2f2e4b715ce5e3df9c15855ead9d2855fd277f'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for c in iter(lambda:f.read(2**20),b''):h.update(c)
 return h.hexdigest()
report=dict(schema_version=1,sdk_sources=sources,owner_pid=os.getpid(),all_commands_terminal=False,whole_pipeline_lock_covers_all_stages_and_gaps=True,release_qualification=False,promotion_allowed=False,javascript_executed_by_openui=False,native_pixels_captured=False,geometry_only_diagnostic=True,viewport_overflow=dict(native='public Rust root overflow-x/overflow-y hidden',chromium='unchanged html overflow:hidden'),steps=[],applications={},probe_sha256=sha(Path(__file__)))
save=lambda:(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');save()
def identity(root):return dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip(),clean=not subprocess.check_output(['git','status','--porcelain'],cwd=root))
def verify_sources():
 assert all(repository_source_identity(root)==sources[label] for label,root in sdks.items()),'measured SDK changed'
 for label,r in report['applications'].items():assert identity(Path(r['root']))==r['source'],'diagnostic source changed'
def run(name,command,root):
 log=OUT/(name+'.log')
 with log.open('xb') as stream:
  child=subprocess.Popen(command,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True);report['current_process']=dict(pid=child.pid,stage=name);save();guard=False
  while child.poll() is None:
   if shutil.disk_usage(MAIN).free<512*2**20 or shutil.disk_usage(STORE).free<10*2**30:
    guard=True;os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=20);break
   time.sleep(1)
  child.wait()
 report.pop('current_process');row=dict(name=name,observed_exit_code=child.returncode,disk_guard_triggered=guard,log_sha256=sha(log));report['steps'].append(row);save();print(json.dumps(row),flush=True)
 assert not guard and child.returncode==0,name+' failed';verify_sources()
try:
 for label,number in [('baseline',2067),('current',2068)]:
  root=Path('/dev/shm/openui-native-intrinsic-matched-v'+str(number));base=['cargo','--config',str(sdks[label]/'bindings/rust/.cargo/config.chromium.toml')]
  run(label+'-format',['bash','-c','ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true src/main.rs'],root)
  run(label+'-metadata',base+['metadata','--offline','--format-version','1'],root)
  subprocess.run(['git','add','.'],cwd=root,check=True,capture_output=True);subprocess.run(['git','commit','-m','Match native viewport policy to immutable Chromium geometry observations'],cwd=root,check=True,capture_output=True)
  report['applications'][label]=dict(root=str(root),source=identity(root),lockfile_sha256=sha(root/'Cargo.lock'));assert report['applications'][label]['source']['clean'];save()
  run(label+'-build',base+['build','--offline','--locked'],root)
  binary=OUT/(label+'-openui-native-intrinsic-api');shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/openui-native-intrinsic-api',binary);report['applications'][label]['binary_sha256']=sha(binary);save()
  run(label+'-first',[str(binary)],root);run(label+'-second',[str(binary)],root)
  assert (OUT/(label+'-first.log')).read_bytes()==(OUT/(label+'-second.log')).read_bytes()
  rows=[json.loads(line) for line in (OUT/(label+'-first.log')).read_text().splitlines()];assert len(rows)==3690
  report['applications'][label]['totals']=dict(native_rows=len(rows),original_cases=sum(r['kind']=='original' for r in rows),constraint_cases=sum(r['kind']=='constraints' for r in rows),callback_calls=sum(r.get('callback_calls',0) for r in rows),geometry_states=len(rows)*2,repeated_output_byte_identical=True)
  print(json.dumps(dict(label=label,totals=report['applications'][label]['totals'])),flush=True);save()
 report['observed_exit_code']=0
except BaseException as error:report.update(observed_exit_code=1,failure=str(error));raise
finally:
 report['all_commands_terminal']=True;report['sdk_sources_after']={label:repository_source_identity(root) for label,root in sdks.items()};report['sdk_sources_unchanged']=report['sdk_sources_after']==sources
 for r in report['applications'].values():r['source_after']=identity(Path(r['root']));r['source_unchanged']=r['source_after']==r['source']
 if not report['sdk_sources_unchanged'] or any(not r['source_unchanged'] for r in report['applications'].values()):report.update(observed_exit_code=1,failure='source changed during pipeline')
 save()
raise SystemExit(report['observed_exit_code'])
