"""Implement shared physical intrinsic sizing and paired constraints."""
import fcntl
import json
import os
import shutil
import subprocess
from pathlib import Path

MAIN = Path('/home/nero/code/open-ui')
OLD = Path('/dev/shm/openui-native-caption-v2034')
ROOT = Path('/dev/shm/openui-native-intrinsic-api-fix-v2054')
lock = open('/tmp/openui-native-cargo-raster-owner.lock', 'a+')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
for name in ['cargo', 'rustc', 'ninja', 'pixel_compare']:
    assert subprocess.run(['pgrep', '-x', name], capture_output=True).returncode == 1
assert not ROOT.exists() and not subprocess.check_output(['git', 'status', '--porcelain'], cwd=OLD)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=OLD, text=True).strip()
assert head == 'c83d24f3cb76ac2f77346a88f73e53860f7f13b3'
subprocess.run(['git', 'worktree', 'add', '--no-checkout', '--detach', str(ROOT), head], cwd=MAIN, check=True, capture_output=True)
for encoded in subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', '-z', head], cwd=MAIN).split(b'\0'):
    if not encoded:
        continue
    name = encoded.decode()
    a, b = OLD / name, ROOT / name
    b.parent.mkdir(parents=True, exist_ok=True)
    if a.is_symlink():
        b.symlink_to(os.readlink(a))
    else:
        os.link(a, b)
subprocess.run(['git', 'read-tree', head], cwd=ROOT, check=True, capture_output=True)

def edit(name, transform):
    p = ROOT / name
    t = p.with_name(p.name + '.isolated-v2054')
    t.write_text(transform(p.read_text()))
    os.replace(t, p)

def intrinsic(s):
    old = 'else if permits_soft_wrap && deterministic_text_profile {'
    assert s.count(old) == 1
    s = s.replace(old, 'else if permits_soft_wrap {', 1)
    old = '''    } else if permits_soft_wrap {
        forced_lines
            .flat_map(|line| line.split(is_css_collapsible_whitespace))
            .filter(|segment| !segment.is_empty())
            .map(measure)
            .fold(LayoutUnit::zero(), |acc, width| acc.max_of(width))
    } else {
        max_content
    };'''
    assert s.count(old) == 1
    return s.replace(old, '''    } else {
        max_content
    };''', 1)

def relative(s):
    old = '    let line_height = used_line_height(metrics, line_height, font_size);'
    assert s.count(old) == 1
    new = '''    // ComputedStyle::ComputedLineHeightAsFixed first rounds font size to
    // LayoutUnit for relative values, then truncates the percent product.
    // Fixed line heights use FromFloatRound. Do this before half-leading so
    // a later ceil of the line extents cannot add a fractional grid cell.
    let font_size_fixed = openui_geometry::LayoutUnit::from_f32_round(font_size).to_f32();
    let line_height = match *line_height {
        LineHeight::Number(number) => openui_geometry::LayoutUnit::from_f32(
            font_size_fixed * (number * 100.0) / 100.0,
        ),
        LineHeight::Percentage(percent) => openui_geometry::LayoutUnit::from_f32(
            font_size_fixed * percent / 100.0,
        ),
        LineHeight::Length(px) => openui_geometry::LayoutUnit::from_f32_round(px),
        LineHeight::Normal => openui_geometry::LayoutUnit::from_f32(
            used_line_height(metrics, line_height, font_size),
        ),
    }.to_f32();'''
    return s.replace(old, new, 1)

def positioned(s):
    old = 'use crate::intrinsic_sizing::compute_intrinsic_block_sizes;'
    assert s.count(old) == 1
    s = s.replace(old, 'use crate::intrinsic_sizing::{compute_intrinsic_block_sizes, IntrinsicSizes};\nuse openui_geometry::MinMaxSizes;', 1)
    # Physical size constraints must consume one explicit physical projection.
    marker = '/// The edge of an out-of-flow box represented by one static-position axis.'
    helper = '''/// Project the legacy intrinsic accumulator into physical border-box axes.
/// Ordinary block descendants already use physical slots. A vertical IFC
/// reports advances in its inline slot and line thickness in its block slot.
fn physical_intrinsic_sizes(
    doc: &Document,
    node_id: NodeId,
    style: &ComputedStyle,
    sizes: IntrinsicSizes,
    border: &BoxStrut,
    padding: &BoxStrut,
) -> (MinMaxSizes, MinMaxSizes) {
    let horizontal_edges = border.left + border.right + padding.left + padding.right;
    let vertical_edges = border.top + border.bottom + padding.top + padding.bottom;
    if !style.writing_mode.is_horizontal()
        && crate::inline::algorithm::has_inline_children(doc, node_id)
        && !crate::block::has_block_children(doc, node_id)
        && !style.display.is_flex()
        && !style.display.is_grid()
        && !style.display.is_table_wrapper()
    {
        let width = if crate::containment::physical_width_is_contained(style) {
            MinMaxSizes::new(sizes.min_content_inline_size, sizes.max_content_inline_size)
        } else {
            MinMaxSizes::new(
                (sizes.min_content_block_size - vertical_edges).clamp_negative_to_zero() + horizontal_edges,
                (sizes.max_content_block_size - vertical_edges).clamp_negative_to_zero() + horizontal_edges,
            )
        };
        let height = crate::intrinsic_sizing::compute_logical_intrinsic_inline_sizes(doc, node_id);
        (width, height)
    } else {
        (
            MinMaxSizes::new(sizes.min_content_inline_size, sizes.max_content_inline_size),
            MinMaxSizes::new(sizes.min_content_block_size, sizes.max_content_block_size),
        )
    }
}

/// Resolve a physical fit-content border-box opportunity from insets/margins.
fn fit_content_size(
    preferred: MinMaxSizes,
    containing_size: LayoutUnit,
    percentage_base: LayoutUnit,
    start: &openui_geometry::Length,
    end: &openui_geometry::Length,
    start_margin: &openui_geometry::Length,
    end_margin: &openui_geometry::Length,
    edges: LayoutUnit,
    static_interval: StaticPositionInterval,
) -> LayoutUnit {
    let zero = LayoutUnit::zero();
    let opportunity = if start.is_auto() && end.is_auto() {
        static_interval.size()
    } else {
        containing_size - resolve_length(start, containing_size, zero, zero)
            - resolve_length(end, containing_size, zero, zero)
    };
    let margins = resolve_margin_or_padding(start_margin, percentage_base)
        + resolve_margin_or_padding(end_margin, percentage_base);
    let available = (opportunity - margins - edges).clamp_negative_to_zero();
    let min = (preferred.min - edges).clamp_negative_to_zero();
    let max = (preferred.max - edges).clamp_negative_to_zero();
    max.min_of(min.max_of(available)) + edges
}

'''
    assert s.count(marker) == 1
    s = s.replace(marker, helper + marker, 1)
    start = s.index('    let vertical_inline_formatting_context =')
    end = s.index('    let shrink_to_fit_max =', start)
    s = s[:start] + '''    let (intrinsic_width, intrinsic_height) = physical_intrinsic_sizes(
        doc, candidate.node_id, style, intrinsic, &border, &padding,
    );
    let (intrinsic_width_min, intrinsic_width_max) = (intrinsic_width.min, intrinsic_width.max);
''' + s[end:]
    old = '            let known_bb_width = intrinsic_width_max;'
    assert s.count(old) == 1
    s = s.replace(old, '''            let known_bb_width = fit_content_size(
                intrinsic_width, cb_width, cb_width, &style.left, &style.right,
                &style.margin_left, &style.margin_right, border_padding_h,
                StaticPositionInterval::new(static_left, cb_width,
                    candidate.static_position_horizontal_edge, sp_horizontal_start_is_left),
            );''', 1)
    start = s.index('    // Override height for intrinsic keywords')
    end = s.index('        } else if style.display.is_table_wrapper()', start)
    block = s[start:end].replace('intrinsic.min_content_block_size', 'intrinsic_height.min').replace('intrinsic.max_content_block_size', 'intrinsic_height.max')
    block = block.replace('let known_bb_height = intrinsic_height.max;', '''let known_bb_height = fit_content_size(
                intrinsic_height, cb_height, cb_width, &style.top, &style.bottom,
                &style.margin_top, &style.margin_bottom, border_padding_v,
                StaticPositionInterval::new(static_top, cb_height,
                    candidate.static_position_vertical_edge, sp_vertical_start_is_top),
            );''')
    s = s[:start] + block + s[end:]
    # Both limits are border-box values; neither intrinsic minimum may return
    # before the maximum is applied. Physical projection is shared above.
    for axis, dimension, edges in [('inline', 'width', 'border_padding_h'), ('block', 'height', 'border_padding_v')]:
        start = s.index('    let min_raw =', s.index('fn apply_min_max_' + axis + '('))
        end = s.index('    // CSS Sizing 4', start)
        projection = '0' if axis == 'inline' else '1'
        block = f'''    let intrinsic = (style.min_{dimension}.is_content_or_intrinsic()
        || style.max_{dimension}.is_content_or_intrinsic()).then(|| {{
        physical_intrinsic_sizes(doc, node_id, style,
            compute_intrinsic_block_sizes(doc, node_id), border, padding).{projection}
    }});
    let min_raw = if style.min_{dimension}.is_auto() {{
        zero
    }} else if let Some(sizes) = intrinsic.filter(|_| style.min_{dimension}.is_content_or_intrinsic()) {{
        if style.min_{dimension}.is_min_content() {{ sizes.min }} else {{ sizes.max }}
    }} else {{
        resolve_length(&style.min_{dimension}, cb_{dimension}, zero, zero)
    }};
    let min_bb = if style.min_{dimension}.is_content_or_intrinsic() {{
        min_raw.max_of({edges})
    }} else if min_raw > zero {{
        if style.box_sizing == BoxSizing::ContentBox {{ min_raw + {edges} }}
        else {{ min_raw.max_of({edges}) }}
    }} else {{ zero }};
    let max_raw = if let Some(sizes) = intrinsic.filter(|_| style.max_{dimension}.is_content_or_intrinsic()) {{
        if style.max_{dimension}.is_min_content() {{ sizes.min }} else {{ sizes.max }}
    }} else {{
        resolve_length(&style.max_{dimension}, cb_{dimension}, LayoutUnit::max(), LayoutUnit::max())
    }};
    let max_bb = if max_raw == LayoutUnit::max() {{
        max_raw
    }} else if style.max_{dimension}.is_content_or_intrinsic() {{
        max_raw.max_of({edges})
    }} else if style.box_sizing == BoxSizing::ContentBox {{
        max_raw + {edges}
    }} else {{ max_raw.max_of({edges}) }};

'''
        s = s[:start] + block + s[end:]
    old = '    let child_space = axes.child_constraint_space('
    assert s.count(old) == 1
    s = s.replace(old, '''    // A vertical auto width is a content-sized logical block dimension
    // unless opposing insets or an aspect ratio already determine it.
    let content_sized_width = !axes.child.is_horizontal() && style.width.is_auto()
        && (style.left.is_auto() || style.right.is_auto()) && !width_from_ar;
    let child_space = axes.child_constraint_space(''', 1)
    s = s.replace('        true, // Physical width is pre-determined by the constraint equation.', '        !content_sized_width,', 1)
    old = '''    } else {
        resolved_width
    };

    // CSS 2.1 §10.7: For auto-height'''
    assert s.count(old) == 1
    s = s.replace(old, '''    } else if content_sized_width {
        apply_min_max_inline(doc, candidate.node_id, style, cb_width, cb_height,
            child_fragment.size.width, &border, &padding, false)
    } else {
        resolved_width
    };

    // CSS 2.1 §10.7: For auto-height''', 1)
    old = '''        && candidate.static_position_horizontal_edge != StaticPositionEdge::Start
    {'''
    assert s.count(old) == 1
    s = s.replace(old, '''        && (content_sized_width || candidate.static_position_horizontal_edge != StaticPositionEdge::Start)
    {''', 1)
    return s

edit('bindings/rust/openui-layout/src/intrinsic_sizing.rs', intrinsic)
edit('bindings/rust/openui-layout/src/out_of_flow.rs', positioned)
edit('bindings/rust/openui-text/src/font/relative.rs', relative)
test = ROOT / 'bindings/rust/openui/tests/native_intrinsic_constraints.rs'
assert not test.exists()
shutil.copy2('/tmp/openui-native-intrinsic-constraints-guard-v2054.rs', test)
paths = ['bindings/rust/openui-layout/src/intrinsic_sizing.rs', 'bindings/rust/openui-layout/src/out_of_flow.rs', 'bindings/rust/openui-text/src/font/relative.rs', 'bindings/rust/openui/tests/native_intrinsic_constraints.rs']
subprocess.run(['bash', '-c', 'ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true ' + ' '.join(paths)], cwd=ROOT, check=True)
subprocess.run(['git', 'add', *paths], cwd=ROOT, check=True)
subprocess.run(['git', 'commit', '-m', 'Resolve native intrinsic dimensions and paired bounds through shared physical axes'], cwd=ROOT, check=True, capture_output=True)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=OLD)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
print(json.dumps(dict(root=str(ROOT), source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(), base_unchanged=True, applied=False, release_qualification=False)))
