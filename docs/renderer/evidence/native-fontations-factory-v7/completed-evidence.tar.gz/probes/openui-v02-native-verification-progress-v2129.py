"""Read the active owner receipt and small progress tails; run no renderer."""
import json
import os
from pathlib import Path

root = Path('/home/nero/code/open-ui/out/renderer-evidence/native-viewport-scroll-v1/native-intrinsic-verification-pipeline-v2120')
data = json.loads((root / 'receipt.json').read_bytes())
process = data.get('current_process')
alive = False
if process:
    try:
        os.kill(process['pid'], 0)
        alive = True
    except ProcessLookupError:
        pass
print(json.dumps(dict(all_commands_terminal=data['all_commands_terminal'],
    current_process=process, current_process_alive=alive,
    completed_matrices={k: v['results'] for k, v in data['matrices'].items()})))
if process:
    log = root / (process['stage'] + '.log')
    if log.exists():
        with log.open('rb') as stream:
            stream.seek(max(0, log.stat().st_size - 2048))
            lines = stream.read().decode(errors='replace').splitlines()
        for line in lines[-2:]:
            print(line[:500])
