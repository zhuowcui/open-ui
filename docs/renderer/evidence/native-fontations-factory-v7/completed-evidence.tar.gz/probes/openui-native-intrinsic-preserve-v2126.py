"""Preserve completed native API work, failed trials and immutable Chromium inputs."""
import gzip,hashlib,json,subprocess,tarfile
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';ROOT=Path('/dev/shm/openui-native-intrinsic-api-retry-v2118');NAME='native-fontations-factory-v7';OUT=MAIN/'docs/renderer/evidence'/NAME;INDEX=MAIN/'docs/renderer/generated'/(NAME+'.json')
assert not OUT.exists() and not INDEX.exists()
load=lambda p:json.loads(p.read_bytes())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for c in iter(lambda:f.read(2**20),b''):h.update(c)
 return h.hexdigest()
owner=load(RAW/'native-intrinsic-verification-pipeline-v2120/receipt.json');assert owner['all_commands_terminal'] and owner['source_unchanged'] and owner['native_intrinsic_app_source_unchanged']
assert owner['native_intrinsic_guard_actually_executed'] and owner['native_fractional_line_height_guard_actually_executed']
api=load(RAW/'native-intrinsic-native-api-audit-v2123.json');audit=load(RAW/'native-intrinsic-renderer-audit-v2124.json');assert api['source']==audit['source']==owner['source']
proof=load(RAW/'native-intrinsic-source-repro-v2105/receipt.json');assert proof['all_commands_terminal'] and all(r['entire_tracked_tree_exact'] for r in proof['sources'])
final_proof=next(r for r in proof['sources'] if r['target_commit']==owner['source']['commit']);assert final_proof['source']==owner['source']
checks=load(RAW/'native-intrinsic-checks-v2122/receipt.json');assert checks['source']==owner['source'] and all(r['observed_exit_code']==0 for r in checks['checks'])
chrome=load(RAW/'native-line-height-chromium-v2086/receipt.json');assert chrome['all_commands_terminal'] and chrome['observed_exit_code']==0 and chrome['totals']['cases']==270
hosted=load(RAW/'native-caption-umbrella-hosted-v2061/receipt.json');assert hosted['all_commands_terminal'] and hosted['failed_jobs']==0 and hosted['all_nine_native_guards_executed_and_passed_in_hosted_parity']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
OUT.mkdir(parents=True);members={}
def add(name,p):assert name not in members and p.is_file();members[name]=p
skip={'pixel_compare','openui-native-intrinsic-api','baseline-openui-native-intrinsic-api','current-openui-native-intrinsic-api','native_glyph_coverage','libopenui_ffi.so','libopenui.so.0','compiler-tmp','chrome-tmp'}
directories=['native-intrinsic-api-pipeline-v2051','native-intrinsic-api-chromium-v2052','native-intrinsic-keywords-primary-v2053','native-intrinsic-api-pipeline-v2056','native-intrinsic-api-pipeline-v2060','native-caption-umbrella-hosted-v2061','native-intrinsic-verification-pipeline-v2064','native-intrinsic-checks-v2066','native-intrinsic-matched-pipeline-v2069','native-line-height-primary-v2073','native-line-height-chromium-v2074','native-line-height-chromium-v2078','native-line-height-converter-primary-v2079','native-line-height-chromium-v2082','native-intrinsic-verification-pipeline-v2083','native-intrinsic-checks-v2085','native-line-height-chromium-v2086','native-intrinsic-engine-prepare-v2090','native-intrinsic-verification-pipeline-v2120','native-intrinsic-font-consumer-v2121','native-intrinsic-checks-v2122','native-intrinsic-source-repro-v2105','native-intrinsic-regions-v2134','native-intrinsic-font-primary-v2112']
directories.extend(['native-intrinsic-verification-pipeline-v2097','native-intrinsic-checks-v2099'])
for name in directories:
 root=RAW/name
 for child in sorted(root.iterdir()):
  if child.name in skip or child.name.startswith('reproduction-index'):continue
  if child.name in ['full-matrix','expanded-matrix']:
   p=child/(child.name.removesuffix('-matrix')+'-summary.json');
   if p.exists():add(str(Path(name)/p.relative_to(root)),p)
   continue
  paths=[child] if child.is_file() else sorted(child.rglob('*'))
  for p in paths:
   if p.is_file() and p.name not in skip:add(str(Path(name)/p.relative_to(root)),p)
for name in ['native-intrinsic-api-audit-v2062.json','native-intrinsic-matched-audit-v2070.json','native-intrinsic-native-api-audit-v2123.json','native-intrinsic-renderer-audit-v2124.json']:add(name,RAW/name)
add('native-intrinsic-native-api-audit-v2101.json',RAW/'native-intrinsic-native-api-audit-v2101.json')
probes=['openui-verified-terminal-binary-relocation-v2057.py','openui-verified-terminal-binary-relocation-v2057.json','openui-native-intrinsic-api-prepare-v2050.py','openui-native-intrinsic-api-source-v2050.rs','openui-native-intrinsic-api-pipeline-v2051.py','openui-native-intrinsic-api-chromium-v2052.py','openui-native-intrinsic-api-chromium-main-v2052.py','openui-native-intrinsic-api-fix-prepare-v2054.py','openui-native-intrinsic-constraints-guard-v2054.rs','openui-native-intrinsic-api-pipeline-v2056.py','openui-native-intrinsic-api-fix-prepare-v2058.py','openui-native-intrinsic-api-pipeline-v2060.py','openui-native-caption-umbrella-hosted-collect-v2061.py','openui-native-intrinsic-api-audit-v2062.py','openui-native-intrinsic-verification-pipeline-v2064.py','openui-native-intrinsic-font-consumer-v2065.py','openui-native-intrinsic-checks-v2066.py','openui-native-intrinsic-matched-prepare-v2067.py','openui-native-intrinsic-matched-pipeline-v2069.py','openui-native-intrinsic-matched-audit-v2070.py','openui-native-intrinsic-renderer-audit-v2072.py','openui-native-line-height-chromium-v2074.py','openui-native-fractional-line-height-guard-v2075.rs','openui-native-line-height-chromium-v2078.py','openui-native-intrinsic-api-guard-prepare-v2080.py','openui-native-fractional-line-height-guard-v2080.rs','openui-native-line-height-chromium-v2082.py','openui-native-intrinsic-verification-pipeline-v2083.py','openui-native-intrinsic-font-consumer-v2084.py','openui-native-intrinsic-checks-v2085.py','openui-native-line-height-chromium-v2086.py','openui-native-intrinsic-engine-prepare-v2090.py','openui-native-intrinsic-engine-prepare-v2095.py','openui-native-intrinsic-verification-pipeline-v2120.py','openui-native-intrinsic-font-consumer-v2121.py','openui-native-intrinsic-checks-v2122.py','openui-native-intrinsic-native-api-audit-v2123.py','openui-native-intrinsic-renderer-audit-v2124.py','openui-verified-terminal-binary-relocation-v2103.py','openui-verified-terminal-binary-relocation-v2103.json','openui-native-pixel-binary-staging-v2104.py','openui-native-pixel-binary-staging-v2104.json','openui-native-intrinsic-source-repro-v2105.py','openui-native-intrinsic-preserve-v2126.py','openui-native-intrinsic-regions-v2134.py','openui-native-intrinsic-font-primary-v2112.py']
probes.extend(['openui-native-intrinsic-verification-pipeline-v2097.py','openui-native-intrinsic-font-consumer-v2098.py','openui-native-intrinsic-checks-v2099.py','openui-native-intrinsic-native-api-audit-v2101.py','openui-verified-terminal-binary-relocation-v2114.py','openui-verified-terminal-binary-relocation-v2114.json','openui-pinned-oracle-cache-relocation-v2117.py','openui-pinned-oracle-cache-relocation-v2117-failed.json','openui-pinned-oracle-cache-relocation-v2131.py','openui-pinned-oracle-cache-relocation-v2131.json','openui-native-intrinsic-retry-prepare-v2118.py','openui-native-intrinsic-docs-v2127.py','openui-native-intrinsic-pr-body-v2128.py','openui-v02-native-verification-progress-v2129.py'])
probes.extend(['openui-native-intrinsic-regions-v2125.py','openui-native-intrinsic-regions-v2125-failed.json'])
for name in probes:add('probes/'+name,Path('/tmp')/name)
for number in [2050,2055,2059]:
 root=Path('/dev/shm/openui-native-intrinsic-api-v'+str(number))
 for name in ['Cargo.toml','Cargo.lock','src/main.rs','.gitignore']:add('native-api-sources/v'+str(number)+'/'+name,root/name)
for number in [2067,2068,2088,2096,2119]:
 root=(MAIN/'out/private-native-apps/native-intrinsic-matched-v2119') if number==2119 else Path('/dev/shm/openui-native-intrinsic-matched-v'+str(number))
 for name in ['Cargo.toml','Cargo.lock','src/main.rs','.gitignore']:add('native-api-sources/v'+str(number)+'/'+name,root/name)
patch=Path(final_proof['patch_path']);assert sha(patch)==final_proof['patch_sha256'];compressed=OUT/'measured-from-9f0d2211.patch.gz'
with compressed.open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',mtime=0) as gz:
  with patch.open('rb') as s:
   while c:=s.read(2**20):gz.write(c)
archive=OUT/'completed-evidence.tar.gz';records=[]
with archive.open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,p in sorted(members.items()):
    row=dict(name=name,bytes=p.stat().st_size,sha256=sha(p),source_path=str(p));info=tarfile.TarInfo(name);info.size=row['bytes'];info.mode=0o644;info.mtime=0
    with p.open('rb') as s:tar.addfile(info,s)
    records.append(row)
with tarfile.open(archive,'r:gz') as tar:
 entries=tar.getmembers();assert len(entries)==len(records)
 for entry,row in zip(entries,records):
  assert entry.name==row['name'];h=hashlib.sha256()
  with tar.extractfile(entry) as s:
   for c in iter(lambda:s.read(2**20),b''):h.update(c)
  assert h.hexdigest()==row['sha256']
residuals=[r for r in api['observations'] if not r['full_rect_exact']]
record=dict(schema_version=1,source=owner['source'],source_after=owner['source_after'],all_commands_terminal=True,release_qualification=False,candidate_applied_to_umbrella=False,promotion_allowed=False,new_release_states_admitted=0,javascript_executed_by_openui=False,pixel_tolerance=0,
 reviewed_shared_changes=['Project intrinsic contributions into physical positioned axes; apply both minimum and maximum bounds with minimum winning conflicts.', 'Fit-content consumes the opportunity after physical insets and margins.', 'Vertical automatic width uses laid-out column extent unless insets or a real aspect ratio fix it.', 'Unicode soft line breaks apply to ordinary font families.', 'Numeric line height uses the rounded font-size LayoutUnit and a truncated relative product; authored percentage resolves through the measured integer-percent fixed-length conversion.'],
 native_geometry=dict(totals=api['totals'],geometry_only=True,native_pixels_captured=False,viewport_policy_matched=True,current_output_identical_to_measured_4c2f2e4b=api['current_native_output_identical_to_4c2f2e4b'],remaining_comparisons=residuals,remaining_investigation_owner='shared intrinsic text advance and strike selection',remaining_root_cause_reviewed=False,no_pixel_qualification_from_rectangles=True),
 fractional_line_height=dict(chromium_capture_source=chrome['source'],cases=270,repeated_capture_pairs=5,all_native_public_callback_guard_cases_executed=True,guard_actual_result=next(s for s in owner['steps'] if s['name']=='native-intrinsic-guard'),prior_approximate_guard_replaced_with_exact_chromium_value=True,prior_failed_guard_and_capture_preserved=True),
 workspace_tests=next(s for s in owner['steps'] if s['name']=='workspace'),read_only_checks_passed=len(checks['checks']),suites={name:{k:v for k,v in row.items() if k!='changed_comparisons'} for name,row in audit['suites'].items()},native_font_totals=audit['native_totals'],native_font_image_changes=audit['native_image_changes'],native_font_geometry_changes=audit['native_geometry_changes'],
 hosted_umbrella=dict(source=hosted['source'],successful_jobs=hosted['successful_jobs'],skipped_jobs=hosted['skipped_jobs'],failed_jobs=hosted['failed_jobs'],all_nine_native_guards_executed_and_passed=True,not_attributed_to_private_native_api_source=True),failed_attempts_preserved=True,prior_disk_guard_stop_preserved=True,serial_cache_transfer_stop_preserved=True,pinned_oracle_cache_relocation_all_files_byte_verified=True,original_viewport_mismatch_preserved_and_not_counted_as_current_api_failure=True,full_census_summaries_archived=True,full_census_individual_image_caches_not_duplicated=True,formal_original_residual_ownership_unchanged=True,
 archive=dict(path=str(archive.relative_to(MAIN)),bytes=archive.stat().st_size,sha256=sha(archive),all_members_hash_verified=True,members=records),reproduction_patch=dict(path=str(compressed.relative_to(MAIN)),bytes=compressed.stat().st_size,sha256=sha(compressed),reproduction=final_proof),all_failed_measured_sources_reconstruct_exactly=True,probe_sha256=sha(Path(__file__)))
INDEX.write_text(json.dumps(record,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(index=str(INDEX),index_sha256=sha(INDEX),archive_bytes=archive.stat().st_size,archive_members=len(records),source=owner['source']['commit'])),flush=True)
