"""Archive terminal native font-unit trials with actual gates and source identities."""
import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1'
INDEX=MAIN/'docs/renderer/generated/native-font-relative-v1.json'
ARCHIVE=MAIN/'docs/renderer/evidence/native-font-relative-v1/completed-evidence.tar.gz'
assert not INDEX.exists() and not ARCHIVE.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_bytes())
current_path=RAW/'native-relative-percent-pipeline-v2204/receipt.json';current=load(current_path)
old_path=RAW/'native-relative-fix-pipeline-v2197/receipt.json';old=load(old_path)
for r in [current,old]:
    assert r['all_commands_terminal'] and r['source_unchanged'] and r['public_source_unchanged']
    assert r['native_app_source_unchanged']
    assert subprocess.run(['ps','-p',str(r['owner_pid'])],capture_output=True).returncode!=0
inputs={}
def add(p,name):
    assert p.is_file() and name not in inputs
    inputs[name]=p
def direct(directory,prefix):
    for p in sorted(directory.iterdir()):
        if p.is_file() and p.suffix in ['.json','.log','.patch','.rs','.cc','.h']:
            add(p,prefix+'/'+p.name)
for name in ['native-relative-fix-pipeline-v2197','native-relative-percent-pipeline-v2204',
    'native-relative-fix-checks-v2199','native-relative-percent-checks-v2206',
    'native-relative-source-repro-v2209','native-relative-source-repro-v2210']:
    direct(RAW/name,'records/'+name)
for suite in current['matrices']:
    matrix=current_path.parent/(suite+'-matrix')
    direct(matrix,'matrices/'+suite)
    if suite=='sizing-neighbors':
        for p in sorted(matrix.rglob('*')):
            if p.is_file() and p.suffix in ['.png','.html']:
                add(p,'matrices/'+suite+'/images/'+str(p.relative_to(matrix)))
for name in ['native-font-relative-primary-v2192','native-font-cache-primary-v2193']:
    direct(RAW/name,'primary-source/'+name)
add(RAW/'native-relative-units-diagnostic-v2194.json','baseline/native-relative-units-diagnostic-v2194.json')
add(RAW/'native-font-relative-api-review-v2212.json','native-api-scope/native-font-relative-api-review-v2212.json')
add(RAW/'native-relative-regression-review-v2222.json','regression-review/native-relative-regression-review-v2222.json')
for profile in current['matrices'].get('full',{}).get('changed_comparisons',[]):
    for origin, directory in [('candidate',current_path.parent/'full-matrix'),('accepted',RAW/'native-event-targets-clean-full-v1456')]:
        case=directory/profile['profile']/profile['id']
        for filename in ['openui.png','chromium.png','test.html']:
            add(case/filename,'regression-review/'+origin+'/'+profile['profile']+'/'+profile['id']+'/'+filename)

add(Path('/tmp/openui-native-font-relative-api-review-v2212.py'),'probes-and-receipts/openui-native-font-relative-api-review-v2212.py')
add(RAW/'native-relative-units-pipeline-v2189/receipt.json','baseline/successful-chromium-diagnostic-receipt.json')
for app in ['native-relative-units-v2196','native-relative-units-v2203']:
    for relative in ['Cargo.toml','Cargo.lock','src/main.rs']:
        add(MAIN/'out/private-native-apps'/app/relative,'native-apps/'+app+'/'+relative)
for pattern in [
    'openui-native-relative-fix-prepare-v2195.*','openui-native-relative-fix-v2195.patch',
    'openui-native-relative-fix-pipeline-v2197.py','openui-native-relative-fix-checks-v2199.py',
    'openui-native-relative-percent-prepare-v2202.py','openui-native-relative-percent-prepare-v2202-failed.json',
    'openui-native-relative-percent-prepare-v2207.*','openui-native-relative-percent-v2202.patch',
    'openui-native-relative-percent-pipeline-v2204.py','openui-native-relative-percent-checks-v2206.py',
    'openui-native-relative-source-repro-v2209.py','openui-native-relative-source-repro-v2210.py']:
    matches=list(Path('/tmp').glob(pattern));assert matches,pattern
    for p in matches:add(p,'probes-and-receipts/'+p.name)
add(Path(__file__),'probes-and-receipts/'+Path(__file__).name)
ARCHIVE.parent.mkdir(parents=True)
members=[]
with ARCHIVE.open('xb') as output:
    with gzip.GzipFile(filename='',mode='wb',fileobj=output,mtime=0,compresslevel=6) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as tar:
            for name,p in sorted(inputs.items()):
                raw=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0
                tar.addfile(info,io.BytesIO(raw));members.append(dict(name=name,source_path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
with tarfile.open(ARCHIVE,'r:gz') as tar:
    assert [m.name for m in tar.getmembers()]==[m['name'] for m in members]
    for row in members:
        raw=tar.extractfile(row['name']).read()
        assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'] and sha(inputs[row['name']])==row['sha256']
checks=load(RAW/'native-relative-percent-checks-v2206/receipt.json');assert checks['source']==current['source']
complete=all(s in current['matrices'] for s in ['full','expanded','focused','primitive'])
safe=complete and all(not row['worsened_comparisons'] and not row['exact_losses'] for row in current['matrices'].values())
report=dict(schema_version=1,source=current['source'],source_after=current['source_after'],source_unchanged=True,
    all_commands_terminal=True,candidate_applied_to_umbrella=False,
    native_geometry=current['native_geometry'],native_unit_audit_sha256=current['native_unit_audit_sha256'],
    native_callbacks_per_run=current['native_callbacks_per_run'],native_outputs_repeat_byte_identically=True,
    native_pixels_captured=False,manual_helper_does_not_complete_reactive_native_unit_declarations=True,
    stages=current['steps'],matrices=current['matrices'],whole_owner_actual_exit=current['observed_exit_code'],
    complete_pixel_matrices_executed=complete,pixel_no_regression_gate_passed=safe,
    read_only_checks=checks['checks'],read_only_checks_passed=sum(r['observed_exit_code']==0 for r in checks['checks']),
    earlier_failed_native_trial=dict(source=old['source'],native_geometry=old['native_geometry'],actual_exit=old['observed_exit_code'],
        failure=old['failure'],workspace_abi_and_pixel_matrices_not_run=True,receipt_sha256=sha(old_path)),
    all_source_trees_reconstruct_exactly=True,failed_preparation_and_native_trial_preserved=True,
    primary_reviews_preserved=True,chromium_geometry_input_unchanged=True,no_intrinsic_sizing_or_fontations_changes_included=True,
    javascript_executed_by_openui=False,pixel_tolerance=0,release_qualification=False,promotion_allowed=False,
    new_release_states_admitted=0,formal_residual_ownership_unchanged=True,
    archive=dict(path=str(ARCHIVE.relative_to(MAIN)),bytes=ARCHIVE.stat().st_size,sha256=sha(ARCHIVE),all_members_hash_verified=True,members=members),
    probe_sha256=sha(Path(__file__)))
INDEX.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(index=str(INDEX),index_sha256=sha(INDEX),archive_bytes=ARCHIVE.stat().st_size,
    archive_members=len(members),native_geometry=current['native_geometry'],complete_pixel_matrices=complete,pixel_no_regression=safe)),flush=True)
