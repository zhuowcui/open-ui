"""Qualify a native font-unit correction through owned Rust callbacks and renderer matrices."""
import collections,fcntl,hashlib,json,os,re,shutil,signal,subprocess,sys,time
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');ROOT=MAIN/'out/private-native-relative-api-v2195'
APP=MAIN/'out/private-native-apps/native-relative-units-v2196'
RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';NAME='native-relative-fix-pipeline-v2197'
OUT=RAW/NAME;STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/NAME
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for program in ['cargo','rustc','ninja','pixel_compare']:
    assert subprocess.run(['pgrep','-x',program],capture_output=True).returncode==1
assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
tmp=STORE/'compiler-tmp';tmp.mkdir()
env=dict(os.environ,OPENUI_NATIVE_WHOLE_OWNER=NAME,CARGO_TARGET_DIR='/mnt/e/openui-v02-cargo-c73754e2/target',
    CARGO_INCREMENTAL='0',RUST_MIN_STACK='4194304',CARGO_BUILD_JOBS='4',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(tmp),
    CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
sys.path.insert(0,str(ROOT/'tools/qualification'))
from renderer_source_identity import repository_source_identity
from residuals import canonical_sha256
source=repository_source_identity(ROOT);public=repository_source_identity(MAIN)
assert source['clean'] and source['commit']=='cea2310c91ef9f312617e03c38a62eca7930e733'
assert public['clean'] and public['commit']=='1dd7a23ea51a1ee7fceff1b659b6b999390fbad8'
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(2**20),b''):h.update(b)
    return h.hexdigest()
load=lambda p:json.loads(p.read_bytes())
tracked=ROOT/'tests/pixel_text/openui_renders/basic_text_openui.png'
if tracked.stat().st_nlink>1:
    temp=tracked.with_name(tracked.name+'.owned-copy-v2197');shutil.copy2(tracked,temp);os.replace(temp,tracked)
tracked_sha=sha(tracked)
refs={str(p.relative_to(ROOT)):sha(p) for p in (ROOT/'tests/pixel_text/chromium_refs').rglob('*') if p.is_file()}
oracle_path=RAW/'native-relative-units-pipeline-v2189/receipt.json';oracle=load(oracle_path)
assert oracle['all_commands_terminal'] and oracle['source_unchanged'] and oracle['observed_exit_code']==0
assert (APP/'src/main.rs').read_bytes()==(MAIN/'out/private-native-apps/native-relative-units-v2182/src/main.rs').read_bytes()
report=dict(schema_version=1,source=source,public_source=public,owner_pid=os.getpid(),steps=[],matrices={},
    all_commands_terminal=False,release_qualification=False,promotion_allowed=False,new_release_states_admitted=0,
    no_intrinsic_sizing_or_fontations_changes_included=True,pixel_tolerance=0,javascript_executed_by_openui=False,
    native_geometry_only=True,native_pixels_captured=False,oracle_receipt_sha256=sha(oracle_path),
    diagnostic_chromium_geometry_reused=True,manual_helper_does_not_complete_reactive_native_unit_declarations=True,
    probe_sha256=sha(Path(__file__)))
def save():(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
def run(name,command,cwd=ROOT/'bindings/rust',zero=True):
    path=OUT/(name+'.log')
    with path.open('xb') as stream:
        child=subprocess.Popen(command,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
        report['current_process']=dict(pid=child.pid,stage=name);save();guard=False
        while child.poll() is None:
            if shutil.disk_usage(MAIN).free<512*2**20 or shutil.disk_usage(STORE).free<10*2**30:
                guard=True;os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=20);break
            time.sleep(1)
        child.wait()
    totals=[tuple(map(int,m)) for m in re.findall(rb'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',path.read_bytes())]
    row=dict(name=name,observed_exit_code=child.returncode,disk_guard_triggered=guard,log_sha256=sha(path),
        passed=sum(t[0] for t in totals),failed=sum(t[1] for t in totals),ignored=sum(t[2] for t in totals))
    report.pop('current_process');report['steps'].append(row);save();print(json.dumps(row),flush=True)
    assert not guard and repository_source_identity(ROOT)==source and repository_source_identity(MAIN)==public
    assert sha(tracked)==tracked_sha and all(sha(ROOT/p)==h for p,h in refs.items())
    if zero:assert child.returncode==0,name
    return row
def app_identity():
    return dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=APP,text=True).strip(),
        tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=APP,text=True).strip(),
        clean=not subprocess.check_output(['git','status','--porcelain'],cwd=APP))
base=['cargo','--config','.cargo/config.chromium.toml']
def matrix(suite,name,ids=None,jobs=8):
    result=OUT/(name+'-matrix');result.mkdir()
    command=[sys.executable,str(ROOT/'tools/qualification/run_renderer_matrix.py'),'--suite',suite,'--results-dir',str(result),
        '--cache-dir','/mnt/e/openui-v02-qualification-d174ea0b/renderer-cache',
        '--oracle-cache-dir',str(MAIN/'out/renderer-qualification-cache/chromium-oracle'),
        '--pixel-compare',str(pixel),'--chrome',str(MAIN/'chrome/linux-147.0.7727.50/chrome-linux64/chrome'),
        '--raster-backend','cpu-skia','--jobs',str(jobs)]
    if ids:command.extend(a for test_id in ids for a in ['--test-id',test_id])
    stage=run(name+'-matrix',command,cwd=ROOT,zero=False)
    path=result/(suite+'-summary.json');s=load(path)
    assert s['source']==s['source_after']==source and s['results']['errors']==0
    prior_path=RAW/('native-event-targets-clean-'+suite+'-v1456')/(suite+'-summary.json');prior=load(prior_path)
    before={(p['profile'],r['id']):r for p in prior['profiles'] for r in p['tests']}
    changes=[];total=0
    invariants=['openui_png_sha256','openui_rgba_sha256','chromium_png_sha256','chromium_rgba_sha256',
        'chromium_oracle_identity_sha256','chromium_oracle_rgba_sha256','status','mismatched_pixels','diff_signature']
    for p in s['profiles']:
        assert p['result_sha256']==canonical_sha256(p['tests'])
        for row in p['tests']:
            total+=1;old=before[(p['profile'],row['id'])]
            assert all(row[f]==old[f] for f in invariants[2:6])
            changed=[f for f in invariants if row[f]!=old[f]]
            if changed:changes.append(dict(profile=p['profile'],id=row['id'],changed_fields=changed,
                prior_status=old['status'],status=row['status'],prior_mismatched_pixels=old['mismatched_pixels'],
                mismatched_pixels=row['mismatched_pixels'],more_wrong_pixels=row['mismatched_pixels']>old['mismatched_pixels'],
                exact_loss=old['status']=='exact' and row['status']!='exact',exact_gain=old['status']!='exact' and row['status']=='exact'))
    assert s['results']['total']==total
    entry=dict(summary_sha256=sha(path),results=s['results'],observed_exit_code=stage['observed_exit_code'],
        partial_selection_not_qualifying=bool(ids),comparisons=total,changed_comparisons=changes,
        worsened_comparisons=sum(x['more_wrong_pixels'] for x in changes),exact_losses=sum(x['exact_loss'] for x in changes),
        exact_gains=sum(x['exact_gain'] for x in changes))
    report['matrices'][name]=entry;save();print(json.dumps(dict(suite=name,results=s['results'],worsened=entry['worsened_comparisons'])),flush=True)
    return entry
try:
    run('locked-metadata',base+['metadata','--offline','--locked','--no-deps','--format-version','1'])
    metadata=json.loads(subprocess.check_output(base+['metadata','--offline','--locked','--no-deps','--format-version','1'],cwd=ROOT/'bindings/rust',env=env))
    packages=[p['name'] for p in metadata['packages'] if p['id'] in metadata['workspace_members']];assert len(packages)==18
    run('clean-workspace',base+['clean','--locked']+[a for p in packages for a in ['-p',p]])
    run('native-relative-guard',base+['test','--offline','--locked','-p','openui','--test','native_font_relative_lengths'])
    assert b'test native_font_relative_lengths_match_chromium_after_rust_callbacks ... ok' in (OUT/'native-relative-guard.log').read_bytes()
    report['native_relative_guard_actually_executed_and_passed']=True
    app_base=['cargo','--config',str(ROOT/'bindings/rust/.cargo/config.chromium.toml')]
    run('native-app-metadata',app_base+['metadata','--offline','--format-version','1'],cwd=APP)
    if subprocess.check_output(['git','status','--porcelain'],cwd=APP):
        subprocess.run(['git','add','.'],cwd=APP,check=True,capture_output=True)
        subprocess.run(['git','commit','-m','Lock the font-unit consuming app to shared metric corrections'],cwd=APP,check=True,capture_output=True)
    report['native_app_source']=app_identity();assert report['native_app_source']['clean']
    run('native-app-build',app_base+['build','--offline','--locked'],cwd=APP)
    binary=OUT/'openui-native-relative-units-api';shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/openui-native-relative-units-api',binary)
    report['native_binary_sha256']=sha(binary)
    run('native-first',[str(binary)],cwd=APP);run('native-second',[str(binary)],cwd=APP)
    assert (OUT/'native-first.log').read_bytes()==(OUT/'native-second.log').read_bytes()
    rows=[json.loads(s) for s in (OUT/'native-first.log').read_text().splitlines()];assert len(rows)==1200
    key=lambda r:tuple(r[k] for k in ['scale','family','size','line_height','unit','coefficient'])
    bykey={key(row):row for row in rows};assert len(bykey)==1200
    observations=[];counts=collections.Counter();groups=collections.defaultdict(collections.Counter)
    for profile in oracle['profiles']:
        for obs in profile['observations']:
            current=bykey.pop(key(obs['native_case']))
            for state in ['before','after']:
                exact=current[state]['bounds']==obs['chromium'][state]
                values=dict(states=1,exact=int(exact),different=int(not exact))
                counts.update(values);groups[current['unit']].update(values)
                observations.append(dict(case={k:current[k] for k in ['scale','family','size','line_height','unit','coefficient']},
                    state=state,native=current[state],chromium=obs['chromium'][state],full_rect_exact=exact))
    assert not bykey and counts['states']==2400
    path=OUT/'native-unit-audit.json';path.write_text(json.dumps(dict(source=source,totals=dict(counts),by_unit={k:dict(v) for k,v in groups.items()},
        observations=observations,geometry_only=True,native_pixels_captured=False,oracle_receipt_sha256=sha(oracle_path)),sort_keys=True,indent=2)+'\n')
    report.update(native_geometry=dict(counts),native_unit_audit_sha256=sha(path),native_callbacks_per_run=sum(r['callback_calls'] for r in rows),
        native_outputs_repeat_byte_identically=True)
    save();print(json.dumps(dict(native_geometry=dict(counts))),flush=True)
    assert counts['different']==0,'font-unit differences remain'
    run('workspace',base+['test','--offline','--locked','--workspace','--no-fail-fast','--features','openui-ffi/linux'])
    content=(OUT/'workspace.log').read_bytes()
    assert b'test native_font_relative_lengths_match_chromium_after_rust_callbacks ... ok' in content
    assert b'test reference_comparison_rejects_single_bit_rgba_changes ... ok' in content
    assert b'test surface_comparison_preserves_rgba_order_and_straight_alpha ... ok' in content
    report['native_and_strict_rgba_guards_actually_executed_in_workspace']=True
    run('ffi-build',base+['build','--offline','--locked','-p','openui-ffi','--features','linux'])
    lib=OUT/'libopenui_ffi.so';shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/libopenui_ffi.so',lib)
    (OUT/'libopenui.so.0').symlink_to(lib.name);report['ffi_binary_sha256']=sha(lib)
    run('ffi-consumers',[sys.executable,str(ROOT/'tools/ffi/verify_abi.py'),'--library',str(lib)],cwd=ROOT)
    run('pixel-build',base+['build','--offline','--locked','-p','pixel-compare','--bin','pixel_compare'])
    local=MAIN/'out/renderer-evidence/native-pixel-binary-stage-v2198';assert not local.exists();local.mkdir()
    pixel=OUT/'pixel_compare';pixel.symlink_to(local/'pixel_compare');shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/pixel_compare',pixel)
    report['pixel_binary_sha256']=sha(pixel)
    ident=load_identity=json.loads(subprocess.check_output([str(pixel),'build-source-identity'],cwd=ROOT,env=env))
    assert ident['source']==source;report['build_identity']=ident;save()
    assert shutil.disk_usage(MAIN).free>700*2**20
    risky=matrix('full','sizing-neighbors',['wpt/css_sizing/block-size-with-min-or-max-content-1-ref',
        'wpt/css_sizing/block-size-with-min-or-max-content-1a','wpt/css_sizing/block-size-with-min-or-max-content-1b'],jobs=4)
    assert not risky['exact_losses'] and not risky['worsened_comparisons'],'known sizing neighbors regress'
    for suite in ['full','expanded','focused','primitive']:
        entry=matrix(suite,suite,jobs=8 if suite in ['full','expanded'] else 4)
        assert entry['comparisons']==dict(full=22924,expanded=23728,focused=640,primitive=960)[suite]
    report['observed_exit_code']=int(any(e['worsened_comparisons'] or e['exact_losses'] for e in report['matrices'].values()))
except BaseException as error:
    report.update(observed_exit_code=1,failure=str(error));raise
finally:
    report.update(all_commands_terminal=True,source_after=repository_source_identity(ROOT),public_source_after=repository_source_identity(MAIN))
    report['source_unchanged']=report['source_after']==source;report['public_source_unchanged']=report['public_source_after']==public
    report['tracked_diagnostic_png_unchanged']=sha(tracked)==tracked_sha
    if 'native_app_source' in report:
        report['native_app_source_after']=app_identity();report['native_app_source_unchanged']=report['native_app_source_after']==report['native_app_source']
    save()
print(json.dumps(dict(observed_exit_code=report['observed_exit_code'],native_geometry=report.get('native_geometry'),
    suites={n:dict(exact=e['results']['exact'],worsened=e['worsened_comparisons']) for n,e in report['matrices'].items()})),flush=True)
raise SystemExit(report['observed_exit_code'])
