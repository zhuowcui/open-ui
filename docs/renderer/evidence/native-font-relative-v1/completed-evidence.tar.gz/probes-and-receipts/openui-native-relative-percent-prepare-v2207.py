"""Finish source-only preparation after a guard-format matching failure."""
import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');BASE=MAIN/'out/private-native-relative-api-v2195'
ROOT=MAIN/'out/private-native-relative-api-v2202';OLDAPP=MAIN/'out/private-native-apps/native-relative-units-v2196'
APP=MAIN/'out/private-native-apps/native-relative-units-v2203'
OUT=Path('/tmp/openui-native-relative-percent-prepare-v2207.json')
assert ROOT.exists() and not APP.exists() and not OUT.exists()
sys.path.insert(0,str(MAIN/'tools/qualification'));from renderer_source_identity import repository_source_identity
before=repository_source_identity(BASE);public=repository_source_identity(MAIN)
assert before['clean'] and before['commit']=='cea2310c91ef9f312617e03c38a62eca7930e733' and public['clean']
status=subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True)
assert status==' M bindings/rust/openui-engine/src/lib.rs\n'
failed=Path('/tmp/openui-native-relative-percent-prepare-v2202-failed.json');assert not failed.exists()
failed.write_text(json.dumps(dict(schema_version=1,observed_exit_code=1,source_only_preparation=True,
    failed_stage='guard text matching after rustfmt expanded the Ex tuple',
    source_before=before,source_after=repository_source_identity(ROOT),native_queries_started=0,
    cargo_commands_run=0,public_source=public,public_source_unchanged=True,release_qualification=False,
    original_probe_sha256=hashlib.sha256(Path('/tmp/openui-native-relative-percent-prepare-v2202.py').read_bytes()).hexdigest()),sort_keys=True,indent=2)+'\n')
engine=(ROOT/'bindings/rust/openui-engine/src/lib.rs').read_text()
assert 'font_size * (percent as i32) as f32 / 100.0' in engine
p=ROOT/'bindings/rust/openui/tests/native_font_relative_lengths.rs';text=p.read_text()
needle='        ] {';assert text.count(needle)==1
extra='            (\n                FontRelativeUnit::Lh,\n                LineHeight::Percentage(127.5),\n                59.421875,\n                64.671875,\n            ),\n'
temp=p.with_name(p.name+'.owned-copy-v2207');temp.write_text(text.replace(needle,extra+needle));os.replace(temp,p)
def configure(root):
    for name in ['user.name','user.email']:
        value=subprocess.check_output(['git','config','--get',name],cwd=MAIN,text=True).strip()
        subprocess.run(['git','config',name,value],cwd=root,check=True,capture_output=True)
files=['bindings/rust/openui-engine/src/lib.rs','bindings/rust/openui/tests/native_font_relative_lengths.rs']
subprocess.run(['bash','-c','ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true '+' '.join(files)],cwd=ROOT,check=True,capture_output=True)
subprocess.run(['git','add',*files],cwd=ROOT,check=True,capture_output=True)
patch=Path('/tmp/openui-native-relative-percent-v2202.patch');patch.write_bytes(subprocess.check_output(['git','diff','--cached','--binary'],cwd=ROOT))
subprocess.run(['git','commit','-m','Resolve native percentage line heights at Chromium computed style precision'],cwd=ROOT,check=True,capture_output=True)
source=repository_source_identity(ROOT);assert source['clean']
assert repository_source_identity(BASE)==before and repository_source_identity(MAIN)==public
APP.mkdir()
for name in ['Cargo.toml','Cargo.lock','src/main.rs']:
    dst=APP/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(OLDAPP/name,dst)
p=APP/'Cargo.toml';s=p.read_text();assert str(BASE) in s;p.write_text(s.replace(str(BASE),str(ROOT)))
subprocess.run(['git','init'],cwd=APP,check=True,capture_output=True);configure(APP)
subprocess.run(['git','add','.'],cwd=APP,check=True,capture_output=True)
subprocess.run(['git','commit','-m','Prepare the identical font-unit app with corrected percentage style conversion'],cwd=APP,check=True,capture_output=True)
report=dict(schema_version=1,source=source,parent_source=before,public_source=public,all_commands_terminal=True,
    source_only_preparation=True,native_queries_started=0,cargo_commands_run=0,source_patch=str(patch),
    source_patch_sha256=hashlib.sha256(patch.read_bytes()).hexdigest(),native_app=str(APP),
    failed_parent_trial_preserved=True,failed_preparation_receipt=str(failed),failed_preparation_receipt_sha256=hashlib.sha256(failed.read_bytes()).hexdigest(),no_intrinsic_sizing_or_fontations_changes_included=True,
    release_qualification=False,promotion_allowed=False,javascript_executed_by_openui=False,
    probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
OUT.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(report),flush=True)
