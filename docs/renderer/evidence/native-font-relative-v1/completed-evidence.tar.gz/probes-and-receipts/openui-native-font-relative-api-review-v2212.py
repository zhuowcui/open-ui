"""Record native declaration work still required beyond measured scalar helpers."""
import hashlib,json
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');ROOT=MAIN/'out/private-native-relative-api-v2202'
RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1'
OUT=RAW/'native-font-relative-api-review-v2212.json';assert not OUT.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=[ROOT/'bindings/rust/openui-style/src/property.rs',ROOT/'bindings/rust/openui-engine/src/lib.rs',
       ROOT/'bindings/rust/openui-text/src/font/relative.rs',ROOT/'bindings/rust/openui-text/src/font/platform.rs',
       ROOT/'bindings/rust/openui/src/document.rs',
       RAW/'native-font-relative-primary-v2192/simple_font_data.cc']
report=dict(schema_version=1,source_commit='4046d366eab0a9fc6aa161dc63d8e646104eab84',
    source_review_only=True,code_changes_applied=False,native_queries_started=0,chromium_processes_started=0,
    native_scalar_sweep_does_not_close_all_unit_apis=True,
    current_public_path='FontRelativeLengthResolver::from_style_in_collection followed by Element::set_width with a pixel length',
    needed_native_work=[
        dict(owner='openui-style and shared Engine native declaration resolution',
            observation='LengthValue has no Ch, Ex, or Lh declaration variant. The measured app recomputes scalar pixel lengths after its Rust callback.',
            needed='Expose native declarations that retain the authored unit and refresh when relevant font properties, inherited styles, fonts or viewport context change.'),
        dict(owner='shared Engine native declaration resolution',
            observation='Native declaration replay resolves font size first. Metric-dependent units also need the final family, weight, style, orientation and line height, independent of setter order.',
            needed='Resolve current and parent/root metric contexts before consuming ordinary lengths, including pseudo styles and animation mutations.'),
        dict(owner='shared Engine native declaration resolution',
            observation='Immediate native length conversion explicitly walks Length, Edges and Gap values. Other typed containers resolve lengths in style application.',
            needed='Apply the same metric context to every supported nested length container and preserve the unchanged-frame zero-work path.'),
        dict(owner='openui-text font-relative length selection',
            observation='The measured sweep is horizontal. Pinned Chromium ZeroInlineSize selects the vertical zero-glyph advance for VerticalUpright and uses orientation-dependent missing-glyph fallbacks.',
            needed='Qualify vertical ch metrics and missing-zero-glyph fallbacks through public native Rust queries; scalar horizontal passes do not waive them.'),
        dict(owner='native C interface',
            observation='The Rust scalar helper diagnostic does not expose new C unit declarations.',
            needed='Add C parity with append-only tags or operations and unchanged existing struct layouts, then run actual consuming C/C++ callers.')],
    source_records=[dict(path=str(p),sha256=sha(p)) for p in paths],
    javascript_executed_by_openui=False,javascript_or_script_bindings_are_not_a_solution=True,
    release_qualification=False,promotion_allowed=False,new_release_states_admitted=0,
    probe_sha256=sha(Path(__file__)))
OUT.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(path=str(OUT),sha256=sha(OUT),needed_native_work_items=len(report['needed_native_work']))),flush=True)
