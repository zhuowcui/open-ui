"""Preserve the failed font-unit trial and correct shared percentage style conversion."""
import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');BASE=MAIN/'out/private-native-relative-api-v2195'
ROOT=MAIN/'out/private-native-relative-api-v2202'
OLDAPP=MAIN/'out/private-native-apps/native-relative-units-v2196'
APP=MAIN/'out/private-native-apps/native-relative-units-v2203'
OUT=Path('/tmp/openui-native-relative-percent-prepare-v2202.json')
assert not ROOT.exists() and not APP.exists() and not OUT.exists()
sys.path.insert(0,str(MAIN/'tools/qualification'));from renderer_source_identity import repository_source_identity
before=repository_source_identity(BASE);public=repository_source_identity(MAIN)
assert before['clean'] and before['commit']=='cea2310c91ef9f312617e03c38a62eca7930e733' and public['clean']
prior=json.loads((MAIN/'out/renderer-evidence/native-viewport-scroll-v1/native-relative-fix-pipeline-v2197/receipt.json').read_bytes())
assert prior['all_commands_terminal'] and prior['source']==before and prior['source_unchanged']
subprocess.run(['git','clone','--shared','--no-checkout',str(BASE),str(ROOT)],check=True,capture_output=True)
def configure(root):
    for name in ['user.name','user.email']:
        value=subprocess.check_output(['git','config','--get',name],cwd=MAIN,text=True).strip()
        subprocess.run(['git','config',name,value],cwd=root,check=True,capture_output=True)
configure(ROOT);subprocess.run(['git','read-tree',before['commit']],cwd=ROOT,check=True,capture_output=True)
for name in filter(None,subprocess.check_output(['git','ls-files','-z'],cwd=BASE).decode().split('\0')):
    src=BASE/name;dst=ROOT/name;dst.parent.mkdir(parents=True,exist_ok=True)
    if src.is_symlink():dst.symlink_to(os.readlink(src))
    else:os.link(src,dst)
assert repository_source_identity(ROOT)==before
def edit(name,old,new):
    p=ROOT/name;s=p.read_text();assert s.count(old)==1,name
    t=p.with_name(p.name+'.owned-copy-v2202');t.write_text(s.replace(old,new));os.replace(t,p)
edit('bindings/rust/openui-engine/src/lib.rs',
    '''fields.line_height =
                        openui_style::LineHeight::Length(percent * font_size / 100.0);''',
    '''// Chromium fixes an authored percentage at this computed
                    // font size after converting the percentage to an int.
                    fields.line_height = openui_style::LineHeight::Length(
                        font_size * (percent as i32) as f32 / 100.0,
                    );''')
edit('bindings/rust/openui/tests/native_font_relative_lengths.rs',
    '''(FontRelativeUnit::Ex, LineHeight::Normal, 37.40625, 40.734375),''',
    '''(FontRelativeUnit::Ex, LineHeight::Normal, 37.40625, 40.734375),
            (
                FontRelativeUnit::Lh,
                LineHeight::Percentage(127.5),
                59.421875,
                64.671875,
            ),''')
files=['bindings/rust/openui-engine/src/lib.rs','bindings/rust/openui/tests/native_font_relative_lengths.rs']
subprocess.run(['bash','-c','ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true '+' '.join(files)],cwd=ROOT,check=True,capture_output=True)
subprocess.run(['git','add',*files],cwd=ROOT,check=True,capture_output=True)
patch=Path('/tmp/openui-native-relative-percent-v2202.patch');patch.write_bytes(subprocess.check_output(['git','diff','--cached','--binary'],cwd=ROOT))
subprocess.run(['git','commit','-m','Resolve native percentage line heights at Chromium computed style precision'],cwd=ROOT,check=True,capture_output=True)
source=repository_source_identity(ROOT);assert source['clean']
assert repository_source_identity(BASE)==before and repository_source_identity(MAIN)==public
APP.mkdir()
for name in ['Cargo.toml','Cargo.lock','src/main.rs']:
    dst=APP/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(OLDAPP/name,dst)
p=APP/'Cargo.toml';s=p.read_text();assert str(BASE) in s;p.write_text(s.replace(str(BASE),str(ROOT)))
subprocess.run(['git','init'],cwd=APP,check=True,capture_output=True);configure(APP)
subprocess.run(['git','add','.'],cwd=APP,check=True,capture_output=True)
subprocess.run(['git','commit','-m','Prepare the identical font-unit app with corrected percentage style conversion'],cwd=APP,check=True,capture_output=True)
report=dict(schema_version=1,source=source,parent_source=before,public_source=public,all_commands_terminal=True,
    source_only_preparation=True,native_queries_started=0,cargo_commands_run=0,source_patch=str(patch),
    source_patch_sha256=hashlib.sha256(patch.read_bytes()).hexdigest(),native_app=str(APP),
    failed_parent_trial_preserved=True,no_intrinsic_sizing_or_fontations_changes_included=True,
    release_qualification=False,promotion_allowed=False,javascript_executed_by_openui=False,
    probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
OUT.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(report),flush=True)
