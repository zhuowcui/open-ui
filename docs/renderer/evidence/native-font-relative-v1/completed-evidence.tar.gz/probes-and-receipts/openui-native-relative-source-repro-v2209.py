"""Reconstruct the exact isolated candidate from the public source without editing it."""
import hashlib, json, os, subprocess, sys
from pathlib import Path
MAIN = Path('/home/nero/code/open-ui')
ROOT = MAIN / 'out/private-native-relative-api-v2195'
OUT = MAIN / 'out/renderer-evidence/native-viewport-scroll-v1/native-relative-source-repro-v2209'
STORE = Path('/mnt/e/openui-v02-qualification-d174ea0b') / OUT.name
assert not OUT.exists() and not STORE.exists()
STORE.mkdir()
OUT.symlink_to(STORE, target_is_directory=True)
sys.path.insert(0, str(MAIN / 'tools/qualification'))
from renderer_source_identity import repository_source_identity
source = repository_source_identity(ROOT)
public = repository_source_identity(MAIN)
base = '1dd7a23ea51a1ee7fceff1b659b6b999390fbad8'
assert source['clean'] and source['commit'] == 'cea2310c91ef9f312617e03c38a62eca7930e733'
assert public['clean'] and public['commit'] == base
patch = OUT / 'source-from-public.patch'
patch.write_bytes(subprocess.check_output(['git', 'diff', '--binary', '--full-index', base, source['commit']], cwd=ROOT))
env = dict(os.environ, GIT_INDEX_FILE=str(STORE / 'independent-index'))
rows = []
for command in [['git', 'read-tree', base], ['git', 'apply', '--cached', str(patch)], ['git', 'write-tree']]:
 completed = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, text=True)
 rows.append(dict(command=command, observed_exit_code=completed.returncode, stdout=completed.stdout, stderr=completed.stderr))
 assert completed.returncode == 0
tree = subprocess.check_output(['git', 'rev-parse', source['commit'] + '^{tree}'], cwd=ROOT, text=True).strip()
assert rows[-1]['stdout'].strip() == tree
assert repository_source_identity(ROOT) == source and repository_source_identity(MAIN) == public
changes = subprocess.check_output(['git', 'diff', '--name-only', base, source['commit']], cwd=ROOT, text=True).splitlines()
assert len(changes) == 4
report = dict(schema_version=1, source=source, base_source=public, base_commit=base,
              entire_tracked_tree_exact=True, expected_tree=tree, reconstructed_tree=tree,
              changed_files=changes, source_unchanged=True, public_source_unchanged=True,
              private_fontations_and_caption_changes_included=False,
              patch_path=str(patch), patch_sha256=hashlib.sha256(patch.read_bytes()).hexdigest(),
              steps=rows, all_commands_terminal=True, cargo_commands_run=0,
              release_qualification=False, promotion_allowed=False,
              probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(OUT / 'receipt.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
print(json.dumps(dict(tree=tree, changed_files=len(changes), patch_sha256=report['patch_sha256'])), flush=True)
