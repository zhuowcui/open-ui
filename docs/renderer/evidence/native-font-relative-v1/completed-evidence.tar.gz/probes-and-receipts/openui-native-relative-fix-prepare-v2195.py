"""Prepare reviewed shared font-relative corrections in an isolated checkout."""
import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui')
ROOT=MAIN/'out/private-native-relative-api-v2195'
APP=MAIN/'out/private-native-apps/native-relative-units-v2196'
OLDAPP=MAIN/'out/private-native-apps/native-relative-units-v2182'
OUT=Path('/tmp/openui-native-relative-fix-prepare-v2195.json')
assert not ROOT.exists() and not APP.exists() and not OUT.exists()
sys.path.insert(0,str(MAIN/'tools/qualification'))
from renderer_source_identity import repository_source_identity
before=repository_source_identity(MAIN)
assert before['clean'] and before['commit']=='1dd7a23ea51a1ee7fceff1b659b6b999390fbad8'
subprocess.run(['git','clone','--shared','--no-checkout',str(MAIN),str(ROOT)],check=True,capture_output=True)
def configure(root):
    for name in ['user.name','user.email']:
        value=subprocess.check_output(['git','config','--get',name],cwd=MAIN,text=True).strip()
        subprocess.run(['git','config',name,value],cwd=root,check=True,capture_output=True)
configure(ROOT)
subprocess.run(['git','read-tree',before['commit']],cwd=ROOT,check=True,capture_output=True)
for name in filter(None,subprocess.check_output(['git','ls-files','-z'],cwd=MAIN).decode().split('\0')):
    src=MAIN/name; dst=ROOT/name; dst.parent.mkdir(parents=True,exist_ok=True)
    if src.is_symlink(): dst.symlink_to(os.readlink(src))
    else: os.link(src,dst)
assert repository_source_identity(ROOT)==before
def edit(name,old,new):
    p=ROOT/name
    s=p.read_text()
    assert s.count(old)==1,name
    t=p.with_name(p.name+'.owned-copy-v2195')
    t.write_text(s.replace(old,new))
    os.replace(t,p)
edit('bindings/rust/openui-text/src/font/collection.rs',
     'let size = adjusted_font_size(&typeface, descriptor, description);',
     '''// Blink's EffectiveFontSize uses the same two-decimal precision as
    // FontCacheKey, before platform data and glyph metrics are constructed.
    let adjusted_size = adjusted_font_size(&typeface, descriptor, description);
    let size = (adjusted_size * 100.0).floor() / 100.0;''')
edit('bindings/rust/openui-text/src/font/platform.rs',
     '''let (w, _) = sk_font.measure_str("0", None);
            w''',
     '''let (width, _) = sk_font.measure_str("0", None);
            // Blink's SkFontGetWidthForGlyph rounds advances for a font
            // without subpixel positioning, including the CSS ch metric.
            if sk_font.is_subpixel() {
                width
            } else {
                width.round()
            }''')
edit('bindings/rust/openui-text/src/font/relative.rs',
     'lh: used_line_height(metrics, line_height, font_size),',
     '''// CSS lh uses ComputedLineHeight, rather than the rounded
            // ComputedLineHeightAsFixed strut used by inline layout.
            lh: match *line_height {
                LineHeight::Number(number) => {
                    let basis = openui_geometry::LayoutUnit::from_f32(font_size).to_f32();
                    openui_geometry::LayoutUnit::from_f32(basis * (number * 100.0) / 100.0)
                        .to_f32()
                }
                _ => used_line_height(metrics, line_height, font_size),
            },''')
guard=ROOT/'bindings/rust/openui/tests/native_font_relative_lengths.rs'
assert not guard.exists()
guard.write_text('''use openui::prelude::*;
use openui_text::{FontRelativeLengthResolver, FontRelativeUnit};
use std::{cell::Cell, rc::Rc};

// Values come from the repeated pinned Chromium native-unit diagnostic,
// not from the Rust conversion under test.
#[test]
fn native_font_relative_lengths_match_chromium_after_rust_callbacks() {
    let fonts = FontCollection::deterministic_test();
    for scale in [1.0, 1.25, 1.5, 2.0, 3.0] {
        for (unit, line_height, before_width, after_width) in [
            (FontRelativeUnit::Ch, LineHeight::Normal, 47.5, 50.0),
            (FontRelativeUnit::Ex, LineHeight::Normal, 37.40625, 40.734375),
            (FontRelativeUnit::Lh, LineHeight::Number(1.2), 56.125, 61.046875),
        ] {
            let document = Document::with_font_collection_and_options(
                ViewportMetrics::from_logical_size(800.0, 600.0, scale).unwrap(),
                fonts.clone(),
                EngineOptions {
                    raster_configuration: RasterConfiguration::deterministic_aliased(false),
                },
            ).unwrap();
            let element = Element::create(&document, "div").unwrap();
            element.set_position(Position::Absolute).unwrap();
            element.set_left(Length::px(0.0)).unwrap();
            element.set_top(Length::px(0.0)).unwrap();
            element.set_height(LengthValue::px(10.0)).unwrap();
            element.set_font_family(FontFamilyList::single("Ahem")).unwrap();
            element.set_font_size(LengthValue::px(18.72)).unwrap();
            element.set_line_height(line_height).unwrap();
            element.set_text("X").unwrap();
            document.body().append_child(&element).unwrap();
            let style = element.computed_style().unwrap();
            let before = FontRelativeLengthResolver::from_style_in_collection(&style, fonts.clone());
            element.set_width(LengthValue::px(before.resolve(2.5, unit))).unwrap();
            let owned = element.bounding_rect().unwrap().unwrap();
            assert_eq!(owned.width, before_width, "{unit:?} at {scale}");
            let weak = element.downgrade();
            let target = weak.clone();
            let calls = Rc::new(Cell::new(0));
            let called = calls.clone();
            element.on("click", move |_| {
                target.upgrade().unwrap().set_font_size(LengthValue::px(20.37)).unwrap();
                called.set(called.get()+1);
            }).unwrap();
            element.click().unwrap();
            let after_style = element.computed_style().unwrap();
            let after = FontRelativeLengthResolver::from_style_in_collection(&after_style, fonts.clone());
            element.set_width(LengthValue::px(after.resolve(2.5, unit))).unwrap();
            assert_eq!(element.bounding_rect().unwrap().unwrap().width, after_width, "{unit:?} at {scale}");
            assert_eq!(calls.get(), 1);
            assert_eq!(style.font_size, 18.72);
            assert_eq!(owned.width, before_width);
            assert_eq!(before.resolve(2.5, unit), FontRelativeLengthResolver::from_style_in_collection(&style, fonts.clone()).resolve(2.5, unit));
            drop(element);
            drop(document);
            assert!(weak.upgrade().is_none());
        }
    }
}
''')
files=['bindings/rust/openui-text/src/font/collection.rs','bindings/rust/openui-text/src/font/platform.rs',
       'bindings/rust/openui-text/src/font/relative.rs','bindings/rust/openui/tests/native_font_relative_lengths.rs']
subprocess.run(['bash','-c','ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true '+' '.join(files)],cwd=ROOT,check=True,capture_output=True)
subprocess.run(['git','add',*files],cwd=ROOT,check=True,capture_output=True)
patch=Path('/tmp/openui-native-relative-fix-v2195.patch')
patch.write_bytes(subprocess.check_output(['git','diff','--cached','--binary'],cwd=ROOT))
subprocess.run(['git','commit','-m','Use shared Chromium font cache and font-relative metric conversions'],cwd=ROOT,check=True,capture_output=True)
source=repository_source_identity(ROOT)
assert source['clean'] and repository_source_identity(MAIN)==before
APP.mkdir()
for name in ['Cargo.toml','Cargo.lock','src/main.rs']:
    dst=APP/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(OLDAPP/name,dst)
p=APP/'Cargo.toml';s=p.read_text();oldroot=str(MAIN/'out/private-native-api-isolated-v2150')
assert oldroot in s;p.write_text(s.replace(oldroot,str(ROOT)))
subprocess.run(['git','init'],cwd=APP,check=True,capture_output=True);configure(APP)
subprocess.run(['git','add','.'],cwd=APP,check=True,capture_output=True)
subprocess.run(['git','commit','-m','Prepare the same native font-unit consumer against shared metric corrections'],cwd=APP,check=True,capture_output=True)
report=dict(schema_version=1,source=source,parent_source=before,source_only_preparation=True,
    source_patch=str(patch),source_patch_sha256=hashlib.sha256(patch.read_bytes()).hexdigest(),
    no_intrinsic_sizing_or_fontations_changes_included=True,native_app=str(APP),
    native_queries_started=0,cargo_commands_run=0,release_qualification=False,promotion_allowed=False,
    javascript_executed_by_openui=False,all_commands_terminal=True,probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
OUT.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(report),flush=True)
