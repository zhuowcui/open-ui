"""Move an unused terminal diagnostic executable without changing its bytes."""
import hashlib,json,os,shutil,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';src=MAIN/'out/renderer-evidence/spanner-boundary-diagnostic-v1/binaries/pixel_compare_spanner_boundary_diagnostic';dst=Path('/mnt/e/openui-v02-qualification-d174ea0b/terminal-evidence-relocated-v2282/pixel_compare_spanner_boundary_diagnostic')
out=Path('/tmp/openui-terminal-evidence-relocation-v2282.json');assert not out.exists() and not dst.exists() and not src.is_symlink()
sys.path.insert(0,str(MAIN/'tools/qualification'));from renderer_source_identity import repository_source_identity
public=repository_source_identity(MAIN);sdk=repository_source_identity(MAIN/'out/private-native-aliased-mask-v2268')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
owner=json.loads((RAW/'native-aliased-renderer-gates-v2276/receipt.json').read_text());assert not owner['all_commands_terminal'] and Path('/proc',str(owner['owner_pid'])).exists()
owner_command=Path('/proc',str(owner['owner_pid']),'cmdline').read_bytes()
expected=sha(src);assert len(expected)==64
size=src.stat().st_size;before_home=shutil.disk_usage(MAIN).free
checks=[]
for process in Path('/proc').iterdir():
 if not process.name.isdigit():continue
 paths=[process/'exe']
 try:paths+=list((process/'fd').iterdir())
 except (PermissionError,FileNotFoundError,ProcessLookupError):pass
 for path in paths:
  try:
   target=os.readlink(path)
   assert target not in [str(src),str(src)+' (deleted)'],f'in-use {path}'
  except (FileNotFoundError,PermissionError,ProcessLookupError):pass
 checks.append(process.name)
dst.parent.mkdir();temp=dst.with_name(dst.name+'.partial');shutil.copy2(src,temp);assert temp.stat().st_size==size and sha(temp)==expected;os.replace(temp,dst)
link=src.with_name(src.name+'.relocated-v2282');link.symlink_to(dst);assert sha(link)==expected;os.replace(link,src)
assert src.is_symlink() and sha(src)==sha(dst)==expected
assert repository_source_identity(MAIN)==public and repository_source_identity(MAIN/'out/private-native-aliased-mask-v2268')==sdk
assert Path('/proc',str(owner['owner_pid']),'cmdline').read_bytes()==owner_command
report=dict(source_path=str(src),destination_path=str(dst),bytes=size,sha256=expected,all_bytes_verified=True,original_path_preserved_as_symlink=True,historical_executable_not_referenced_by_active_owner=True,processes_checked=len(checks),no_executable_or_file_descriptor_using_original_file=True,active_owner_unchanged=True,active_owner_pid=owner['owner_pid'],source_unchanged=True,public_source=public,sdk_source=sdk,home_free_before=before_home,home_free_after=shutil.disk_usage(MAIN).free,reference_bytes_changed=0,qualification_gate_changed=False,all_commands_terminal=True,probe_sha256=sha(Path(__file__)))
out.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(report))
