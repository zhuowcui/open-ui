"""Prepare native upright ch resolution from primary vertical glyph metrics."""
import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');BASE=MAIN/'out/private-native-aliased-mask-v2268';ROOT=MAIN/'out/private-native-vertical-ch-v2283';OLDAPP=MAIN/'out/private-native-apps/native-vertical-ch-v2213';APP=MAIN/'out/private-native-apps/native-vertical-ch-v2284'
OUT=Path('/tmp/openui-native-vertical-ch-prepare-v2283.json');assert not ROOT.exists() and not APP.exists() and not OUT.exists()
sys.path.insert(0,str(MAIN/'tools/qualification'));from renderer_source_identity import repository_source_identity
before=repository_source_identity(BASE);public=repository_source_identity(MAIN)
assert before['clean'] and before['commit']=='4839e107fee5ae07e28fcda990f3433216263580' and public['clean']
assert shutil.disk_usage(MAIN).free>700*2**20
subprocess.run(['git','clone','--shared','--no-checkout',str(BASE),str(ROOT)],check=True,capture_output=True)
for key in ['user.name','user.email']:
 value=subprocess.check_output(['git','config','--get',key],cwd=MAIN,text=True).strip();subprocess.run(['git','config',key,value],cwd=ROOT,check=True)
subprocess.run(['git','read-tree',before['commit']],cwd=ROOT,check=True)
for name in filter(None,subprocess.check_output(['git','ls-files','-z'],cwd=BASE).decode().split('\0')):
 src=BASE/name;dst=ROOT/name;dst.parent.mkdir(parents=True,exist_ok=True)
 if src.is_symlink():dst.symlink_to(os.readlink(src))
 else:os.link(src,dst)
assert repository_source_identity(ROOT)==before
for name in ['bindings/rust/openui-text/src/font/platform.rs','bindings/rust/openui-text/src/font/relative.rs']:
 p=ROOT/name;t=p.with_name(p.name+'.owned-v2283');shutil.copy2(p,t);os.replace(t,p)
p=ROOT/'bindings/rust/openui-text/src/font/platform.rs';s=p.read_text()
old='''    /// OpenType vertical advance for a glyph, falling back to one em for a
    /// face without `vhea`/`vmtx` data.'''
new='''    /// OpenType vertical advance for a glyph. A face without `vhea`/`vmtx`
    /// uses its separately rounded raw ascent and descent, excluding leading.''';assert s.count(old)==1;s=s.replace(old,new)
old='''            .map(|(advance, units_per_em)| advance as f32 * self.size / units_per_em)
            .unwrap_or(self.size)'''
new='''            .map(|(advance, units_per_em)| advance as f32 * self.size / units_per_em)
            .unwrap_or_else(|| {
                // HarfBuzz's synthesized vertical advance reads the resolved
                // platform font before CSS metric overrides are applied.
                let (_, raw_metrics) = self.sk_font.metrics();
                (-raw_metrics.ascent).round() + raw_metrics.descent.round()
            })''';assert s.count(old)==1;p.write_text(s.replace(old,new))
p=ROOT/'bindings/rust/openui-text/src/font/relative.rs';s=p.read_text()
s=s.replace('use openui_style::{ComputedStyle, LineHeight};','use openui_style::{ComputedStyle, FontOrientation, LineHeight};')
old='''        let metrics = font.font_metrics().copied().unwrap_or_default();
        Self::from_metrics(style.font_size, &style.line_height, &metrics)'''
new='''        let metrics = font.font_metrics().copied().unwrap_or_default();
        let mut resolver = Self::from_metrics(style.font_size, &style.line_height, &metrics);
        let upright = font.description().orientation == FontOrientation::VerticalUpright;
        // ch follows the primary zero glyph in the element's inline direction.
        // Preserve a present zero advance; a missing glyph uses the CSS fallback.
        resolver.ch = font
            .primary_font()
            .and_then(|data| {
                let zero_glyph = data.sk_font().unichar_to_glyph('0' as i32);
                (zero_glyph != 0).then(|| {
                    if upright {
                        data.vertical_advance(zero_glyph)
                    } else {
                        data.metrics().zero_width
                    }
                })
            })
            .unwrap_or(style.font_size * if upright { 1.0 } else { 0.5 });
        resolver''';assert s.count(old)==1;p.write_text(s.replace(old,new))
subprocess.run(['bash','-c','ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true bindings/rust/openui-text/src/font/platform.rs bindings/rust/openui-text/src/font/relative.rs'],cwd=ROOT,check=True)
subprocess.run(['git','add','bindings/rust/openui-text/src/font/platform.rs','bindings/rust/openui-text/src/font/relative.rs'],cwd=ROOT,check=True)
patch=Path('/tmp/openui-native-vertical-ch-v2283.patch');assert not patch.exists();patch.write_bytes(subprocess.check_output(['git','diff','--cached','--binary','--full-index'],cwd=ROOT))
subprocess.run(['git','commit','-m','Resolve upright native ch with primary vertical advance and rounded raw fallback'],cwd=ROOT,check=True,capture_output=True)
source=repository_source_identity(ROOT);assert source['clean'] and repository_source_identity(BASE)==before and repository_source_identity(MAIN)==public
APP.mkdir()
for name in ['Cargo.toml','Cargo.lock','src/main.rs']:
 p=APP/name;p.parent.mkdir(parents=True,exist_ok=True);content=(OLDAPP/name).read_bytes()
 if name=='Cargo.toml':content=content.replace(str(MAIN/'out/private-native-relative-api-v2202').encode(),str(ROOT).encode())
 p.write_bytes(content)
subprocess.run(['git','init','-q'],cwd=APP,check=True)
for key in ['user.name','user.email']:
 value=subprocess.check_output(['git','config','--get',key],cwd=MAIN,text=True).strip();subprocess.run(['git','config',key,value],cwd=APP,check=True)
subprocess.run(['git','add','.'],cwd=APP,check=True);subprocess.run(['git','commit','-q','-m','Prepare unchanged native vertical font-unit app against upright metric correction'],cwd=APP,check=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=dict(source=source,parent_source=before,public_source=public,root=str(ROOT),app_root=str(APP),source_patch=str(patch),source_patch_sha256=sha(patch),app_source_unchanged_from_baseline=sha(APP/'src/main.rs')==sha(OLDAPP/'src/main.rs'),orientation_and_glyph_based=True,new_font_name_size_or_test_id_conditions=False,raw_fallback_ignores_css_metric_overrides=True,missing_zero_fallback_implemented=True,missing_zero_fallback_and_override_cases_not_yet_runtime_verified=True,all_commands_terminal=True,source_only_preparation=True,cargo_commands_run=0,native_commands_run=0,chromium_commands_run=0,shared_parent_census_currently_live=True,parent_renderer_qualification_not_assumed=True,release_qualification=False,promotion_allowed=False,javascript_executed_by_openui=False,probe_sha256=sha(Path(__file__)))
OUT.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(report))
