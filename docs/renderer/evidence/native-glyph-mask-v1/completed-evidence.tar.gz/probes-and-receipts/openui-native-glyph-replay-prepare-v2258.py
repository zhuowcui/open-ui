"""Remove terminal-mask repainting in an isolated, immutable renderer trial."""
import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');BASE=MAIN/'out/private-native-caption-metrics-v2234';ROOT=MAIN/'out/private-native-glyph-replay-v2258';OLDAPP=MAIN/'out/private-native-apps/native-glyph-origin-v2256';APP=MAIN/'out/private-native-apps/native-glyph-origin-v2259'
OUT=Path('/tmp/openui-native-glyph-replay-prepare-v2258.json')
assert not ROOT.exists() and not APP.exists() and not OUT.exists()
sys.path.insert(0,str(MAIN/'tools/qualification'));from renderer_source_identity import repository_source_identity
before=repository_source_identity(BASE);public=repository_source_identity(MAIN)
assert before['clean'] and before['commit']=='db177050b5e615abcede59b877bed9b58da8a496' and public['clean']
assert shutil.disk_usage(MAIN).free>700*2**20
subprocess.run(['git','clone','--shared','--no-checkout',str(BASE),str(ROOT)],check=True,capture_output=True)
for key in ['user.name','user.email']:
 value=subprocess.check_output(['git','config','--get',key],cwd=MAIN,text=True).strip();subprocess.run(['git','config',key,value],cwd=ROOT,check=True)
subprocess.run(['git','read-tree',before['commit']],cwd=ROOT,check=True)
for name in filter(None,subprocess.check_output(['git','ls-files','-z'],cwd=BASE).decode().split('\0')):
 src=BASE/name;dst=ROOT/name;dst.parent.mkdir(parents=True,exist_ok=True)
 if src.is_symlink():dst.symlink_to(os.readlink(src))
 else:os.link(src,dst)
assert repository_source_identity(ROOT)==before
p=ROOT/'bindings/rust/openui-paint/src/painter.rs';t=p.with_name(p.name+'.owned-v2258');shutil.copy2(p,t);os.replace(t,p)
s=p.read_text();start=s.index('            if fragment.text_run_orientation == openui_layout::TextRunOrientation::Clockwise {\n                paint_rotated_aliased_terminal_edges(');end=s.index('\n        } else {',start)
s=s[:start]+s[end:]
start=s.index('/// Replay the terminal device cell of a scaled, clockwise Ahem glyph');end=s.index('fn should_replay_line_clamp_ahem_preceding_row(',start)
s=s[:start]+s[end:];p.write_text(s)
subprocess.run(['bash','-c','ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true bindings/rust/openui-paint/src/painter.rs'],cwd=ROOT,check=True)
subprocess.run(['git','add','bindings/rust/openui-paint/src/painter.rs'],cwd=ROOT,check=True)
patch=Path('/tmp/openui-native-glyph-replay-v2258.patch');patch.write_bytes(subprocess.check_output(['git','diff','--cached','--binary','--full-index'],cwd=ROOT))
subprocess.run(['git','commit','-m','Remove terminal glyph-mask repainting from rotated aliased text'],cwd=ROOT,check=True,capture_output=True)
source=repository_source_identity(ROOT);assert source['clean'] and repository_source_identity(BASE)==before and repository_source_identity(MAIN)==public
APP.mkdir()
for name in ['Cargo.toml','Cargo.lock','src/main.rs']:
 p=APP/name;p.parent.mkdir(parents=True,exist_ok=True);content=(OLDAPP/name).read_bytes()
 if name=='Cargo.toml':content=content.replace(str(BASE).encode(),str(ROOT).encode())
 p.write_bytes(content)
subprocess.run(['git','init','-q'],cwd=APP,check=True)
for key in ['user.name','user.email']:
 value=subprocess.check_output(['git','config','--get',key],cwd=MAIN,text=True).strip();subprocess.run(['git','config',key,value],cwd=APP,check=True)
subprocess.run(['git','add','.'],cwd=APP,check=True);subprocess.run(['git','commit','-q','-m','Prepare unchanged native glyph app against single-pass rotated glyph trial'],cwd=APP,check=True)
report=dict(source=source,parent_source=before,public_source=public,root=str(ROOT),app_root=str(APP),all_commands_terminal=True,source_only_preparation=True,cargo_commands_run=0,native_commands_run=0,chromium_commands_run=0,source_patch=str(patch),source_patch_sha256=hashlib.sha256(patch.read_bytes()).hexdigest(),terminal_repainting_removed_globally=True,added_font_or_size_conditions=False,release_qualification=False,promotion_allowed=False,javascript_executed_by_openui=False,probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
OUT.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(report))
