"""Own the completed full-census regressions and preserve before/after change evidence."""
import hashlib, json, sys
from pathlib import Path

MAIN = Path('/home/nero/code/open-ui')
RAW = MAIN / 'out/renderer-evidence/native-viewport-scroll-v1'
OUT = RAW / 'native-glyph-full-review-v2298.json'
assert not OUT.exists()
sys.path.insert(0, str(MAIN / 'tools/qualification'))
from residuals import analyze_image_difference
load = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
p = RAW / 'native-aliased-renderer-gates-v2276/receipt.json'
gate = load(p)
assert gate['all_commands_terminal'] and gate['source_unchanged'] and gate['public_source_unchanged']
assert not Path('/proc', str(gate['owner_pid'])).exists()
cache = Path('/mnt/e/openui-v02-qualification-d174ea0b/renderer-cache')
owned = []
computed = {}
for suite in ['full', 'expanded']:
    current = load(RAW / 'native-aliased-renderer-gates-v2276' / (suite + '-matrix') / (suite + '-summary.json'))
    prior = load(RAW / ('native-event-targets-clean-' + suite + '-v1456') / (suite + '-summary.json'))
    rows = {(p['profile'], r['id']): r for p in current['profiles'] for r in p['tests']}
    old = {(p['profile'], r['id']): r for p in prior['profiles'] for r in p['tests']}
    for change in gate['matrices'][suite]['changed_comparisons']:
        if not change['more_wrong_pixels']:
            continue
        key = (change['profile'], change['id'])
        row = rows[key]
        before = old[key]
        assert all(row[k] == before[k] for k in ['chromium_png_sha256', 'chromium_rgba_sha256', 'chromium_oracle_identity_sha256', 'chromium_oracle_rgba_sha256'])
        if key not in computed:
            baseline = cache / before['openui_png_cache_path']
            candidate = cache / row['openui_png_cache_path']
            assert sha(baseline) == before['openui_png_sha256'] and sha(candidate) == row['openui_png_sha256']
            computed[key] = analyze_image_difference(baseline, candidate)
        input_case = 'input-scrollable-region' in change['id']
        select_case = 'select-4-option' in change['id']
        owned.append(dict(suite=suite, **change, owning_subsystem='text-and-paint',
                          additional_owner='native-controls' if input_case or select_case else 'positioned-text-paint',
                          reviewed_failure_class='native-control-glyph-row-and-clip' if input_case or select_case else 'large-viewport-font-glyph-origin-or-strike',
                          exact_root_cause_not_yet_proven=True, further_reduced_native_consumer_required=True,
                          reference_difference=row['diff_signature'], native_change_difference=computed[key],
                          prior_openui_png_sha256=before['openui_png_sha256'], candidate_openui_png_sha256=row['openui_png_sha256'],
                          chromium_png_sha256=row['chromium_png_sha256'], old_openui_used_only_for_change_analysis=True))
report = dict(schema_version=1, source=gate['source'], all_commands_terminal=True,
              renderer_receipt_sha256=sha(p), actual_renderer_owner_exit=gate['observed_exit_code'],
              matrices=gate['matrices'], owned_regression_comparisons=owned,
              unique_worsened_comparisons=len(computed), precise_root_cause_and_minimizer_gate_open=True,
              formal_release_ownership_ledger_unchanged=True, candidate_applied_to_umbrella=False,
              accepted_original_exact=21334, accepted_original_total=22924,
              javascript_executed_by_openui=False, pixel_tolerance=0,
              new_release_states_admitted=0, release_qualification=False, promotion_allowed=False,
              probe_sha256=sha(Path(__file__)))
OUT.write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
print(json.dumps(dict(unique_worsened=len(computed), owned_rows=len(owned), receipt_sha256=sha(OUT))))
