"""Finish app preparation; preserve the earlier preparation failures."""
import hashlib,json,subprocess,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');SDK=MAIN/'out/private-native-aliased-mask-v2268';APP=MAIN/'out/private-native-apps/native-glyph-origin-v2269';OLDAPP=MAIN/'out/private-native-apps/native-glyph-origin-v2256'
sys.path.insert(0,str(MAIN/'tools/qualification'));from renderer_source_identity import repository_source_identity
source=repository_source_identity(SDK);public=repository_source_identity(MAIN)
assert source['clean'] and source['commit']=='4839e107fee5ae07e28fcda990f3433216263580' and public['clean']
assert APP.is_dir() and not list(APP.iterdir())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
failed=Path('/tmp/openui-native-aliased-mask-prepare-v2268-failed.json');assert not failed.exists()
failed.write_text(json.dumps(dict(observed_exit_code=1,error='FileNotFoundError copying Cargo.toml: consuming app source and destination were the same empty directory',failed_stage='app-copy after clean candidate source committed',source_after=source,public_source_after=public,cargo_commands_run=0,native_commands_run=0,chromium_commands_run=0,all_commands_terminal=True,probe_sha256=sha(Path('/tmp/openui-native-aliased-mask-prepare-v2268.py'))),sort_keys=True,indent=2)+'\n')
for name in ['Cargo.toml','Cargo.lock','src/main.rs']:
 p=APP/name;p.parent.mkdir(parents=True,exist_ok=True);content=(OLDAPP/name).read_bytes()
 if name=='Cargo.toml':content=content.replace(str(MAIN/'out/private-native-caption-metrics-v2234').encode(),str(SDK).encode())
 p.write_bytes(content)
subprocess.run(['git','init','-q'],cwd=APP,check=True)
for key in ['user.name','user.email']:
 value=subprocess.check_output(['git','config','--get',key],cwd=MAIN,text=True).strip();subprocess.run(['git','config',key,value],cwd=APP,check=True)
subprocess.run(['git','add','.'],cwd=APP,check=True);subprocess.run(['git','commit','-q','-m','Prepare unchanged Rust glyph app against single-pass mask positioning'],cwd=APP,check=True)
assert repository_source_identity(SDK)==source and repository_source_identity(MAIN)==public
out=Path('/tmp/openui-native-aliased-mask-app-prepare-v2271.json');assert not out.exists()
report=dict(source=source,public_source=public,parent_source=repository_source_identity(MAIN/'out/private-native-aliased-strike-v2261'),root=str(SDK),app_root=str(APP),app_source_sha256=sha(APP/'src/main.rs'),original_app_source_sha256=sha(OLDAPP/'src/main.rs'),source_patch_sha256=sha(Path('/tmp/openui-native-aliased-mask-v2268.patch')),failed_preparation_attempts_preserved=True,source_unchanged=True,public_source_unchanged=True,all_commands_terminal=True,cargo_commands_run=0,native_commands_run=0,chromium_commands_run=0,release_qualification=False,promotion_allowed=False,javascript_executed_by_openui=False,probe_sha256=sha(Path(__file__)))
assert report['app_source_sha256']==report['original_app_source_sha256'];out.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(report))
