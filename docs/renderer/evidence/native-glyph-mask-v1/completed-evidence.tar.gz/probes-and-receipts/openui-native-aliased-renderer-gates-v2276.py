"""Check the source-verified shared glyph fix before running complete census gates."""
import fcntl,hashlib,json,os,re,shutil,signal,subprocess,sys,time
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');ROOT=MAIN/'out/private-native-aliased-mask-v2268'
RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';NAME='native-aliased-renderer-gates-v2276'
OUT=RAW/NAME;STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/NAME
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for program in ['cargo','rustc','ninja','pixel_compare']:
    assert subprocess.run(['pgrep','-x',program],capture_output=True).returncode==1
assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
tmp=STORE/'compiler-tmp';tmp.mkdir()
env=dict(os.environ,OPENUI_NATIVE_WHOLE_OWNER=NAME,CARGO_TARGET_DIR='/mnt/e/openui-v02-cargo-c73754e2/target',
    CARGO_INCREMENTAL='0',RUST_MIN_STACK='4194304',CARGO_BUILD_JOBS='4',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(tmp),
    CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
sys.path.insert(0,str(ROOT/'tools/qualification'))
from renderer_source_identity import repository_source_identity
from residuals import canonical_sha256
source=repository_source_identity(ROOT);public=repository_source_identity(MAIN)
assert source['clean'] and source['commit']=='4839e107fee5ae07e28fcda990f3433216263580'
assert public['clean'] and public['commit']=='ee76ec1fc2dd0fbc2bf9281cbd6c1a1d0f55a17b'
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(2**20),b''):h.update(b)
    return h.hexdigest()
load=lambda p:json.loads(p.read_bytes())
tracked=ROOT/'tests/pixel_text/openui_renders/basic_text_openui.png'
if tracked.stat().st_nlink>1:
    temp=tracked.with_name(tracked.name+'.owned-copy-v2197');shutil.copy2(tracked,temp);os.replace(temp,tracked)
tracked_sha=sha(tracked)
refs={str(p.relative_to(ROOT)):sha(p) for p in (ROOT/'tests/pixel_text/chromium_refs').rglob('*') if p.is_file()}
report=dict(schema_version=1,source=source,public_source=public,owner_pid=os.getpid(),steps=[],matrices={},
    all_commands_terminal=False,release_qualification=False,promotion_allowed=False,new_release_states_admitted=0,
    shared_intrinsic_shaping_and_caption_floors_changed=True,terminal_repainting_removed=True,
    shared_physical_aliased_strike=True,ahem_ink_clip_removed=True,preceding_row_replay_removed=True,aliased_subpixel_policy_respects_resolved_font=True,pixel_tolerance=0,javascript_executed_by_openui=False,
    complete_renderer_matrices_not_run=True,probe_sha256=sha(Path(__file__)))
def save():(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
def run(name,command,cwd=ROOT/'bindings/rust',zero=True):
    path=OUT/(name+'.log')
    with path.open('xb') as stream:
        child=subprocess.Popen(command,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
        report['current_process']=dict(pid=child.pid,stage=name);save();guard=False
        while child.poll() is None:
            if shutil.disk_usage(MAIN).free<512*2**20 or shutil.disk_usage(STORE).free<10*2**30:
                guard=True;os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=20);break
            time.sleep(1)
        child.wait()
    totals=[tuple(map(int,m)) for m in re.findall(rb'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',path.read_bytes())]
    row=dict(name=name,observed_exit_code=child.returncode,disk_guard_triggered=guard,log_sha256=sha(path),
        passed=sum(t[0] for t in totals),failed=sum(t[1] for t in totals),ignored=sum(t[2] for t in totals))
    report.pop('current_process');report['steps'].append(row);save();print(json.dumps(row),flush=True)
    assert not guard and repository_source_identity(ROOT)==source and repository_source_identity(MAIN)==public
    assert sha(tracked)==tracked_sha and all(sha(ROOT/p)==h for p,h in refs.items())
    if zero:assert child.returncode==0,name
    return row
base=['cargo','--config','.cargo/config.chromium.toml']
def matrix(suite,name,ids=None,jobs=8):
    result=OUT/(name+'-matrix');result.mkdir()
    command=[sys.executable,str(ROOT/'tools/qualification/run_renderer_matrix.py'),'--suite',suite,'--results-dir',str(result),
        '--cache-dir','/mnt/e/openui-v02-qualification-d174ea0b/renderer-cache',
        '--oracle-cache-dir',str(MAIN/'out/renderer-qualification-cache/chromium-oracle'),
        '--pixel-compare',str(pixel),'--chrome',str(MAIN/'chrome/linux-147.0.7727.50/chrome-linux64/chrome'),
        '--raster-backend','cpu-skia','--jobs',str(jobs)]
    if ids:command.extend(a for test_id in ids for a in ['--test-id',test_id])
    stage=run(name+'-matrix',command,cwd=ROOT,zero=False)
    path=result/(suite+'-summary.json');s=load(path)
    assert s['source']==s['source_after']==source and s['results']['errors']==0
    prior_path=RAW/('native-event-targets-clean-'+suite+'-v1456')/(suite+'-summary.json');prior=load(prior_path)
    before={(p['profile'],r['id']):r for p in prior['profiles'] for r in p['tests']}
    changes=[];total=0
    invariants=['openui_png_sha256','openui_rgba_sha256','chromium_png_sha256','chromium_rgba_sha256',
        'chromium_oracle_identity_sha256','chromium_oracle_rgba_sha256','status','mismatched_pixels','diff_signature']
    for p in s['profiles']:
        assert p['result_sha256']==canonical_sha256(p['tests'])
        for row in p['tests']:
            total+=1;old=before[(p['profile'],row['id'])]
            assert all(row[f]==old[f] for f in invariants[2:6])
            changed=[f for f in invariants if row[f]!=old[f]]
            if changed:changes.append(dict(profile=p['profile'],id=row['id'],changed_fields=changed,
                prior_status=old['status'],status=row['status'],prior_mismatched_pixels=old['mismatched_pixels'],
                mismatched_pixels=row['mismatched_pixels'],more_wrong_pixels=row['mismatched_pixels']>old['mismatched_pixels'],
                exact_loss=old['status']=='exact' and row['status']!='exact',exact_gain=old['status']!='exact' and row['status']=='exact'))
    assert s['results']['total']==total
    entry=dict(summary_sha256=sha(path),results=s['results'],observed_exit_code=stage['observed_exit_code'],
        partial_selection_not_qualifying=bool(ids),comparisons=total,changed_comparisons=changes,
        worsened_comparisons=sum(x['more_wrong_pixels'] for x in changes),exact_losses=sum(x['exact_loss'] for x in changes),
        exact_gains=sum(x['exact_gain'] for x in changes))
    report['matrices'][name]=entry;save();print(json.dumps(dict(suite=name,results=s['results'],worsened=entry['worsened_comparisons'])),flush=True)
    return entry

save()
try:
    native=load(RAW/'native-glyph-origin-pipeline-v2272/receipt.json')
    assert native['all_commands_terminal'] and native['source_unchanged'] and native['public_source_unchanged']
    assert native['source']==source and native['totals']['exact_images']==20 and native['totals']['exact_geometry']==20
    report['native_reproducer_receipt_sha256']=sha(RAW/'native-glyph-origin-pipeline-v2272/receipt.json')
    run('locked-metadata',base+['metadata','--offline','--locked','--no-deps','--format-version','1'])
    run('clean-pixel-package',base+['clean','--locked','-p','pixel-compare'])
    run('pixel-build',base+['build','--offline','--locked','-p','pixel-compare','--bin','pixel_compare'])
    pixel=OUT/'pixel_compare';shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/pixel_compare',pixel)
    report['pixel_binary_sha256']=sha(pixel)
    ident=json.loads(subprocess.check_output([str(pixel),'build-source-identity'],cwd=ROOT,env=env))
    assert ident['source']==source;report['build_identity']=ident;save()
    assert shutil.disk_usage(MAIN).free>700*2**20
    risky=matrix('full','sizing-caption-neighbors',['wpt/css_sizing/block-size-with-min-or-max-content-1-ref',
        'wpt/css_sizing/block-size-with-min-or-max-content-1a','wpt/css_sizing/block-size-with-min-or-max-content-1b','wpt/css_multicol/multicol-span-all-004','wpt/css_multicol/multicol-span-all-004-ref'],jobs=4)
    for suite in ['focused','primitive']:
        entry=matrix(suite,suite,jobs=4)
        assert entry['comparisons']==dict(focused=640,primitive=960)[suite]
    early_failed=any(e['worsened_comparisons'] or e['exact_losses'] for e in report['matrices'].values())
    if not early_failed:
        for suite in ['full','expanded']:
            entry=matrix(suite,suite,jobs=8)
            assert entry['comparisons']==dict(full=22924,expanded=23728)[suite]
        report['complete_renderer_matrices_not_run']=False
    report['observed_exit_code']=int(any(e['worsened_comparisons'] or e['exact_losses'] for e in report['matrices'].values()))
except BaseException as error:
    report.update(observed_exit_code=1,failure=str(error));raise
finally:
    report.update(all_commands_terminal=True,source_after=repository_source_identity(ROOT),public_source_after=repository_source_identity(MAIN))
    report['source_unchanged']=report['source_after']==source;report['public_source_unchanged']=report['public_source_after']==public
    report['tracked_diagnostic_png_unchanged']=sha(tracked)==tracked_sha
    save()
print(json.dumps(dict(observed_exit_code=report['observed_exit_code'],suites={n:dict(exact=e['results']['exact'],worsened=e['worsened_comparisons']) for n,e in report['matrices'].items()})),flush=True)
raise SystemExit(report['observed_exit_code'])
