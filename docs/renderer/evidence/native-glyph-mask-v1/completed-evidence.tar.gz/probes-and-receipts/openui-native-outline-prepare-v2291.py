"""Prepare a public Rust outline minimizer without compiling or running any renderer."""
import hashlib, json, subprocess, sys
from pathlib import Path

MAIN = Path('/home/nero/code/open-ui')
SDK = MAIN / 'out/private-native-aliased-mask-v2268'
APP = MAIN / 'out/private-native-apps/native-outline-corner-v2291'
OLD = MAIN / 'out/private-native-apps/native-glyph-origin-v2269'
sys.path.insert(0, str(MAIN / 'tools/qualification'))
from renderer_source_identity import repository_source_identity
source = repository_source_identity(SDK)
public = repository_source_identity(MAIN)
assert source['clean'] and source['commit'] == '4839e107fee5ae07e28fcda990f3433216263580'
assert public['clean'] and not APP.exists()
APP.mkdir()
(APP / 'src').mkdir()
name = 'openui-native-outline-corner-api'
(APP / 'Cargo.toml').write_text((OLD / 'Cargo.toml').read_text().replace('openui-native-glyph-origin-api', name))
(APP / 'Cargo.lock').write_bytes((OLD / 'Cargo.lock').read_bytes())
(APP / 'src/main.rs').write_bytes(Path('/tmp/openui-native-outline-corner-app-v2291.rs').read_bytes())
subprocess.run(['git', 'init', '-q'], cwd=APP, check=True)
for key in ['user.name', 'user.email']:
    value = subprocess.check_output(['git', 'config', '--get', key], cwd=MAIN, text=True).strip()
    subprocess.run(['git', 'config', key, value], cwd=APP, check=True)
subprocess.run(['git', 'add', '.'], cwd=APP, check=True)
subprocess.run(['git', 'commit', '-q', '-m', 'Prepare native outline corner and neighboring Rust callbacks'], cwd=APP, check=True)

p = Path('/tmp/openui-native-glyph-origin-pipeline-v2257.py')
s = p.read_text()
for old, new in [
    ('private-native-caption-metrics-v2234', 'private-native-aliased-mask-v2268'),
    ('native-glyph-origin-v2256', 'native-outline-corner-v2291'),
    ('native-glyph-origin-pipeline-v2257', 'native-outline-corner-pipeline-v2292'),
    ('db177050b5e615abcede59b877bed9b58da8a496', source['commit']),
    ('openui-native-glyph-origin-api', name),
    ('a reduced public Rust glyph app', 'a reduced public Rust outline app'),
    ('the native glyph origin consuming app', 'the native outline corner consuming app'),
    ("writing=row['writing']", "writing=row['name']"),
]:
    assert old in s, old
    s = s.replace(old, new)
start = s.index("            if writing=='horizontal':")
end = s.index('            queries=[]', start)
s = s[:start] + '''            left=top=20 if state=='before' else 21
            width=row['width'];height=row['height']
            page=directory/'test.html'
            page.write_text(f\'''<!doctype html><style>*{{margin:0;padding:0;box-sizing:content-box}}
html,body{{width:800px;height:600px;overflow:hidden;background:white}}
#frame{{position:absolute;left:{left}px;top:{top}px;width:{width}px;height:{height}px;outline:1px solid blue}}
</style><div id="frame"></div>\''')
''' + s[end:]
anchor="lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)"
assert s.count(anchor) == 1
s = s.replace(anchor, anchor + '''
previous=json.loads((RAW/'native-aliased-renderer-gates-v2276/receipt.json').read_bytes())
assert previous['all_commands_terminal'] and previous['source_unchanged'] and previous['public_source_unchanged']
assert not Path('/proc',str(previous['owner_pid'])).exists()
''')
s = s.replace('offline_javascript_executed_only_in_chromium=True,complete_renderer_matrices_not_run=True,',
              'offline_javascript_executed_only_in_chromium=True,complete_renderer_matrices_not_run=True,chromium_captures_run=0,outline_minimizer_hypothesis_not_assumed_proven=True,')
s = s.replace('query=observe(page,picture,expression,scale)', 'query=observe(page,picture,expression,scale);report["chromium_captures_run"]+=1')
s = s.replace('report.update(observed_exit_code=0,native_pngs_repeat_byte_identically=True)',
              "report.update(observed_exit_code=int(totals['different_images']!=0 or totals['exact_geometry']!=20),native_pngs_repeat_byte_identically=True)")
s += "\nraise SystemExit(report['observed_exit_code'])\n"
pipeline = Path('/tmp/openui-native-outline-corner-pipeline-v2292.py')
assert not pipeline.exists()
compile(s, str(pipeline), 'exec')
pipeline.write_text(s)
assert repository_source_identity(SDK) == source and repository_source_identity(MAIN) == public
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
report = dict(source=source, public_source=public, app=str(APP),
              app_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=APP, text=True).strip(),
              app_source_sha256=sha(APP / 'src/main.rs'), pipeline=str(pipeline), pipeline_sha256=sha(pipeline),
              source_only=True, native_commands_run=0, cargo_commands_run=0, chromium_commands_run=0,
              hypothesis_not_qualified=True, javascript_executed_by_openui=False, release_qualification=False)
out = Path('/tmp/openui-native-outline-prepare-v2291.json')
assert not out.exists()
out.write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
print(json.dumps(report))
