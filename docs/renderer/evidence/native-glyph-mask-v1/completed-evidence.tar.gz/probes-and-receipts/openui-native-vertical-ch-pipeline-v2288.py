"""Verify public Rust upright ch correction against unchanged repeated Chromium geometry."""
import fcntl,hashlib,json,os,shutil,signal,subprocess,sys,time
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');SDK=MAIN/'out/private-native-vertical-ch-v2285';APP=MAIN/'out/private-native-apps/native-vertical-ch-v2286'
RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';NAME='native-vertical-ch-pipeline-v2288';OUT=RAW/NAME;STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/NAME
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
previous=json.loads((RAW/'native-aliased-renderer-gates-v2276/receipt.json').read_text())
assert previous['all_commands_terminal'] and previous['source_unchanged'] and previous['public_source_unchanged']
assert not Path('/proc',str(previous['owner_pid'])).exists()
for program in ['cargo','rustc','ninja','pixel_compare']:assert subprocess.run(['pgrep','-x',program],capture_output=True).returncode==1
assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
sys.path.insert(0,str(SDK/'tools/qualification'));from renderer_source_identity import repository_source_identity
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_bytes())
source=repository_source_identity(SDK);public=repository_source_identity(MAIN)
assert source['clean'] and source['commit']=='36b5db31afc8f9fd8722b1926a37f2e937c70a30' and public['clean']
oracle_path=RAW/'native-vertical-ch-pipeline-v2215/receipt.json';oracle=load(oracle_path)
assert oracle['all_commands_terminal'] and oracle['source_unchanged'] and oracle['observed_exit_code']==0
assert oracle['geometry_states']==1440 and oracle['full_rect_exact']==1280
assert (APP/'src/main.rs').read_bytes()==(MAIN/'out/private-native-apps/native-vertical-ch-v2213/src/main.rs').read_bytes()
chrome=MAIN/'chrome/linux-147.0.7727.50/chrome-linux64/chrome';assert sha(chrome)==oracle['chromium_binary_sha256']
assert source['harness_sha256']==oracle['source']['harness_sha256']
tmp=STORE/'compiler-tmp';tmp.mkdir()
env=dict(os.environ,OPENUI_NATIVE_WHOLE_OWNER=NAME,CARGO_TARGET_DIR='/mnt/e/openui-v02-cargo-c73754e2/target',CARGO_INCREMENTAL='0',RUST_MIN_STACK='4194304',CARGO_BUILD_JOBS='4',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(tmp),CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
report=dict(schema_version=1,source=source,public_source=public,parent_renderer_source=previous['source'],parent_renderer_actual_exit=previous['observed_exit_code'],parent_renderer_qualification_not_assumed=True,owner_pid=os.getpid(),all_commands_terminal=False,steps=[],profiles=[],geometry_only_diagnostic=True,native_pixels_captured=False,chromium_captures_run=0,chromium_geometry_reused=True,oracle_receipt_sha256=sha(oracle_path),javascript_executed_by_openui=False,offline_javascript_executed_only_in_chromium=False,manual_resolution_does_not_complete_reactive_length_declarations=True,missing_zero_and_metric_override_cases_not_in_this_sweep=True,complete_pixel_matrices_not_run=True,new_release_states_admitted=0,release_qualification=False,promotion_allowed=False,probe_sha256=sha(Path(__file__)))
def save():(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
def run(name,command):
 path=OUT/(name+'.log')
 with path.open('xb') as stream:
  child=subprocess.Popen(command,cwd=APP,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True);report['current_process']=dict(stage=name,pid=child.pid);save();guard=False
  while child.poll() is None:
   if shutil.disk_usage(MAIN).free<512*2**20 or shutil.disk_usage(STORE).free<10*2**30:guard=True;os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=20);break
   time.sleep(1)
  child.wait()
 report.pop('current_process');row=dict(name=name,observed_exit_code=child.returncode,disk_guard_triggered=guard,log_sha256=sha(path));report['steps'].append(row);save();print(json.dumps(row),flush=True)
 assert not guard and child.returncode==0,name
 assert repository_source_identity(SDK)==source and repository_source_identity(MAIN)==public

def app_identity():return dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=APP,text=True).strip(),tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=APP,text=True).strip(),clean=not subprocess.check_output(['git','status','--porcelain'],cwd=APP))
save()
try:
 base=['cargo','--config',str(SDK/'bindings/rust/.cargo/config.chromium.toml')]
 run('native-format',['bash','-c','ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true --check src/main.rs'])
 run('native-metadata',base+['metadata','--offline','--format-version','1'])
 if subprocess.check_output(['git','status','--porcelain'],cwd=APP):
  subprocess.run(['git','add','.'],cwd=APP,check=True,capture_output=True);subprocess.run(['git','commit','-m','Lock native upright font-unit consuming app'],cwd=APP,check=True,capture_output=True)
 report['native_app_source']=app_identity();assert report['native_app_source']['clean'];save()
 run('native-build',base+['build','--offline','--locked'])
 binary=OUT/'openui-native-vertical-ch-api';shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/openui-native-vertical-ch-api',binary);report['native_binary_sha256']=sha(binary);save()
 for repeat in ['first','second']:run('native-'+repeat,[str(binary)])
 assert (OUT/'native-first.log').read_bytes()==(OUT/'native-second.log').read_bytes()
 rows=[json.loads(line) for line in (OUT/'native-first.log').read_text().splitlines()];assert len(rows)==720 and sum(row['callback_calls'] for row in rows)==720
 keys=['scale','family','size','line_height','unit','coefficient','writing','orientation'];key=lambda r:tuple(r[k] for k in keys)
 bykey={key(row):row for row in rows};assert len(bykey)==720
 exact_count=0;gains=0;losses=0
 for profile in oracle['profiles']:
  old_dir=RAW/'native-vertical-ch-pipeline-v2215'/str(profile['scale']);directory=OUT/str(profile['scale']);directory.mkdir()
  assert sha(old_dir/'test.html')==profile['html_sha256']
  assert sha(old_dir/'1.png')==profile['first_png_sha256']==profile['second_png_sha256']==sha(old_dir/'2.png')
  queries=load(old_dir/'1-geometry.json');assert queries==load(old_dir/'2-geometry.json')
  assert queries==[obs['chromium'] for obs in profile['observations']]
  for filename in ['test.html','1.png','2.png','1-geometry.json','2-geometry.json']:shutil.copy2(old_dir/filename,directory/filename)
  observations=[]
  for obs in profile['observations']:
   native=bykey.pop(key(obs['native_case']));chromium=obs['chromium'];exact={state:native[state]['bounds']==chromium[state] for state in ['before','after']}
   exact_count+=sum(exact.values());gains+=sum(exact[state] and not obs['full_rect_exact'][state] for state in exact);losses+=sum(not exact[state] and obs['full_rect_exact'][state] for state in exact)
   observations.append(dict(native_case=native,chromium=chromium,full_rect_exact=exact))
  report['profiles'].append(dict(scale=profile['scale'],html_sha256=sha(directory/'test.html'),first_png_sha256=sha(directory/'1.png'),second_png_sha256=sha(directory/'2.png'),repeated_png_and_queries_identical=True,geometry_queries_sha256=sha(directory/'1-geometry.json'),observations=observations));save()
 assert not bykey
 report.update(observed_exit_code=int(exact_count!=1440),geometry_states=1440,full_rect_exact=exact_count,geometry_differences=1440-exact_count,exact_geometry_gains=gains,exact_geometry_losses=losses,native_outputs_byte_identical=True,native_callbacks_per_run=720,native_cases=720)
except BaseException as error:report.update(observed_exit_code=1,failure=str(error));raise
finally:
 report.update(all_commands_terminal=True,source_after=repository_source_identity(SDK),public_source_after=repository_source_identity(MAIN));report['source_unchanged']=report['source_after']==source;report['public_source_unchanged']=report['public_source_after']==public
 if 'native_app_source' in report:report['native_app_source_after']=app_identity();report['native_app_source_unchanged']=report['native_app_source_after']==report['native_app_source']
 save()
print(json.dumps({k:report.get(k) for k in ['observed_exit_code','geometry_states','full_rect_exact','exact_geometry_gains','exact_geometry_losses']}),flush=True)
raise SystemExit(report['observed_exit_code'])
