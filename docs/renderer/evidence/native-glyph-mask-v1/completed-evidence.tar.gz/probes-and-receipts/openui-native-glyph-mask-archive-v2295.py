"""Archive finished native, renderer and API evidence; never archive a running gate as qualified."""
import gzip, hashlib, io, json, tarfile
from pathlib import Path

MAIN = Path('/home/nero/code/open-ui')
RAW = MAIN / 'out/renderer-evidence/native-viewport-scroll-v1'
OUT = RAW / 'native-glyph-mask-archive-v2295'
STORE = Path('/mnt/e/openui-v02-qualification-d174ea0b') / OUT.name
load = lambda p: json.loads(p.read_bytes())

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(2**20), b''):
            h.update(chunk)
    return h.hexdigest()

gate_name = 'native-aliased-renderer-gates-v2276'
gate = load(RAW / gate_name / 'receipt.json')
assert gate['all_commands_terminal'] and gate['source_unchanged'] and gate['public_source_unchanged']
assert not Path('/proc', str(gate['owner_pid'])).exists()
assert not gate['complete_renderer_matrices_not_run']
assert gate['matrices']['full']['comparisons'] == 22924
assert gate['matrices']['expanded']['comparisons'] == 23728
vertical_name = 'native-vertical-ch-pipeline-v2288'
vertical = load(RAW / vertical_name / 'receipt.json')
outline_name = 'native-outline-corner-pipeline-v2292'
outline = load(RAW / outline_name / 'receipt.json')
for report in [vertical, outline]:
    assert report['all_commands_terminal'] and report['source_unchanged'] and report['public_source_unchanged']
    assert report['native_app_source_unchanged'] and not Path('/proc', str(report['owner_pid'])).exists()
assert not OUT.exists() and not STORE.exists()
STORE.mkdir()
OUT.symlink_to(STORE, target_is_directory=True)
inputs = {}

def add(path, name):
    assert path.is_file() and name not in inputs, name
    inputs[name] = path

def collect(root, prefix, suffixes):
    for path in sorted(root.rglob('*')):
        if path.is_file() and path.suffix in suffixes:
            add(path, prefix + '/' + str(path.relative_to(root)))

native_steps = []
for name in ['native-glyph-origin-pipeline-v2257', 'native-glyph-origin-pipeline-v2260',
             'native-glyph-origin-pipeline-v2263', 'native-glyph-origin-pipeline-v2272']:
    report = load(RAW / name / 'receipt.json')
    assert report['all_commands_terminal'] and report['source_unchanged'] and report['public_source_unchanged']
    assert report['native_app_source_unchanged'] and not Path('/proc', str(report['owner_pid'])).exists()
    native_steps.append(dict(name=name, source=report['source'], totals=report['totals'],
                             receipt_sha256=sha(RAW / name / 'receipt.json')))
    collect(RAW / name, 'native/' + name, {'.json', '.log', '.py', '.html', '.png'})
for name in [vertical_name, outline_name, 'native-aliased-mask-checks-v2275',
             'native-vertical-ch-checks-v2287', 'native-aliased-mask-source-repro-v2274',
             'native-outline-primary-v2293']:
    report = load(RAW / name / 'receipt.json')
    assert report['all_commands_terminal']
    collect(RAW / name, 'records/' + name, {'.json', '.log', '.patch', '.py', '.html', '.png', '.cc'})
add(RAW / 'native-glyph-raster-review-v2277.json', 'records/native-glyph-raster-review-v2277.json')
add(RAW / 'native-glyph-full-review-v2298.json', 'records/native-glyph-full-review-v2298.json')
selected_images = 0
for name in [gate_name, 'native-aliased-renderer-gates-v2264']:
    report = load(RAW / name / 'receipt.json')
    assert report['all_commands_terminal'] and report['source_unchanged'] and report['public_source_unchanged']
    assert not Path('/proc', str(report['owner_pid'])).exists()
    for p in sorted((RAW / name).glob('*')):
        if p.is_file() and p.suffix in {'.json', '.log'}:
            add(p, 'renderer/' + name + '/' + p.name)
    for suite, matrix in report['matrices'].items():
        root = RAW / name / (suite + '-matrix')
        filename = 'full-summary.json' if suite == 'sizing-caption-neighbors' else suite + '-summary.json'
        path = root / filename
        assert sha(path) == matrix['summary_sha256']
        summary = load(path)
        rows = {(profile['profile'], row['id']): row for profile in summary['profiles'] for row in profile['tests']}
        add(path, 'renderer/' + name + '/' + suite + '/' + filename)
        for change in matrix['changed_comparisons']:
            directory = root / change['profile'] / change['id']
            row = rows[(change['profile'], change['id'])]
            for filename in ['test.html', 'chromium.png', 'openui.png']:
                input_path = directory / filename
                if filename.endswith('.png'):
                    prefix = filename.removesuffix('.png')
                    if not input_path.is_file():
                        input_path = Path('/mnt/e/openui-v02-qualification-d174ea0b/renderer-cache') / row[prefix + '_png_cache_path']
                    assert sha(input_path) == row[prefix + '_png_sha256']
                add(input_path, 'renderer/' + name + '/' + suite + '/' + change['profile'] + '/' + change['id'] + '/' + filename)
                selected_images += int(filename.endswith('.png'))
for app in ['native-glyph-origin-v2256', 'native-glyph-origin-v2259', 'native-glyph-origin-v2262',
            'native-glyph-origin-v2269', 'native-vertical-ch-v2286', 'native-outline-corner-v2291']:
    for filename in ['Cargo.toml', 'Cargo.lock', 'src/main.rs']:
        add(MAIN / 'out/private-native-apps' / app / filename, 'native-apps/' + app + '/' + filename)
repro = load(RAW / 'native-aliased-mask-source-repro-v2274/receipt.json')
for rel in repro['production_changes']:
    add(MAIN / 'out/private-native-aliased-mask-v2268' / rel, 'source/glyph-mask/' + rel)
for rel in ['bindings/rust/openui-text/src/font/platform.rs', 'bindings/rust/openui-text/src/font/relative.rs']:
    add(MAIN / 'out/private-native-vertical-ch-v2285' / rel, 'source/vertical-ch/' + rel)
for pattern in ['openui-native-glyph-origin-app-v2256.rs', 'openui-native-glyph-origin-pipeline-v2257.py',
                'openui-native-glyph-origin-pipeline-v2260.py', 'openui-native-glyph-origin-pipeline-v2263.py',
                'openui-native-glyph-origin-pipeline-v2272.py', 'openui-native-glyph-replay-prepare-v2258.*',
                'openui-native-glyph-replay-v2258.patch', 'openui-native-aliased-strike-v2261.patch',
                'openui-native-aliased-mask-prepare-v2267*', 'openui-native-aliased-mask-prepare-v2268*',
                'openui-native-aliased-mask-app-prepare-v2271.*', 'openui-native-aliased-mask-v2268.patch',
                'openui-native-aliased-renderer-gates-v2276.py', 'openui-native-vertical-ch-prepare-v2283*',
                'openui-native-vertical-ch-prepare-v2285.*', 'openui-native-vertical-ch-v2285.patch',
                'openui-native-vertical-ch-pipeline-v2288.py', 'openui-native-outline-corner-app-v2291.rs',
                'openui-native-outline-prepare-v2291.*', 'openui-native-outline-corner-pipeline-v2292.py',
                'openui-native-outline-primary-v2293.py', 'openui-terminal-evidence-relocation-v2266.*',
                'openui-terminal-evidence-relocation-v2282.*', 'openui-terminal-evidence-relocation-v2296.*',
                'openui-native-glyph-full-review-v2298.py']:
    paths = list(Path('/tmp').glob(pattern))
    assert paths, pattern
    for p in paths:
        add(p, 'probes-and-receipts/' + p.name)
workspace_path = RAW / 'native-aliased-workspace-v2290/receipt.json'
workspace = None
if workspace_path.exists():
    workspace = load(workspace_path)
    assert workspace['all_commands_terminal'] and workspace['source_unchanged'] and workspace['public_source_unchanged']
    assert not Path('/proc', str(workspace['owner_pid'])).exists()
    collect(workspace_path.parent, 'workspace/native-aliased-workspace-v2290', {'.json', '.log'})
    add(Path('/tmp/openui-native-aliased-workspace-v2290.py'), 'probes-and-receipts/openui-native-aliased-workspace-v2290.py')
add(Path(__file__), 'probes-and-receipts/' + Path(__file__).name)
archive = OUT / 'completed-evidence.tar.gz'
members = []
with archive.open('xb') as stream:
    with gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0, compresslevel=6) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, path in sorted(inputs.items()):
                content = path.read_bytes()
                info = tarfile.TarInfo(name)
                info.size = len(content)
                info.mode = 0o644
                info.mtime = 0
                tar.addfile(info, io.BytesIO(content))
                members.append(dict(name=name, source_path=str(path), bytes=len(content), sha256=hashlib.sha256(content).hexdigest()))
assert archive.stat().st_size < 95 * 2**20, 'Split immutable evidence archives instead of exceeding GitHub file limits'
with tarfile.open(archive, 'r:gz') as tar:
    assert [m.name for m in tar.getmembers()] == [m['name'] for m in members]
    for row in members:
        content = tar.extractfile(row['name']).read()
        assert len(content) == row['bytes'] and hashlib.sha256(content).hexdigest() == row['sha256'] == sha(inputs[row['name']])
report = dict(schema_version=1, source=gate['source'], public_source_at_trial=gate['public_source'],
              all_commands_terminal=True, candidate_applied_to_umbrella=False, native_steps=native_steps,
              renderer_matrices=gate['matrices'], actual_renderer_gate_exit=gate['observed_exit_code'],
              upright_ch=dict(source=vertical['source'], actual_exit=vertical['observed_exit_code'],
                              geometry_states=vertical.get('geometry_states'), full_rect_exact=vertical.get('full_rect_exact'),
                              geometry_differences=vertical.get('geometry_differences'), native_pixels_captured=False),
              outline_minimizer=dict(source=outline['source'], actual_exit=outline['observed_exit_code'],
                                     totals=outline.get('totals'), chromium_captures_run=outline.get('chromium_captures_run')),
              workspace=workspace, selected_changed_images=selected_images,
              accepted_original_exact=21334, accepted_original_total=22924, new_release_states_admitted=0,
              archive=dict(path=str(archive), bytes=archive.stat().st_size, sha256=sha(archive),
                           all_members_freshly_hash_verified=True, members=members),
              javascript_executed_by_openui=False, pixel_tolerance=0, release_qualification=False,
              promotion_allowed=False, probe_sha256=sha(Path(__file__)))
(OUT / 'receipt.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
print(json.dumps(dict(bytes=archive.stat().st_size, members=len(members), sha256=sha(archive))))
