"""Use a shared strong hinted physical strike for Chromium aliased author text."""
import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');BASE=MAIN/'out/private-native-aliased-strike-v2261';ROOT=MAIN/'out/private-native-aliased-mask-v2268';OLDAPP=MAIN/'out/private-native-apps/native-glyph-origin-v2269';APP=MAIN/'out/private-native-apps/native-glyph-origin-v2269'
OUT=Path('/tmp/openui-native-aliased-mask-prepare-v2268.json')
assert not ROOT.exists() and not APP.exists() and not OUT.exists()
sys.path.insert(0,str(MAIN/'tools/qualification'));from renderer_source_identity import repository_source_identity
before=repository_source_identity(BASE);public=repository_source_identity(MAIN)
assert before['clean'] and before['commit']=='58ab7b421d476f6385558168ec331bcc05fdb448' and public['clean']
assert shutil.disk_usage(MAIN).free>700*2**20
subprocess.run(['git','clone','--shared','--no-checkout',str(BASE),str(ROOT)],check=True,capture_output=True)
for key in ['user.name','user.email']:
 value=subprocess.check_output(['git','config','--get',key],cwd=MAIN,text=True).strip();subprocess.run(['git','config',key,value],cwd=ROOT,check=True)
subprocess.run(['git','read-tree',before['commit']],cwd=ROOT,check=True)
for name in filter(None,subprocess.check_output(['git','ls-files','-z'],cwd=BASE).decode().split('\0')):
 src=BASE/name;dst=ROOT/name;dst.parent.mkdir(parents=True,exist_ok=True)
 if src.is_symlink():dst.symlink_to(os.readlink(src))
 else:os.link(src,dst)
assert repository_source_identity(ROOT)==before
for name in ['bindings/rust/openui-paint/src/painter.rs','bindings/rust/openui-text/src/shaping/shape_result.rs']:
 p=ROOT/name;t=p.with_name(p.name+'.owned-v2268');shutil.copy2(p,t);os.replace(t,p)
p=ROOT/'bindings/rust/openui-paint/src/painter.rs';s=p.read_text()
start=s.index('        let replays_native_small_ahem_start = inside_native_button');end=s.index('\n    }\n    // 4. Emphasis',start)
s=s[:start]+s[end:];p.write_text(s)
p=ROOT/'bindings/rust/openui-text/src/shaping/shape_result.rs';s=p.read_text()
old='    font.set_subpixel(true);'
new="    // A monochrome mask uses the resolved font's positioning policy.\n    // LCD paths retain fractional phases for their coverage filter.\n    font.set_subpixel(\n        raster_policy != TextRasterPolicy::ChromiumAliased || source_font.is_subpixel(),\n    );"
assert s.count(old)==1;p.write_text(s.replace(old,new))
subprocess.run(['bash','-c','ulimit -s 262144; rustfmt --edition 2021 --config skip_children=true bindings/rust/openui-paint/src/painter.rs bindings/rust/openui-text/src/shaping/shape_result.rs'],cwd=ROOT,check=True)
subprocess.run(['git','add','bindings/rust/openui-paint/src/painter.rs','bindings/rust/openui-text/src/shaping/shape_result.rs'],cwd=ROOT,check=True)
patch=Path('/tmp/openui-native-aliased-mask-v2268.patch');patch.write_bytes(subprocess.check_output(['git','diff','--cached','--binary','--full-index'],cwd=ROOT))
subprocess.run(['git','commit','-m','Respect monochrome glyph positioning and remove preceding-row mask replay'],cwd=ROOT,check=True,capture_output=True)
source=repository_source_identity(ROOT);assert source['clean'] and repository_source_identity(BASE)==before and repository_source_identity(MAIN)==public
APP.mkdir()
for name in ['Cargo.toml','Cargo.lock','src/main.rs']:
 p=APP/name;p.parent.mkdir(parents=True,exist_ok=True);content=(OLDAPP/name).read_bytes()
 if name=='Cargo.toml':content=content.replace(str(BASE).encode(),str(ROOT).encode())
 p.write_bytes(content)
subprocess.run(['git','init','-q'],cwd=APP,check=True)
for key in ['user.name','user.email']:
 value=subprocess.check_output(['git','config','--get',key],cwd=MAIN,text=True).strip();subprocess.run(['git','config',key,value],cwd=APP,check=True)
subprocess.run(['git','add','.'],cwd=APP,check=True);subprocess.run(['git','commit','-q','-m','Prepare unchanged native glyph app against single-pass positioning trial'],cwd=APP,check=True)
report=dict(source=source,parent_source=before,public_source=public,root=str(ROOT),app_root=str(APP),all_commands_terminal=True,source_only_preparation=True,cargo_commands_run=0,native_commands_run=0,chromium_commands_run=0,source_patch=str(patch),source_patch_sha256=hashlib.sha256(patch.read_bytes()).hexdigest(),aliased_physical_strike_policy_shared=True,preceding_row_replay_removed=True,aliased_subpixel_policy_respects_resolved_font=True,added_font_or_size_conditions=False,release_qualification=False,promotion_allowed=False,javascript_executed_by_openui=False,probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
OUT.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(report))
