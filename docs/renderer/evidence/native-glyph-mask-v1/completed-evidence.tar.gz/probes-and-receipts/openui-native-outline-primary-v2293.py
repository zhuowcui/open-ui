"""Preserve exact pinned primary outline sources; do not use the unverified local checkout as an oracle."""
import base64, concurrent.futures, hashlib, json, subprocess, urllib.request
from pathlib import Path

MAIN = Path('/home/nero/code/open-ui')
OUT = MAIN / 'out/renderer-evidence/native-viewport-scroll-v1/native-outline-primary-v2293'
STORE = Path('/mnt/e/openui-v02-qualification-d174ea0b') / OUT.name
assert not OUT.exists() and not STORE.exists()
before = subprocess.check_output(['git', 'status', '--porcelain'], cwd=MAIN)
assert not before
STORE.mkdir()
OUT.symlink_to(STORE, target_is_directory=True)
files = {
    'box_border_painter.cc': 'third_party/blink/renderer/core/paint/box_border_painter.cc',
    'outline_painter.cc': 'third_party/blink/renderer/core/paint/outline_painter.cc',
    'graphics_context.cc': 'third_party/blink/renderer/platform/graphics/graphics_context.cc',
}

def fetch(item):
    name, path = item
    url = 'https://chromium.googlesource.com/chromium/src/+/147.0.7727.50/' + path + '?format=TEXT'
    with urllib.request.urlopen(url, timeout=30) as response:
        content = base64.b64decode(response.read(), validate=True)
    (OUT / name).write_bytes(content)
    local = Path('/home/nero/chromium/src') / path
    return dict(name=name, url=url, bytes=len(content), sha256=hashlib.sha256(content).hexdigest(),
                unverified_local_checkout_bytes_identical=local.read_bytes() == content)

with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    rows = list(pool.map(fetch, files.items()))
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=MAIN) == before
report = dict(schema_version=1, files=rows, all_commands_terminal=True, source_changed=False,
              native_commands_run=0, chromium_commands_run=0, cargo_commands_run=0,
              local_checkout_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd='/home/nero/chromium/src', text=True).strip(),
              web_tool_could_not_open_primary_page=True, primary_review_only=True, release_qualification=False,
              javascript_executed_by_openui=False,
              probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(OUT / 'receipt.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
print(json.dumps(report))
