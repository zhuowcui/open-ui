use openui::prelude::*;
use openui_text::{FontRelativeLengthResolver, FontRelativeUnit};
use std::{cell::Cell, rc::Rc};

// Values come from the repeated pinned Chromium native-unit diagnostic,
// not from the Rust conversion under test.
#[test]
fn native_font_relative_lengths_match_chromium_after_rust_callbacks() {
    let fonts = FontCollection::deterministic_test();
    for scale in [1.0, 1.25, 1.5, 2.0, 3.0] {
        for (unit, line_height, before_width, after_width) in [
            (FontRelativeUnit::Ch, LineHeight::Normal, 47.5, 50.0),
            (
                FontRelativeUnit::Ex,
                LineHeight::Normal,
                37.40625,
                40.734375,
            ),
            (
                FontRelativeUnit::Lh,
                LineHeight::Number(1.2),
                56.125,
                61.046875,
            ),
            (
                FontRelativeUnit::Lh,
                LineHeight::Percentage(127.5),
                59.421875,
                64.671875,
            ),
        ] {
            let document = Document::with_font_collection_and_options(
                ViewportMetrics::from_logical_size(800.0, 600.0, scale).unwrap(),
                fonts.clone(),
                EngineOptions {
                    raster_configuration: RasterConfiguration::deterministic_aliased(false),
                },
            )
            .unwrap();
            let element = Element::create(&document, "div").unwrap();
            element.set_position(Position::Absolute).unwrap();
            element.set_left(Length::px(0.0)).unwrap();
            element.set_top(Length::px(0.0)).unwrap();
            element.set_height(LengthValue::px(10.0)).unwrap();
            element
                .set_font_family(FontFamilyList::single("Ahem"))
                .unwrap();
            element.set_font_size(LengthValue::px(18.72)).unwrap();
            element.set_line_height(line_height).unwrap();
            element.set_text("X").unwrap();
            document.body().append_child(&element).unwrap();
            let style = element.computed_style().unwrap();
            let before =
                FontRelativeLengthResolver::from_style_in_collection(&style, fonts.clone());
            element
                .set_width(LengthValue::px(before.resolve(2.5, unit)))
                .unwrap();
            let owned = element.bounding_rect().unwrap().unwrap();
            assert_eq!(owned.width, before_width, "{unit:?} at {scale}");
            let weak = element.downgrade();
            let target = weak.clone();
            let calls = Rc::new(Cell::new(0));
            let called = calls.clone();
            element
                .on("click", move |_| {
                    target
                        .upgrade()
                        .unwrap()
                        .set_font_size(LengthValue::px(20.37))
                        .unwrap();
                    called.set(called.get() + 1);
                })
                .unwrap();
            element.click().unwrap();
            let after_style = element.computed_style().unwrap();
            let after =
                FontRelativeLengthResolver::from_style_in_collection(&after_style, fonts.clone());
            element
                .set_width(LengthValue::px(after.resolve(2.5, unit)))
                .unwrap();
            assert_eq!(
                element.bounding_rect().unwrap().unwrap().width,
                after_width,
                "{unit:?} at {scale}"
            );
            assert_eq!(calls.get(), 1);
            assert_eq!(style.font_size, 18.72);
            assert_eq!(owned.width, before_width);
            assert_eq!(
                before.resolve(2.5, unit),
                FontRelativeLengthResolver::from_style_in_collection(&style, fonts.clone())
                    .resolve(2.5, unit)
            );
            drop(element);
            drop(document);
            assert!(weak.upgrade().is_none());
        }
    }
}
