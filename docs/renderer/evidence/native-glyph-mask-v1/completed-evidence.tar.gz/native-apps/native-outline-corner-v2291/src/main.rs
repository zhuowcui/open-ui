use openui::prelude::*;
use serde_json::{json, Value};
use std::{cell::Cell, error::Error, path::Path, rc::Rc};

fn geometry(element: &Element) -> Result<Value, Box<dyn Error>> {
    let rect = element.bounding_rect()?.ok_or("owned bounds required")?;
    Ok(json!({"x":rect.x,"y":rect.y,"width":rect.width,"height":rect.height}))
}

fn main() -> Result<(), Box<dyn Error>> {
    let output = std::env::args().nth(1).ok_or("output directory required")?;
    let output = Path::new(&output);
    std::fs::create_dir_all(output)?;
    for scale in [1.0, 1.25, 1.5, 2.0, 3.0] {
        for (name, width, height) in [("corner", 305.0, 75.0), ("neighbor", 304.0, 74.0)] {
            let path = output.join(format!("{name}-{scale}"));
            std::fs::create_dir(&path)?;
            let document = Document::with_font_collection_and_options(
                ViewportMetrics::from_logical_size(800.0, 600.0, scale)?,
                FontCollection::deterministic_test(),
                EngineOptions {
                    raster_configuration: RasterConfiguration::deterministic_aliased(false),
                },
            )?;
            let body = document.body();
            body.set_background_color(Color::WHITE)?;
            body.set_overflow_x(Overflow::Hidden)?;
            body.set_overflow_y(Overflow::Hidden)?;
            let element = Element::create(&document, "div")?;
            element.set_position(Position::Absolute)?;
            element.set_left(Length::px(20.0))?;
            element.set_top(Length::px(20.0))?;
            element.set_width(LengthValue::px(width))?;
            element.set_height(LengthValue::px(height))?;
            element.set_outline_width(1)?;
            element.set_outline_style(BorderStyle::Solid)?;
            element.set_outline_color(StyleColor::Resolved(Color::BLUE))?;
            body.append_child(&element)?;
            let before = geometry(&element)?;
            let snapshot = element.bounding_rect()?.ok_or("owned snapshot required")?;
            document.render_to_png(path.join("before.png"))?;
            let weak = element.downgrade();
            let target = weak.clone();
            let calls = Rc::new(Cell::new(0));
            let count = calls.clone();
            element.on("click", move |_| {
                let target = target.upgrade().unwrap();
                target.set_left(Length::px(21.0)).unwrap();
                target.set_top(Length::px(21.0)).unwrap();
                count.set(count.get() + 1);
            })?;
            element.click()?;
            let after = geometry(&element)?;
            document.render_to_png(path.join("after.png"))?;
            assert_eq!(calls.get(), 1);
            assert_eq!(
                before,
                json!({"x":snapshot.x,"y":snapshot.y,"width":snapshot.width,"height":snapshot.height})
            );
            println!(
                "{}",
                json!({"scale":scale,"name":name,"width":width,"height":height,"before":before,"after":after,"callbacks":calls.get(),"owned_bounds_unchanged":true})
            );
            drop(element);
            drop(body);
            drop(document);
            assert!(weak.upgrade().is_none());
        }
    }
    Ok(())
}
