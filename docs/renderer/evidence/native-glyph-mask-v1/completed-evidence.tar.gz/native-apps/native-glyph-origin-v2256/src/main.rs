use openui::prelude::*;
use serde_json::{json, Value};
use std::{cell::Cell, error::Error, path::Path, rc::Rc};

fn bounds(element: &Element) -> Result<Value, Box<dyn Error>> {
    let rect = element.bounding_rect()?.ok_or("owned bounds required")?;
    Ok(json!({"x":rect.x,"y":rect.y,"width":rect.width,"height":rect.height}))
}

fn main() -> Result<(), Box<dyn Error>> {
    let output = std::env::args().nth(1).ok_or("output directory required")?;
    let output = Path::new(&output);
    std::fs::create_dir_all(output)?;
    let fonts = FontCollection::deterministic_test();
    for scale in [1.0, 1.25, 1.5, 2.0, 3.0] {
        for (name, writing, left, top, width, height) in [
            (
                "horizontal",
                WritingMode::HorizontalTb,
                21.0,
                21.0,
                150.0,
                42.0,
            ),
            ("vertical", WritingMode::VerticalLr, 21.0, 73.0, 42.0, 150.0),
        ] {
            let path = output.join(format!("{name}-{scale}"));
            std::fs::create_dir(&path)?;
            let document = Document::with_font_collection_and_options(
                ViewportMetrics::from_logical_size(800.0, 600.0, scale)?,
                fonts.clone(),
                EngineOptions {
                    raster_configuration: RasterConfiguration::deterministic_aliased(false),
                },
            )?;
            document.body().set_width(LengthValue::px(800.0))?;
            document.body().set_height(LengthValue::px(600.0))?;
            document.body().set_background_color(Color::WHITE)?;
            document.body().set_overflow_x(Overflow::Hidden)?;
            document.body().set_overflow_y(Overflow::Hidden)?;
            let element = Element::create(&document, "div")?;
            element.set_position(Position::Absolute)?;
            element.set_left(Length::px(left))?;
            element.set_top(Length::px(top))?;
            element.set_width(LengthValue::px(width))?;
            element.set_height(LengthValue::px(height))?;
            element.set_writing_mode(writing)?;
            element.set_text_orientation(TextOrientation::Mixed)?;
            element.set_font_family(FontFamilyList {
                families: [
                    "Ahem",
                    "Droid Sans Fallback",
                    "Noto Sans Devanagari",
                    "Noto Color Emoji",
                    "DejaVu Sans",
                ]
                .into_iter()
                .map(|name| FontFamily::Named(name.into()))
                .collect(),
            })?;
            element.set_font_size(LengthValue::px(15.0))?;
            element.set_line_height(LineHeight::Length(21.0))?;
            element.set_font_kerning(FontKerning::None)?;
            element.set_font_variant_ligatures(FontVariantLigatures::none())?;
            element.set_color(Color::BLACK)?;
            element.set_border_top_width(1)?;
            element.set_border_right_width(1)?;
            element.set_border_bottom_width(1)?;
            element.set_border_left_width(1)?;
            element.set_border_top_style(BorderStyle::Solid)?;
            element.set_border_right_style(BorderStyle::Solid)?;
            element.set_border_bottom_style(BorderStyle::Solid)?;
            element.set_border_left_style(BorderStyle::Solid)?;
            element.set_border_top_color(StyleColor::Resolved(Color::BLUE))?;
            element.set_border_right_color(StyleColor::Resolved(Color::BLUE))?;
            element.set_border_bottom_color(StyleColor::Resolved(Color::BLUE))?;
            element.set_border_left_color(StyleColor::Resolved(Color::BLUE))?;
            document.body().append_child(&element)?;
            let first = document.create_text_node("min")?;
            element.append_text_child(&first)?;
            let br = Element::create(&document, "br")?;
            element.append_child(&br)?;
            let second = document.create_text_node("in the box")?;
            element.append_text_child(&second)?;
            let before = bounds(&element)?;
            let owned_style = element.computed_style()?;
            let owned_bounds = element.bounding_rect()?.ok_or("snapshot required")?;
            document.render_to_png(path.join("before.png"))?;
            let target = element.downgrade();
            let weak = target.clone();
            let calls = Rc::new(Cell::new(0));
            let observed = calls.clone();
            element.on("click", move |_| {
                let element = target.upgrade().unwrap();
                if writing == WritingMode::HorizontalTb {
                    element.set_left(Length::px(188.0)).unwrap();
                } else {
                    element.set_top(Length::px(225.0)).unwrap();
                }
                observed.set(observed.get() + 1);
            })?;
            element.click()?;
            let after = bounds(&element)?;
            document.render_to_png(path.join("after.png"))?;
            assert_eq!(calls.get(), 1);
            assert_eq!(owned_style.font_size, 15.0);
            assert_eq!(
                before,
                json!({"x":owned_bounds.x,"y":owned_bounds.y,"width":owned_bounds.width,"height":owned_bounds.height})
            );
            assert_eq!(first.data()?, "min");
            assert_eq!(second.data()?, "in the box");
            println!(
                "{}",
                json!({"scale":scale,"writing":name,"before":before,"after":after,"callbacks":calls.get(),"owned_snapshots_unchanged":true})
            );
            drop(first);
            drop(second);
            drop(br);
            drop(element);
            drop(document);
            assert!(weak.upgrade().is_none());
        }
    }
    Ok(())
}
