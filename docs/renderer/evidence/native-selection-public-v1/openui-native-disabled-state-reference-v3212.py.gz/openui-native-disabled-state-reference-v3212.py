import fcntl,hashlib,json,os,subprocess,sys,tempfile
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');NAME='native-disabled-state-reference-v3212';RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';OUT=Path('/mnt/e/openui-v02-qualification-d174ea0b')/NAME
lock=open('/tmp/'+NAME+'.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert not OUT.exists() and not (RAW/NAME).exists();OUT.mkdir();(RAW/NAME).symlink_to(OUT,target_is_directory=True)
sys.path.insert(0,str(MAIN/'tools/accountability'));import run_all_pixel_comparisons as capture
sys.path.insert(0,'/tmp');from openui_parallel_source_identity_v3060 import identity
source=identity(MAIN);assert source['clean'] and source['commit']=='fcabea38ac537bca58cb1f6653199ee3bbd42097'
chrome=MAIN/'chrome/linux-147.0.7727.50/chrome-linux64/chrome';scratch=Path('/dev/shm/ou3212');scratch.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
cases=[
('all-enabled','',''),
('outer-disabled','','f.setAttribute("disabled","")'),
('inner-disabled','','nf.setAttribute("disabled","")'),
('both-disabled','','f.setAttribute("disabled","");nf.setAttribute("disabled","")'),
('optgroup-disabled','','og.setAttribute("disabled","")'),
('select-disabled','','s.setAttribute("disabled","")'),
('option-own','','o.setAttribute("disabled","")'),
('option-move-out','og.setAttribute("disabled","")','s.appendChild(o)'),
('option-wrapper','og.setAttribute("disabled","")','wrap.appendChild(o)'),
('legend-hidden','','l1.style.display="none";f.setAttribute("disabled","")'),
('legend-second-first','','f.setAttribute("disabled","");f.insertBefore(l2,l1)'),
('ordinary-disabled','','normal.setAttribute("disabled","")'),
]
setup=r"""
document.body.innerHTML='<fieldset id=f><legend id=l1><TAG id=first></TAG></legend><legend id=l2><TAG id=second></TAG></legend><div id=normal><TAG id=a></TAG></div><fieldset id=nf><legend><TAG id=innerfirst></TAG></legend><TAG id=inner></TAG></fieldset><select id=s><optgroup id=og><option id=o>One</option></optgroup><option id=o2>Two</option><span id=wrap></span></select></fieldset><TAG id=b></TAG>';
for(const id of ['f','l1','l2','normal','nf','first','second','a','innerfirst','inner','b','s','og','o','o2','wrap'])window[id]=document.getElementById(id);
window.fields=[f,nf,first,second,a,innerfirst,inner,b,s,og,o,o2,normal];
window.snapshot=()=>Object.fromEntries(fields.map(node=>[node.id,{kind:node.tagName.toLowerCase(),own:node.hasAttribute('disabled'),property:node.disabled===undefined?null:node.disabled,effective:node.matches(':disabled'),enabled:node.matches(':enabled'),connected:node.isConnected,parent:node.parentElement?(node.parentElement.id||node.parentElement.tagName.toLowerCase()):null}]));true
"""

report=dict(schema_version=1,source=source,owner_pid=os.getpid(),all_commands_terminal=False,script_runs_only_in_offline_chromium=True,javascript_executed_by_openui=False,native_api_behavior_measured=False,release_qualification=False,diagnostic_only=True,probe_sha256=sha(__file__),chrome_sha256=sha(chrome),harness_sha256=sha(MAIN/'tools/accountability/run_all_pixel_comparisons.py'),runs=[])
def save():(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
def evaluate(client,text,promise=False):
 r=client.command('Runtime.evaluate',dict(expression=text,returnByValue=True,awaitPromise=promise));assert 'exceptionDetails' not in r,r;return r['result'].get('value')
def barrier(client):return evaluate(client,'new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve(true))))',True)
save()
try:
 for repeat in [1,2]:
  observations=[]
  for tag in ['input','textarea']:
   for name,callbacks,actions in cases:
    process=None;client=None
    with tempfile.TemporaryDirectory(prefix='chrome-',dir=scratch) as profile:
     try:
      command=[str(chrome),'--headless','--disable-gpu','--no-sandbox','--no-first-run','--no-default-browser-check','--remote-debugging-port=0','--user-data-dir='+profile,'--window-size=800,687','about:blank'];process=subprocess.Popen(command,env=capture.chrome_environment(str(chrome.parent)),stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True);port=capture._wait_for_devtools_endpoint(profile,process);client=capture._CdpWebSocket(capture._page_websocket_url(port));client.command('Page.enable');client.command('Page.bringToFront');client.command('Emulation.setFocusEmulationEnabled',dict(enabled=True))
      evaluate(client,setup.replace('TAG',tag));barrier(client);evaluate(client,callbacks+';true');barrier(client)
      initial=evaluate(client,'snapshot()');synchronous=evaluate(client,actions+';snapshot()');barrier(client);observed=evaluate(client,'snapshot()')
      observations.append(dict(scenario=tag+'-'+name,control=tag,variant=name,initial=initial,synchronous=synchronous,observed=observed))
     finally:capture._close_chromium_client(client);capture._stop_chromium_process(process)
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=MAIN,text=True).strip()==source['commit'] and not subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=MAIN)
    report['current_scenario']=tag+'-'+name;save()
  report.pop('current_scenario',None);path=OUT/('observations-'+str(repeat)+'.json');path.write_text(json.dumps(observations,sort_keys=True,indent=2)+'\n');report['runs'].append(dict(repeat=repeat,scenarios=len(observations),callback_rows=0,observations_sha256=sha(path)));save()
 assert (OUT/'observations-1.json').read_bytes()==(OUT/'observations-2.json').read_bytes();report['repeated_observations_identical']=True;report['observed_exit_code']=0
except BaseException as error:report.update(observed_exit_code=1,failure=repr(error));raise
finally:
 report.update(source_after=identity(MAIN),all_commands_terminal=True);report['source_unchanged']=report['source_after']==source;assert sha(chrome)==report['chrome_sha256'] and sha(MAIN/'tools/accountability/run_all_pixel_comparisons.py')==report['harness_sha256'];save()
print(json.dumps(dict(all_commands_terminal=True,observed_exit_code=report['observed_exit_code'],scenarios=report['runs'])),flush=True)
raise SystemExit(report['observed_exit_code'])
