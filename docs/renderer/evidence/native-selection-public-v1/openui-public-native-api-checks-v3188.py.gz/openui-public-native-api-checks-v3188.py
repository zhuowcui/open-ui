import fcntl,hashlib,json,os,re,shutil,signal,subprocess,sys,time
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');ROOT=MAIN;RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';OUT=RAW/'public-native-api-checks-v3188';STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/OUT.name
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
sys.path.insert(0,'/tmp');from openui_parallel_source_identity_v3060 import identity as repository_source_identity
prior=json.loads((RAW/'public-native-selection-v3182/receipt.json').read_bytes());assert prior['all_commands_terminal'] and prior['source_unchanged'] and prior['observed_exit_code']==0
assert json.loads(Path('/tmp/openui-public-native-selection-completed-audit-v3184.json').read_bytes())['actual_whole_exit_code']==0
assert json.loads(Path('/tmp/openui-public-native-api-stopped-audit-v3186.json').read_bytes())['actual_whole_exit_code']==1
assert json.loads(Path('/tmp/openui-retired-build-cache-cleanup-v3187.json').read_bytes())['observed_exit_code']==0
source=repository_source_identity(ROOT);assert source['clean'] and source['commit'].startswith('fcabea38')
public_source=source;assert public_source['clean'] and public_source['commit'].startswith('fcabea38')
env=dict(os.environ,CARGO_TARGET_DIR='/mnt/e/openui-v02-cargo-c73754e2/target',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_BUILD_JOBS='4',RUST_MIN_STACK='4194304',CARGO_INCREMENTAL='0',PYTHONDONTWRITEBYTECODE='1',TMPDIR='/dev/shm/ou3188')
env.pop('LD_PRELOAD',None);env.pop('LD_LIBRARY_PATH',None)
Path(env['TMPDIR']).mkdir(exist_ok=False)
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as stream:
  for data in iter(lambda:stream.read(1024*1024),b''):h.update(data)
 return h.hexdigest()
report=dict(schema_version=1,source=source,public_source=public_source,steps=[],all_commands_terminal=False,owner_pid=os.getpid(),release_qualification=False,renderer_matrices_not_run=True,probe_sha256=sha(Path(__file__)))
def save():(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
def run(name,command,cwd=ROOT/'bindings/rust',required=True):
 current=repository_source_identity(ROOT);assert current==source==public_source
 log=OUT/(name+'.log')
 with log.open('xb') as stream:
  child=subprocess.Popen(command,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True);report['current_process']=dict(pid=child.pid,stage=name);save()
  try:
   while child.poll() is None:
    if shutil.disk_usage(ROOT).free<128*2**20 or shutil.disk_usage(Path(env['CARGO_TARGET_DIR'])).free<10*2**30:
     report['disk_guard_triggered']=True;os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=20);break
    time.sleep(1)
   code=child.wait()
  except BaseException:
   if child.poll() is None:
    os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=20)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
   raise
 report.pop('current_process');row=dict(name=name,command=command,observed_exit_code=code,log_sha256=sha(log));report['steps'].append(row);save();print(json.dumps(dict(name=name,observed_exit_code=code)),flush=True)
 current=repository_source_identity(ROOT);assert current==source==public_source
 if required:assert code==0,name
 return log.read_bytes()
base=['cargo','--config',str(ROOT/'bindings/rust/.cargo/config.chromium.toml')]
save()
try:
 meta=json.loads(run('locked-metadata',base+['metadata','--locked','--offline','--format-version','1']))
 local={p['id']:p for p in meta['packages'] if p['source'] is None}
 assert all(Path(p['manifest_path']).resolve().is_relative_to(ROOT) for p in local.values())
 run('clean-local-packages',base+['clean','--locked']+[a for p in local for a in ['-p',p]])
 proof={}
 def verify(log,first):
  artifacts=[]
  for line in log.splitlines():
   if not line.startswith(b'{'):continue
   record=json.loads(line)
   if record.get('reason')!='compiler-artifact' or record['target']['kind']==['custom-build']:continue
   package=local.get(record['package_id'])
   if package is None:continue
   assert Path(record['manifest_path']).resolve()==Path(package['manifest_path']).resolve()
   assert Path(record['target']['src_path']).resolve().is_relative_to(ROOT)
   hashes={path:sha(path) for path in record['filenames']}
   if record['fresh']:assert not first and all(proof.get(p)==h for p,h in hashes.items()),record
   proof.update(hashes);artifacts.append(dict(record=record,sha256=hashes))
  assert any(a['record']['target']['name']=='openui_ffi' for a in artifacts)
  return artifacts
 workspace=run('locked-workspace-tests',base+['test','--locked','--offline','--workspace','--features','openui-ffi/linux','--message-format=json'])
 report['workspace_artifacts']=verify(workspace,True)
 totals=[tuple(map(int,m)) for m in re.findall(rb'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',workspace)]
 report['workspace_tests']=dict(passed=sum(t[0] for t in totals),failed=sum(t[1] for t in totals),ignored=sum(t[2] for t in totals));assert report['workspace_tests']['failed']==0;save()
 ffi=run('build-linux-c-abi',base+['build','--locked','--offline','-p','openui-ffi','--features','linux','--message-format=json'])
 report['ffi_artifacts']=verify(ffi,False)
 library=OUT/'libopenui_ffi.so';shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/libopenui_ffi.so',library)
 assert sha(library) in [h for artifact in report['ffi_artifacts'] for h in artifact['sha256'].values()]
 (OUT/'libopenui.so.0').symlink_to(library.name)
 report['library_sha256']=sha(library);report['library_source_proven']=True;save()
 run('all-c-cpp-consumers',[sys.executable,str(ROOT/'tools/ffi/verify_abi.py'),'--library',str(library)],ROOT)
 headless=run('headless-c-abi-tests',base+['test','--locked','--offline','-p','openui-ffi','--lib','--message-format=json'])
 report['headless_artifacts']=verify(headless,False);save()
 run('release-source',[sys.executable,'tools/release/build_v02_linux.py','--verify-source'],ROOT,required=False)
 run('conformance',[sys.executable,'tools/conformance/verify_v02.py'],ROOT,required=False)
 run('performance-contract',[sys.executable,'tools/performance/verify_v02.py'],ROOT,required=False)
 run('porter-controls',[sys.executable,'-m','unittest','tools.wpt.test_sp20_closure'],ROOT,required=False)
 run('rust-format',['bash','-c','ulimit -s 262144; cargo fmt --all -- --check'],required=False)
 run('c-abi-generator',[sys.executable,'tools/ffi/generate_ffi.py','--check'],ROOT,required=False)
 for generator in ['tools/release/generate_v02_contract.py','tools/style/generate_properties.py','tools/wpt/generate_sp13r_multicol_closure.py','tools/wpt/generate_sp17_closure.py','tools/wpt/generate_sp18_closure.py','tools/wpt/generate_sp20_closure.py']:
  run('generator-'+Path(generator).stem,[sys.executable,generator,'--check'],ROOT,required=False)
 run('renderer-contract',[sys.executable,'tools/qualification/generate_renderer_contract.py','--check'],ROOT,required=False)
 run('accountability',[sys.executable,'tools/accountability/audit.py','--repository-only'],ROOT,required=False)
 report['observed_exit_code']=int(any(x['observed_exit_code']!=0 for x in report['steps']))
 report['all_required_steps_recorded']=len(report['steps'])==20
except BaseException as error:
 report.update(observed_exit_code=1,failure=repr(error));raise
finally:
 report['source_after']=repository_source_identity(ROOT);report['source_unchanged_throughout']=report['source_after']==source
 report['public_source_after']=report['source_after'];report['public_source_unchanged_throughout']=report['public_source_after']==public_source
 report['all_commands_terminal']=True;save();print(json.dumps(dict(all_terminal=True,observed_exit_code=report.get('observed_exit_code'),source_unchanged=report['source_unchanged_throughout'])),flush=True)

raise SystemExit(report['observed_exit_code'])
