import fcntl,hashlib,json,os,shutil,signal,subprocess,sys,time
from pathlib import Path
MAIN=Path('/home/nero/code/open-ui');SDK=MAIN;RAW=MAIN/'out/renderer-evidence/native-viewport-scroll-v1';NAME='public-native-selection-v3182';OUT=Path('/mnt/e/openui-v02-qualification-d174ea0b')/NAME
prior=json.loads((RAW/'native-rounded-layer-main-renderer-v3139/receipt.json').read_bytes());assert prior['all_commands_terminal']
failed=json.loads((RAW/'public-native-selection-v3167/receipt.json').read_bytes());assert failed['all_commands_terminal'] and failed['source_unchanged'] and failed['observed_exit_code']==1
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['cargo','rustc','pixel_compare','rustfmt']:assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
assert not OUT.exists() and not (RAW/NAME).exists();OUT.mkdir();(RAW/NAME).symlink_to(OUT,target_is_directory=True)
sys.path.insert(0,'/tmp');from openui_parallel_source_identity_v3060 import identity
print('Reading every clean public source byte',flush=True)
source=identity(SDK);assert source['clean'] and source['commit']==Path('/tmp/openui-public-native-selection-pin-v3182.txt').read_text().strip()
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(2**20),b''):h.update(b)
    return h.hexdigest()
reference_pins={'native-selection-reentry-oracle-v3062/receipt.json': 'af5d20ef562449e89da7af720e018bdb6b1d9c98c7bf1e9fdc5564537ebd0dc4', 'native-selection-reentry-oracle-v3062/observations-1.json': '3de3fa59ae761225c625d89d02111e43dc13848da2bf1965b09b059986c55865', 'native-selection-reentry-oracle-v3062/observations-2.json': '3de3fa59ae761225c625d89d02111e43dc13848da2bf1965b09b059986c55865', 'native-selection-frame-reentry-oracle-v3084/receipt.json': '41af67f8f798538488bdba646971cd9458292fc6e7655b6f23ba1b62a4158fc5', 'native-selection-frame-reentry-oracle-v3084/observations-1.json': '857034e9d1f6eb18ebf2ad417a787365ba7e4ae237205be5c23be031e0c8cc63', 'native-selection-frame-reentry-oracle-v3084/observations-2.json': '857034e9d1f6eb18ebf2ad417a787365ba7e4ae237205be5c23be031e0c8cc63', 'native-selection-value-oracle-v3111/receipt.json': '63adca4ba011d83abf9780148ece2fe06b85ed26b55bff9aa5c46ee9e0036ea4', 'native-selection-value-oracle-v3111/observations-1.json': '54544780982c67d3d6f6c27bcbf126769cf86a4748ee3f4e5b1253fbdc25a148', 'native-selection-value-oracle-v3111/observations-2.json': '54544780982c67d3d6f6c27bcbf126769cf86a4748ee3f4e5b1253fbdc25a148', 'native-range-scalar-replacement-oracle-v2995/receipt.json': '976726754e6a46c18c0e6e86fc3c04b45b63f30d74f759bc05735e6954c36567', 'native-range-scalar-replacement-oracle-v2995/observations-1.json': '975da433559db95621b88856c6a43a50db5651608b1e772011a5fe91eb636308', 'native-range-scalar-replacement-oracle-v2995/observations-2.json': '975da433559db95621b88856c6a43a50db5651608b1e772011a5fe91eb636308', 'native-range-replacement-oracle-v2897/receipt.json': '95e012ea45987806d70d0c7c727898afded94f2fd55d26d360190305a87f62d8', 'native-range-replacement-oracle-v2897/observations-1.json': '7132b6d4fc45391c8c572679994fd04bfbe0bc72639018b00fc5ec082a36a8f4', 'native-range-replacement-oracle-v2897/observations-2.json': '7132b6d4fc45391c8c572679994fd04bfbe0bc72639018b00fc5ec082a36a8f4', 'native-disabled-focus-oracle-v3135/receipt.json': 'ca1f75935f981e56c1fcc5bf7e1a0be07bbe272fbb7c3d40fddbd70179483e8e', 'native-disabled-focus-oracle-v3135/observations-1.json': '1b50c76174e789b8f692e4657a57595ca88c997b79245314fe179d153d3ae731', 'native-disabled-focus-oracle-v3135/observations-2.json': '1b50c76174e789b8f692e4657a57595ca88c997b79245314fe179d153d3ae731', 'native-editing-metadata-oracle-v2697/receipt.json': '919eaf7029a6b2c7b86939d4c3accdfd9fa2399f06601931b29bae2c9f3ddba0', 'native-editing-metadata-oracle-v2697/observations-1.json': '8ee53d647b4861b398c5a259e15ec9a8bf46170404a88cb5f2b499c132303193', 'native-editing-metadata-oracle-v2697/observations-2.json': '8ee53d647b4861b398c5a259e15ec9a8bf46170404a88cb5f2b499c132303193', 'native-editing-extra-metadata-oracle-v2720/receipt.json': 'f24999835a3e3ec07ca4657446c0a8197ee10a7f6428d998c76667bbbdb808dc', 'native-editing-extra-metadata-oracle-v2720/observations-1.json': '4e2077fc0e3217d1a7737b310c2515384399c8befce808df09d662155bcf5712', 'native-editing-extra-metadata-oracle-v2720/observations-2.json': '4e2077fc0e3217d1a7737b310c2515384399c8befce808df09d662155bcf5712'}
assert all(sha(RAW/p)==h for p,h in reference_pins.items())
report=dict(schema_version=1,source=source,steps=[],owner_pid=os.getpid(),all_commands_terminal=False,diagnostic_only=False,implementation_integrated=True,all_native_apis_qualified=False,release_qualified=False,javascript_executed_by_openui=False,driver_sha256=sha(__file__))
env=dict(os.environ,CARGO_TARGET_DIR='/mnt/e/openui-v02-cargo-c73754e2/target',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='4',RUST_MIN_STACK='4194304',PYTHONDONTWRITEBYTECODE='1',TMPDIR='/dev/shm')
local={};artifact_proof={}
def save():(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
def run(name,command):
    with (OUT/(name+'.log')).open('xb') as log:
        child=subprocess.Popen(command,cwd=SDK/'bindings/rust',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);report['current_process']=dict(pid=child.pid,name=name);save()
        try:
            while child.poll() is None:
                if shutil.disk_usage(MAIN).free<128*2**20 or shutil.disk_usage(OUT).free<6*2**30:
                    report['disk_guard_triggered']=True;os.killpg(child.pid,signal.SIGTERM);break
                time.sleep(1)
            code=child.wait()
        except BaseException:
            if child.poll() is None:os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=20)
            raise
        finally:
            report.pop('current_process',None);report['steps'].append(dict(name=name,command=command,actual_exit_code=child.returncode,log_sha256=sha(OUT/(name+'.log'))));save()
    print(json.dumps(report['steps'][-1]),flush=True);assert code==0,name
    data=(OUT/(name+'.log')).read_bytes()
    if local and command[0]=='cargo':
        artifacts=[]
        for line in data.splitlines():
            if not line.startswith(b'{'):continue
            record=json.loads(line)
            if record.get('reason')!='compiler-artifact' or record['target']['kind']==['custom-build'] or record['package_id'] not in local:continue
            assert Path(record['manifest_path']).resolve()==Path(local[record['package_id']]['manifest_path']).resolve()
            assert Path(record['target']['src_path']).resolve().is_relative_to(SDK.resolve())
            hashes={p:sha(p) for p in record['filenames']}
            if record['fresh']:
                assert name!='control-tests' and all(artifact_proof.get(p)==h for p,h in hashes.items()),record
            artifact_proof.update(hashes);artifacts.append(dict(record=record,sha256=hashes))
        if artifacts:report.setdefault('local_artifacts',{})[name]=artifacts;save()
    return data
save()
try:
    cargo=['cargo','--config',str(SDK/'bindings/rust/.cargo/config.chromium.toml')]
    metadata=json.loads(run('locked-metadata',cargo+['metadata','--locked','--offline','--format-version','1']))
    local={p['id']:p for p in metadata['packages'] if p['source'] is None}
    assert all(Path(p['manifest_path']).resolve().is_relative_to(SDK.resolve()) for p in local.values())
    run('clean-local-packages',cargo+['clean','--locked']+[a for p in local for a in ['-p',p]])
    run('control-tests',cargo+['test','--locked','--offline','-p','openui-engine','-p','openui','-p','openui-ffi','--features','openui-ffi/linux','--lib','--message-format=json'])
    run('native-focus-integration-guards',cargo+['test','--locked','--offline','-p','openui','--features','linux,ffi-integration','--test','native_focus','--test','native_input_notifications','--message-format=json'])
    run('native-app-build',cargo+['build','--locked','--offline','-p','openui','--example','native_input_metadata','--example','native_selection_phases','--example','native_selection_values','--example','native_range_scalar','--example','native_range_modes','--example','native_disabled_focus','--features','linux,ffi-integration','--message-format=json'])
    target=Path(env['CARGO_TARGET_DIR'])/'debug/examples'
    report['binaries']={}
    for name in ['native_input_metadata','native_selection_phases','native_selection_values','native_range_scalar','native_range_modes','native_disabled_focus']:
        binary=OUT/name;shutil.copy2(target/name,binary);report['binaries'][name]=dict(sha256=sha(binary));save()
        for number in [1,2]:
            data=run(name+'-'+str(number),[str(binary)])
            json.loads(data);(OUT/(name+'-'+str(number)+'.json')).write_bytes(data)
        assert (OUT/(name+'-1.json')).read_bytes()==(OUT/(name+'-2.json')).read_bytes()
    run('ffi-library-build',cargo+['build','--locked','--offline','-p','openui-ffi','--features','linux','--message-format=json'])
    library=OUT/'libopenui_ffi.so';shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/libopenui_ffi.so',library)
    (OUT/'libopenui.so.0').symlink_to(library.name)
    report['ffi_library_sha256']=sha(library);assert report['ffi_library_sha256'] in artifact_proof.values();report['fresh_local_library_provenance_verified']=True;save()
    run('all-existing-c-cpp-consumers',[sys.executable,str(SDK/'tools/ffi/verify_abi.py'),'--library',str(library)])
    sys.path.insert(0,str(SDK/'tools/ffi'));import verify_abi
    cc,cxx,c_flags,cxx_flags,link_flags=verify_abi.compilers()
    for language,compiler,flags,standard in [('c',cc,c_flags,'c11'),('cpp',cxx,cxx_flags,'c++17')]:
        for stem in ['selection_tasks','disabled_focus','input_metadata']:
            example=SDK/'examples/c_v02'/(stem+('.c' if language=='c' else '.cc'))
            obj=OUT/(stem+'-'+language+'.o');binary=OUT/(stem+'-'+language)
            run('compile-'+stem+'-'+language,[compiler,'-std='+standard,'-Wall','-Wextra','-Werror','-pthread',*flags,'-I'+str(SDK/'include'),str(example),'-c','-o',str(obj)])
            run('link-'+stem+'-'+language,[cxx,'-pthread',*cxx_flags,*link_flags,'-fuse-ld=lld',str(obj),str(library),'-Wl,-rpath,'+str(OUT),'-o',str(binary)])
            report['binaries'][stem+'-'+language]=dict(sha256=sha(binary));save()
            for number in [1,2]:
                data=run(stem+'-'+language+'-'+str(number),[str(binary)])
                json.loads(data);(OUT/(stem+'-'+language+'-'+str(number)+'.json')).write_bytes(data)
            assert (OUT/(stem+'-'+language+'-1.json')).read_bytes()==(OUT/(stem+'-'+language+'-2.json')).read_bytes()
    refs={}; metadata_refs=[]; reference_inputs={}
    reference_names=['native-selection-reentry-oracle-v3062','native-selection-frame-reentry-oracle-v3084','native-selection-value-oracle-v3111','native-range-scalar-replacement-oracle-v2995','native-range-replacement-oracle-v2897','native-disabled-focus-oracle-v3135','native-editing-metadata-oracle-v2697','native-editing-extra-metadata-oracle-v2720']
    for name in reference_names:
        directory=RAW/name;r=json.loads((directory/'receipt.json').read_bytes());assert r['all_commands_terminal'] and r['observed_exit_code']==0 and r['source_unchanged']
        p=directory/'observations-1.json';assert p.read_bytes()==(directory/'observations-2.json').read_bytes()
        for filename in ['receipt.json','observations-1.json','observations-2.json']:
            reference_inputs[str(directory/filename)]=sha(directory/filename)
        rows=json.loads(p.read_bytes());refs.update({x['scenario']:x for x in rows})
        if name.startswith('native-editing-'):metadata_refs.extend(rows)
    assert len(metadata_refs)==11 and sum(len(row['observed']['rows']) for row in metadata_refs)==69
    report['reference_inputs_sha256']=reference_inputs
    def scalar_native_reference(row):
        row=json.loads(json.dumps(row))
        for state in [row['observed'],*row['observed']['rows']]:
            value=state['value']
            for key in ['selection_start','selection_end']:
                state[key]=len(value.encode('utf-16-le')[:state[key]*2].decode('utf-16-le').encode('utf-8'))
        return row
    def range_error_reference(row):
        row=json.loads(json.dumps(row))
        if row['observed']['error']=='IndexSizeError':row['observed']['error']='Engine(InvalidSelection)'
        return row
    comparisons=[]
    for name in ['native_input_metadata','native_selection_phases','native_selection_values','native_disabled_focus']:
        for row in json.loads((OUT/(name+'-1.json')).read_bytes()):
            ref=refs[row['scenario']]
            comparisons.append(dict(scenario=row['scenario'],exact=row==ref,callback_rows=len(row['observed']['rows']),native=row,chromium=ref))
    for name in ['native_range_scalar','native_range_modes']:
        for row in json.loads((OUT/(name+'-1.json')).read_bytes()):
            ref=refs[row['scenario']]
            ref=scalar_native_reference(ref) if name=='native_range_scalar' else range_error_reference(ref)
            comparisons.append(dict(scenario=row['scenario'],exact=row==ref,callback_rows=len(row['observed']['rows']),native=row,chromium_normalized=ref))
    report['selection_comparisons']=comparisons;report['exact_selection_scenarios']=sum(x['exact'] for x in comparisons);report['selection_scenarios']=len(comparisons)
    assert len(comparisons)==109
    report['c_comparisons']=[]
    for language in ['c','cpp']:
        for stem in ['selection_tasks','disabled_focus','input_metadata']:
            rows=json.loads((OUT/(stem+'-'+language+'-1.json')).read_bytes())
            assert len(rows)==dict(selection_tasks=76,disabled_focus=22,input_metadata=11)[stem]
            for row in rows:
                ref=refs[row['scenario']]
                if 'native_status' in row:
                    if '-unicode-scalar-' in row['scenario']:ref=scalar_native_reference(ref)
                    def actual_control(control):
                        return dict(value=control['value'],selection_start=control['start'],selection_end=control['end'],direction=control['direction'])
                    observed=actual_control(row['observed']['state']['a'])
                    observed['active']='text' if row['observed']['state']['active']=='a' else row['observed']['state']['active']
                    observed['rows']=[dict(type=x['type'],active='text' if x['active']=='a' else x['active'],bubbles=x['bubbles'],cancelable=x['cancelable'],**actual_control(x['a'])) for x in row['observed']['rows']]
                    expected={key:ref['observed'][key] for key in ['value','selection_start','selection_end','direction','active']}
                    expected['rows']=[{key:x[key] for key in ['type','value','selection_start','selection_end','direction','active','bubbles','cancelable']} for x in ref['observed']['rows']]
                    exact=observed==expected and row['native_status']==(-9 if ref['observed']['error']=='IndexSizeError' else 0)
                    report['c_comparisons'].append(dict(language=language,scenario=row['scenario'],scope='declared fields including queried event properties and actual focus',exact=exact,native=row,chromium_common=expected))
                else:
                    report['c_comparisons'].append(dict(language=language,scenario=row['scenario'],scope='complete observation schema',exact=row==ref,native=row,chromium=ref))
    report['exact_c_scenarios']=sum(x['exact'] for x in report['c_comparisons']);assert len(report['c_comparisons'])==218
    report['c_queries_observe_event_flags_focus_attributes_and_identity']=True
    report['c_unicode_positions_are_explicit_utf8_scalar_boundaries']=True
    report['all_reference_bytes_unchanged']=all(sha(p)==h for p,h in reference_inputs.items());assert report['all_reference_bytes_unchanged']
    assert all(sha(RAW/p)==h for p,h in reference_pins.items())
    report['observed_exit_code']=int(not all(x['exact'] for x in comparisons+report['c_comparisons']));save()
except BaseException as e:report.update(observed_exit_code=130 if isinstance(e,KeyboardInterrupt) else 1,failure=repr(e));raise
finally:
    print('Final complete public source audit',flush=True)
    report['source_after']=identity(SDK);report['source_unchanged']=report['source_after']==source;report['all_commands_terminal']=True;save()
print(json.dumps({k:report.get(k) for k in ['observed_exit_code','source_unchanged','selection_scenarios','exact_selection_scenarios']}),flush=True)
raise SystemExit(report['observed_exit_code'])
