"""Measure both complete Chromium gates, preserving their actual failing exits."""
import fcntl
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

MAIN = Path('/home/nero/code/open-ui')
RAW = MAIN / 'out/renderer-evidence/native-viewport-scroll-v1'
ROOT = Path('/dev/shm/openui-native-font-variation-candidate-mutation-v1877')
NAME = 'native-font-variation-census-pipeline-v1883'
OUT = RAW / NAME
STORE = Path('/mnt/e/openui-v02-qualification-d174ea0b') / NAME
lock = open('/tmp/openui-native-cargo-raster-owner.lock', 'a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
for program in ['cargo', 'pixel_compare']:
    assert subprocess.run(['pgrep', '-x', program], capture_output=True).returncode == 1
sys.path.insert(0, str(MAIN / 'tools/qualification'))
from renderer_source_identity import repository_source_identity
from residuals import canonical_sha256

sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
prior_path = RAW / 'native-font-variation-pipeline-v1880/receipt.json'
prior = json.loads(prior_path.read_bytes())
assert prior['all_commands_terminal'] and prior['observed_exit_code'] == 0 and not prior.get('failure')
assert len(prior['steps']) == 6 and all(s['observed_exit_code'] == 0 for s in prior['steps'])
source = repository_source_identity(ROOT)
assert source == prior['source'] == prior['source_after'] and source['clean']
assert source['commit'] == 'feb7e872bd4b55bbbae40a600e280a1cb5ba2ac4'
build_path = RAW / 'native-font-variation-candidate-build-v1879/build.json'
build = json.loads(build_path.read_bytes())
assert build['all_commands_terminal'] and build['observed_exit_code'] == 0
assert build['source'] == build['source_after'] == source
binary = build_path.parent / 'pixel_compare'
assert sha(binary) == next(s['binary_sha256'] for s in build['steps'] if s['name'] == 'pixel-build')
consumer = json.loads((RAW / 'native-font-variation-candidate-consumer-v1879/receipt.json').read_bytes())
assert consumer['all_commands_terminal'] and consumer['observed_exit_code'] == 0
assert consumer['font_reference_exact_scales'] == consumer['callback_scales_verified'] == 5
assert not OUT.exists() and not STORE.exists()
STORE.mkdir(); OUT.symlink_to(STORE, target_is_directory=True)
worker = Path('/tmp/openui-native-font-variation-matrices-v1882.py')
report = dict(schema_version=1, source=source, source_after=source, owner_pid=os.getpid(),
    all_commands_terminal=False, state='prepared-verified', steps=[],
    release_qualification=False, promotion_allowed=False, new_release_states_admitted=0,
    javascript_executed_by_openui=False, pixel_tolerance=0,
    whole_pipeline_lock_covers_all_stages_and_gaps=True,
    prior_terminal_pipeline_sha256=sha(prior_path), build_receipt_sha256=sha(build_path),
    binary_sha256=sha(binary), worker_sha256=sha(worker), probe_sha256=sha(Path(__file__)))
save = lambda: (OUT / 'receipt.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
save()
try:
    for suite, total in [('full', 22924), ('expanded', 23728)]:
        assert repository_source_identity(ROOT) == source
        assert sha(worker) == report['worker_sha256'] and sha(binary) == report['binary_sha256']
        report['state'] = 'running-' + suite; save()
        log = OUT / (suite + '.log')
        with log.open('xb') as stream:
            process = subprocess.Popen([sys.executable, str(worker), suite], cwd=ROOT,
                env=dict(os.environ, OPENUI_NATIVE_WHOLE_OWNER=NAME, PYTHONDONTWRITEBYTECODE='1'),
                stdout=stream, stderr=subprocess.STDOUT)
            report['current_process'] = dict(pid=process.pid, program=worker.name); save()
            process.wait()
        report.pop('current_process')
        row = dict(name=suite, observed_exit_code=process.returncode, log_sha256=sha(log))
        report['steps'].append(row)
        report['source_after'] = repository_source_identity(ROOT); save()
        assert process.returncode in [0, 1], 'matrix command failed outside the pixel gate'
        summary_path = RAW / ('native-font-variation-clean-' + suite + '-v1882') / (suite + '-summary.json')
        summary = json.loads(summary_path.read_bytes())
        assert summary['source'] == summary['source_after'] == source
        assert summary['results']['total'] == total and summary['results']['errors'] == 0
        assert summary['results']['profile_result_sha256'] == canonical_sha256([p['result_sha256'] for p in summary['profiles']])
        for profile in summary['profiles']:
            assert len(profile['tests']) == profile['total']
            assert profile['result_sha256'] == canonical_sha256(profile['tests'])
        row.update(results=summary['results'], summary_sha256=sha(summary_path),
                   required_exact_pixel_gate_passed=(process.returncode == 0))
        save()
        print(json.dumps(dict(suite=suite, actual_exit=process.returncode,
            exact=summary['results']['exact'], different=summary['results']['different'], errors=0)), flush=True)
    passed = all(s['required_exact_pixel_gate_passed'] for s in report['steps'])
    report.update(state='complete-exact-pixel-gates-pass' if passed else 'complete-required-pixel-gates-fail',
        evidence_collection_completed=True, observed_exit_code=0 if passed else 1)
except BaseException as error:
    report.update(state='stopped-on-harness-error', failure=str(error), observed_exit_code=2)
    raise
finally:
    report.update(all_commands_terminal=True, source_after=repository_source_identity(ROOT))
    assert report['source_after'] == source; save()
raise SystemExit(report['observed_exit_code'])
