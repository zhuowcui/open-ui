"""Preserve complete census and current-head hosted results without relabeling sources."""
import hashlib
import json
import tarfile
from pathlib import Path

ROOT = Path('/home/nero/code/open-ui')
RAW = ROOT / 'out/renderer-evidence/native-viewport-scroll-v1'
DEST = ROOT / 'docs/renderer/evidence/native-variable-font-instance-v2'
INDEX = ROOT / 'docs/renderer/generated/native-variable-font-instance-v2.json'
assert not DEST.exists() and not INDEX.exists()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
owner_path = RAW / 'native-font-variation-census-pipeline-v1883/receipt.json'
audit_path = RAW / 'native-font-variation-matrix-audit-v1884.json'
hosted_path = RAW / 'native-font-variation-umbrella-hosted-v1890/receipt.json'
checks_path = RAW / 'native-font-variation-umbrella-checks-v1886/receipt.json'
owner, audit, hosted, checks = [json.loads(p.read_bytes()) for p in [owner_path, audit_path, hosted_path, checks_path]]
assert owner['all_commands_terminal'] and owner['evidence_collection_completed'] and not owner.get('failure')
assert owner['source'] == owner['source_after'] == audit['source'] == audit['source_after']
assert audit['all_commands_terminal'] and audit['all_chromium_inputs_unchanged']
assert audit['original_rows_agree_in_expanded'] == 22924
assert hosted['all_commands_terminal'] and hosted['failed_jobs'] == 0
assert hosted['source'] == 'e0e9382d284ca17aec1f6f75a96e2ed81f80e273'
assert hosted['all_seven_native_guards_executed_and_passed_in_hosted_parity']
assert checks['all_commands_terminal'] and checks['source'] == checks['source_after']
assert checks['source']['commit'] == hosted['source'] and checks['source']['clean']
assert len(checks['checks']) == 15 and all(c['observed_exit_code'] == 0 for c in checks['checks'])
sources = {}
for p in [owner_path, audit_path, hosted_path, checks_path]:
    sources[str(p.relative_to(RAW))] = p
for name in ['native-font-variation-census-pipeline-v1883', 'native-font-variation-umbrella-hosted-v1890',
             'native-font-variation-umbrella-checks-v1886']:
    for p in sorted((RAW / name).rglob('*')):
        if p.is_file() and not p.is_symlink() and p.suffix in ['.json', '.log']:
            sources[str(p.relative_to(RAW))] = p
for suite in ['full', 'expanded']:
    for p in sorted((RAW / ('native-font-variation-clean-' + suite + '-v1882')).glob('*.json')):
        sources[str(p.relative_to(RAW))] = p
    for p in [RAW / ('native-font-variation-clean-' + suite + '-v1882.log'),
              RAW / ('native-font-variation-' + suite + '-exit-v1882.json')]:
        sources[str(p.relative_to(RAW))] = p
for name in ['census-pipeline-v1883', 'matrices-v1882', 'matrix-audit-v1884',
             'umbrella-hosted-collect-v1890', 'umbrella-checks-v1886', 'census-preserve-v1891']:
    p = Path('/tmp/openui-native-font-variation-' + name + '.py')
    sources['probes/' + p.name] = p
DEST.mkdir()
archive = DEST / 'completed-evidence.tar.gz'
members = []
first_by_hash = {}
with tarfile.open(archive, 'w:gz', compresslevel=6, format=tarfile.PAX_FORMAT) as tar:
    for name, path in sorted(sources.items()):
        digest = sha(path)
        row = dict(path=name, bytes=path.stat().st_size, sha256=digest)
        info = tar.gettarinfo(str(path), arcname=name)
        if digest in first_by_hash:
            info.type = tarfile.LNKTYPE; info.linkname = first_by_hash[digest]; info.size = 0
            tar.addfile(info)
        else:
            first_by_hash[digest] = name
            with path.open('rb') as stream: tar.addfile(info, stream)
        members.append(row)
with tarfile.open(archive, 'r:gz') as tar:
    actual = tar.getmembers(); assert len(actual) == len(members)
    for member, row in zip(actual, members):
        assert member.name == row['path']
        data = tar.extractfile(member).read()
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
manifest = DEST / 'archive-members.json'
manifest.write_text(json.dumps(members, sort_keys=True, indent=2) + '\n')
index = dict(schema_version=1, source=owner['source'], source_after=owner['source_after'],
    all_commands_terminal=True, release_qualification=False, pixel_tolerance=0,
    new_release_states_admitted=0, javascript_executed_by_openui=False,
    chromium_is_only_pixel_target=True, native_callback_reference_is_not_chromium=True,
    suites=audit['suites'], all_chromium_inputs_unchanged=True,
    candidate_has_exact_regressions=audit['candidate_has_exact_regressions'],
    reviewed_root_cause_for_every_existing_residual=False, new_formal_wpt_owners_assigned=0,
    original_rows_agree_in_expanded=22924, addition_cases=audit['addition_cases'],
    addition_cases_four_profile_exact=audit['addition_cases_four_profile_exact'],
    actual_census_owner_exit=owner['observed_exit_code'],
    hosted_source=hosted['source'],
    hosted_jobs=dict(success=hosted['successful_jobs'], skipped=hosted['skipped_jobs'], failed=hosted['failed_jobs']),
    all_seven_native_guards_actually_ran_and_passed_in_hosted_parity=True,
    skipped_jobs_are_not_release_passes=True, umbrella_read_only_checks_passed=15,
    prior_native_proof=dict(path='docs/renderer/generated/native-variable-font-instance-v1.json',
        sha256=sha(ROOT / 'docs/renderer/generated/native-variable-font-instance-v1.json')),
    receipts_sha256={str(p.relative_to(RAW)): sha(p) for p in [owner_path, audit_path, hosted_path, checks_path]},
    artifacts=[dict(path=str(p.relative_to(ROOT)), bytes=p.stat().st_size, sha256=sha(p)) for p in [archive, manifest]],
    archive_members=len(members), preserver_sha256=sha(Path(__file__)))
INDEX.write_text(json.dumps(index, sort_keys=True, indent=2) + '\n')
print(json.dumps(dict(index=str(INDEX), index_sha256=sha(INDEX), members=len(members),
    archive_bytes=archive.stat().st_size, has_exact_regressions=audit['candidate_has_exact_regressions'],
    suites={name:dict(exact=data['results']['exact'], total=data['results']['total'],
        actual_exit=data['actual_exit'], gains=data['exact_gains'], losses=data['exact_losses'])
        for name, data in audit['suites'].items()})), flush=True)
