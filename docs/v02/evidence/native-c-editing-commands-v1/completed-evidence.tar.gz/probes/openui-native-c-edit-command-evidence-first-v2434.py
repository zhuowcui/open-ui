import gzip,hashlib,io,json,os,re,shutil,subprocess,tarfile
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');RAW=ROOT/'out/renderer-evidence/native-viewport-scroll-v1'
HEAD='7adb21304e512f0b4e35638eded8e86e5e102309'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==HEAD
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
sha=lambda data:hashlib.sha256(data).hexdigest()
load=lambda p:json.loads(p.read_bytes())
failed=load(RAW/'native-c-edit-command-checks-v2426/receipt.json')
passed=load(RAW/'native-c-edit-command-checks-v2429/receipt.json')
checks=load(RAW/'native-c-edit-command-readonly-checks-v2430/receipt.json')
hosted=load(RAW/'native-c-edit-command-hosted-checks-v2433/receipt.json')
windows=load(RAW/'native-c-edit-command-hosted-windows-v2432/receipt.json')
assert failed['all_commands_terminal'] and failed['observed_exit_code']==1
assert next(x for x in failed['steps'] if x['name']=='locked-workspace-tests')['observed_exit_code']==101
assert passed['all_commands_terminal'] and passed['observed_exit_code']==0 and passed['source_unchanged_throughout'] and passed['library_source_proven']
assert len(passed['steps'])==18 and all(x['observed_exit_code']==0 for x in passed['steps'])
assert passed['workspace_tests']==dict(passed=8569,failed=0,ignored=13)
assert checks['all_commands_terminal'] and len(checks['checks'])==17 and all(x['observed_exit_code']==0 for x in checks['checks'])
assert hosted['all_terminal'] and hosted['successful_jobs']==6 and hosted['skipped_jobs']==5
assert windows['source_trees_verified_identical'] and windows['all_window_consumers_passed'] and windows['window_consumers']==6
old_types=load(Path('/tmp/openui-c-edit-command-parent-layout-v2425.json'));new_types=load(ROOT/'docs/v02/generated/openui-ffi-layout.json')
old_symbols=set(Path('/tmp/openui-c-edit-command-parent-symbols-v2425.txt').read_text().splitlines());new_symbols=set((ROOT/'docs/v02/generated/openui-ffi-symbols.txt').read_text().splitlines())
assert len(old_symbols)==113 and len(new_symbols)==114 and new_symbols-old_symbols=={'oui_element_edit_text_v1'}
assert old_symbols<=new_symbols and all(new_types['types'][k]==v for k,v in old_types['types'].items()) and old_types['abi_version']==new_types['abi_version']
abi=dict(previous_symbols=113,current_symbols=114,added_symbols=sorted(new_symbols-old_symbols),removed_symbols=[],previous_layouts_preserved=True,abi_version_unchanged=True,new_command_layout=new_types['types']['OuiEditCommandV1'],checksum=(ROOT/'docs/v02/generated/openui-ffi-checksum.txt').read_text().strip())
headless=(RAW/'native-c-edit-command-checks-v2429/headless-c-abi-tests.log').read_bytes()
assert b'39 passed; 0 failed; 0 ignored' in headless
members={}
for name in ['native-c-edit-command-checks-v2426','native-c-edit-command-checks-v2429','native-c-edit-command-readonly-checks-v2428','native-c-edit-command-readonly-checks-v2430','native-c-edit-command-hosted-windows-v2432','native-c-edit-command-hosted-checks-v2433']:
 for p in sorted((RAW/name).iterdir()):
  if p.is_file() and not p.is_symlink() and p.suffix in ['.json','.log']:
   members['raw/'+name+'/'+p.name]=p.read_bytes()
for name in ['openui-native-c-edit-command-checks-v2426.py','openui-native-c-edit-command-checks-v2429.py','openui-native-c-edit-command-readonly-checks-v2427.py','openui-native-c-edit-command-readonly-checks-v2428.py','openui-native-c-edit-command-readonly-checks-v2430.py','openui-native-c-edit-command-hosted-checks-v2433.py','openui-native-c-edit-command-parent-layout-v2425.json','openui-native-c-edit-command-parent-symbols-v2425.txt','openui-native-c-edit-command-evidence-v2434.py']:
 p=Path('/tmp')/name;assert p.is_file();members['probes/'+name]=p.read_bytes()
for name in ['bindings/rust/openui-ffi/src/editing_command.rs','bindings/rust/openui-ffi/src/types.rs','bindings/rust/openui-ffi/src/lib.rs','bindings/rust/openui/src/document.rs','bindings/rust/Cargo.lock','include/openui.h','tools/ffi/openui.h.in','tools/ffi/generate_ffi.py','tools/ffi/verify_abi.py','tools/ffi/verify_native_window.py','examples/c_v02/edit_commands.c','examples/c_v02/edit_commands.cc','examples/c_v02/native/window.c','examples/c_v02/native/window.cc','examples/c_v02/header_smoke.cc','docs/v02/generated/openui-ffi-layout.json','docs/v02/generated/openui-ffi-symbols.txt','docs/v02/generated/openui-ffi-checksum.txt','bindings/rust/openui-ffi/openui.map']:
 members['source/'+name]=(ROOT/name).read_bytes()
prechecks=dict(generic_compiler_probe=dict(observed_exit_code=127,c_status='clang could not find assert.h and stdio.h without the sysroot',cpp_status='c++ command unavailable',qualification=False),corrected_compiler_probe=dict(observed_exit_code=0,compilers_and_flags='tools/ffi/verify_abi.py::compilers() pinned Chromium sysroot'),readonly_probe_v2427=dict(observed_exit_code=1,reason='Stale assert expected 60 C/C++ source files; the new consumers increase that inventory to 62. No checks ran.',qualification=False),readonly_probe_v2428=dict(observed_exit_code=0,checks=17,source='a29eb98022f2d4fe257cbb83f0bb32999793c869'))
members['prechecks.json']=(json.dumps(prechecks,sort_keys=True,indent=2)+'\n').encode()
dest=ROOT/'docs/v02/evidence/native-c-editing-commands-v1';assert not dest.exists();dest.mkdir(parents=True)
archive=dest/'completed-evidence.tar.gz'
with archive.open('xb') as stream:
 with gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for name,data in sorted(members.items()):
    item=tarfile.TarInfo(name);item.size=len(data);item.mtime=0;item.mode=0o644;item.uid=item.gid=0;tar.addfile(item,io.BytesIO(data))
with tarfile.open(archive) as tar:
 actual={item.name:tar.extractfile(item).read() for item in tar if item.isfile()}
assert actual.keys()==members.keys() and all(sha(actual[name])==sha(data) for name,data in members.items())
index=dict(schema_version=1,archive_sha256=sha(archive.read_bytes()),members=[dict(name=name,bytes=len(data),sha256=sha(data)) for name,data in sorted(members.items())])
(dest/'archive-members.json').write_text(json.dumps(index,sort_keys=True,indent=2)+'\n')
report=dict(schema_version=1,kind='native_c_editing_command_application_api',implementation_commit=HEAD,initial_implementation_commit='a29eb98022f2d4fe257cbb83f0bb32999793c869',javascript_executed_by_openui=False,public_api='oui_element_edit_text_v1',rust_api='Element::edit_text(EditCommand)',shared_rust_document_engine_and_event_path=True,abi=abi,clean_checks=passed,readonly_checks=checks,failed_initial_checks=failed,failed_initial_reason='A guard expected InvalidHandle for a null pointer; the existing ABI contract returns InvalidArgument. Only that test expectation changed in the correction.',headless_c_abi_tests=dict(passed=39,failed=0,ignored=0),all_c_cpp_consumers=dict(c=14,cpp=8,actual_exit=0),focused_c_cpp_editing_consumers=passed['consumers'],hosted_jobs=hosted,hosted_windows=windows,prechecks=prechecks,evidence_archive=dict(path=str(archive.relative_to(ROOT)),sha256=index['archive_sha256'],bytes=archive.stat().st_size,members=len(members),all_member_hashes_verified=True),source_snapshot_hashes={name.removeprefix('source/'):sha(data) for name,data in members.items() if name.startswith('source/')},all_local_owners_terminal=True,release_qualification=False,renderer_matrices_not_run=True,renderer_changes_promoted=False,expected_pixels='Pinned Chromium only',references_changed=False,pixel_tolerance=0,accepted_original=dict(exact=21334,total=22924),accepted_expanded=dict(exact=22137,total=23728),new_pixel_comparisons_admitted=0,remaining_gates=['Full original and expanded exact Chromium matrices','Complete editor scrolling and selection pixels','Remaining native element APIs and contexts','Physical GPU and release lab qualification','Release performance, packaging, provenance and publication'])
(ROOT/'docs/v02/generated/native-c-editing-commands-v1.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
def detach(path):
 temp=path.with_name(path.name+'.evidence-detach-v2434');shutil.copy2(path,temp);os.replace(temp,path)
p=ROOT/'docs/v02/native-c-editing-commands.md';detach(p);s=p.read_text();marker='## Qualification status\n';assert s.count(marker)==1;s=s[:s.index(marker)]+'''## Verified implementation

Clean implementation `7adb2130` passes all 18 local stages. The locked Linux
workspace run passes **8,569 tests**, with zero failures and 13 ignored tests.
All local Rust libraries are freshly compiled from that checkout; later cached
artifacts must match the hashes from the preceding verified build of the same
source. The copied C library is bound to those artifact records. The source
remains clean and unchanged through the entire pipeline, including the gaps
between commands.

The headless C ABI run passes **39/39 tests**. Five new guards cover all text
units and directions, selection extension, shared Rust/C history, callback
mutation, malformed headers, readonly/disabled controls, stale handles,
wrong-thread calls, outstanding borrows and panic containment. The initial
workspace run exits 101 because a new guard expects the wrong null-handle
status. That failure is preserved; the correction changes only that expectation.

All **114 exports**, every previous symbol and every prior ABI layout are
verified. **Fourteen C and eight C++ consumers** compile and run. The new editing
consumers repeat byte-identical output twice in each language, with six input
and two button callbacks per run. All 17 read-only checks also pass.

The six active hosted jobs pass. Five optional MSRV, Miri, fuzz and sanitizer
jobs are skipped, not qualified. All six C/C++ window consumers pass on X11
software, X11 Mesa OpenGL presentation and pure Wayland software. C observes
five input callbacks and C++ three per window run; selection-only calls add no
input callback. The hosted checkout is synthetic PR merge `4c5dc29c`, whose
Git tree is verified identical to `7adb2130`; the reports retain their actual
checkout identities, matching header and consumer-source hashes.

The [versioned evidence](generated/native-c-editing-commands-v1.json) and
[hash-verified archive](evidence/native-c-editing-commands-v1/completed-evidence.tar.gz)
preserve completed logs, Cargo records, consumers, ABI inputs, hosted window
reports, failed checks and corrected checks. C editing-command parity is
implemented and verified through the shared native Rust path.

These checks establish editing API behavior. Complete Chromium pixel matching,
editor scrolling, selection rendering, all native APIs and release
qualification remain open. Accepted renderer results stay **21,334/22,924**
original and **22,137/23,728** expanded exact. This work changes no renderer code,
reference image or pixel tolerance and admits no new pixel comparison.
''';p.write_text(s)
p=ROOT/'docs/renderer/native-input-editor-scrollport.md';detach(p);s=p.read_text();old='''queries, source patches, apps, lockfiles and the pinned primary sources. C edit
command parity, complete editor scrolling and selection pixels, remaining
glyph masks, and full renderer qualification remain open. No JavaScript runs
in Open UI.''';new='''queries, source patches, apps, lockfiles and the pinned primary sources.
That source did not expose C editing commands. The later
[native C editing API](../v02/native-c-editing-commands.md) implements and
verifies them at `7adb2130`. Complete editor scrolling and selection pixels,
remaining glyph masks, and full renderer qualification remain open.
No JavaScript runs in Open UI.''';assert s.count(old)==1;p.write_text(s.replace(old,new))
print(json.dumps(dict(implementation_commit=HEAD,local_stages=18,workspace_tests=passed['workspace_tests'],exports=114,c_consumers=14,cpp_consumers=8,archive_bytes=archive.stat().st_size,archive_members=len(members),archive_sha256=index['archive_sha256']),indent=2))
