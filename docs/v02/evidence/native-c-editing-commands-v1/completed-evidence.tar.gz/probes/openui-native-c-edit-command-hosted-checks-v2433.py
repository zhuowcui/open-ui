import concurrent.futures,hashlib,json,subprocess
from pathlib import Path
root=Path('/home/nero/code/open-ui');out=root/'out/renderer-evidence/native-viewport-scroll-v1/native-c-edit-command-hosted-checks-v2433';store=Path('/mnt/e/openui-v02-qualification-d174ea0b')/out.name
assert not out.exists() and not store.exists();store.mkdir();out.symlink_to(store,target_is_directory=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='7adb21304e512f0b4e35638eded8e86e5e102309'
rows=[];jobs=[]
for run in [37587689701,37587689724,37587689714]:
 d=json.loads(subprocess.check_output(['gh','api',f'repos/zhuowcui/open-ui/actions/runs/{run}'],cwd=root))
 assert d['head_sha']==head and d['status']=='completed'
 j=json.loads(subprocess.check_output(['gh','api',f'repos/zhuowcui/open-ui/actions/runs/{run}/jobs'],cwd=root))
 (out/f'{run}.json').write_text(json.dumps(dict(run=d,jobs=j),sort_keys=True,indent=2)+'\n')
 row=dict(run_id=run,name=d['name'],conclusion=d['conclusion'],jobs=[dict(id=x['id'],name=x['name'],status=x['status'],conclusion=x['conclusion']) for x in j['jobs']]);rows.append(row)
 for x in j['jobs']:
  if x['conclusion']!='skipped':jobs.append((run,x['id'],x['name']))
def fetch(job):
 run,job_id,name=job;p=out/f'{run}-{job_id}.log'
 result=subprocess.run(['gh','run','view',str(run),'--repo','zhuowcui/open-ui','--job',str(job_id),'--log'],cwd=root,capture_output=True)
 assert result.returncode==0,(job,result.stderr)
 p.write_bytes(result.stdout)
 return dict(run_id=run,job_id=job_id,name=name,log_sha256=hashlib.sha256(result.stdout).hexdigest(),bytes=len(result.stdout))
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:logs=list(pool.map(fetch,jobs))
receipt=dict(schema_version=1,source_commit=head,runs=rows,logs=logs,successful_jobs=sum(x['conclusion']=='success' for r in rows for x in r['jobs']),skipped_jobs=sum(x['conclusion']=='skipped' for r in rows for x in r['jobs']),all_terminal=True,release_qualification=False)
(out/'receipt.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ['source_commit','successful_jobs','skipped_jobs','all_terminal','runs']},indent=2))
