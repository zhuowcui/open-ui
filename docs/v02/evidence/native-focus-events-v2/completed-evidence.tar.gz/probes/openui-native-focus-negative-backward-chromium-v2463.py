import hashlib,json,os,shutil,signal,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');OUT=ROOT/'out/renderer-evidence/native-viewport-scroll-v1/native-focus-negative-backward-chromium-v2463';STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/OUT.name
assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
sys.path.insert(0,str(ROOT/'tools/accountability'));import run_all_pixel_comparisons as capture
chrome=ROOT/'chrome/linux-147.0.7727.50/chrome-linux64/chrome';digest=hashlib.sha256(chrome.read_bytes()).hexdigest();assert digest=='0ba87684df0afc11faaea40ac57bd2f1d68b67191443b38215a36b90e6f08848'
expressions={
 'negative-setup':'''(() => {document.body.innerHTML='<input tabindex="2" id="x"><div tabindex="-1" id="a"></div><input tabindex="-1" id="b"><button tabindex="1" id="c">C</button><input id="d">';window.log=[];for(const e of document.body.children)for(const t of ['focus','blur'])e.addEventListener(t,()=>log.push([e.id,t,document.activeElement.id||'body']));a.focus();b.focus();return {log:log.map(r=>[...r]),active:document.activeElement.id};})()''',
 'read':'''({log:log.map(r=>[...r]),active:document.activeElement.id||'body'})''',
 'propagation':'''(() => {document.body.innerHTML='<section id="p"><input id="a"></section>';const log=[];for(const [e,label] of [[p,'parent'],[a,'target']])for(const type of ['focus','blur'])for(const capture of [true,false])e.addEventListener(type,event=>{event.preventDefault();log.push([label,type,capture,event.eventPhase,event.bubbles,event.cancelable,event.defaultPrevented]);},capture);a.focus();a.blur();return log.map(r=>[...r]);})()''',
 'modal':'''(() => {document.body.innerHTML='<input id="outside"><dialog id="modal"><input id="inside"></dialog>';const log=[];for(const e of [outside,inside])for(const t of ['focus','blur'])e.addEventListener(t,()=>log.push([e.id,t,document.activeElement.id||'body']));outside.focus();modal.showModal();modal.close();return {log:log.map(r=>[...r]),active:document.activeElement.id||'body'};})()'''
}
(OUT/'expressions.json').write_text(json.dumps(expressions,sort_keys=True,indent=2)+'\n')
report=dict(schema_version=1,chromium_binary_sha256=digest,chromium_version='147.0.7727.50',javascript_executed_by_openui=False,offline_javascript_executed_only_in_chromium=True,reference_images_modified=False,pixel_images_generated=0,release_qualification=False,all_commands_terminal=False,observations=[])
try:
 for repeat in range(2):
  profile=tempfile.mkdtemp(prefix='chrome-focus-',dir=STORE);client=None
  with (OUT/f'chrome-{repeat}.stderr.log').open('xb') as log:
   process=subprocess.Popen([str(chrome),'--headless','--disable-gpu','--disable-dev-shm-usage','--no-sandbox','--no-first-run','--no-default-browser-check','--remote-debugging-port=0','--user-data-dir='+profile,'about:blank'],stdout=subprocess.DEVNULL,stderr=log,start_new_session=True,env=capture.chrome_environment(str(chrome.parent),False,False))
   try:
    port=capture._wait_for_devtools_endpoint(profile,process);client=capture._CdpWebSocket(capture._page_websocket_url(port));client.command('Page.enable');client.command('Page.bringToFront');client.command('Emulation.setFocusEmulationEnabled',dict(enabled=True))
    def evaluate(name):
     value=client.command('Runtime.evaluate',dict(expression=expressions[name],returnByValue=True));assert 'exceptionDetails' not in value;return value['result']['value']
    observed={'negative_programmatic':evaluate('negative-setup')}
    for name,modifiers in [('tab_backward_from_negative',8)]:
     for type in ['rawKeyDown','keyUp']:client.command('Input.dispatchKeyEvent',dict(type=type,key='Tab',code='Tab',windowsVirtualKeyCode=9,nativeVirtualKeyCode=9,modifiers=modifiers))
     observed[name]=evaluate('read')
    observed['propagation']=evaluate('propagation');observed['modal']=evaluate('modal');report['observations'].append(observed)
   finally:
    if client is not None:client.close()
    try:os.killpg(process.pid,signal.SIGTERM)
    except ProcessLookupError:pass
    try:process.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
    shutil.rmtree(profile)
 assert report['observations'][0]==report['observations'][1];report['repeated_observations_identical']=True
finally:
 report['all_commands_terminal']=True;(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps(report['observations'][0],indent=2))
