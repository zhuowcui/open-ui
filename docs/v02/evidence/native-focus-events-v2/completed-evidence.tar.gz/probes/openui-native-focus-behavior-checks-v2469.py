import fcntl,hashlib,json,os,re,shutil,signal,subprocess,sys,time
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');RAW=ROOT/'out/renderer-evidence/native-viewport-scroll-v1';OUT=RAW/'native-focus-behavior-checks-v2469';STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/OUT.name
lock=open('/tmp/openui-native-cargo-raster-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
sys.path.insert(0,str(ROOT/'tools/qualification'));from renderer_source_identity import repository_source_identity
source=repository_source_identity(ROOT);assert source['clean'] and source['commit']=='442d7a64378a5a238e92033db08450f1da5a08a4'
env=dict(os.environ,CARGO_TARGET_DIR='/mnt/e/openui-v02-cargo-c73754e2/target',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_BUILD_JOBS='4',RUST_MIN_STACK='4194304',CARGO_INCREMENTAL='0',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(STORE))
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as stream:
  for data in iter(lambda:stream.read(1024*1024),b''):h.update(data)
 return h.hexdigest()
report=dict(schema_version=1,source=source,steps=[],all_commands_terminal=False,owner_pid=os.getpid(),release_qualification=False,renderer_matrices_not_run=True,probe_sha256=sha(Path(__file__)))
def save():(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
def run(name,command,cwd=ROOT/'bindings/rust'):
 assert repository_source_identity(ROOT)==source
 log=OUT/(name+'.log')
 with log.open('xb') as stream:
  child=subprocess.Popen(command,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True);report['current_process']=dict(pid=child.pid,stage=name);save()
  try:
   while child.poll() is None:
    if shutil.disk_usage(ROOT).free<512*2**20 or shutil.disk_usage(Path(env['CARGO_TARGET_DIR'])).free<10*2**30:
     report['disk_guard_triggered']=True;os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=20);break
    time.sleep(1)
   code=child.wait()
  except BaseException:
   if child.poll() is None:
    os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=20)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
   raise
 report.pop('current_process');row=dict(name=name,command=command,observed_exit_code=code,log_sha256=sha(log));report['steps'].append(row);save();print(json.dumps(row),flush=True)
 assert repository_source_identity(ROOT)==source
 assert code==0,name
 return log.read_bytes()
base=['cargo','--config',str(ROOT/'bindings/rust/.cargo/config.chromium.toml')]
save()
try:
 meta=json.loads(run('locked-metadata',base+['metadata','--locked','--offline','--format-version','1']))
 local={p['id']:p for p in meta['packages'] if p['source'] is None}
 assert all(Path(p['manifest_path']).resolve().is_relative_to(ROOT) for p in local.values())
 run('clean-local-packages',base+['clean','--locked']+[a for p in local for a in ['-p',p]])
 proof={}
 def verify(log,first):
  artifacts=[]
  for line in log.splitlines():
   if not line.startswith(b'{'):continue
   record=json.loads(line)
   if record.get('reason')!='compiler-artifact' or record['target']['kind']==['custom-build']:continue
   package=local.get(record['package_id'])
   if package is None:continue
   assert Path(record['manifest_path']).resolve()==Path(package['manifest_path']).resolve()
   assert Path(record['target']['src_path']).resolve().is_relative_to(ROOT)
   hashes={path:sha(path) for path in record['filenames']}
   if record['fresh']:assert not first and all(proof.get(p)==h for p,h in hashes.items()),record
   proof.update(hashes);artifacts.append(dict(record=record,sha256=hashes))
  assert any(a['record']['target']['name']=='openui_ffi' for a in artifacts)
  return artifacts
 workspace=run('locked-workspace-tests',base+['test','--locked','--offline','--workspace','--features','openui-ffi/linux','--message-format=json'])
 report['workspace_artifacts']=verify(workspace,True)
 totals=[tuple(map(int,m)) for m in re.findall(rb'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',workspace)]
 report['workspace_tests']=dict(passed=sum(t[0] for t in totals),failed=sum(t[1] for t in totals),ignored=sum(t[2] for t in totals));assert report['workspace_tests']['failed']==0;save()
 ffi=run('build-linux-c-abi',base+['build','--locked','--offline','-p','openui-ffi','--features','linux','--message-format=json'])
 report['ffi_artifacts']=verify(ffi,False)
 library=OUT/'libopenui_ffi.so';shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug/libopenui_ffi.so',library)
 assert sha(library) in [h for artifact in report['ffi_artifacts'] for h in artifact['sha256'].values()]
 (OUT/'libopenui.so.0').symlink_to(library.name)
 report['library_sha256']=sha(library);report['library_source_proven']=True;save()
 run('all-c-cpp-consumers',[sys.executable,str(ROOT/'tools/ffi/verify_abi.py'),'--library',str(library)],ROOT)
 sys.path.insert(0,str(ROOT/'tools/ffi'));from verify_abi import compilers
 cc,cxx,cflags,cxxflags,linkflags=compilers()
 for language,suffix,compiler,standard,flags in [('c','c',cc,'c11',cflags),('cpp','cc',cxx,'c++17',cxxflags)]:
  obj=OUT/('edit-commands-'+language+'.o');binary=OUT/('edit-commands-'+language)
  run('compile-'+language,[compiler,'-std='+standard,'-Wall','-Wextra','-Werror',*flags,'-I'+str(ROOT/'include'),str(ROOT/'examples/c_v02'/('edit_commands.'+suffix)),'-c','-o',str(obj)],ROOT)
  run('link-'+language,[cxx,*cxxflags,*linkflags,'-fuse-ld=lld',str(obj),str(library),'-Wl,-rpath,'+str(OUT),'-o',str(binary)],ROOT)
  first=run('edit-commands-'+language+'-first',[str(binary)],ROOT);second=run('edit-commands-'+language+'-second',[str(binary)],ROOT)
  assert first==second and first.count(b'input=3 click=1')==2
  report.setdefault('consumers',[]).append(dict(language=language,binary_sha256=sha(binary),repeated_output_identical=True,input_callbacks_per_run=6,click_callbacks_per_run=2))
  save()
 headless=run('headless-c-abi-tests',base+['test','--locked','--offline','-p','openui-ffi','--lib','--message-format=json'])
 report['headless_artifacts']=verify(headless,False);save()
 run('rust-format',['bash','-c','ulimit -s 262144; cargo fmt --all -- --check'])
 run('c-abi-generator',[sys.executable,'tools/ffi/generate_ffi.py','--check'],ROOT)
 run('renderer-contract',[sys.executable,'tools/qualification/generate_renderer_contract.py','--check'],ROOT)
 run('accountability',[sys.executable,'tools/accountability/audit.py'],ROOT)
 report['observed_exit_code']=0
except BaseException as error:
 report.update(observed_exit_code=1,failure=repr(error));raise
finally:
 report['source_after']=repository_source_identity(ROOT);report['source_unchanged_throughout']=report['source_after']==source
 report['all_commands_terminal']=True;save();print(json.dumps(dict(all_terminal=True,observed_exit_code=report.get('observed_exit_code'),source_unchanged=report['source_unchanged_throughout'])),flush=True)
