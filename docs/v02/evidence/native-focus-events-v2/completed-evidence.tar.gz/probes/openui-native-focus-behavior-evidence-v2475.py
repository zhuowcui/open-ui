import gzip,hashlib,io,json,os,shutil,subprocess,tarfile
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');RAW=ROOT/'out/renderer-evidence/native-viewport-scroll-v1';HEAD='442d7a64378a5a238e92033db08450f1da5a08a4'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==HEAD
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
sha=lambda data:hashlib.sha256(data).hexdigest();load=lambda p:json.loads(p.read_bytes())
failed=[load(RAW/name/'receipt.json') for name in ['native-focus-behavior-checks-v2464','native-focus-behavior-checks-v2466']]
passed=load(RAW/'native-focus-behavior-checks-v2469/receipt.json');checks=load(RAW/'native-focus-behavior-source-checks-v2470/receipt.json');consumer=load(RAW/'native-focus-behavior-consumer-v2472/receipt.json');hosted=load(RAW/'native-focus-behavior-hosted-checks-v2474/receipt.json');windows=load(RAW/'native-focus-behavior-hosted-windows-v2473/receipt.json');chromium=[load(RAW/name/'receipt.json') for name in ['native-focus-behavior-chromium-v2461','native-focus-tab-order-chromium-v2462','native-focus-negative-backward-chromium-v2463']]
assert all(x['all_commands_terminal'] and x['observed_exit_code']==1 for x in failed)
assert passed['all_commands_terminal'] and passed['observed_exit_code']==0 and passed['source_unchanged_throughout'] and passed['library_source_proven']
assert len(passed['steps'])==18 and all(x['observed_exit_code']==0 for x in passed['steps'])
assert passed['workspace_tests']==dict(passed=8583,failed=0,ignored=13)
assert checks['all_commands_terminal'] and len(checks['checks'])==17 and all(x['observed_exit_code']==0 for x in checks['checks'])
assert consumer['all_commands_terminal'] and consumer['observed_exit_code']==0 and consumer['source_unchanged_throughout'] and consumer['repeated_output_identical']
assert hosted['all_terminal'] and hosted['successful_jobs']==6 and hosted['skipped_jobs']==5
assert windows['source_trees_verified_identical'] and windows['all_window_consumers_passed'] and windows['window_consumers']==6
assert all(x['all_commands_terminal'] and x['repeated_observations_identical'] for x in chromium)
assert b'44 passed; 0 failed; 0 ignored' in (RAW/'native-focus-behavior-checks-v2469/headless-c-abi-tests.log').read_bytes()
for name in ['openui-ffi-layout.json','openui-ffi-symbols.txt','openui-ffi-checksum.txt']:
 assert subprocess.check_output(['git','show','d9e2bfbd:docs/v02/generated/'+name],cwd=ROOT)==(ROOT/'docs/v02/generated'/name).read_bytes()
members={}
raw_names=['native-focus-behavior-chromium-v2461','native-focus-tab-order-chromium-v2462','native-focus-negative-backward-chromium-v2463','native-focus-behavior-checks-v2464','native-focus-behavior-source-checks-v2465','native-focus-behavior-checks-v2466','native-focus-behavior-source-checks-v2467','native-focus-pointer-diagnostic-v2468','native-focus-behavior-checks-v2469','native-focus-behavior-source-checks-v2470','native-focus-behavior-consumer-v2472','native-focus-behavior-hosted-windows-v2473','native-focus-behavior-hosted-checks-v2474']
for name in raw_names:
 for p in sorted((RAW/name).iterdir()):
  if p.is_file() and not p.is_symlink() and p.suffix in ['.json','.log','.c','.js']:
   members['raw/'+name+'/'+p.name]=p.read_bytes()
for name in ['openui-native-focus-behavior-chromium-v2461.py','openui-native-focus-tab-order-chromium-v2462.py','openui-native-focus-negative-backward-chromium-v2463.py','openui-native-focus-behavior-checks-v2464.py','openui-native-focus-behavior-source-checks-v2465.py','openui-native-focus-behavior-checks-v2466.py','openui-native-focus-behavior-source-checks-v2467.py','openui-native-focus-pointer-diagnostic-v2468.py','openui-native-focus-pointer-diagnostic-first-v2468.py','openui-native-focus-behavior-checks-v2469.py','openui-native-focus-behavior-source-checks-v2470.py','openui-native-focus-behavior-consumer-v2472.py','openui-native-focus-behavior-hosted-windows-v2473.py','openui-native-focus-behavior-hosted-checks-v2474.py','openui-native-focus-behavior-evidence-v2475.py']:
 p=Path('/tmp')/name;assert p.is_file();members['probes/'+name]=p.read_bytes()
for name in ['bindings/rust/openui-engine/src/interaction.rs','bindings/rust/openui/src/document.rs','bindings/rust/openui/src/events.rs','bindings/rust/openui/tests/native_focus.rs','bindings/rust/openui-ffi/src/lib.rs','bindings/rust/openui-ffi/src/focus_tests.rs','bindings/rust/openui-ffi/src/native_app_tests.rs','bindings/rust/openui-ffi/src/native_app.rs','bindings/rust/Cargo.lock','include/openui.h','tools/ffi/verify_abi.py','tools/ffi/verify_native_window.py','examples/c_v02/native/window.c','examples/c_v02/native/window.cc','docs/v02/generated/openui-ffi-layout.json','docs/v02/generated/openui-ffi-symbols.txt','docs/v02/generated/openui-ffi-checksum.txt']:
 members['source/'+name]=(ROOT/name).read_bytes()
failures=dict(initial_compile=dict(qualification=False,reason='An existing Linux guard relied on FocusOrigin imported by production code. The production import became unused; the fix imports the enum explicitly in that test.'),pointer_guard=dict(qualification=False,reason='The unstyled controls have zero bounds. A center-point click hit the root. The corrected pointer guard authors visible bounds and asserts the hit target; default geometry remains an owned layout investigation.'),pointer_probe_first=dict(qualification=False,reason='The initial artifact selector included both the shared library and test executable; its assertion failed before library loading or output creation. The corrected selector chooses only the freshly compiled shared-library artifact.'))
members['failed-attempts.json']=(json.dumps(failures,sort_keys=True,indent=2)+'\n').encode()
dest=ROOT/'docs/v02/evidence/native-focus-events-v2';assert not dest.exists();dest.mkdir(parents=True);archive=dest/'completed-evidence.tar.gz'
with archive.open('xb') as stream:
 with gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for name,data in sorted(members.items()):
    item=tarfile.TarInfo(name);item.size=len(data);item.mtime=0;item.mode=0o644;item.uid=item.gid=0;tar.addfile(item,io.BytesIO(data))
with tarfile.open(archive) as tar:actual={item.name:tar.extractfile(item).read() for item in tar if item.isfile()}
assert actual.keys()==members.keys() and all(sha(actual[name])==sha(data) for name,data in members.items())
index=dict(schema_version=1,archive_sha256=sha(archive.read_bytes()),members=[dict(name=name,bytes=len(data),sha256=sha(data)) for name,data in sorted(members.items())]);(dest/'archive-members.json').write_text(json.dumps(index,sort_keys=True,indent=2)+'\n')
report=dict(schema_version=2,kind='native_negative_tabindex_modal_and_focus_propagation',implementation_commit=HEAD,production_commit='e1357de3655bbd28b4a3ea9fe4f92359a6ca263c',javascript_executed_by_openui=False,shared_rust_document_engine_and_event_path=True,abi=dict(exports=114,symbols_unchanged=True,all_struct_layouts_unchanged=True,checksum_unchanged=True),clean_checks=passed,readonly_checks=checks,failed_checks=failed,failed_attempts=failures,headless_c_abi_tests=dict(passed=44,failed=0,ignored=0),rust_application_focus_tests=9,c_facade_focus_tests=5,all_c_cpp_consumers=dict(c=14,cpp=8,actual_exit=0),corrected_c_consumer=consumer,chromium_behavior_reference=chromium,native_window_wrap_policy_retained=True,chromium_browser_ui_escape_not_counted_as_native_pass=True,hosted_jobs=hosted,hosted_windows=windows,default_control_geometry=load(RAW/'native-focus-pointer-diagnostic-v2468/receipt.json'),default_control_geometry_owner='native layout and interaction',default_control_geometry_qualified=False,evidence_archive=dict(path=str(archive.relative_to(ROOT)),sha256=index['archive_sha256'],bytes=archive.stat().st_size,members=len(members),all_member_hashes_verified=True),source_snapshot_hashes={name.removeprefix('source/'):sha(data) for name,data in members.items() if name.startswith('source/')},all_local_owners_terminal=True,release_qualification=False,renderer_matrices_not_run=True,renderer_changes_promoted=False,expected_pixels='Pinned Chromium only',references_changed=False,pixel_tolerance=0,new_pixel_comparisons_admitted=0,remaining_focus_owner='native Document, Engine interaction and C facade',remaining_focus_behavior=['Focus-in/out events and related target metadata','Default modal autofocus selection','Additional control kinds and nested focus scopes','Complete raw/normalized event metadata review','Default native control geometry'],remaining_gates=['Full exact Chromium pixel matrices','Remaining needed native APIs','Compositor and release-lab qualification','Release performance, packaging, provenance and publication'])
(ROOT/'docs/v02/generated/native-focus-events-v2.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
doc=Path('/tmp/openui-native-focus-behavior-doc-v2471.md').read_text();marker='Four new Rust application guards';assert marker in doc
verified=f'''Clean implementation `{HEAD[:8]}` passes **8,583 locked workspace tests**,
with zero failures and 13 ignored tests, and **44/44 headless C facade tests**.
All 18 local stages and 17 read-only checks pass. Local artifacts and the copied
C library are bound to that clean checkout, which stays unchanged through the
whole pipeline. Fourteen C and eight C++ consumers compile and run; all 114
exports and prior layouts remain intact.

Six active hosted jobs pass; five optional hardening jobs are skipped, not
qualified. All six window consumers pass on X11 software, X11 Mesa presentation
and pure Wayland software. Their actual synthetic merge
`{windows['hosted_checkout'][:8]}` has the identical Git tree to `{HEAD[:8]}`.

'''
(ROOT/'docs/v02/native-focus-behavior.md').write_text(doc.replace(marker,verified+marker))
def edit(path,old,new):
 temp=path.with_name(path.name+'.focus-v2-detach');shutil.copy2(path,temp);os.replace(temp,path);s=path.read_text();assert s.count(old)==1;path.write_text(s.replace(old,new))
edit(ROOT/'docs/v02/native-focus-events.md','## Remaining work\n','''## Later implementation

The [native focus follow-up](native-focus-behavior.md) implements negative
`tabindex` focus, modal callback delivery and non-bubbling propagation on
`442d7a64`. The v1 evidence above keeps its original source and scope.

## Work open at the v1 checkpoint
''')
edit(ROOT/'docs/v02/supported-platforms.md','The [native focus callback correction](native-focus-events.md) routes Rust,','''The [native focus follow-up](native-focus-behavior.md) implements negative
`tabindex` focus, modal callback/restoration behavior and capture/target focus
notifications. Rust and C use the shared Document transition; remaining focus
contexts and default control geometry are still unqualified.

The [native focus callback correction](native-focus-events.md) routes Rust,''')
print(json.dumps(dict(implementation_commit=HEAD,workspace_tests=passed['workspace_tests'],exports=114,archive_members=len(members),archive_bytes=archive.stat().st_size,archive_sha256=index['archive_sha256']),indent=2))
