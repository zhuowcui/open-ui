import ctypes as c,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');RAW=ROOT/'out/renderer-evidence/native-viewport-scroll-v1';OUT=RAW/'native-focus-pointer-diagnostic-v2468';STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/OUT.name
sys.path.insert(0,str(ROOT/'tools/qualification'));from renderer_source_identity import repository_source_identity
source=repository_source_identity(ROOT);assert source['clean'] and source['commit']=='449a7700bedb7bd7569f9d02f7ca2b4f9d5585e9'
records=[]
for line in (RAW/'native-focus-behavior-checks-v2466/locked-workspace-tests.log').read_bytes().splitlines():
 if line.startswith(b'{'):
  r=json.loads(line)
  if r.get('reason')=='compiler-artifact' and r['target']['name']=='openui_ffi' and 'cdylib' in r['target']['kind']:records.append(r)
assert len(records)==1 and not records[0]['fresh'] and Path(records[0]['manifest_path']).resolve()==ROOT/'bindings/rust/openui-ffi/Cargo.toml'
library=Path(next(p for p in records[0]['filenames'] if p.endswith('.so')));libsha=hashlib.sha256(library.read_bytes()).hexdigest()
assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
lib=c.CDLL(str(library))
class Utf(c.Structure):_fields_=[('data',c.c_char_p),('length',c.c_size_t)]
class View(c.Structure):_fields_=[('width',c.c_double),('height',c.c_double),('pw',c.c_uint32),('ph',c.c_uint32),('scale',c.c_double),('authority',c.c_uint32),('reserved',c.c_uint32)]
class Config(c.Structure):_fields_=[('size',c.c_uint32),('abi',c.c_uint32),('view',View)]
class Rect(c.Structure):_fields_=[('x',c.c_float),('y',c.c_float),('width',c.c_float),('height',c.c_float)]
def call(name,*args):
 code=getattr(lib,name)(*args);assert code==0,(name,code)
def text(value):data=value.encode();return Utf(data,len(data))
config=Config(c.sizeof(Config),0x00020000,View(320,200,320,200,1,1,0));document=c.c_void_p();root=c.c_void_p();nodes=[];observations=[]
call('oui_document_create',c.byref(config),c.byref(document));call('oui_document_root',document,c.byref(root))
for label in ['a','b','c']:
 node=c.c_void_p();call('oui_element_create',document,c.c_int(23),c.byref(node));call('oui_element_append_child',root,node);call('oui_element_set_attribute',node,text('id'),text(label));nodes.append(node)
call('oui_element_set_control_value',nodes[0],text('preview'))
for label,node in zip(['a','b','c'],nodes):
 rect=Rect();call('oui_element_get_bounds',node,c.byref(rect));x=rect.x+rect.width/2;y=rect.y+rect.height/2;hit=c.c_void_p();call('oui_document_hit_test',document,c.c_float(x),c.c_float(y),c.byref(hit));observations.append(dict(id=label,bounds={n:getattr(rect,n) for n,_ in Rect._fields_},point=[x,y],inside_viewport=0<=x<320 and 0<=y<200,hit=next((name for name,p in zip(['a','b','c','root'],nodes+[root]) if p.value==hit.value),None)))
for node in nodes+[root]:call('oui_element_destroy',node)
call('oui_document_destroy',document);assert repository_source_identity(ROOT)==source and hashlib.sha256(library.read_bytes()).hexdigest()==libsha
report=dict(schema_version=1,source=source,library_sha256=libsha,compiler_record=records[0],artifact_freshly_compiled=True,workspace_failed=True,qualification=False,observations=observations,all_commands_terminal=True,javascript_executed_by_openui=False)
(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(observations,indent=2))
