import hashlib,json,subprocess,zipfile,io
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');RAW=ROOT/'out/renderer-evidence/native-viewport-scroll-v1';OUT=RAW/'native-focus-behavior-hosted-windows-v2473';STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/OUT.name
assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head=='442d7a64378a5a238e92033db08450f1da5a08a4'
def api(path):return json.loads(subprocess.check_output(['gh','api','repos/zhuowcui/open-ui/'+path],cwd=ROOT))
metadata=api('actions/artifacts/11471913455');assert metadata['name']=='native-c-cpp-window-smokes' and not metadata['expired']
blob=subprocess.check_output(['gh','api','repos/zhuowcui/open-ui/actions/artifacts/11471913455/zip'],cwd=ROOT);(OUT/'artifact.zip').write_bytes(blob)
reports=[]
with zipfile.ZipFile(io.BytesIO(blob)) as zipped:
 for item in zipped.infolist():
  if item.filename.endswith('.json'):
   name=Path(item.filename).name;data=zipped.read(item);(OUT/name).write_bytes(data);report=json.loads(data);reports.append(report)
assert len(reports)==3 and len({r['source_commit'] for r in reports})==1
checkout=reports[0]['source_commit'];commit=api('commits/'+checkout);implementation=api('commits/'+head)
(OUT/'hosted_checkout-commit.json').write_text(json.dumps(commit,sort_keys=True,indent=2)+'\n');(OUT/'implementation-commit.json').write_text(json.dumps(implementation,sort_keys=True,indent=2)+'\n')
local_tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=ROOT,text=True).strip()
assert local_tree==implementation['commit']['tree']['sha']==commit['commit']['tree']['sha']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for report in reports:
 assert report['source_clean'] and report['passed'] and report['header_sha256']==sha(ROOT/'include/openui.h')
 for c in report['consumers']:
  assert c['returncode']==0 and not c['timed_out'] and 'focus=4 blur=3' in c['stdout']
  assert c['source_sha256']==sha(ROOT/c['source'])
assert {(r['protocol'],r['backend']) for r in reports}=={('x11','software'),('x11','opengl'),('wayland','software')}
(OUT/'artifact-metadata.json').write_text(json.dumps(metadata,sort_keys=True,indent=2)+'\n')
result=dict(schema_version=1,implementation_commit=head,hosted_checkout=checkout,git_tree=local_tree,source_trees_verified_identical=True,reports=reports,window_consumers=6,all_window_consumers_passed=True,focus_callbacks_per_consumer=4,blur_callbacks_per_consumer=3,release_qualification=False,all_commands_terminal=True,artifact_sha256=hashlib.sha256(blob).hexdigest(),artifact_id=metadata['id'])
(OUT/'receipt.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['implementation_commit','hosted_checkout','source_trees_verified_identical','window_consumers','all_window_consumers_passed']},indent=2))
