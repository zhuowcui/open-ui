#include <stdio.h>
#include <string.h>
#include "openui.h"
static unsigned events;
static OuiUtf8 text(const char* s) { OuiUtf8 value={(const uint8_t*)s,strlen(s)};return value; }
static void count(OuiEvent* event,void* data) { (void)data; if(event->event_type==OUI_EVENT_FOCUS || event->event_type==OUI_EVENT_BLUR) ++events; }
#define CHECK(call) do { OuiStatus s=(call);if(s!=OUI_OK){fprintf(stderr,"status=%d at line %d\n",s,__LINE__);return 2;} } while(0)
int main(void) {
 OuiDocumentConfig cfg={sizeof(cfg),OUI_ABI_VERSION,{64,64,64,64,1,OUI_VIEWPORT_LOGICAL,0}};
 OuiDocument* doc=NULL;OuiElement *root=NULL,*a=NULL,*b=NULL;OuiListener* listeners[4]={NULL,NULL,NULL,NULL};
 CHECK(oui_document_create(&cfg,&doc));CHECK(oui_document_root(doc,&root));
 CHECK(oui_element_create(doc,OUI_ELEMENT_INPUT,&a));CHECK(oui_element_create(doc,OUI_ELEMENT_INPUT,&b));
 CHECK(oui_element_append_child(root,a));CHECK(oui_element_append_child(root,b));
 CHECK(oui_element_add_event_listener(a,OUI_EVENT_FOCUS,0,count,NULL,&listeners[0]));
 CHECK(oui_element_add_event_listener(a,OUI_EVENT_BLUR,0,count,NULL,&listeners[1]));
 CHECK(oui_element_add_event_listener(b,OUI_EVENT_FOCUS,0,count,NULL,&listeners[2]));
 CHECK(oui_element_add_event_listener(b,OUI_EVENT_BLUR,0,count,NULL,&listeners[3]));
 CHECK(oui_element_focus(a));printf("after_c_focus=%u\n",events);
 CHECK(oui_element_focus(b));printf("after_c_transfer=%u\n",events);
 CHECK(oui_element_blur(b));printf("after_c_blur=%u\n",events);
 OuiEvent key={sizeof(key),OUI_ABI_VERSION,OUI_EVENT_KEY_DOWN,0,0,0,0,0,0,0,0,9,0,{NULL,0},NULL,NULL};
 key.text=text("Tab");OuiUtf8 empty={NULL,0};CHECK(oui_document_dispatch_key_input_v1(doc,&key,empty));
 printf("after_native_tab=%u\n",events);
 for(unsigned i=0;i<4;++i)CHECK(oui_listener_destroy(listeners[i]));
 CHECK(oui_element_destroy(a));CHECK(oui_element_destroy(b));CHECK(oui_element_destroy(root));CHECK(oui_document_destroy(doc));return 0;
}
