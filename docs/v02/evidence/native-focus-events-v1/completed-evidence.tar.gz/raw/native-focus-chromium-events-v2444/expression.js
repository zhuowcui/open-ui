(() => {
 const result=[];
 for(const scenario of ['ordinary','focus-c-during-blur-a','focus-b-during-focus-a','remove-b-during-blur-a']) {
  document.body.innerHTML='<input id="a"><input id="b"><input id="c">';
  const [a,b,c]=['a','b','c'].map(id=>document.getElementById(id));
  const log=[];
  for(const el of [a,b,c]) for(const type of ['focus','blur']) el.addEventListener(type,()=>log.push([el.id,type,document.activeElement.id||'body']));
  if(scenario==='focus-c-during-blur-a') a.addEventListener('blur',()=>c.focus());
  if(scenario==='focus-b-during-focus-a') a.addEventListener('focus',()=>b.focus());
  if(scenario==='remove-b-during-blur-a') a.addEventListener('blur',()=>b.remove());
  a.focus(); if(scenario!=='focus-b-during-focus-a')b.focus();
  if(scenario==='ordinary'){b.focus();b.blur();}
  result.push({scenario,log,final:document.activeElement.id||'body',documentHasFocus:document.hasFocus()});
 }
 return result;
})()