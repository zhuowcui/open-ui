import hashlib,json,os,subprocess,sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');RAW=ROOT/'out/renderer-evidence/native-viewport-scroll-v1';OUT=RAW/'native-c-focus-diagnostic-v2440';STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/OUT.name
assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
parent=json.loads((RAW/'native-c-edit-command-checks-v2429/receipt.json').read_bytes());assert parent['all_commands_terminal'] and parent['library_source_proven'] and parent['observed_exit_code']==0
library=RAW/'native-c-edit-command-checks-v2429/libopenui_ffi.so';assert hashlib.sha256(library.read_bytes()).hexdigest()==parent['library_sha256']
api=json.loads((ROOT/'docs/v02/generated/native-c-editing-commands-v1.json').read_bytes())
for file in ['bindings/rust/openui/src/document.rs','bindings/rust/openui-ffi/src/lib.rs','bindings/rust/openui-ffi/src/editing_command.rs','include/openui.h']:
 assert hashlib.sha256((ROOT/file).read_bytes()).hexdigest()==api['source_snapshot_hashes'][file]
source=OUT/'focus.c';source.write_text('''#include <stdio.h>
#include <string.h>
#include "openui.h"
static unsigned events;
static OuiUtf8 text(const char* s) { OuiUtf8 value={(const uint8_t*)s,strlen(s)};return value; }
static void count(OuiEvent* event,void* data) { (void)data; if(event->event_type==OUI_EVENT_FOCUS || event->event_type==OUI_EVENT_BLUR) ++events; }
#define CHECK(call) do { OuiStatus s=(call);if(s!=OUI_OK){fprintf(stderr,"status=%d at line %d\\n",s,__LINE__);return 2;} } while(0)
int main(void) {
 OuiDocumentConfig cfg={sizeof(cfg),OUI_ABI_VERSION,{64,64,64,64,1,OUI_VIEWPORT_LOGICAL,0}};
 OuiDocument* doc=NULL;OuiElement *root=NULL,*a=NULL,*b=NULL;OuiListener* listeners[4]={NULL,NULL,NULL,NULL};
 CHECK(oui_document_create(&cfg,&doc));CHECK(oui_document_root(doc,&root));
 CHECK(oui_element_create(doc,OUI_ELEMENT_INPUT,&a));CHECK(oui_element_create(doc,OUI_ELEMENT_INPUT,&b));
 CHECK(oui_element_append_child(root,a));CHECK(oui_element_append_child(root,b));
 CHECK(oui_element_add_event_listener(a,OUI_EVENT_FOCUS,0,count,NULL,&listeners[0]));
 CHECK(oui_element_add_event_listener(a,OUI_EVENT_BLUR,0,count,NULL,&listeners[1]));
 CHECK(oui_element_add_event_listener(b,OUI_EVENT_FOCUS,0,count,NULL,&listeners[2]));
 CHECK(oui_element_add_event_listener(b,OUI_EVENT_BLUR,0,count,NULL,&listeners[3]));
 CHECK(oui_element_focus(a));printf("after_c_focus=%u\\n",events);
 CHECK(oui_element_focus(b));printf("after_c_transfer=%u\\n",events);
 CHECK(oui_element_blur(b));printf("after_c_blur=%u\\n",events);
 OuiEvent key={sizeof(key),OUI_ABI_VERSION,OUI_EVENT_KEY_DOWN,0,0,0,0,0,0,0,0,9,0,{NULL,0},NULL,NULL};
 key.text=text("Tab");OuiUtf8 empty={NULL,0};CHECK(oui_document_dispatch_key_input_v1(doc,&key,empty));
 printf("after_native_tab=%u\\n",events);
 for(unsigned i=0;i<4;++i)CHECK(oui_listener_destroy(listeners[i]));
 CHECK(oui_element_destroy(a));CHECK(oui_element_destroy(b));CHECK(oui_element_destroy(root));CHECK(oui_document_destroy(doc));return 0;
}
''')
sys.path.insert(0,str(ROOT/'tools/ffi'));from verify_abi import compilers
cc,cxx,cflags,cxxflags,linkflags=compilers();obj=OUT/'focus.o';binary=OUT/'focus';steps=[]
for name,command in [('compile',[cc,'-std=c11','-Wall','-Wextra','-Werror',*cflags,'-I'+str(ROOT/'include'),str(source),'-c','-o',str(obj)]),('link',[cxx,*cxxflags,*linkflags,'-fuse-ld=lld',str(obj),str(library),'-Wl,-rpath,'+str(library.parent),'-o',str(binary)]),('run',[str(binary)])]:
 result=subprocess.run(command,cwd=ROOT,capture_output=True);(OUT/(name+'.log')).write_bytes(result.stdout+result.stderr);steps.append(dict(name=name,command=command,observed_exit_code=result.returncode,stdout=result.stdout.decode(),stderr=result.stderr.decode()));assert result.returncode==0
observed=steps[-1]['stdout'];assert observed=='after_c_focus=0\nafter_c_transfer=0\nafter_c_blur=0\nafter_native_tab=1\n'
assert hashlib.sha256(library.read_bytes()).hexdigest()==parent['library_sha256']
report=dict(schema_version=1,kind='native_c_focus_callback_gap',main_inspected_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),library_source=parent['source'],library_source_proven=True,library_sha256=parent['library_sha256'],source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),steps=steps,observed=observed,root_cause='C focus/blur call Engine methods directly; public Rust Element focus/blur call Document methods that dispatch focus changes and cancel composition.',owner='native Document and C facade',same_public_rust_path_required=True,release_qualification=False,pixel_images_generated=0,all_commands_terminal=True)
(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(observed=observed,library_source_commit=parent['source']['commit'],library_source_proven=True,all_terminal=True),indent=2))
