import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');RAW=ROOT/'out/renderer-evidence/native-viewport-scroll-v1';OUT=RAW/'native-focus-consumer-v2450';STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/OUT.name
sys.path.insert(0,str(ROOT/'tools/qualification'));from renderer_source_identity import repository_source_identity
source=repository_source_identity(ROOT);assert source['clean']
parent=json.loads((RAW/'native-focus-checks-v2448/receipt.json').read_bytes());assert parent['all_commands_terminal'] and parent['library_source_proven'] and parent['observed_exit_code']==0 and parent['source']==source
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
library=RAW/'native-focus-checks-v2448/libopenui_ffi.so';assert sha(library)==parent['library_sha256']
assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
original=RAW/'native-c-focus-diagnostic-v2440/focus.c';shutil.copy2(original,OUT/'focus.c')
assert sha(original)==sha(OUT/'focus.c')
sys.path.insert(0,str(ROOT/'tools/ffi'));from verify_abi import compilers
cc,cxx,cflags,cxxflags,linkflags=compilers();obj=OUT/'focus.o';binary=OUT/'focus'
report=dict(schema_version=1,source=source,library_sha256=parent['library_sha256'],library_source_proven=True,library_receipt=str(RAW/'native-focus-checks-v2448/receipt.json'),steps=[],all_commands_terminal=False,release_qualification=False,pixel_images_generated=0,javascript_executed_by_openui=False,header_sha256=sha(ROOT/'include/openui.h'),consumer_source_sha256=sha(original),probe_sha256=sha(__file__))
def save():(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
save()
try:
 for name,command in [('compile',[cc,'-std=c11','-Wall','-Wextra','-Werror',*cflags,'-I'+str(ROOT/'include'),str(OUT/'focus.c'),'-c','-o',str(obj)]),('link',[cxx,*cxxflags,*linkflags,'-fuse-ld=lld',str(obj),str(library),'-Wl,-rpath,'+str(library.parent),'-o',str(binary)]),('first',[str(binary)]),('second',[str(binary)])]:
  assert repository_source_identity(ROOT)==source
  result=subprocess.run(command,cwd=ROOT,capture_output=True)
  log=OUT/(name+'.log');log.write_bytes(result.stdout+result.stderr)
  report['steps'].append(dict(name=name,command=command,observed_exit_code=result.returncode,log_sha256=sha(log),stdout=result.stdout.decode(),stderr=result.stderr.decode()));save();assert result.returncode==0
  assert repository_source_identity(ROOT)==source
 expected='after_c_focus=1\nafter_c_transfer=3\nafter_c_blur=4\nafter_native_tab=5\n'
 assert report['steps'][-1]['stdout']==report['steps'][-2]['stdout']==expected
 assert sha(library)==parent['library_sha256']
 report.update(observed=expected,repeated_output_identical=True,binary_sha256=sha(binary),observed_exit_code=0)
except BaseException as error:report.update(observed_exit_code=1,failure=repr(error));raise
finally:
 report.update(all_commands_terminal=True,source_after=repository_source_identity(ROOT));report['source_unchanged_throughout']=report['source_after']==source;save()
print(json.dumps({k:report[k] for k in ['observed','source','library_source_proven','all_commands_terminal']},indent=2))
