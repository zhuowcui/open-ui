import hashlib,json,os,shutil,signal,subprocess,sys,tempfile,time
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');OUT=ROOT/'out/renderer-evidence/native-viewport-scroll-v1/native-focus-chromium-events-v2442';STORE=Path('/mnt/e/openui-v02-qualification-d174ea0b')/OUT.name
assert not OUT.exists() and not STORE.exists();STORE.mkdir();OUT.symlink_to(STORE,target_is_directory=True)
sys.path.insert(0,str(ROOT/'tools/accountability'));import run_all_pixel_comparisons as capture
chrome=ROOT/'chrome/linux-147.0.7727.50/chrome-linux64/chrome';digest=hashlib.sha256(chrome.read_bytes()).hexdigest();assert digest=='0ba87684df0afc11faaea40ac57bd2f1d68b67191443b38215a36b90e6f08848'
expression='''(() => {
 const result=[];
 for(const scenario of ['ordinary','focus-c-during-blur-a','focus-b-during-focus-a','remove-b-during-blur-a']) {
  document.body.innerHTML='<input id="a"><input id="b"><input id="c">';
  const [a,b,c]=['a','b','c'].map(id=>document.getElementById(id));
  const log=[];
  for(const el of [a,b,c]) for(const type of ['focus','blur']) el.addEventListener(type,()=>log.push([el.id,type,document.activeElement.id||'body']));
  if(scenario==='focus-c-during-blur-a') a.addEventListener('blur',()=>c.focus());
  if(scenario==='focus-b-during-focus-a') a.addEventListener('focus',()=>b.focus());
  if(scenario==='remove-b-during-blur-a') a.addEventListener('blur',()=>b.remove());
  a.focus(); if(scenario!=='focus-b-during-focus-a')b.focus();
  if(scenario==='ordinary'){b.focus();b.blur();}
  result.push({scenario,log,final:document.activeElement.id||'body'});
 }
 return result;
})()'''
report=dict(schema_version=1,chromium_binary_sha256=digest,chromium_version='147.0.7727.50',offline_javascript_executed_only_in_chromium=True,javascript_executed_by_openui=False,reference_images_modified=False,pixel_images_generated=0,release_qualification=False,all_commands_terminal=False,observations=[])
(OUT/'expression.js').write_text(expression)
try:
 for repeat in range(2):
  profile=tempfile.mkdtemp(prefix='chrome-focus-',dir=STORE);client=None
  with (OUT/f'chrome-{repeat}.stderr.log').open('xb') as log:
   process=subprocess.Popen([str(chrome),'--headless','--disable-gpu','--disable-dev-shm-usage','--no-sandbox','--no-first-run','--no-default-browser-check','--remote-debugging-port=0','--user-data-dir='+profile,'about:blank'],stdout=subprocess.DEVNULL,stderr=log,start_new_session=True)
   try:
    port=capture._wait_for_devtools_endpoint(profile,process);client=capture._CdpWebSocket(capture._page_websocket_url(port));value=client.command('Runtime.evaluate',dict(expression=expression,returnByValue=True));assert 'exceptionDetails' not in value;report['observations'].append(value['result']['value'])
   finally:
    if client is not None:client.close()
    try:os.killpg(process.pid,signal.SIGTERM)
    except ProcessLookupError:pass
    try:process.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
    shutil.rmtree(profile)
 assert report['observations'][0]==report['observations'][1]
 report['repeated_observations_identical']=True
finally:
 report['all_commands_terminal']=True;(OUT/'receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps(report['observations'][0],indent=2))
