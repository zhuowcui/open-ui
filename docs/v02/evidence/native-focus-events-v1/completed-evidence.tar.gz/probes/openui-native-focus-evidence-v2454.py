import gzip,hashlib,io,json,os,re,shutil,subprocess,tarfile
from pathlib import Path
ROOT=Path('/home/nero/code/open-ui');RAW=ROOT/'out/renderer-evidence/native-viewport-scroll-v1';HEAD='9349e5b3a5cfaa4e7e928cc883552a8cd2c724c1'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==HEAD
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
sha=lambda data:hashlib.sha256(data).hexdigest();load=lambda p:json.loads(p.read_bytes())
failed=load(RAW/'native-focus-checks-v2446/receipt.json');passed=load(RAW/'native-focus-checks-v2448/receipt.json');checks=load(RAW/'native-focus-source-checks-v2449/receipt.json');consumer=load(RAW/'native-focus-consumer-v2450/receipt.json');hosted=load(RAW/'native-focus-hosted-checks-v2452/receipt.json');windows=load(RAW/'native-focus-hosted-windows-v2451/receipt.json');chromium=load(RAW/'native-focus-chromium-events-v2445/receipt.json')
assert failed['all_commands_terminal'] and failed['observed_exit_code']==1
assert passed['all_commands_terminal'] and passed['observed_exit_code']==0 and passed['source_unchanged_throughout'] and passed['library_source_proven']
assert len(passed['steps'])==18 and all(x['observed_exit_code']==0 for x in passed['steps'])
assert passed['workspace_tests']['failed']==0 and passed['workspace_tests']['passed']==8576 and passed['workspace_tests']['ignored']==13
assert checks['all_commands_terminal'] and len(checks['checks'])==17 and all(x['observed_exit_code']==0 for x in checks['checks'])
assert consumer['all_commands_terminal'] and consumer['observed_exit_code']==0 and consumer['source_unchanged_throughout'] and consumer['repeated_output_identical']
assert hosted['all_terminal'] and hosted['successful_jobs']==6 and hosted['skipped_jobs']==5
assert windows['source_trees_verified_identical'] and windows['all_window_consumers_passed'] and windows['window_consumers']==6
assert chromium['all_commands_terminal'] and chromium['repeated_observations_identical'] and len(chromium['observations'][0])==6
headless=(RAW/'native-focus-checks-v2448/headless-c-abi-tests.log').read_bytes();assert b'41 passed; 0 failed; 0 ignored' in headless
for name in ['openui-ffi-layout.json','openui-ffi-symbols.txt','openui-ffi-checksum.txt']:
 before=subprocess.check_output(['git','show','ef4d0195:docs/v02/generated/'+name],cwd=ROOT)
 assert before==(ROOT/'docs/v02/generated'/name).read_bytes()
assert len((ROOT/'docs/v02/generated/openui-ffi-symbols.txt').read_text().splitlines())==114
members={}
for name in ['native-c-focus-diagnostic-v2440','native-focus-chromium-events-v2442','native-focus-chromium-events-v2443','native-focus-chromium-events-v2444','native-focus-chromium-events-v2445','native-focus-checks-v2446','native-focus-source-checks-v2447','native-focus-checks-v2448','native-focus-source-checks-v2449','native-focus-consumer-v2450','native-focus-hosted-windows-v2451','native-focus-hosted-checks-v2452']:
 for p in sorted((RAW/name).iterdir()):
  if p.is_file() and not p.is_symlink() and p.suffix in ['.json','.log','.c','.js']:
   members['raw/'+name+'/'+p.name]=p.read_bytes()
for name in ['openui-native-c-focus-diagnostic-v2440.py','openui-native-focus-chromium-events-v2442.py','openui-native-focus-chromium-events-v2443.py','openui-native-focus-chromium-events-v2444.py','openui-native-focus-chromium-events-v2445.py','openui-native-focus-checks-v2446.py','openui-native-focus-source-checks-v2447.py','openui-native-focus-checks-v2448.py','openui-native-focus-source-checks-v2449.py','openui-native-focus-consumer-v2450.py','openui-native-focus-hosted-windows-v2451.py','openui-native-focus-hosted-checks-v2452.py','openui-native-focus-evidence-v2454.py']:
 p=Path('/tmp')/name;assert p.is_file();members['probes/'+name]=p.read_bytes()
for name in ['bindings/rust/openui-engine/src/interaction.rs','bindings/rust/openui/src/document.rs','bindings/rust/openui/tests/native_focus.rs','bindings/rust/openui-ffi/src/lib.rs','bindings/rust/openui-ffi/src/focus_tests.rs','bindings/rust/openui-ffi/src/native_app.rs','bindings/rust/Cargo.lock','include/openui.h','tools/ffi/verify_abi.py','tools/ffi/verify_native_window.py','examples/c_v02/native/window.c','examples/c_v02/native/window.cc','docs/v02/generated/openui-ffi-layout.json','docs/v02/generated/openui-ffi-symbols.txt','docs/v02/generated/openui-ffi-checksum.txt']:
 members['source/'+name]=(ROOT/name).read_bytes()
prechecks=dict(chromium_v2442=dict(admitted=False,reason='Chromium could not load libnspr4.so without its pinned capture environment; no event observations were admitted.'),chromium_v2443=dict(admitted=False,reason='The page was not focused and delivered no focus/blur events.'),chromium_v2444=dict(admitted=False,reason='The result retained mutable log arrays; later document replacement contaminated earlier logs.'),chromium_v2445=dict(admitted=True,reason='Page focus is enabled and event log rows are copied before later document mutation; two runs agree.'),initial_workspace=dict(admitted=False,reason='New test stored the u32 C event discriminator as i32; compilation exited 101. The corrected checkpoint changes that test field only.'))
members['prechecks.json']=(json.dumps(prechecks,sort_keys=True,indent=2)+'\n').encode()
dest=ROOT/'docs/v02/evidence/native-focus-events-v1';assert not dest.exists();dest.mkdir(parents=True);archive=dest/'completed-evidence.tar.gz'
with archive.open('xb') as stream:
 with gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for name,data in sorted(members.items()):
    item=tarfile.TarInfo(name);item.size=len(data);item.mtime=0;item.mode=0o644;item.uid=item.gid=0;tar.addfile(item,io.BytesIO(data))
with tarfile.open(archive) as tar:
 actual={item.name:tar.extractfile(item).read() for item in tar if item.isfile()}
assert actual.keys()==members.keys() and all(sha(actual[name])==sha(data) for name,data in members.items())
index=dict(schema_version=1,archive_sha256=sha(archive.read_bytes()),members=[dict(name=name,bytes=len(data),sha256=sha(data)) for name,data in sorted(members.items())]);(dest/'archive-members.json').write_text(json.dumps(index,sort_keys=True,indent=2)+'\n')
report=dict(schema_version=1,kind='native_focus_callback_and_composition_correction',implementation_commit=HEAD,initial_implementation_commit='dd3e858cd80ced3a80df8536bb61e20b8330bc2e',javascript_executed_by_openui=False,shared_rust_document_engine_and_event_path=True,rust_public_api=['Element::focus','Element::blur','Document::advance_focus','Element::perform_accessibility_action'],c_public_api=['oui_element_focus','oui_element_blur','oui_element_perform_accessibility_action'],abi=dict(exports=114,symbols_unchanged=True,all_struct_layouts_unchanged=True,checksum_unchanged=True),clean_checks=passed,readonly_checks=checks,failed_initial_checks=failed,headless_c_abi_tests=dict(passed=41,failed=0,ignored=0),all_c_cpp_consumers=dict(c=14,cpp=8,actual_exit=0),original_gap=load(RAW/'native-c-focus-diagnostic-v2440/receipt.json'),corrected_c_consumer=consumer,chromium_event_reference=chromium,hosted_jobs=hosted,hosted_windows=windows,prechecks=prechecks,evidence_archive=dict(path=str(archive.relative_to(ROOT)),sha256=index['archive_sha256'],bytes=archive.stat().st_size,members=len(members),all_member_hashes_verified=True),source_snapshot_hashes={name.removeprefix('source/'):sha(data) for name,data in members.items() if name.startswith('source/')},all_local_owners_terminal=True,release_qualification=False,renderer_matrices_not_run=True,renderer_changes_promoted=False,expected_pixels='Pinned Chromium only',references_changed=False,pixel_tolerance=0,new_pixel_comparisons_admitted=0,remaining_focus_owner='native Document and Engine interaction',remaining_focus_behavior=['Programmatic negative-tabindex focus','Modal focus event delivery','Focus event propagation','Other consuming application focus contexts'],remaining_gates=['Full exact Chromium pixel matrices','Remaining needed native APIs','Compositor and release-lab qualification','Release performance, packaging, provenance and publication'])
(ROOT/'docs/v02/generated/native-focus-events-v1.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
doc=Path('/tmp/openui-native-focus-doc-v2454.md').read_text();marker='Five Rust application tests';assert marker in doc
verified='''The clean locked Linux workspace passes **8,576 tests**, with zero failures
and 13 ignored tests. The headless C facade passes **41/41 tests**. All 18 local
stages and 17 read-only checks pass. All local Rust artifacts and the copied C
library are bound to the clean implementation checkout; the source stays
unchanged through the full pipeline. Fourteen C and eight C++ ABI consumers
compile and run; all 114 exports and existing layouts stay unchanged.

Six active hosted jobs pass; five optional hardening jobs are skipped, not
qualified. All six C/C++ window consumers pass on X11 software, X11 Mesa
presentation and pure Wayland software. The hosted reports retain synthetic
merge `bfec80f7`, whose Git tree is verified identical to `9349e5b3`.

'''
(ROOT/'docs/v02/native-focus-events.md').write_text(doc.replace(marker,verified+marker))
p=ROOT/'docs/v02/supported-platforms.md';temp=p.with_name(p.name+'.focus-detach-v2454');shutil.copy2(p,temp);os.replace(temp,p);s=p.read_text();marker='The [native editing consumer]';assert s.count(marker)==1
s=s.replace(marker,'''The [native focus callback correction](native-focus-events.md) routes Rust,
C, keyboard and accessibility focus/blur through the retained Document. It
verifies callback order, composition cancellation and callback mutation from
native applications. Remaining focus semantics and complete API qualification
are still open.

'''+marker);p.write_text(s)
print(json.dumps(dict(implementation_commit=HEAD,workspace_tests=passed['workspace_tests'],local_stages=18,exports=114,archive_members=len(members),archive_sha256=index['archive_sha256'],archive_bytes=archive.stat().st_size),indent=2))
